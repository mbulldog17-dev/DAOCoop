DAOCoop - 3-player co-op for Dragon Age: Origins
=================================================

Play one Dragon Age: Origins campaign with up to three people. Player 1 is the Warden; Players 2
and 3 make their own characters in the character creator and play them on a controller, alongside
the Warden and the AI companions. Couch co-op on one PC, with experimental online play.

Back up your saves before your first session (Documents\BioWare\Dragon Age\Characters). The mod
also makes its own backups while you play co-op.


WHAT YOU NEED
-------------
- Dragon Age: Origins (Ultimate Edition or base game), patch 1.05. Tested on GOG.
  Steam and EA app should work but are not fully tested. They can't get the 4GB patch
  (copy protection), so the game may run out of memory and crash, most often after character
  creation.
- Windows 10 or 11.
- One XInput controller (Xbox or compatible) for each of Players 2 and 3.
  Player 1 can use keyboard and mouse or a controller.
- Recommended: "Dragon Age - Native Controller Framework" (nexusmods.com/dragonage/mods/7051).
  It lets Players 2 and 3 use the menus (inventory, level-up, loot, shops) with their controller,
  and lets Player 1 play on a controller. Install it before this mod.


INSTALL (about a minute)
------------------------
1. Close the game.
2. Right-click the zip > Properties > tick "Unblock" (if it is there) > OK.
3. Right-click the zip > Extract All > Extract. (Running it from inside the zip does not work.)
4. In the unzipped folder, double-click INSTALL.cmd.
   - "Windows protected your PC": More info > Run anyway.
   - It finds the game by itself. If it can't, pick the game folder (the one with bin_ship in it).
   - Windows asks for permission, because the game is usually under Program Files.
   - If another mod already uses dinput8.dll (for example a controller mod), it keeps working:
     it is kept as dinput8_chain.dll and loaded through DAOCoop.
   - On the GOG version it offers the 4GB patch for DAOrigins.exe (fewer crashes on modern PCs).
     The original is saved and UNINSTALL.cmd can put it back.
5. Start the game as usual.
Updating: install a newer version the same way. Your settings are kept.


STARTING A CO-OP GAME
---------------------
1. Main menu > Co-op (under New Game) > Local Co-op (or Online Multiplayer).
2. Choose New Game or Load Game.
3. Lobby: Players 2 and 3 press START on their controller to join, then A when ready.
   Player 1 readies with A on a controller or E on the keyboard.
4. New game: Player 1 makes the Warden. When the origin story begins, the character creator opens
   for Player 2, then Player 3. They use the Warden's difficulty.
Players 2/3 can also join later with START; they're offered the creator wherever the party is.


CONTROLS FOR PLAYERS 2 AND 3
----------------------------
Left stick ............ move (same movement as Player 1)
A ..................... attack your target / open doors and chests, loot
D-pad up .............. use the nearest object
RB .................... next enemy
D-pad left / right .... pick the friend your heals and buffs go to
X / Y / B ............. abilities (hold RT or LT for two more pages)
Hold LB 1.5 s ......... teleport to the Warden
Start ................. level up
View .................. your inventory   (View + Y: character, View + B: journal)
View + Start .......... pause for everyone
Hold View 2 s ......... step away (the AI plays your character; View or Start to come back)
RS in a menu or talk .. pass it to the next player (Player 1: RS or F3)
View + A .............. show the controls again
Your skills are shown next to your portrait. In combat a ring in your colour marks your character
(blue = Player 2, green = Player 3).


SETTINGS
--------
<game folder>\DAOCoop\DAOCoop.ini - every setting is explained in the file. Common ones:
- [Controllers]  which controller is Player 2 / Player 3
- [Camera]       shared-screen wall, combat zoom-out
- [Difficulty]   enemy toughness per extra player
- [Markers]      player rings, name tags, target markers


IF SOMETHING GOES WRONG
-----------------------
- Crashes in the character creator or while loading: turn off Discord's in-game overlay for the
  game (Discord > User Settings > Game Overlay). It crashes this game with or without the mod.
- The game doesn't start after installing: run UNINSTALL.cmd (say yes to putting back the original
  DAOrigins.exe) and check the game is up to date.
- A co-op character is missing after loading a save: that player holds LS (left stick click) for
  2 seconds to restore the newest backup that has the character.
- Asking for help: set Verbose=1 under [Debug] in DAOCoop.ini, play until it happens, and send
  <game folder>\DAOCoop\DAOCoop.log.
- Antivirus warnings: mods that load into a game this way are sometimes flagged.


UNINSTALL
---------
Double-click UNINSTALL.cmd. It removes the mod, puts back anything it replaced, and asks before
deleting the DAOCoop folder (settings, logs, backups).


Third-party notices: LICENSES.txt.
Fan-made. Not made, endorsed or supported by BioWare or Electronic Arts.
