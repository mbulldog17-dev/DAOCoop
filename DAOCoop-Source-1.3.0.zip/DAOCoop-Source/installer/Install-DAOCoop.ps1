# Installs the DAOCoop co-op mod for Dragon Age: Origins from this install package.
# Start it with INSTALL.cmd (UNINSTALL.cmd takes the mod out again). Close the game first.
#   -GamePath "<game folder>"   skip the search (the folder with bin_ship in it; a folder above works too)
#   -Uninstall                  put the game back the way it was
#   -Yes                        take the default answer to every question
#   -ListGames                  only print every game folder found (path|kind), one per line
# The game is looked for in: the folder this package is in (and up to 3 folders above it), Steam
# (its record of the install and every library), BioWare's registry entry, the usual game folders
# on every drive; else the player picks it.
param(
    [string]$GamePath = "",
    [switch]$Uninstall,
    [switch]$Yes,
    [switch]$PauseAtEnd,
    [switch]$ListGames
)
$ErrorActionPreference = "Stop"
$pkg = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $pkg "files"
$exeRel = "bin_ship\DAOrigins.exe"
$steamAppIds = @("47810", "17450")   # Ultimate Edition, original Dragon Age: Origins
$folderPattern = "*Dragon Age*"

function Ask([string]$question, [bool]$default) {
    if ($Yes) { return $default }
    $hint = "[y/N]"
    if ($default) { $hint = "[Y/n]" }
    while ($true) {
        $a = Read-Host "$question $hint"
        if ([string]::IsNullOrWhiteSpace($a)) { return $default }
        if ($a -match '^\s*(y|yes)\s*$') { return $true }
        if ($a -match '^\s*(n|no)\s*$') { return $false }
    }
}

function Test-GameFolder([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    try { return (Test-Path -LiteralPath (Join-Path $p $exeRel) -PathType Leaf) } catch { return $false }
}

# The package put into the game folder: this script's folder, or a folder above it.
function Find-NearPackage {
    $d = $pkg
    for ($i = 0; $i -lt 4; $i++) {
        if ([string]::IsNullOrEmpty($d)) { break }
        if (Test-GameFolder $d) { return $d }
        $d = Split-Path -Parent $d
    }
    return $null
}

function Get-SteamRoots {
    $roots = @()
    foreach ($key in @("HKCU:\Software\Valve\Steam", "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam", "HKLM:\SOFTWARE\Valve\Steam")) {
        try {
            $item = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($n in @("SteamPath", "InstallPath")) {
                $v = $item.$n
                if ($v) { $roots += ($v -replace '/', '\') }
            }
        } catch { }
    }
    if (${env:ProgramFiles(x86)}) { $roots += (Join-Path ${env:ProgramFiles(x86)} "Steam") }
    if ($env:ProgramFiles) { $roots += (Join-Path $env:ProgramFiles "Steam") }
    $out = @()
    foreach ($r in $roots) { if ($r -and (Test-Path -LiteralPath $r) -and ($out -notcontains $r)) { $out += $r } }
    return $out
}

function Get-GameCandidates {
    $c = @()
    # Steam's uninstall record of the game
    foreach ($id in $steamAppIds) {
        foreach ($k in @("HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App $id",
                         "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App $id")) {
            try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).InstallLocation; if ($v) { $c += $v } } catch { }
        }
    }
    # BioWare's own entry (EA app / Origin / disc installs)
    foreach ($k in @("HKLM:\SOFTWARE\WOW6432Node\BioWare\Dragon Age", "HKLM:\SOFTWARE\BioWare\Dragon Age")) {
        try {
            $item = Get-ItemProperty -Path $k -ErrorAction Stop
            foreach ($n in @("Path", "Install Dir", "InstallDir")) { $v = $item.$n; if ($v) { $c += $v } }
        } catch { }
    }
    # GOG Galaxy / GOG installer entries
    foreach ($root in @("HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games", "HKLM:\SOFTWARE\GOG.com\Games")) {
        try {
            foreach ($k in Get-ChildItem -Path $root -ErrorAction Stop) {
                $item = Get-ItemProperty -Path $k.PSPath -ErrorAction SilentlyContinue
                if ($item -and $item.gameName -like "*Dragon Age*" -and $item.path) { $c += $item.path }
            }
        } catch { }
    }
    # every Steam library, with the folder name from the game's appmanifest
    foreach ($root in Get-SteamRoots) {
        $libs = @($root)
        $vdf = Join-Path $root "steamapps\libraryfolders.vdf"
        if (Test-Path -LiteralPath $vdf) {
            try {
                $text = Get-Content -LiteralPath $vdf -Raw
                foreach ($m in [regex]::Matches($text, '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            } catch { }
        }
        foreach ($lib in $libs) {
            $apps = Join-Path $lib "steamapps"
            foreach ($id in $steamAppIds) {
                $acf = Join-Path $apps "appmanifest_$id.acf"
                if (Test-Path -LiteralPath $acf) {
                    try {
                        $m = [regex]::Match((Get-Content -LiteralPath $acf -Raw), '"installdir"\s+"([^"]+)"')
                        if ($m.Success) { $c += (Join-Path $apps ("common\" + $m.Groups[1].Value)) }
                    } catch { }
                }
            }
            $c += (Join-Path $apps "common\Dragon Age Ultimate Edition")
        }
    }
    # the usual game folders on every drive
    $parents = @("SteamLibrary\steamapps\common", "Steam\steamapps\common", "Steam Library\steamapps\common",
                 "SteamGames\steamapps\common", "Games\Steam\steamapps\common", "Games\SteamLibrary\steamapps\common",
                 "Program Files (x86)\Steam\steamapps\common", "Program Files\Steam\steamapps\common",
                 "Program Files (x86)\Origin Games", "Program Files\EA Games", "Program Files (x86)\EA Games",
                 "Program Files\Electronic Arts", "Program Files (x86)\Dragon Age", "GOG Games", "GOG Galaxy\Games",
                 "Program Files (x86)\GOG Galaxy\Games", "Games", "")
    $drives = @()
    try {
        $drives = @([IO.DriveInfo]::GetDrives() | Where-Object { ($_.DriveType -eq 'Fixed' -or $_.DriveType -eq 'Removable') -and $_.IsReady } |
                    ForEach-Object { $_.RootDirectory.FullName })
    } catch { }
    foreach ($dr in $drives) {
        foreach ($par in $parents) {
            $pp = $dr
            if ($par) { $pp = Join-Path $dr $par }
            if (-not (Test-Path -LiteralPath $pp -PathType Container)) { continue }
            if (Test-GameFolder $pp) { $c += $pp }
            foreach ($d in @(Get-ChildItem -LiteralPath $pp -Directory -Filter $folderPattern -ErrorAction SilentlyContinue)) { $c += $d.FullName }
        }
    }
    return $c
}

# Every install found, each once (a PC can have both the Steam and the GOG version).
function Find-AllGameFolders {
    $seen = @{}
    $out = @()
    foreach ($c in Get-GameCandidates) {
        if (-not $c) { continue }
        if (-not (Test-GameFolder $c)) { continue }
        $full = (Get-Item -LiteralPath $c).FullName.TrimEnd('\', '/')
        $key = $full.ToLower()
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        $out += $full
    }
    return $out
}

function Get-GameKind([string]$game) {
    $exe = Join-Path $game $exeRel
    try { if (Test-SteamDrm $exe) { return "Steam" } } catch { }
    if ($game -match '(?i)gog') { return "GOG" }
    return "no copy protection (GOG or other)"
}

function Find-GameFolder {
    $seen = @{}
    foreach ($c in Get-GameCandidates) {
        if (-not $c) { continue }
        $key = $c.TrimEnd('\').ToLower()
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        if (Test-GameFolder $c) { return $c }
    }
    return $null
}

# DAOrigins.exe in the folders below $dir (a few levels down; Windows' own folders skipped)
function Find-GameBelow([string]$dir, [int]$depth) {
    $subs = @()
    try {
        $subs = @(Get-ChildItem -LiteralPath $dir -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -notmatch '^(\$.*|Windows|WinSxS|System Volume Information|ProgramData|AppData|Recovery|PerfLogs|node_modules|\..*)$' })
    } catch { }
    foreach ($d in $subs) { if (Test-GameFolder $d.FullName) { return $d.FullName } }
    if ($depth -gt 1) {
        $likely = '(?i)dragon|steam|game|common|librar|origin|ea |gog|bioware'
        $ordered = @($subs | Where-Object { $_.Name -match $likely }) + @($subs | Where-Object { $_.Name -notmatch $likely })
        foreach ($d in $ordered) {
            $r = Find-GameBelow $d.FullName ($depth - 1)
            if ($r) { return $r }
        }
    }
    return $null
}

# A folder the player gave: the game folder, bin_ship, DAOrigins.exe itself, or a folder above the game.
function Resolve-GameFolder([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    $p = ($p.Trim() -replace '^["'']+|["'']+$', '').Trim()
    if ($p -match '(?i)\.exe$') { $p = Split-Path -Parent $p }
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    try { if (-not (Test-Path -LiteralPath $p -PathType Container)) { return $null } } catch { return $null }
    if ((Split-Path -Leaf $p) -ieq "bin_ship") { $p = Split-Path -Parent $p }
    if (Test-GameFolder $p) { return $p }
    foreach ($sub in @("steamapps\common\Dragon Age Ultimate Edition", "common\Dragon Age Ultimate Edition", "Dragon Age Ultimate Edition", "Dragon Age")) {
        $c = Join-Path $p $sub
        if (Test-GameFolder $c) { return $c }
    }
    Write-Host "Looking for DAOrigins.exe inside $p ..."
    return (Find-GameBelow $p 4)
}

function Pick-GameFolder {
    if ($Yes) { return $null }
    $picked = $null
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $owner = New-Object System.Windows.Forms.Form
        $owner.TopMost = $true
        $owner.ShowInTaskbar = $false
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = "Select the Dragon Age: Origins folder (the one with bin_ship in it). A Steam library or a drive with the game somewhere in it works too."
        $dlg.ShowNewFolderButton = $false
        Write-Host "Pick the game folder in the window that opened (if you do not see it, it is behind this one)."
        if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $picked = $dlg.SelectedPath }
        $owner.Dispose()
    } catch { }
    if ($picked) { return $picked }
    Write-Host "Or type / paste the game folder here (dragging DAOrigins.exe into this window works too)."
    return (Read-Host "Game folder (Enter to stop)")
}

function Read-Pairs([string]$file) {
    $m = @{}
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) {
            if ($line -match '^\s*([A-Za-z0-9_]+)\s*=\s*(.*)$') { $m[$Matches[1]] = $Matches[2].Trim() }
        }
    }
    return $m
}

function Md5([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm MD5).Hash.ToLower() }

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-Writable([string]$dir) {
    try {
        $t = Join-Path $dir (".daocoop-write-test-" + [guid]::NewGuid().ToString("N"))
        [IO.File]::WriteAllText($t, "x")
        Remove-Item -LiteralPath $t -Force
        return $true
    } catch { return $false }
}

# The 4GB patch: the "large address aware" flag in the exe's header. Without it this 32-bit game
# can only use 2GB of memory and crashes on modern PCs when it runs out.
# Returns $true / $false, or $null when the file is not a 32-bit Windows program.
function Get-LaaOffset([byte[]]$bytes) {
    if ($bytes.Length -lt 0x40 -or $bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) { return $null }
    $pe = [BitConverter]::ToInt32($bytes, 0x3C)
    if ($pe -lt 0 -or $pe + 24 -gt $bytes.Length) { return $null }
    if ([BitConverter]::ToUInt32($bytes, $pe) -ne 0x00004550) { return $null }   # "PE\0\0"
    if ([BitConverter]::ToUInt16($bytes, $pe + 4) -ne 0x14C) { return $null }    # x86
    return ($pe + 22)                                                             # Characteristics
}
function Test-LargeAddressAware([string]$exe) {
    $bytes = [IO.File]::ReadAllBytes($exe)
    $o = Get-LaaOffset $bytes
    if ($null -eq $o) { return $null }
    return (([BitConverter]::ToUInt16($bytes, $o) -band 0x20) -ne 0)
}
function Set-LargeAddressAware([string]$exe) {
    $bytes = [IO.File]::ReadAllBytes($exe)
    $o = Get-LaaOffset $bytes
    if ($null -eq $o) { throw "$exe is not a 32-bit Windows program - not patched." }
    $bytes[$o] = $bytes[$o] -bor 0x20
    [IO.File]::WriteAllBytes($exe, $bytes)
}

# The Steam version of DAOrigins.exe is wrapped in Steam's copy protection (a ".bind" section). It refuses
# to start once the exe is changed in any way ("Application load error 3:0000065432"), so the 4GB patch
# can't be used there. The GOG version has no wrapper and can be patched.
function Test-SteamDrm([string]$exe) {
    $bytes = [IO.File]::ReadAllBytes($exe)
    $o = Get-LaaOffset $bytes
    if ($null -eq $o) { return $false }
    $pe = $o - 22
    $count = [BitConverter]::ToUInt16($bytes, $pe + 6)
    $first = $pe + 24 + [BitConverter]::ToUInt16($bytes, $pe + 20)
    for ($i = 0; $i -lt $count; $i++) {
        $at = $first + 40 * $i
        if ($at + 8 -gt $bytes.Length) { break }
        $name = [Text.Encoding]::ASCII.GetString($bytes, $at, 8).TrimEnd([char]0)
        if ($name -eq ".bind") { return $true }
    }
    return $false
}

# True when a DLL is a DAOCoop build (its log text is inside it), even without an install record.
function Test-DAOCoopDll([string]$file) {
    try {
        $text = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($file))
        return $text.Contains("loaded into DAOrigins.exe") -and $text.Contains("DAOCoop")
    } catch { return $false }
}

# The game is usually under Program Files, which needs administrator rights to change.
# Run this script again as administrator (Windows asks) and pass on the answer.
function Restart-Elevated([string]$game) {
    $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-GamePath", "`"$game`"", "-PauseAtEnd")
    if ($Uninstall) { $argList += "-Uninstall" }
    if ($Yes) { $argList += "-Yes" }
    Write-Host "`nWindows needs your permission to change files in the game folder. Answer Yes in the window that opens."
    try {
        $p = Start-Process -FilePath "powershell.exe" -ArgumentList ($argList -join " ") -Verb RunAs -Wait -PassThru
        exit $p.ExitCode
    } catch {
        throw "Windows' permission was not given - nothing was changed. You can also right-click INSTALL.cmd and choose 'Run as administrator'."
    }
}

function Find-Game {
    if ($GamePath) {
        $game = Resolve-GameFolder $GamePath
        if (-not $game) { throw "DAOrigins.exe was not found in (or under): $GamePath" }
        return (Get-Item -LiteralPath $game).FullName.TrimEnd('\', '/')
    }
    $game = Find-NearPackage
    if ($game) {
        Write-Host "`nUsing the game folder this package is in: $game"
    } else {
        Write-Host "`nLooking for the game..."
        $all = @(Find-AllGameFolders)
        $game = $null
        if ($all.Count -gt 1) {
            # never guess here (not even with -Yes): the wrong copy is easy to miss
            Write-Host "Found more than one copy of the game:"
            for ($i = 0; $i -lt $all.Count; $i++) { Write-Host ("  {0}. {1}  ({2})" -f ($i + 1), $all[$i], (Get-GameKind $all[$i])) }
            while (-not $game) {
                $a = Read-Host "Which one? (1-$($all.Count), Enter to pick another folder)"
                if ([string]::IsNullOrWhiteSpace($a)) { break }
                $n = 0
                if ([int]::TryParse($a.Trim(), [ref]$n) -and $n -ge 1 -and $n -le $all.Count) { $game = $all[$n - 1] }
            }
        } elseif ($all.Count -eq 1) {
            $game = $all[0]
        }
        if ($game -and $all.Count -le 1) {
            Write-Host "Found the game here: $game"
            $verb = "Install the mod into this folder?"
            if ($Uninstall) { $verb = "Take the mod out of this folder?" }
            if (-not (Ask $verb $true)) { $game = $null }
        } elseif ($all.Count -eq 0) {
            Write-Host "Could not find the game folder by itself." -ForegroundColor Yellow
            Write-Host "Steam shows it: right-click Dragon Age: Origins in your library > Manage > Browse local files."
            Write-Host "You can also put this unzipped folder into the game folder and run INSTALL.cmd there."
        }
    }
    while (-not $game) {
        $p = Pick-GameFolder
        if ([string]::IsNullOrWhiteSpace($p)) { throw "No game folder chosen - nothing was changed." }
        $game = Resolve-GameFolder $p
        if (-not $game) { Write-Host "DAOrigins.exe is not in (or under): $p" -ForegroundColor Yellow }
    }
    return (Get-Item -LiteralPath $game).FullName.TrimEnd('\', '/')
}

function Do-Uninstall([string]$game) {
    $bin = Join-Path $game "bin_ship"
    $modFolder = Join-Path $game "DAOCoop"
    $recordFile = Join-Path $modFolder "install-record.txt"
    $rec = Read-Pairs $recordFile
    # installs before 0.1.2 used version.dll; newer ones use dinput8.dll
    $dllName = $rec["DllName"]
    if (-not $dllName) { $dllName = "version.dll" }
    $dll = Join-Path $bin $dllName
    if (Test-Path -LiteralPath $dll) {
        $ours = ($rec["DllMd5"] -and (Md5 $dll) -eq $rec["DllMd5"]) -or (Test-Path -LiteralPath $recordFile)
        if (-not $ours -and -not (Ask "bin_ship\$dllName does not look like this mod's. Remove it anyway?" $false)) {
            throw "Stopped - nothing was changed."
        }
        Remove-Item -LiteralPath $dll -Force
        Write-Host "Removed the mod (bin_ship\$dllName)." -ForegroundColor Green
    } else {
        Write-Host "The mod's $dllName is not in bin_ship."
    }
    # another mod's dinput8.dll that DAOCoop passed calls on to: give it its name back
    $chain = Join-Path $bin "dinput8_chain.dll"
    if ($rec["ChainedDll"] -eq "1" -and (Test-Path -LiteralPath $chain) -and -not (Test-Path -LiteralPath (Join-Path $bin "dinput8.dll"))) {
        Move-Item -LiteralPath $chain -Destination (Join-Path $bin "dinput8.dll")
        Write-Host "Put back the other mod's dinput8.dll (it was kept as dinput8_chain.dll)." -ForegroundColor Green
    }
    # an older install (version.dll) may have replaced another mod's version.dll
    if ($rec["OriginalDll"]) {
        $original = Join-Path $modFolder ("backups\" + $rec["OriginalDll"])
        if (Test-Path -LiteralPath $original) {
            Copy-Item -LiteralPath $original -Destination (Join-Path $bin "version.dll") -Force
            Write-Host "Put back the version.dll that was there before the mod." -ForegroundColor Green
        }
    }
    # the 4GB patch on DAOrigins.exe, if this installer made it
    if ($rec["LaaPatched"] -eq "1") {
        $exe = Join-Path $game $exeRel
        $exeBackup = Join-Path $modFolder "backups\DAOrigins.before-4gb-patch.exe"
        if ((Test-Path -LiteralPath $exeBackup) -and (Test-Path -LiteralPath $exe)) {
            if ((Md5 $exe) -ne $rec["ExePatchedMd5"]) {
                Write-Host "DAOrigins.exe changed since the 4GB patch (a game update?), so it is left as it is."
            } else {
                Write-Host "`nThe installer gave DAOrigins.exe the 4GB patch. It helps the game even without the mod,"
                Write-Host "but undo it if the game stopped starting after installing."
                if (Ask "Put back the original DAOrigins.exe (without the 4GB patch)?" $true) {
                    Copy-Item -LiteralPath $exeBackup -Destination $exe -Force
                    Write-Host "Put back the original DAOrigins.exe." -ForegroundColor Green
                }
            }
        }
    }
    # the HUD movie in the game's override folder
    if ($rec["OverrideFile"]) {
        $removed = 0; $ovDir = ""
        foreach ($rel in ($rec["OverrideFile"] -split ";")) {
            if (-not $rel) { continue }
            $ov = Join-Path $game $rel
            if (Test-Path -LiteralPath $ov) { Remove-Item -LiteralPath $ov -Force; $removed++; $ovDir = Split-Path $ov }
        }
        if ($ovDir -and (Test-Path -LiteralPath $ovDir) -and -not (Get-ChildItem -LiteralPath $ovDir -Force)) { Remove-Item -LiteralPath $ovDir -Force }
        if ($removed) { Write-Host "Removed the mod's game files ($removed in packages\core\override\DAOCoop)." -ForegroundColor Green }
    }
    if (Test-Path -LiteralPath $modFolder) {
        Write-Host "`nThe DAOCoop folder holds the mod's settings, logs and backups."
        if (Ask "Delete it too?" $false) {
            Remove-Item -LiteralPath $modFolder -Recurse -Force
            Write-Host "Deleted the DAOCoop folder." -ForegroundColor Green
        } elseif (Test-Path -LiteralPath $recordFile) {
            Remove-Item -LiteralPath $recordFile -Force
        }
    }
    Write-Host "`nDone. The game starts without the mod now." -ForegroundColor Green
}

function Merge-Ini([string]$from, [string]$into) {
    # Adds settings (and sections) that exist in $from but not yet in $into; never changes a value.
    $have = @{}; $sec = ""
    foreach ($l in (Get-Content -LiteralPath $into)) {
        if ($l -match '^\s*\[(.+)\]\s*$') { $sec = $matches[1].ToLower(); $have["[$sec]"] = 1 }
        elseif ($l -match '^\s*([^;=\s][^=]*?)\s*=') { $have["$sec|" + $matches[1].ToLower()] = 1 }
    }
    $added = [ordered]@{}; $sec = ""; $pendingComments = @()
    foreach ($l in (Get-Content -LiteralPath $from)) {
        if ($l -match '^\s*\[(.+)\]\s*$') { $sec = $matches[1]; $pendingComments = @(); continue }
        if ($l -match '^\s*;') { $pendingComments += $l; continue }
        if ($l -match '^\s*([^;=\s][^=]*?)\s*=') {
            $key = "$($sec.ToLower())|" + $matches[1].ToLower()
            if (-not $have.ContainsKey($key)) {
                if (-not $added.Contains($sec)) { $added[$sec] = New-Object System.Collections.ArrayList }
                foreach ($c in $pendingComments) { [void]$added[$sec].Add($c) }
                [void]$added[$sec].Add($l)
            }
            $pendingComments = @()
        } elseif ($l.Trim() -eq "") { $pendingComments = @() }
    }
    if ($added.Count -eq 0) { return 0 }
    $text = [System.IO.File]::ReadAllText($into)
    foreach ($sec in $added.Keys) {
        $block = ($added[$sec] -join "`r`n")
        if ($have.ContainsKey("[" + $sec.ToLower() + "]")) {
            # put the new keys right under the existing section header
            $rx = New-Object System.Text.RegularExpressions.Regex ("(?im)^\s*\[" + [regex]::Escape($sec) + "\]\s*\r?\n")
            $text = $rx.Replace($text, { param($m) $m.Value + $block + "`r`n" }, 1)
        } else {
            $text = $text.TrimEnd() + "`r`n`r`n[" + $sec + "]`r`n" + $block + "`r`n"
        }
    }
    [System.IO.File]::WriteAllText($into, $text)
    return ($added.Values | ForEach-Object { $_.Count } | Measure-Object -Sum).Sum
}

function Do-Install([string]$game) {
    $man = Read-Pairs (Join-Path $pkg "manifest.txt")
    if ($man["Version"]) { Write-Host ("`nDAOCoop version " + $man["Version"] + " (mod built " + $man["DllBuilt"] + ")") }

    # 1. the game version the mod was made for
    $exe = Join-Path $game $exeRel
    $have = ((Get-Item -LiteralPath $exe).VersionInfo.ProductVersion -replace '[^0-9.]', '')
    if ($man["GameVersion"] -and $have -ne $man["GameVersion"]) {
        Write-Host "`nYour game is version $have, but the mod was made for $($man["GameVersion"])." -ForegroundColor Yellow
        Write-Host "The mod works with fixed places in the game's memory, so with another version it may not work" -ForegroundColor Yellow
        Write-Host "or the game may not start. Let Steam (or the EA app / GOG) update the game first." -ForegroundColor Yellow
        if (-not (Ask "Install anyway?" $false)) { throw "Stopped - nothing was changed." }
    }

    # 2. the mod's DLL: bin_ship\dinput8.dll. The game imports DirectInput8Create from dinput8.dll and
    #    Windows loads it from bin_ship first. (Builds before 0.1.2 used version.dll, which the Steam build
    #    never loads; that one is removed below.)
    $bin = Join-Path $game "bin_ship"
    $src = Join-Path $payload "bin_ship\dinput8.dll"
    $dst = Join-Path $bin "dinput8.dll"
    $chain = Join-Path $bin "dinput8_chain.dll"
    $modFolder = Join-Path $game "DAOCoop"
    $backups = Join-Path $modFolder "backups"
    $recordFile = Join-Path $modFolder "install-record.txt"
    $rec = Read-Pairs $recordFile
    $originalDll = $rec["OriginalDll"]
    $chained = $rec["ChainedDll"]
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    New-Item -ItemType Directory -Force -Path $backups | Out-Null

    # 2a. an older DAOCoop install's version.dll
    $oldDll = Join-Path $bin "version.dll"
    if ((Test-Path -LiteralPath $recordFile) -and $rec["DllName"] -ne "dinput8.dll" -and (Test-Path -LiteralPath $oldDll) -and
        $rec["DllMd5"] -and (Md5 $oldDll) -eq $rec["DllMd5"]) {
        Remove-Item -LiteralPath $oldDll -Force
        Write-Host "`nRemoved the older DAOCoop version.dll (the mod now loads as dinput8.dll)."
        if ($originalDll) {
            $original = Join-Path $backups $originalDll
            if (Test-Path -LiteralPath $original) {
                Copy-Item -LiteralPath $original -Destination $oldDll -Force
                Write-Host "Put back the other mod's version.dll that the older install had replaced."
            }
            $originalDll = ""
        }
    }

    # 2b. dinput8.dll
    $oursBefore = $rec["DllName"] -eq "dinput8.dll"
    if (Test-Path -LiteralPath $dst) {
        if ((Md5 $dst) -eq (Md5 $src)) {
            Write-Host "`nThis version of the mod is already installed."
        } elseif (($oursBefore -and (Md5 $dst) -eq $rec["DllMd5"]) -or (Test-DAOCoopDll $dst)) {
            # our own older build: keep a copy, then replace it
            Copy-Item -LiteralPath $dst -Destination (Join-Path $backups "dinput8.before-daocoop-$stamp.dll") -Force
            Copy-Item -LiteralPath $src -Destination $dst -Force
            Write-Host "`nUpdated the mod (bin_ship\dinput8.dll; the older build is saved in DAOCoop\backups)." -ForegroundColor Green
        } else {
            # another mod's dinput8.dll (for example the Native Controller Framework): keep it working by
            # renaming it to dinput8_chain.dll. DAOCoop passes every DirectInput call on to it.
            Write-Host "`nbin_ship already has a dinput8.dll from another mod (for example the Native Controller"
            Write-Host "Framework). DAOCoop can keep it as dinput8_chain.dll and pass every call on to it, so both"
            Write-Host "mods load. A copy is also saved in DAOCoop\backups, and uninstalling gives it its name back."
            if (-not (Ask "Install DAOCoop alongside it?" $true)) { throw "Stopped - nothing was changed." }
            Copy-Item -LiteralPath $dst -Destination (Join-Path $backups "dinput8.other-mod-$stamp.dll") -Force
            if (Test-Path -LiteralPath $chain) { Remove-Item -LiteralPath $chain -Force }
            Move-Item -LiteralPath $dst -Destination $chain
            Copy-Item -LiteralPath $src -Destination $dst -Force
            $chained = "1"
            Write-Host "Installed the mod (bin_ship\dinput8.dll); the other mod now loads through dinput8_chain.dll." -ForegroundColor Green
        }
    } else {
        Copy-Item -LiteralPath $src -Destination $dst -Force
        Write-Host "`nInstalled the mod (bin_ship\dinput8.dll)." -ForegroundColor Green
    }
    if ($chained -eq "1" -and -not (Test-Path -LiteralPath $chain)) { $chained = "" }
    # keep the newest 5 backups of our own older builds
    Get-ChildItem -LiteralPath $backups -File | Where-Object { $_.Name -like "*.before-daocoop-*.dll" } |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 | Remove-Item -Force -ErrorAction SilentlyContinue

    # 3. settings: the package's, unless this PC already has its own
    $cfg = Join-Path $modFolder "DAOCoop.ini"
    $cfgSrc = Join-Path $payload "DAOCoop\DAOCoop.ini"
    if (-not (Test-Path -LiteralPath $cfg) -and (Test-Path -LiteralPath $cfgSrc)) {
        Copy-Item -LiteralPath $cfgSrc -Destination $cfg -Force
        Write-Host "Settings: DAOCoop\DAOCoop.ini (from the package)."
    } elseif (Test-Path -LiteralPath $cfg) {
        $n = 0
        if (Test-Path -LiteralPath $cfgSrc) { $n = Merge-Ini $cfgSrc $cfg }
        if ($n -gt 0) { Write-Host "Settings: kept your DAOCoop\DAOCoop.ini and added the new settings of this version." }
        else { Write-Host "Settings: kept your DAOCoop\DAOCoop.ini." }
    }

    # 3b. files for the game's override folder: the 6-slot party portraits movie and the
    #     Player 2/3 marker icons. Installed into packages\core\override\DAOCoop.
    $ovSrc = Join-Path $payload "override"
    $hudDir = Join-Path $game "packages\core\override\DAOCoop"
    $overrideFiles = @()
    if (Test-Path -LiteralPath $ovSrc) {
        New-Item -ItemType Directory -Force -Path $hudDir | Out-Null
        foreach ($f in (Get-ChildItem -LiteralPath $ovSrc -File)) {
            if ($f.Extension -ieq ".gfx") {
                # Another mod replacing the same menu movie wins; ours is skipped (the
                # game would load only one of them). Checked in the game folder and in
                # Documents\BioWare\Dragon Age, where mod managers also install.
                $roots = @((Join-Path $game "packages\core\override"),
                           (Join-Path ([Environment]::GetFolderPath("MyDocuments")) "BioWare\Dragon Age\packages\core\override"))
                $other = foreach ($r in $roots) {
                    if (Test-Path -LiteralPath $r) {
                        Get-ChildItem -LiteralPath $r -Recurse -Filter $f.Name -ErrorAction SilentlyContinue |
                            Where-Object { $_.DirectoryName -ne $hudDir }
                    }
                }
                if ($other) {
                    $what = if ($f.Name -ieq "portraits.gfx") { "the 6-portrait HUD" } elseif ($f.Name -ieq "startmenu2.gfx") { "the Co-op button on the start menu" } elseif ($f.Name -ieq "floatylayer.gfx") { "the coloured P2/P3 off-screen arrows" } else { $f.Name }
                    Write-Host "Another mod already replaces $($f.Name) ($(@($other)[0].FullName)); $what is not installed." -ForegroundColor Yellow
                    continue
                }
            }
            Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $hudDir $f.Name) -Force
            $overrideFiles += ("packages\core\override\DAOCoop\" + $f.Name)
        }
        if ($overrideFiles.Count) { Write-Host "Game files: $($overrideFiles.Count) added to packages\core\override\DAOCoop (start menu Co-op button, party portraits, P2/P3 markers and arrows)." }
    }
    $overrideFile = ($overrideFiles -join ";")

    # 4. let the game write its log and settings into DAOCoop (Program Files is read-only for programs
    #    run without administrator rights). Grants the Users group "modify" on that one folder only.
    & icacls.exe $modFolder /grant "*S-1-5-32-545:(OI)(CI)M" /Q | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Could not let the game write into DAOCoop; it will write its log to %LOCALAPPDATA%\DAOCoop instead." -ForegroundColor Yellow
    }

    # 5. the 4GB patch (large address aware) on DAOrigins.exe; the original is kept for uninstalling
    $laaPatched = $rec["LaaPatched"]
    $exePatchedMd5 = $rec["ExePatchedMd5"]
    $exeBackup = Join-Path $backups "DAOrigins.before-4gb-patch.exe"
    $laa = Test-LargeAddressAware $exe
    if (Test-SteamDrm $exe) {
        # an earlier version of this installer patched the Steam exe, which stops it from starting: undo that
        if ($laaPatched -eq "1" -and (Test-Path -LiteralPath $exeBackup) -and (Md5 $exe) -eq $exePatchedMd5) {
            Copy-Item -LiteralPath $exeBackup -Destination $exe -Force
            Write-Host "Put back the original DAOrigins.exe (an earlier install had given it the 4GB patch," -ForegroundColor Green
            Write-Host "which Steam's copy protection does not allow)." -ForegroundColor Green
        }
        $laaPatched = ""
        $exePatchedMd5 = ""
        Write-Host "4GB patch: not possible on the Steam version (Steam's copy protection blocks any change to"
        Write-Host "DAOrigins.exe). The game runs without it; the GOG version can be patched."
    } elseif ($laa -eq $true) {
        Write-Host "4GB patch: DAOrigins.exe already has it."
    } elseif ($laa -eq $false) {
        Write-Host "`nDAOrigins.exe does not have the 4GB patch. Without it the game can only use 2GB of memory and"
        Write-Host "often crashes on modern PCs (more so with mods). The patch changes one flag in the exe; the original"
        Write-Host "is saved in DAOCoop\backups and uninstalling can put it back."
        if (Ask "Apply the 4GB patch?" $true) {
            Copy-Item -LiteralPath $exe -Destination (Join-Path $backups "DAOrigins.before-4gb-patch.exe") -Force
            Set-LargeAddressAware $exe
            if ((Test-LargeAddressAware $exe) -ne $true) { throw "The 4GB patch did not stick - DAOrigins.exe was not changed as expected." }
            $laaPatched = "1"
            $exePatchedMd5 = Md5 $exe
            Write-Host "4GB patch applied (original saved as DAOCoop\backups\DAOrigins.before-4gb-patch.exe)." -ForegroundColor Green
            Write-Host "If the game no longer starts, run UNINSTALL.cmd, or let GOG Galaxy / Steam verify the game's files."
        }
    } else {
        Write-Host "4GB patch: skipped (DAOrigins.exe is not the expected 32-bit program)." -ForegroundColor Yellow
    }

    # 6. what was done (uninstalling reads it)
    $lines = @(("Installed=" + (Get-Date -Format "yyyy-MM-dd HH:mm")),
               ("Version=" + $man["Version"]),
               ("DllName=dinput8.dll"),
               ("DllMd5=" + (Md5 $dst)),
               ("ChainedDll=" + $chained),
               ("OriginalDll=" + $originalDll),
               ("GameVersion=" + $have),
               ("LaaPatched=" + $laaPatched),
               ("ExePatchedMd5=" + $exePatchedMd5),
               ("OverrideFile=" + $overrideFile))
    Set-Content -LiteralPath $recordFile -Value $lines -Encoding ASCII

    Write-Host ""
    Write-Host "Done. Start Dragon Age: Origins as usual." -ForegroundColor Green
    Write-Host "  Controllers: P2 and P3 use the controller slots in DAOCoop\DAOCoop.ini."
    Write-Host "  Each start writes DAOCoop\DAOCoop.log in the game folder: send it along when asking for help."
    Write-Host "  To take the mod out again: UNINSTALL.cmd."
}

if ($ListGames) {
    foreach ($g in Find-AllGameFolders) { Write-Output ($g + "|" + (Get-GameKind $g)) }
    exit 0
}

$code = 0
try {
    Write-Host ""
    if ($Uninstall) {
        Write-Host "DAOCoop co-op mod - take it out" -ForegroundColor Cyan
        Write-Host "===============================" -ForegroundColor Cyan
    } else {
        Write-Host "DAOCoop co-op mod - install" -ForegroundColor Cyan
        Write-Host "===========================" -ForegroundColor Cyan
        if (-not (Test-Path -LiteralPath (Join-Path $payload "bin_ship\dinput8.dll"))) {
            throw "The 'files' folder is not next to this script. Unzip the whole package first (right-click the zip > Extract All), then run INSTALL.cmd from the unzipped folder."
        }
    }
    # downloaded files carry a 'from the internet' mark that can make Windows block the DLL
    try {
        Get-ChildItem -LiteralPath $pkg -Force -File | Unblock-File -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $payload) { Get-ChildItem -LiteralPath $payload -Recurse -Force -File | Unblock-File -ErrorAction SilentlyContinue }
    } catch { }
    if (Get-Process -Name DAOrigins -ErrorAction SilentlyContinue) { throw "Dragon Age: Origins is running. Close it first." }

    $game = Find-Game
    if (-not (Test-Writable (Join-Path $game "bin_ship"))) {
        if (Test-Admin) { throw "Windows refused to write into $game\bin_ship, even as administrator." }
        Restart-Elevated $game
    }
    if ($Uninstall) { Do-Uninstall $game } else { Do-Install $game }
}
catch {
    Write-Host "`n$($_.Exception.Message)" -ForegroundColor Red
    $code = 1
}
if ($PauseAtEnd) { Read-Host "`nPress Enter to close" | Out-Null }
exit $code
