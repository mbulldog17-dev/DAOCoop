# Builds the DAOCoop DLL, makes an install package in dist\, and installs it into the game.
# Start it with build.bat in the project folder.
#   -NoInstall          build and package only
#   -Configuration X    Release (default) or Debug
#   -ChooseGame         ask again which copy of the game to install into
# The game folder build.bat installs into is remembered in game-path.txt in the project folder.
param(
    [switch]$NoInstall,
    [string]$Configuration = "Release",
    [switch]$ChooseGame
)
$ErrorActionPreference = "Stop"
$project = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"

# Prefers the CMake that ships with Visual Studio: it always knows that Visual Studio version
# (VS 2022, VS 2026, ...), while an older standalone CMake on the PATH may not.
function Find-CMake {
    if (Test-Path -LiteralPath $vswhere) {
        $found = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
                            -find "Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" 2>$null |
                 Select-Object -First 1
        if ($found -and (Test-Path -LiteralPath $found)) { return $found }
    }
    $c = Get-Command cmake.exe -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    return $null
}

# Which copy of the game build.bat installs into: game-path.txt, or ask once and remember it.
function Get-TargetGame([string]$installer) {
    $file = Join-Path $project "game-path.txt"
    if (-not $ChooseGame -and (Test-Path -LiteralPath $file)) {
        $saved = (Get-Content -LiteralPath $file -TotalCount 1).Trim()
        if ($saved -and (Test-Path -LiteralPath (Join-Path $saved "bin_ship\DAOrigins.exe"))) { return $saved }
        Write-Host "The game folder in game-path.txt is gone: $saved" -ForegroundColor Yellow
    }
    $found = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -ListGames | Where-Object { $_ -match '\|' })
    if ($found.Count -eq 0) { return $null }   # the installer asks for the folder itself
    $choice = 0
    if ($found.Count -gt 1) {
        Write-Host "`nFound more than one copy of Dragon Age: Origins:"
        for ($i = 0; $i -lt $found.Count; $i++) {
            $parts = $found[$i] -split '\|', 2
            Write-Host ("  {0}. {1}  ({2})" -f ($i + 1), $parts[0], $parts[1])
        }
        $choice = -1
        while ($choice -lt 0) {
            $a = Read-Host "Which one should build.bat install the mod into? (1-$($found.Count))"
            $n = 0
            if ([int]::TryParse("$a".Trim(), [ref]$n) -and $n -ge 1 -and $n -le $found.Count) { $choice = $n - 1 }
        }
    }
    $game = ($found[$choice] -split '\|', 2)[0]
    Set-Content -LiteralPath $file -Value $game -Encoding ASCII
    Write-Host "Installing into: $game (remembered in game-path.txt; run build.bat -ChooseGame to change it)"
    return $game
}

# The newest Visual Studio (release or preview) with the C++ tools: its name, or $null
function Get-VisualCpp {
    if (-not (Test-Path -LiteralPath $vswhere)) { return $null }
    $name = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property displayName 2>$null |
            Select-Object -First 1
    if ($name) { return $name }
    return $null
}

$code = 0
try {
    Write-Host "`nDAOCoop - build" -ForegroundColor Cyan
    Write-Host "===============" -ForegroundColor Cyan

    $vsName = Get-VisualCpp
    if (-not $vsName) {
        throw ("Visual Studio with C++ was not found. Install Visual Studio Community (free) with the " +
               "'Desktop development with C++' workload, then run build.bat again: https://visualstudio.microsoft.com/vs/community/")
    }
    Write-Host "Using $vsName"
    $cmake = Find-CMake
    if (-not $cmake) { throw "CMake was not found. In the Visual Studio Installer, add 'C++ CMake tools for Windows' to the C++ workload." }

    $src = Join-Path $project "dll"
    $build = Join-Path $project "build"
    Write-Host "`nConfiguring (32-bit, like the game)..."
    & $cmake -S $src -B $build -A Win32 | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "CMake could not set up the build (see above)." }
    Write-Host "`nBuilding..."
    & $cmake --build $build --config $Configuration | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "The build failed (see the errors above)." }
    $dll = Join-Path $build "$Configuration\dinput8.dll"
    if (-not (Test-Path -LiteralPath $dll)) { throw "The build finished but $dll is missing." }
    Write-Host "Built $dll" -ForegroundColor Green

    Write-Host "`nMaking the install package..."
    $pkgDir = & (Join-Path $project "scripts\Make-Install-Package.ps1") -Dll $dll -Quiet | Select-Object -Last 1

    if ($NoInstall) {
        Write-Host "`nNot installed (-NoInstall). Install with INSTALL.cmd in: $pkgDir"
    } else {
        $installer = Join-Path $pkgDir "Install-DAOCoop.ps1"
        $game = Get-TargetGame $installer
        Write-Host "`nInstalling into the game..."
        if ($game) {
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Yes -GamePath $game
        } else {
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Yes
        }
        if ($LASTEXITCODE -ne 0) { throw "Installing failed (see above). The package is in $pkgDir." }
    }
}
catch {
    Write-Host "`n$($_.Exception.Message)" -ForegroundColor Red
    $code = 1
}
exit $code
