# Packs the mod into one small zip anyone can install: the built DLL, clean settings, the installer /
# uninstaller and a README. Nothing personal: no saves, logs or source code.
# build.bat runs it after every successful build; MAKE-INSTALL-PACKAGE.cmd runs it by hand.
#   -Dll "<path to dinput8.dll>"   default: build\Release\dinput8.dll in the project
#   -OutDir "<folder>"             default: dist\ in the project
#   -Version "<text>"              default: the mod version in dll\src\dllmain.cpp (kVersion), else the build date
#   -GameVersion "<x.y.z.w>"       the DAOrigins.exe version the mod is made for
#   -Keep 3                        how many packages to keep (0 = keep all)
#   -Quiet                         fewer messages (used by the build script)
# Writes the unzipped package folder's path to the output, so the build script can install from it.
param(
    [string]$Dll = "",
    [string]$OutDir = "",
    [string]$Version = "",
    [string]$GameVersion = "1.05.13263.0",
    [int]$Keep = 3,
    [switch]$Quiet
)
$ErrorActionPreference = "Stop"
$project = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Say([string]$text, [string]$color = "Gray") { if (-not $Quiet) { Write-Host $text -ForegroundColor $color } }
function Md5([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm MD5).Hash.ToLower() }
# a .cmd file needs Windows line ends
function Write-Cmd([string]$path, [string[]]$lines) { [IO.File]::WriteAllText($path, (($lines -join "`r`n") + "`r`n"), [Text.Encoding]::ASCII) }

if (-not $Dll) { $Dll = Join-Path $project "build\Release\dinput8.dll" }
if (-not (Test-Path -LiteralPath $Dll)) { throw "There is no built DLL at $Dll. Run build.bat first." }
if (-not $OutDir) { $OutDir = Join-Path $project "dist" }
$installer = Join-Path $project "installer\Install-DAOCoop.ps1"
$readme = Join-Path $project "installer\Package-README.txt"
$ini = Join-Path $project "dll\DAOCoop.ini"
foreach ($need in @($installer, $readme, $ini)) { if (-not (Test-Path -LiteralPath $need)) { throw "$need is missing." } }

$di = Get-Item -LiteralPath $Dll
if (-not $Version) {
    $main = Join-Path $project "dll\src\dllmain.cpp"
    if (Test-Path -LiteralPath $main) {
        $m = Select-String -LiteralPath $main -Pattern 'kVersion\s*=\s*"([^"]+)"' | Select-Object -First 1
        if ($m) { $Version = $m.Matches[0].Groups[1].Value }
    }
}
if (-not $Version) { $Version = $di.LastWriteTime.ToString("yyyy.MM.dd.HHmm") }
$name = "DAOCoop-" + $Version
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$root = Join-Path $OutDir $name
if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $root "files\bin_ship") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $root "files\DAOCoop") | Out-Null

Copy-Item -LiteralPath $Dll -Destination (Join-Path $root "files\bin_ship\dinput8.dll") -Force
Copy-Item -LiteralPath $ini -Destination (Join-Path $root "files\DAOCoop\DAOCoop.ini") -Force
$assets = Join-Path $project "dll\assets"
if (Test-Path -LiteralPath $assets) {
    New-Item -ItemType Directory -Force -Path (Join-Path $root "files\override") | Out-Null
    Get-ChildItem -LiteralPath $assets -File | Where-Object { $_.Extension -in ".gfx", ".dds" } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $root ("files\override\" + $_.Name)) -Force }
}
Copy-Item -LiteralPath $installer -Destination (Join-Path $root "Install-DAOCoop.ps1") -Force
Copy-Item -LiteralPath $readme -Destination (Join-Path $root "README.txt") -Force
$licenses = Join-Path $project "installer\LICENSES.txt"
if (Test-Path -LiteralPath $licenses) { Copy-Item -LiteralPath $licenses -Destination (Join-Path $root "LICENSES.txt") -Force }
Write-Cmd (Join-Path $root "INSTALL.cmd") @(
    "@echo off", "cd /d `"%~dp0`"",
    "echo Installing the DAOCoop co-op mod for Dragon Age: Origins...",
    "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0Install-DAOCoop.ps1`" %*",
    "echo.", "pause")
Write-Cmd (Join-Path $root "UNINSTALL.cmd") @(
    "@echo off", "cd /d `"%~dp0`"",
    "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0Install-DAOCoop.ps1`" -Uninstall %*",
    "echo.", "pause")

$lines = @("Package=DAOCoop co-op mod for Dragon Age: Origins - install package",
           ("Version=" + $Version),
           ("Created=" + (Get-Date -Format "yyyy-MM-dd HH:mm")),
           ("DllBuilt=" + $di.LastWriteTime.ToString("yyyy-MM-dd HH:mm")),
           ("DllMd5=" + (Md5 $Dll)),
           ("GameVersion=" + $GameVersion))
Set-Content -LiteralPath (Join-Path $root "manifest.txt") -Value $lines -Encoding ASCII

$zip = Join-Path $OutDir ($name + ".zip")
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($root, $zip, [System.IO.Compression.CompressionLevel]::Optimal, $true)
$kb = [Math]::Round((Get-Item -LiteralPath $zip).Length / 1KB)

if ($Keep -gt 0) {
    Get-ChildItem -LiteralPath $OutDir -Filter "DAOCoop-*.zip" -File |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip $Keep | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem -LiteralPath $OutDir -Directory -Filter "DAOCoop-*" |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip $Keep | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host "Install package: $zip ($kb KB)" -ForegroundColor Green
Say "Share that zip. People unzip it and run INSTALL.cmd - README.txt inside explains the rest."
Write-Output $root
