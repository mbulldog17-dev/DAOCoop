class Portraits extends GUI.Element
{
   var VAlign;
   var HAlign;
   var LocalIndex;
   var SetCreatureToken;
   var m_HoldPositionMC;
   var m_SelectAllMC;
   var m_nSoundType;
   var TooltipType;
   var OnSelected;
   var OnUnselected;
   var OnButtonAction;
   var OnSecondaryButtonAction;
   var UpdateTooltip;
   var IsSelected;
   var SetTooltipSource;
   static var cm_mcPortraits;
   static var MAX_NUM_FOLLOWERS = 6;
   var m_nVisibleMemberCount = 0;
   function Portraits()
   {
      super();
   }
   function FinalizeInstance()
   {
      Portraits.cm_mcPortraits = this;
      this.AddBehaviour(Behaviour.AlignedLayout);
      this.VAlign = Behaviour.AlignedLayout.ALIGN_TOP;
      this.HAlign = Behaviour.AlignedLayout.ALIGN_LEFT;
      _root.Portrait1_mc_init = function()
      {
         this.LocalIndex = 0;
         this.SetCreatureToken("Party.Members.0");
      };
      _root.Portrait2_mc_init = function()
      {
         this.LocalIndex = 1;
         this.SetCreatureToken("Party.Members.1");
      };
      _root.Portrait3_mc_init = function()
      {
         this.LocalIndex = 2;
         this.SetCreatureToken("Party.Members.2");
      };
      _root.Portrait4_mc_init = function()
      {
         this.LocalIndex = 3;
         this.SetCreatureToken("Party.Members.3");
      };
      _root.Portrait5_mc_init = function()
      {
         this.LocalIndex = 8;
         this.SetCreatureToken("Party.Members.4");
      };
      _root.Portrait6_mc_init = function()
      {
         this.LocalIndex = 9;
         this.SetCreatureToken("Party.Members.5");
      };
      _root.Player1Summon_mc_init = function()
      {
         this.LocalIndex = 4;
         this.SetCreatureToken("Party.Summons.0");
      };
      _root.Player2Summon_mc_init = function()
      {
         this.LocalIndex = 5;
         this.SetCreatureToken("Party.Summons.1");
      };
      _root.Player3Summon_mc_init = function()
      {
         this.LocalIndex = 6;
         this.SetCreatureToken("Party.Summons.2");
      };
      _root.Player4Summon_mc_init = function()
      {
         this.LocalIndex = 7;
         this.SetCreatureToken("Party.Summons.3");
      };
      var host = this;
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_PMEMBER_0_VISIBILITY,"Party.Members.0",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_PMEMBER_1_VISIBILITY,"Party.Members.1",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_PMEMBER_2_VISIBILITY,"Party.Members.2",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_PMEMBER_3_VISIBILITY,"Party.Members.3",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(70000,"Party.Members.4",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(70001,"Party.Members.5",function()
      {
         host.UpdateVisibleMemberCount();
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_SELECTABLE_MEMBER_COUNT,"Party.SelectableMemberCount",function()
      {
         host.UpdatePartySelection();
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_SELECTED_COUNT,"Party.SelectedCount",function()
      {
         host.UpdatePartySelection();
      }
      );
      this.SetupSelectAllToggle();
      this.SetupHoldPositionToggle();
      var portraitMC = new DataType.MovieController(host);
      this.m_HoldPositionMC = new DataType.MovieController(_root.HoldPositionToggle_mc);
      this.m_SelectAllMC = new DataType.MovieController(_root.SelectAllToggle_mc);
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_GAME_MODE,"GameModeController.CurrentGameMode",function(a_nGameMode)
      {
         if(a_nGameMode == GUISystem.GM_EXPLORE || a_nGameMode == GUISystem.GM_COMBAT || a_nGameMode == GUISystem.GM_LOADING)
         {
            MovieUtils.EnableHitTest(host);
            portraitMC.PlayToPercent(0);
            host.UpdatePartySelection();
         }
         else
         {
            MovieUtils.DisableHitTest(host);
            portraitMC.PlayToPercent(1);
            host.UpdatePartySelection();
         }
      }
      );
      TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_HIGHLIGHT,"GUI.GuiHighlights." + DAConstants.GUI_HIGHLIGHT_FOLLOWER + ".Highlight",function(a_nHighlight)
      {
         Portraits.cm_mcPortraits.UpdateFollowerHighlight(a_nHighlight != 0);
      }
      );
      this.CoopBarsStart();
   }
   // DAOCoop: Player 2/3's ability slots next to their portrait. The DLL answers
   // GetValue("DAOCoop.Bar.<creature id>") with "player|page|ability1|ability2|ability3"
   // (page 0 = slots 1-3, 1 = RT held: 4-6, 2 = LT held: 7-9), or "" for anyone else.
   function CoopBarsStart()
   {
      var host = this;
      var ticker = this.createEmptyMovieClip("CoopBarTicker_mc",31000);
      ticker.m_nCount = 0;
      ticker.onEnterFrame = function()
      {
         this.m_nCount = this.m_nCount - 1;
         if(this.m_nCount > 0)
         {
            return undefined;
         }
         this.m_nCount = 4;
         host.CoopBarsUpdate();
      };
   }
   function CoopBarsUpdate()
   {
      var mode = ExternalCommands.GetValue("GameModeController.CurrentGameMode");
      var show = mode == GUISystem.GM_EXPLORE || mode == GUISystem.GM_COMBAT;
      var i = 1;
      while(i <= Portraits.MAX_NUM_FOLLOWERS)
      {
         var pmc = this["Portrait" + i + "_mc"];
         var info = "";
         if(show && pmc != undefined && pmc._visible && pmc.m_sCreatureToken != undefined)
         {
            var id = ExternalCommands.GetValue(pmc.m_sCreatureToken + ".ID");
            if(id != null && id != undefined)
            {
               var r = ExternalCommands.GetValue("DAOCoop.Bar." + id);
               if(r != null && r != undefined)
               {
                  info = String(r);
               }
            }
         }
         this.CoopBarShow(i,pmc,info);
         i = i + 1;
      }
   }
   function CoopBarText(a_mc, a_sName, a_nDepth, a_nX, a_nY, a_nW, a_nSize, a_nColour, a_sAlign)
   {
      var t = a_mc.createTextField(a_sName,a_nDepth,a_nX,a_nY,a_nW,a_nSize + 8);
      var f = new TextFormat();
      f.font = "$TitleFont";
      f.size = a_nSize;
      f.bold = true;
      f.align = a_sAlign;
      t.embedFonts = true;
      t.selectable = false;
      t.setNewTextFormat(f);
      t.textColor = a_nColour;
      t.filters = [new flash.filters.GlowFilter(0,1,3,3,5,1)];
      return t;
   }
   function CoopBarBuild(bar)
   {
      var colours = [3832831,15909376,14692400];
      var letters = ["X","Y","B"];
      var k = 0;
      while(k < 3)
      {
         var s = bar.createEmptyMovieClip("Slot" + k + "_mc",10 + k);
         s._x = k * 42;
         s.beginFill(0,60);
         s.moveTo(0,0);
         s.lineTo(38,0);
         s.lineTo(38,38);
         s.lineTo(0,38);
         s.lineTo(0,0);
         s.endFill();
         var ic = s.createEmptyMovieClip("Icon_mc",1);
         ic._x = 1;
         ic._y = 1;
         var frame = s.createEmptyMovieClip("Frame_mc",2);
         frame.lineStyle(2,colours[k],100);
         frame.moveTo(0,0);
         frame.lineTo(38,0);
         frame.lineTo(38,38);
         frame.lineTo(0,38);
         frame.lineTo(0,0);
         this.CoopBarText(s,"Num_txt",3,1,20,18,13,16777215,"left");
         this.CoopBarText(s,"Key_txt",4,20,-2,18,12,colours[k],"right").text = letters[k];
         s.m_nAbility = -1;
         k = k + 1;
      }
      this.CoopBarText(bar,"Page_txt",50,128,10,40,14,16777215,"left");
   }
   function CoopBarShow(i, pmc, info)
   {
      var bar = this["CoopBar" + i + "_mc"];
      if(info == "")
      {
         if(bar != undefined)
         {
            bar._visible = false;
         }
         return undefined;
      }
      var parts = info.split("|");
      if(parts.length < 5)
      {
         return undefined;
      }
      if(bar == undefined)
      {
         bar = this.createEmptyMovieClip("CoopBar" + i + "_mc",31000 + i);
         this.CoopBarBuild(bar);
      }
      // 1.2.48: the portrait's bounds change while an ability runs or recharges (extra
      // effects inside the clip), which slid the bar over the portrait. Measure once while
      // the bounds look normal, keep that offset from the portrait's origin, and follow
      // only the origin afterwards.
      var o = {x:0,y:0};
      pmc.localToGlobal(o);
      this.globalToLocal(o);
      var g = pmc.getBounds(this);
      var w = g.xMax - g.xMin;
      var h = g.yMax - g.yMin;
      if(bar.m_bAnchored != true && w > 20 && w <= 120 && h > 20 && h <= 140)
      {
         bar.m_nOffX = g.xMax + 48 - o.x;   // 1.2.24 sat on top of the portrait frame (drawn outside the clip bounds)
         bar.m_nOffY = g.yMin + Math.max(0,(h - 38) / 2) - o.y;
         bar.m_bAnchored = true;
      }
      if(bar.m_bAnchored == true)
      {
         bar._x = o.x + bar.m_nOffX;
         bar._y = o.y + bar.m_nOffY;
      }
      else
      {
         var right = g.xMax;
         if(w > 120)
         {
            right = g.xMin + 90;
         }
         bar._x = right + 48;
         bar._y = g.yMin + Math.max(0,(h - 38) / 2);
      }
      bar._visible = true;
      var page = Number(parts[1]);
      var k = 0;
      while(k < 3)
      {
         var s = bar["Slot" + k + "_mc"];
         var ab = Number(parts[2 + k]);
         if(s.m_nAbility != ab)
         {
            s.m_nAbility = ab;
            if(ab > 0)
            {
               var icon = ExternalCommands.Get2DAValue(_2DA.TABLE_ABI_BASE,ab,_2DA.HASH_ICON);
               s.Icon_mc._visible = true;
               MovieUtils.LoadImageFixedSize(s.Icon_mc,String(icon),36,36);
            }
            else
            {
               s.Icon_mc._visible = false;
            }
         }
         s.Num_txt.text = String(page * 3 + k + 1);
         k = k + 1;
      }
      bar.Page_txt.text = page != 1 ? (page != 2 ? "" : "LT") : "RT";
   }
   function SetupSelectAllToggle()
   {
      var _loc3_ = this;
      _root.SelectAllToggle_mc_init = function()
      {
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_TOP;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_LEFT;
         this.m_nSoundType = SoundEvents.ST_SELECT_ALL_PARTY;
         this.AddBehaviour(Behaviour.DisplayTooltip);
         this.TooltipType = Behaviour.DisplayTooltip.TOOLTIP_TYPE_SIMPLE_FLOATING;
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_TOGGLE_FULL_PARTY_KEY_BINDING,"InputMappings.Mappings.ToggleFullPartySelect.PrimaryMappedKey",function(a_sBoundKey)
         {
            _root.SelectAllToggle_mc.SetTooltipSource(Localization.Strings.LOC_TOGGLE_FULL_PARTY_SELECT + " <b>(" + a_sBoundKey + ")</b>");
         }
         );
         this.OnSelected = function()
         {
         };
         this.OnUnselected = function()
         {
         };
         this.OnButtonAction = function()
         {
            ExternalCommands.SendMessage("Party.ToggleFullPartySelectMessage");
         };
         this.OnSecondaryButtonAction = function()
         {
            ExternalCommands.SendMessage("Party.ToggleFullPartySelectMessage");
         };
      };
   }
   function SetupHoldPositionToggle()
   {
      host = this;
      _root.HoldPositionToggle_mc_init = function()
      {
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_TOP;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_LEFT;
         this.AddBehaviour(Behaviour.DisplayTooltip);
         this.TooltipType = Behaviour.DisplayTooltip.TOOLTIP_TYPE_SIMPLE_FLOATING;
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_TOGGLE_HOLD_PARTY_KEY_BINDING,"InputMappings.Mappings.ToggleHoldParty.PrimaryMappedKey",function(a_sBoundKey)
         {
            _root.HoldPositionToggle_mc.UpdateTooltip();
         }
         );
         this.OnSelected = function()
         {
            this.UpdateTooltip();
         };
         this.OnUnselected = function()
         {
            this.UpdateTooltip();
         };
         this.UpdateTooltip = function()
         {
            if(this.IsSelected())
            {
               this.SetTooltipSource(Localization.Strings.LOC_PARTY_MOVEMENT_DISABLED + " <b>(" + ExternalCommands.GetValue("InputMappings.Mappings.ToggleHoldParty.PrimaryMappedKey") + ")</b>");
            }
            else
            {
               this.SetTooltipSource(Localization.Strings.LOC_PARTY_MOVEMENT_ENABLED + " <b>(" + ExternalCommands.GetValue("InputMappings.Mappings.ToggleHoldParty.PrimaryMappedKey") + ")</b>");
            }
         };
         this.OnButtonAction = function()
         {
            ExternalCommands.SetValue("Party.HoldPositions",true);
         };
         this.OnSecondaryButtonAction = function()
         {
            ExternalCommands.SetValue("Party.HoldPositions",false);
         };
         var host = this;
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.PORTRAITS_HOLD_POSITION,"Party.HoldPositions",function(a_bHoldPositions)
         {
            if(a_bHoldPositions != 0)
            {
               host.Select(true);
            }
            else
            {
               host.Unselect(true);
            }
         }
         );
      };
   }
   function UpdatePartySelection()
   {
      var _loc4_ = ExternalCommands.GetValue("Party.SelectableMemberCount");
      var _loc5_ = ExternalCommands.GetValue("Party.SelectedCount");
      var _loc3_ = ExternalCommands.GetValue("GameModeController.CurrentGameMode");
      if(_loc3_ != GUISystem.GM_EXPLORE && _loc3_ != GUISystem.GM_COMBAT)
      {
         this.m_HoldPositionMC.PlayToPercent(1);
         this.m_SelectAllMC.PlayToPercent(1);
         MovieUtils.DisableHitTest(_root.SelectAllToggle_mc);
         MovieUtils.DisableHitTest(_root.HoldPositionToggle_mc);
      }
      else
      {
         this.m_HoldPositionMC.PlayToPercent(0);
         this.m_SelectAllMC.PlayToPercent(0);
         MovieUtils.EnableHitTest(_root.SelectAllToggle_mc);
         MovieUtils.EnableHitTest(_root.HoldPositionToggle_mc);
         if(_loc4_ <= 1)
         {
            MovieUtils.HideMovie(_root.SelectAllToggle_mc);
            MovieUtils.HideMovie(_root.HoldPositionToggle_mc);
         }
         else
         {
            MovieUtils.ShowMovie(_root.SelectAllToggle_mc);
            MovieUtils.ShowMovie(_root.HoldPositionToggle_mc);
         }
      }
      if(_loc4_ == _loc5_)
      {
         _root.SelectAllToggle_mc.Select(true);
      }
      else
      {
         _root.SelectAllToggle_mc.Unselect(true);
      }
   }
   function UpdateVisibleMemberCount()
   {
      this.m_nVisibleMemberCount = 0;
      if(ExternalCommands.GetValue("Party.Members.0") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      if(ExternalCommands.GetValue("Party.Members.1") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      if(ExternalCommands.GetValue("Party.Members.2") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      if(ExternalCommands.GetValue("Party.Members.3") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      if(ExternalCommands.GetValue("Party.Members.4") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      if(ExternalCommands.GetValue("Party.Members.5") != null)
      {
         this.m_nVisibleMemberCount = this.m_nVisibleMemberCount + 1;
      }
      var _loc3_ = _root.Portraits_mc["Portrait" + this.m_nVisibleMemberCount + "_mc"].GetGlobalGeometry();
      _root.SelectAllToggle_mc._y = _loc3_.y + _loc3_.height;
      _root.HoldPositionToggle_mc._y = _loc3_.y + _loc3_.height;
   }
   function UpdateFollowerHighlight(a_bHighlight)
   {
      if(a_bHighlight == false)
      {
         var _loc3_ = 0;
         while(_loc3_ < Portraits.MAX_NUM_FOLLOWERS)
         {
            _root.Portraits_mc["Portrait" + (_loc3_ + 1) + "_mc"].UnHighlight();
            _loc3_ = _loc3_ + 1;
         }
      }
      else
      {
         var _loc6_ = ExternalCommands.GetValue("SelectedChar.ID");
         _loc3_ = 0;
         while(_loc3_ < this.m_nVisibleMemberCount)
         {
            var _loc4_ = this["Portrait" + (_loc3_ + 1) + "_mc"];
            var _loc5_ = ExternalCommands.GetValue(_loc4_.m_sCreatureToken + ".ID");
            if(_loc5_ != _loc6_ && _loc5_ != null)
            {
               _loc4_.Highlight();
            }
            else
            {
               _loc4_.UnHighlight();
            }
            _loc3_ = _loc3_ + 1;
         }
      }
   }
}
