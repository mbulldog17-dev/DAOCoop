@echo off
rem Makes a shareable install package (dist\DAOCoop-<version>.zip) from the last build.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Make-Install-Package.ps1" %*
echo.
pause
