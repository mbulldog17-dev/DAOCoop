# DAOCoop - 3-player co-op for Dragon Age: Origins

Local (and experimental online) co-op for Dragon Age: Origins 1.05. Player 1 plays the Warden;
Players 2 and 3 make their own characters in the full character creator and play them on Xbox
controllers, alongside the Warden and the AI companions.

Player download, install steps and controls: see the mod page on Nexus Mods and
`installer/Package-README.txt` (the README that ships in the download).

## How it works

`dinput8.dll` is a DirectInput proxy: the game loads it from its `bin_ship` folder, and it passes
every DirectInput call on to Windows' own DLL (or to another mod's `dinput8.dll`, kept as
`dinput8_chain.dll`, e.g. the Native Controller Framework). Inside the game it:

- reads the extra controllers (XInput) and drives the co-op characters through the game's own
  command queue and its stick-movement action;
- calls the game's script commands directly (party, character creator, abilities, saves);
- hooks a small number of engine functions by address for the 1.05.13263.0 build - every hook
  checks the original bytes first and stays off (logged) if they don't match;
- adds UI through the game's Scaleform movies (`dll/assets/*.gfx`, built from `tools/`).

Reverse-engineering notes for every address used are in `docs/engine-notes.md`.

## Building from source

Needs Windows and Visual Studio 2022 or newer with **Desktop development with C++**
(the free Community edition is fine). CMake comes with it.

1. Clone or download this repository.
2. Double-click **`build.bat`**. It:
   1. builds the DLL (32-bit, like the game): `build\Release\dinput8.dll`;
   2. makes the install package: `dist\DAOCoop-<version>.zip`;
   3. installs it into the game (it finds the game, or asks; Windows asks for permission
      because the game is usually under Program Files).

`build.bat -NoInstall` only builds and packages. `build.bat -ChooseGame` picks a different game
copy. `uninstall.bat` removes the mod again. `MAKE-INSTALL-PACKAGE.cmd` re-packages the last build.

Manual build without the scripts:

```
cmake -S dll -B build -A Win32
cmake --build build --config Release
```

The UI movies in `dll/assets` are prebuilt. To rebuild one, use the `build.sh` in its `tools/`
folder with JPEXS FFDec and the game's original movie from `packages/core/data/guiexport.erf`
(not included here).

## Project layout

| Path | What it is |
| --- | --- |
| `dll/src/` | The mod (C++17) |
| `dll/src/online/` | Online play (invite codes, picture/sound streaming, virtual controllers) |
| `dll/assets/` | UI movies and marker textures copied to the game's override folder |
| `dll/DAOCoop.ini` | Default settings (every option is explained in the file) |
| `installer/` | The player installer, the README and third-party notices that ship in the download |
| `scripts/` | Build and packaging scripts |
| `tools/` | Sources for the patched UI movies (ActionScript) and the marker textures |
| `docs/` | Engine notes |

## What goes where in the game folder

| Path | What it is |
| --- | --- |
| `bin_ship\dinput8.dll` | The mod. The game loads it by itself, and it passes every DirectInput call on to Windows (or to `dinput8_chain.dll`). |
| `bin_ship\dinput8_chain.dll` | Only when another mod had a `dinput8.dll`: that mod, renamed |
| `DAOCoop\DAOCoop.ini` | Settings (controller slots for P2 and P3) |
| `DAOCoop\DAOCoop.log` | Written on every start |
| `DAOCoop\backups\` | DLLs the installer replaced, and the original `DAOrigins.exe` from before the 4GB patch |
| `DAOCoop\install-record.txt` | What the installer did, for uninstalling |

Why `dinput8.dll`: the game imports `DirectInput8Create` from it, so Windows loads ours
from `bin_ship` first; the Native Controller Framework loads the same way on this build.
The first builds used `version.dll`, but crash dumps showed the Steam build always loads
Windows' own `version.dll` from System32, so that copy was never used.

## Credits and notices

- Online play is adapted from the author's co-op mod for Kingdoms of Amalur: Re-Reckoning, which
  builds on the open-source AmalurCoop project (MIT License) - see `installer/LICENSES.txt`.
- Controller menus use the separate Dragon Age - Native Controller Framework mod by
  ChronicallyBored (not included).
- The ActionScript in `tools/` and the movies in `dll/assets/` are modified versions of the game's
  own UI files.

Fan-made. Not made, endorsed or supported by BioWare or Electronic Arts.
