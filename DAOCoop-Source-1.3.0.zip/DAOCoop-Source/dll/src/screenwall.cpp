#include "screenwall.h"
#include "hooks.h"
#include "game.h"
#include "log.h"
#include "regroup.h"
#include "d3d9hook.h"
#include "script.h"
#include <windows.h>
#include <cmath>
#include <cstdio>

static ScreenWallSettings g_s;
static bool g_on = false;

// From the main tick.
static int      g_n = 0;
static uint32_t g_id[3];
static int      g_num[3];
static float    g_pos[3][3];
static void*    g_leadObj = nullptr;
static uint32_t g_hero = 0xFFFFFFFF;

// Player 1 pushing against a co-op player (for the pull).
static int      g_blockedBy = 0;          // player number, 0 = none
static unsigned g_blockedAt = 0, g_blockSince = 0;
static float    g_blockerPos[2];

// --- the game's projection -----------------------------------------------------------
typedef void* (__thiscall* GetX_t)(void*);
typedef void  (__thiscall* Project_t)(void*, float*, float*, float*, unsigned char*);

static bool ProjectRaw(const float p[3], float* nx, float* ny, bool* on)
{
    void* r = *reinterpret_cast<void**>(0xC31650);
    if (!r) return false;
    void* x = reinterpret_cast<GetX_t>((*reinterpret_cast<void***>(r))[0x24 / 4])(r);
    if (!x) return false;
    void* cam = *reinterpret_cast<void**>(static_cast<char*>(x) + 0xC0);
    if (!cam) return false;
    alignas(16) float v[4] = { p[0], p[1], p[2], 1.f };
    float sx = 0.f, sy = 0.f;
    unsigned char vis = 0;
    reinterpret_cast<Project_t>((*reinterpret_cast<void***>(cam))[0x4C / 4])(cam, v, &sx, &sy, &vis);
    int w = 0, h = 0;
    if (!D3D9BackBufferSize(&w, &h)) return false;
    *nx = sx / (float)w; *ny = sy / (float)h; *on = vis != 0;
    return std::isfinite(*nx) && std::isfinite(*ny);
}
static bool Project(const float p[3], float* nx, float* ny, bool* on)
{
#ifdef _MSC_VER
    __try { return ProjectRaw(p, nx, ny, on); } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
#else
    return ProjectRaw(p, nx, ny, on);
#endif
}
bool ScreenWallProject(const float p[3], float* nx, float* ny, bool* on) { return Project(p, nx, ny, on); }

// How far a point is past edge e (0 left, 1 right, 2 bottom = feet, 3 top = head):
// > 0 means inside the free strip at that edge or beyond it.
static const float kHead = 1.8f, kChest = 1.1f;
static bool Outward(int e, float x, float y, float z, float* out)
{
    // The camera keeps Player 1's feet at the very bottom of the screen (feet at 0.92-1.1 in the
    // 1.2.44 log), so feet can't be the test: a character counts as cut off when its chest
    // (sides, bottom) or head (top) leaves the screen.
    float p[3] = { x, y, e == 3 ? z + kHead : z + kChest };
    float nx, ny; bool on;
    if (!Project(p, &nx, &ny, &on) || !on) return false;
    float m = g_s.edge;
    switch (e) {
    case 0:  *out = m - nx; break;
    case 1:  *out = nx - (1.f - m); break;
    case 2:  *out = ny - (1.f - m); break;
    default: *out = m - ny; break;
    }
    return true;
}

// Ground direction that moves player j toward edge e on screen (camera fixed).
static bool EdgeDir(int j, int e, float* gx, float* gy)
{
    const float eps = 0.25f;
    float o0, ox, oy;
    const float* p = g_pos[j];
    if (!Outward(e, p[0], p[1], p[2], &o0) || !Outward(e, p[0] + eps, p[1], p[2], &ox) ||
        !Outward(e, p[0], p[1] + eps, p[2], &oy)) return false;
    float a = (ox - o0) / eps, b = (oy - o0) / eps, l = std::sqrt(a * a + b * b);
    if (l < 1e-5f) return false;
    *gx = a / l; *gy = b / l;
    return true;
}

static void Remove(float& dx, float& dy, float gx, float gy, bool positive)
{
    float d = dx * gx + dy * gy;
    if (positive ? d > 0.f : d < 0.f) { dx -= d * gx; dy -= d * gy; }
}

bool ScreenWallFilter(uint32_t mover, float& dx, float& dy)
{
    if (!g_on || g_n < 2) return true;
    int me = -1;
    for (int i = 0; i < g_n; ++i) if (g_id[i] == mover) me = i;
    if (me < 0) return true;
    { float nx, ny; bool on; if (!Project(g_pos[0], &nx, &ny, &on)) return true; }   // no projection: no wall
    float ox = dx, oy = dy;
    int blocker = 0, why = 0, whyEdge = -1;
    for (int j = 0; j < g_n; ++j) {
        const float* p = g_pos[j];
        bool seen = false, pressed = false;
        for (int e = 0; e < 4; ++e) {
            float o;
            if (!Outward(e, p[0], p[1], p[2], &o)) continue;
            seen = true;
            if (o <= 0.f) continue;
            float gx, gy;
            if (!EdgeDir(j, e, &gx, &gy)) continue;
            pressed = true;
            float before = dx * gx + dy * gy;
            // j itself: no further toward that edge. Anyone else: not away from j
            // (the camera follows them and pushes j out).
            Remove(dx, dy, gx, gy, j == me);
            if (j != me && before < -0.05f && !blocker) blocker = g_num[j];
            if (std::fabs(before) > 0.05f && (j == me ? before > 0.f : before < 0.f)) { why = g_num[j]; whyEdge = e; }
        }
        if (!seen && j != me) {
            // j is off screen (or behind the camera): don't walk away from j on the ground.
            float ax = p[0] - g_pos[me][0], ay = p[1] - g_pos[me][1], l = std::sqrt(ax * ax + ay * ay);
            if (l > 0.5f) {
                float before = (dx * ax + dy * ay) / l;
                Remove(dx, dy, ax / l, ay / l, false);
                if (before < -0.05f && !blocker) blocker = g_num[j];
                if (before < -0.05f) { why = g_num[j]; whyEdge = -1; }
                pressed = true;
            }
        }
        (void)pressed;
    }
    if (me == 0 && blocker > 1) {                          // Player 1 held back by a co-op player
        unsigned now = GetTickCount();
        if (g_blockedBy != blocker || now - g_blockedAt > 400) {
            g_blockedBy = blocker; g_blockSince = now;
            for (int j = 0; j < g_n; ++j) if (g_num[j] == blocker) { g_blockerPos[0] = g_pos[j][0]; g_blockerPos[1] = g_pos[j][1]; }
        }
        g_blockedAt = now;
    }
    float l = std::sqrt(dx * dx + dy * dy);
    if (l < 0.25f) {                                       // pushing straight into the wall
        static int loggedStop = 0;
        if (g_s.verbose && loggedStop < 20) { ++loggedStop; Log("Screen wall: player %d stopped: player %d at the %s", g_num[me], why,
            whyEdge == 0 ? "left" : whyEdge == 1 ? "right" : whyEdge == 2 ? "bottom" : whyEdge == 3 ? "top" : "off screen"); }
        return false;
    }
    dx /= l; dy /= l;
    static int logged = 0;
    if (g_s.verbose && logged < 20 && (std::fabs(dx - ox) + std::fabs(dy - oy)) > 0.05f) {
        ++logged;
        static const char* kEdge[] = { "left", "right", "bottom", "top", "off screen" };
        Log("Screen wall: player %d slides (%.2f %.2f) -> (%.2f %.2f): player %d at the %s", g_num[me], ox, oy, dx, dy,
            why, whyEdge >= 0 ? kEdge[whyEdge] : kEdge[4]);
    }
    return true;
}

// --- Player 1's stick / WASD: 0x6ADCF0 thiscall(creature, moveDeg, faceDeg, camDeg, run) ---
typedef void (__thiscall* Dm_t)(void*, float, float, float, unsigned);
typedef void (__thiscall* MoveState_t)(void*, int);
static Dm_t g_dm = nullptr;
static unsigned g_lastStickAt = 0;         // Player 1 last steered with the stick / WASD

static void __fastcall HookDm(void* c, void*, float m, float f, float cam, unsigned run)
{
    if (c && c == g_leadObj) g_lastStickAt = GetTickCount();
    if (g_on && c && c == g_leadObj && g_n >= 2) {
        float a = m * 0.01745329f, dx = -std::sin(a), dy = std::cos(a);
        if (!ScreenWallFilter(g_id[0], dx, dy)) {
            int state = *reinterpret_cast<int*>(static_cast<char*>(c) + 0xB20);
            if (state != 0 && state != 3) reinterpret_cast<MoveState_t>(0xA63800)(static_cast<char*>(c) + 0xA30, 3);
            return;
        }
        float h = std::atan2(-dx, dy) * 57.29578f;
        if (h < 0.f) h += 360.f;
        if (std::fabs(h - m) > 0.5f) { m = h; f = h; }
    }
    g_dm(c, m, f, cam, run);
}

void ScreenWallInit(const ScreenWallSettings& s)
{
    g_s = s;
    if (g_s.edge < 0.f) g_s.edge = 0.f;
    if (g_s.edge > 0.3f) g_s.edge = 0.3f;
    if (!s.enabled) { Log("Screen wall: off"); return; }
    static const uint8_t kDm[] = { 0x83, 0xEC, 0x10, 0xD9, 0x05, 0x70, 0x26, 0xAF, 0x00 };
    g_dm = reinterpret_cast<Dm_t>(HookInstall(0x6ADCF0, reinterpret_cast<void*>(&HookDm), 9, kDm, "screen wall (Player 1 movement)"));
    Log("Screen wall: on (%.0f%% edges, pull after %.0f s)%s", g_s.edge * 100.f, g_s.pullSeconds,
        g_dm ? "" : " - Player 1 not held back (hook failed)");
}

void ScreenWallSetPlayers(const uint32_t* ids, const int* num, const float (*pos)[3], int n,
                          bool active, uint32_t hero, unsigned now)
{
    g_hero = hero;
    bool was = g_on;
    g_on = g_s.enabled && active && n >= 2;
    if (!g_on) { g_n = 0; g_leadObj = nullptr; g_blockedBy = 0; if (was) Log("Screen wall: idle"); return; }
    if (!was) Log("Screen wall: active (%d players on screen)", n);
    g_n = n > 3 ? 3 : n;
    for (int i = 0; i < g_n; ++i) {
        g_id[i] = ids[i]; g_num[i] = num[i];
        for (int k = 0; k < 3; ++k) g_pos[i][k] = pos[i][k];
    }
    g_leadObj = game::ClientCreature(g_id[0]);

    static unsigned nextLog = 0;
    if (g_s.verbose && (int)(now - nextLog) >= 0) {
        nextLog = now + 5000;
        char line[200]; int at = 0;
        for (int i = 0; i < g_n && at < 150; ++i) {
            float nx = -1, ny = -1; bool on = false;
            float c[3] = { g_pos[i][0], g_pos[i][1], g_pos[i][2] + kChest };
            Project(c, &nx, &ny, &on);
            at += snprintf(line + at, sizeof(line) - at, " P%d (%.2f %.2f%s)", g_num[i], nx, ny, on ? "" : " off");
        }
        Log("Screen wall: chest on screen (0-1, top left = 0 0)%s", line);
    }

    // Mouse click-to-move (1.2.46): Player 1's character walking a path, not steered by the
    // stick. If the wall would hold that step back, stop the walk (clicking again along or
    // toward the others works; the pull below still brings a stuck partner over).
    {
        static uint32_t lastLead = 0xFFFFFFFF;
        static float last[2];
        static unsigned lastAt = 0, stoppedAt = 0;
        static int logged = 0;
        float vx = g_pos[0][0] - last[0], vy = g_pos[0][1] - last[1];
        float d = std::sqrt(vx * vx + vy * vy), dt = (now - lastAt) / 1000.f;
        bool same = lastLead == g_id[0] && dt > 0.f && dt < 0.5f;
        lastLead = g_id[0]; last[0] = g_pos[0][0]; last[1] = g_pos[0][1]; lastAt = now;
        if (same && d / dt > 1.0f && now - g_lastStickAt > 300 && now - stoppedAt > 250) {
            char* obj = static_cast<char*>(g_leadObj);
            int type = -1;
#ifdef _MSC_VER
            __try { char** q = *reinterpret_cast<char***>(obj + 0x2DC); if (q && *q) type = (unsigned char)(*q)[2]; } __except (1) {}
#else
            if (obj) { char** q = *reinterpret_cast<char***>(obj + 0x2DC); if (q && *q) type = (unsigned char)(*q)[2]; }
#endif
            if (type == 0x0E) {                            // move to a location (clicked ground)
                float dx = vx / d, dy = vy / d, fx = dx, fy = dy;
                bool ok = ScreenWallFilter(g_id[0], fx, fy);
                if (!ok || fx * dx + fy * dy < 0.8f) {
                    script::ClearAllCommands(g_id[0], true);
                    stoppedAt = now;
                    if (logged < 10) { ++logged; Log("Screen wall: Player 1's walk stopped (would leave a partner off screen)"); }
                }
            }
        }
    }

    // Pull: Player 1 kept pushing against a co-op player who stayed put.
    if (g_blockedBy && now - g_blockedAt > 400) g_blockedBy = 0;
    if (g_blockedBy && g_s.pullSeconds > 0.f && now - g_blockSince > (unsigned)(g_s.pullSeconds * 1000.f)) {
        for (int j = 0; j < g_n; ++j) {
            if (g_num[j] != g_blockedBy) continue;
            float mx = g_pos[j][0] - g_blockerPos[0], my = g_pos[j][1] - g_blockerPos[1];
            if (mx * mx + my * my < 1.f && RegroupTeleport(g_blockedBy, g_id[j], g_hero, "Player 1 kept walking"))
                Log("Screen wall: Player %d brought to the Warden (Player 1 pushed %.0f s)", g_blockedBy, g_s.pullSeconds);
        }
        g_blockedBy = 0;
    }
}
