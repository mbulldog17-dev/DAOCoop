#include "pads.h"
#include "log.h"
#include "vpad.h"
#include <cstdlib>

static CRITICAL_SECTION g_lock;
static HANDLE g_thread = nullptr;
static volatile LONG g_running = 0;
static volatile int g_index[COOP_PLAYERS] = { -1, -1 };
static PadSnapshot g_state[COOP_PLAYERS] = {};
static volatile DWORD g_rumbleUntil[COOP_PLAYERS] = {};
static volatile LONG  g_rumbleStrength[COOP_PLAYERS] = {};   // 0..65535
static LONG g_rumbling[COOP_PLAYERS] = {};                   // strength now on the motors
static int g_p1Index = 0;
// Lobby: every slot is watched and new presses are remembered until taken, so
// a quick tap is never missed (whoever reads them, whenever).
static volatile LONG g_scan = 0;
static volatile LONG g_latch[kVPadSlots] = {};
static volatile LONG g_slotConnected[kVPadSlots] = {};                 // Player 1's own controller (for the screen hand-over)
static PadSnapshot g_p1 = {};

static const char* kPlayerName[COOP_PLAYERS] = { "P2", "P3" };

struct ButtonName { WORD mask; const char* name; };
static const ButtonName kButtons[] = {
    { XINPUT_GAMEPAD_A, "A" }, { XINPUT_GAMEPAD_B, "B" },
    { XINPUT_GAMEPAD_X, "X" }, { XINPUT_GAMEPAD_Y, "Y" },
    { XINPUT_GAMEPAD_LEFT_SHOULDER, "LB" }, { XINPUT_GAMEPAD_RIGHT_SHOULDER, "RB" },
    { XINPUT_GAMEPAD_START, "Start" }, { XINPUT_GAMEPAD_BACK, "View" },
    { XINPUT_GAMEPAD_DPAD_UP, "DpadUp" }, { XINPUT_GAMEPAD_DPAD_DOWN, "DpadDown" },
    { XINPUT_GAMEPAD_DPAD_LEFT, "DpadLeft" }, { XINPUT_GAMEPAD_DPAD_RIGHT, "DpadRight" },
    { XINPUT_GAMEPAD_LEFT_THUMB, "LS" }, { XINPUT_GAMEPAD_RIGHT_THUMB, "RS" },
};

static bool StickActive(SHORT x, SHORT y)
{
    return abs(x) > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE || abs(y) > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
}

static DWORD WINAPI PollThread(LPVOID)
{
    PadSnapshot prev[COOP_PLAYERS] = {};
    DWORD nextTry[COOP_PLAYERS] = {};
    while (InterlockedCompareExchange(&g_running, 1, 1)) {
        for (int p = 0; p < COOP_PLAYERS; ++p) {
            PadSnapshot now = {};
            if (g_index[p] >= 0) {
                // XInputGetState on an empty slot is slow, so an unplugged
                // controller is only looked for once a second (drop-in).
                DWORD t = GetTickCount();
                if (prev[p].connected || (int)(t - nextTry[p]) >= 0) {
                    XINPUT_STATE s = {};
                    if (VPadGetState((DWORD)g_index[p], &s) == ERROR_SUCCESS) {
                        now.connected = true;
                        now.gamepad = s.Gamepad;
                    } else {
                        nextTry[p] = t + 1000;
                    }
                }
            }

            // Log what changed so we can confirm input end to end.
            if (now.connected != prev[p].connected)
                Log("%s controller (pad %d) %s", kPlayerName[p], g_index[p],
                    now.connected ? "connected" : "disconnected");
            WORD pressed = now.gamepad.wButtons & ~prev[p].gamepad.wButtons;
            for (const ButtonName& b : kButtons)
                if (pressed & b.mask) Log("%s pressed %s", kPlayerName[p], b.name);
            bool moving = StickActive(now.gamepad.sThumbLX, now.gamepad.sThumbLY);
            bool wasMoving = StickActive(prev[p].gamepad.sThumbLX, prev[p].gamepad.sThumbLY);
            if (moving != wasMoving)
                Log("%s left stick %s", kPlayerName[p], moving ? "moving" : "released");

            // Short rumble requested by PadsRumble (lobby join / ready feedback).
            LONG want = (now.connected && (int)(g_rumbleUntil[p] - GetTickCount()) > 0) ? g_rumbleStrength[p] : 0;
            if (want != g_rumbling[p] && g_index[p] >= 0 && now.connected) {
                XINPUT_VIBRATION v = {};
                v.wLeftMotorSpeed = (WORD)want;
                v.wRightMotorSpeed = (WORD)(want * 3 / 4);
                if (g_index[p] < 4) XInputSetState((DWORD)g_index[p], &v);   // (online friends: no rumble yet)
                g_rumbling[p] = want;
            }

            EnterCriticalSection(&g_lock);
            g_state[p] = now;
            LeaveCriticalSection(&g_lock);
            prev[p] = now;
        }
        // Lobby: watch all four slots.
        if (InterlockedCompareExchange(&g_scan, 0, 0)) {
            static WORD prevB[kVPadSlots] = {};
            static DWORD nextTrySlot[kVPadSlots] = {};
            DWORD t = GetTickCount();
            for (int slot = 0; slot < kVPadSlots; ++slot) {   // 4/5: online friends (vpad.h)
                if (!g_slotConnected[slot] && (int)(t - nextTrySlot[slot]) < 0) continue;
                XINPUT_STATE st = {};
                if (VPadGetState((DWORD)slot, &st) != ERROR_SUCCESS) {
                    if (g_slotConnected[slot]) Log("Lobby scan: controller slot %d disconnected", slot);
                    InterlockedExchange(&g_slotConnected[slot], 0);
                    nextTrySlot[slot] = t + 1000;
                    prevB[slot] = 0;
                    continue;
                }
                if (!g_slotConnected[slot]) {
                    Log("Lobby scan: controller slot %d connected", slot);
                    prevB[slot] = st.Gamepad.wButtons;          // already held: not a press
                }
                InterlockedExchange(&g_slotConnected[slot], 1);
                WORD pressedNow = st.Gamepad.wButtons & ~prevB[slot];
                prevB[slot] = st.Gamepad.wButtons;
                if (pressedNow) {
                    InterlockedOr(&g_latch[slot], pressedNow);
                    for (const ButtonName& b : kButtons)
                        if (pressedNow & b.mask) Log("Lobby scan: slot %d pressed %s", slot, b.name);
                }
            }
        }

        // Player 1's controller (only read here, never routed): screen hand-over button.
        {
            static DWORD p1Next = 0;
            PadSnapshot now = {};
            DWORD t = GetTickCount();
            if (g_p1Index >= 0 && (g_p1.connected || (int)(t - p1Next) >= 0)) {
                XINPUT_STATE s = {};
                if (VPadGetState((DWORD)g_p1Index, &s) == ERROR_SUCCESS) { now.connected = true; now.gamepad = s.Gamepad; }
                else p1Next = t + 1000;
            }
            EnterCriticalSection(&g_lock);
            g_p1 = now;
            LeaveCriticalSection(&g_lock);
        }
        Sleep(16); // ~60 polls a second
    }
    return 0;
}

void PadsStart(int p2Index, int p3Index)
{
    InitializeCriticalSection(&g_lock);
    g_index[PLAYER_2] = p2Index;
    g_index[PLAYER_3] = p3Index;
    Log("Controller assignment: P2 = pad %d, P3 = pad %d", p2Index, p3Index);
    InterlockedExchange(&g_running, 1);
    g_thread = CreateThread(nullptr, 0, PollThread, nullptr, 0, nullptr);
}

void PadsStop()
{
    InterlockedExchange(&g_running, 0);
    if (g_thread) {
        WaitForSingleObject(g_thread, 500);
        CloseHandle(g_thread);
        g_thread = nullptr;
    }
}

PadSnapshot PadsGet(CoopPlayer player)
{
    EnterCriticalSection(&g_lock);
    PadSnapshot s = g_state[player];
    LeaveCriticalSection(&g_lock);
    return s;
}

void PadsRumble(CoopPlayer player, int ms, int strength)
{
    if (strength < 0) strength = 0;
    if (strength > 65535) strength = 65535;
    // A stronger request wins over a weaker one that is still running.
    bool running = (int)(g_rumbleUntil[player] - GetTickCount()) > 0;
    if (running && strength < g_rumbleStrength[player]) return;
    g_rumbleStrength[player] = strength;
    g_rumbleUntil[player] = GetTickCount() + (DWORD)ms;
}

void PadsSetP1Index(int index) { g_p1Index = index; }

PadSnapshot PadsGetP1()
{
    EnterCriticalSection(&g_lock);
    PadSnapshot s = g_p1;
    LeaveCriticalSection(&g_lock);
    return s;
}

int PadsIndex(CoopPlayer player) { return g_index[player]; }

void PadsAssign(CoopPlayer player, int index)
{
    if (g_index[player] == index) return;
    Log("Controller assignment: %s = pad %d (was %d)", kPlayerName[player], index, g_index[player]);
    g_index[player] = index;
}

int PadsP1Index() { return g_p1Index; }

// Raw read of any slot (lobby: who pressed START?). Cheap for connected pads;
// callers throttle empty slots themselves.
bool PadsReadSlot(int index, XINPUT_GAMEPAD* out)
{
    XINPUT_STATE s = {};
    if (index < 0 || index >= kVPadSlots || VPadGetState((DWORD)index, &s) != ERROR_SUCCESS) return false;
    *out = s.Gamepad;
    return true;
}

void PadsScanSlots(bool on)
{
    if (on) for (int i = 0; i < kVPadSlots; ++i) InterlockedExchange(&g_latch[i], 0);
    InterlockedExchange(&g_scan, on ? 1 : 0);
    Log("Lobby scan: %s", on ? "watching all controller slots" : "off");
}

WORD PadsTakePressed(int slot)
{
    if (slot < 0 || slot >= kVPadSlots) return 0;
    return (WORD)InterlockedExchange(&g_latch[slot], 0);
}

bool PadsSlotConnected(int slot)
{
    return slot >= 0 && slot < kVPadSlots && InterlockedCompareExchange(&g_slotConnected[slot], 0, 0) != 0;
}
