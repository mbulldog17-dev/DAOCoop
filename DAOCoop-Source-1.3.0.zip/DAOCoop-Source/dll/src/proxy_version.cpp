// Forwards every documented export of the system version.dll.
// The game loads our version.dll from bin_ship first; each call here is passed
// straight through to the real one in the Windows system folder.
#include <windows.h>

static HMODULE g_real = nullptr;

static FARPROC Real(const char* name)
{
    if (!g_real) {
        wchar_t path[MAX_PATH];
        GetSystemDirectoryW(path, MAX_PATH); // 32-bit process: Windows redirects this to SysWOW64
        lstrcatW(path, L"\\version.dll");
        g_real = LoadLibraryW(path);
    }
    return g_real ? GetProcAddress(g_real, name) : nullptr;
}

#define FORWARD(ret, name, params, args)                                  \
    extern "C" ret WINAPI Proxy_##name params                             \
    {                                                                     \
        typedef ret (WINAPI* fn_t) params;                                \
        static fn_t fn = (fn_t)Real(#name);                               \
        return fn ? fn args : (ret)0;                                     \
    }

FORWARD(BOOL,  GetFileVersionInfoA,      (LPCSTR f, DWORD h, DWORD n, LPVOID d), (f, h, n, d))
FORWARD(BOOL,  GetFileVersionInfoW,      (LPCWSTR f, DWORD h, DWORD n, LPVOID d), (f, h, n, d))
FORWARD(BOOL,  GetFileVersionInfoExA,    (DWORD fl, LPCSTR f, DWORD h, DWORD n, LPVOID d), (fl, f, h, n, d))
FORWARD(BOOL,  GetFileVersionInfoExW,    (DWORD fl, LPCWSTR f, DWORD h, DWORD n, LPVOID d), (fl, f, h, n, d))
FORWARD(DWORD, GetFileVersionInfoSizeA,  (LPCSTR f, LPDWORD h), (f, h))
FORWARD(DWORD, GetFileVersionInfoSizeW,  (LPCWSTR f, LPDWORD h), (f, h))
FORWARD(DWORD, GetFileVersionInfoSizeExA,(DWORD fl, LPCSTR f, LPDWORD h), (fl, f, h))
FORWARD(DWORD, GetFileVersionInfoSizeExW,(DWORD fl, LPCWSTR f, LPDWORD h), (fl, f, h))
FORWARD(DWORD, VerFindFileA,  (DWORD fl, LPCSTR a, LPCSTR b, LPCSTR c, LPSTR d, PUINT e, LPSTR g, PUINT h), (fl, a, b, c, d, e, g, h))
FORWARD(DWORD, VerFindFileW,  (DWORD fl, LPCWSTR a, LPCWSTR b, LPCWSTR c, LPWSTR d, PUINT e, LPWSTR g, PUINT h), (fl, a, b, c, d, e, g, h))
FORWARD(DWORD, VerInstallFileA, (DWORD fl, LPCSTR a, LPCSTR b, LPCSTR c, LPCSTR d, LPCSTR e, LPSTR g, PUINT h), (fl, a, b, c, d, e, g, h))
FORWARD(DWORD, VerInstallFileW, (DWORD fl, LPCWSTR a, LPCWSTR b, LPCWSTR c, LPCWSTR d, LPCWSTR e, LPWSTR g, PUINT h), (fl, a, b, c, d, e, g, h))
FORWARD(DWORD, VerLanguageNameA, (DWORD l, LPSTR s, DWORD n), (l, s, n))
FORWARD(DWORD, VerLanguageNameW, (DWORD l, LPWSTR s, DWORD n), (l, s, n))
FORWARD(BOOL,  VerQueryValueA, (LPCVOID b, LPCSTR s, LPVOID* p, PUINT n), (b, s, p, n))
FORWARD(BOOL,  VerQueryValueW, (LPCVOID b, LPCWSTR s, LPVOID* p, PUINT n), (b, s, p, n))
