#pragma once
// Co-op lobby behind the "Co-op" button on the start menu (startmenu2.gfx).
//
// The menu movie talks to us through the game's own ExternalInterface
// "GetValue" handler (0x51EC60, cdecl(holder, args, argc)): we hook it and
// answer every name that starts with "DAOCoop." ourselves, everything else
// goes to the game. The answer is returned the way the game does it: a
// wide-string GFxValue {type 5, -, wchar_t*} through the movie's
// SetExternalInterfaceRetVal (vtable +0xA8; movie = holder+0x1C).
//
//   DAOCoop.Version            -> "0.8.0" (no answer = mod not loaded: no button)
//   DAOCoop.Cmd.Open / Close   -> lobby on / off
//   DAOCoop.Cmd.Mode.local|host|join
//   DAOCoop.Cmd.Players.2|3
//   DAOCoop.Cmd.Ready.1|0      -> Player 1 ready
//   DAOCoop.Cmd.Launch         -> "ok" when everyone is ready: the session is
//                                 stored, then the movie starts a new game
//   DAOCoop.Cmd.SinglePlayer   -> plain "New Game": co-op off for this game
//   DAOCoop.Floaty.<id>        -> "2"/"3" when off-screen arrow floaty <id> belongs to
//                                 that player's character (floatylayer.gfx), else "0"
//   DAOCoop.Lobby              -> "allReady|canStart|<code><line>|..."
//                                 codes: H header, R ready, W waiting, X missing
//
// Local lobby: Players 2/3 press START (or A) on their controller to join, A
// to get ready, B to step back. Online (host/join) is menus only for now:
// the hooks for a network layer are the LobbyNet* functions in lobby.cpp.
#include <cstdint>

struct LobbySettings {
    bool enabled;
    bool slotsFromLobby;     // a lobby game sets the HUD party slots to 3 + players
    int  padP2, padP3;       // controller slots, for the on-screen hints
    bool offscreenArrows;    // answer DAOCoop.Floaty.<id> for the coloured off-screen arrows
    bool assignInLobby;      // controller order: first free controller to press START = Player 2
};

void LobbyInit(const LobbySettings& s, const wchar_t* iniPath);
void LobbyTick(unsigned nowMs);          // main thread, every tick (controllers in the lobby)
// The session the last game was started with ([Session] in DAOCoop.ini):
// applied at startup so loading a save keeps its player count.
void LobbyApplySavedSession();
