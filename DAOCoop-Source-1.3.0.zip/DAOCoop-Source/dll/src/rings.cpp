#include "rings.h"
#include "screenwall.h"
#include "d3d9hook.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cmath>

static RingSettings g_s;
static const int kSeg = 40;

struct RingVerts { int n; float x[(kSeg + 1) * 2], y[(kSeg + 1) * 2]; uint32_t argb; };
static RingVerts g_ring[2];
static int g_count = 0;
static CRITICAL_SECTION g_lock;
static bool g_init = false;

void RingsSetPlayers(const float (*pos)[3], const uint32_t* rgb, int n, bool combat, bool active)
{
    if (!g_init) return;
    bool show = active && (g_s.mode == 2 || (g_s.mode == 1 && combat));
    RingVerts tmp[2];
    int c = 0;
    int w = 0, h = 0;
    if (show && D3D9BackBufferSize(&w, &h)) {
        for (int i = 0; i < n && i < 2; ++i) {
            RingVerts& r = tmp[c];
            bool ok = true;
            for (int k = 0; k <= kSeg && ok; ++k) {
                float a = 6.2831853f * k / kSeg, ca = std::cos(a), sa = std::sin(a);
                for (int side = 0; side < 2; ++side) {
                    float rad = g_s.radius * (side ? 0.82f : 1.f);
                    float p[3] = { pos[i][0] + ca * rad, pos[i][1] + sa * rad, pos[i][2] + 0.05f };
                    float nx, ny; bool on;
                    if (!ScreenWallProject(p, &nx, &ny, &on) || nx < -2.f || nx > 3.f || ny < -2.f || ny > 3.f) { ok = false; break; }
                    r.x[k * 2 + side] = nx * w - 0.5f; r.y[k * 2 + side] = ny * h - 0.5f;
                }
            }
            if (!ok) continue;
            r.n = (kSeg + 1) * 2;
            r.argb = ((uint32_t)(g_s.alpha & 0xFF) << 24) | (rgb[i] & 0xFFFFFF);
            ++c;
        }
    }
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < c; ++i) g_ring[i] = tmp[i];
    g_count = c;
    LeaveCriticalSection(&g_lock);
}

struct Vtx { float x, y, z, rhw; DWORD c; };

static void Draw(IDirect3DDevice9* dev)
{
    RingVerts r[2];
    int c;
    EnterCriticalSection(&g_lock);
    c = g_count;
    for (int i = 0; i < c; ++i) r[i] = g_ring[i];
    LeaveCriticalSection(&g_lock);
    if (!c) return;

    IDirect3DStateBlock9* sb = nullptr;
    if (FAILED(dev->CreateStateBlock(D3DSBT_ALL, &sb)) || !sb) return;
    IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
    dev->GetRenderTarget(0, &oldRt);
    dev->GetDepthStencilSurface(&oldDs);
    if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
        dev->SetRenderTarget(0, bb);
        dev->SetDepthStencilSurface(nullptr);
        if (SUCCEEDED(dev->BeginScene())) {
            dev->SetVertexShader(nullptr);
            dev->SetPixelShader(nullptr);
            dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);
            dev->SetTexture(0, nullptr);
            dev->SetRenderState(D3DRS_ZENABLE, FALSE);
            dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
            dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
            dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
            dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
            dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
            dev->SetRenderState(D3DRS_LIGHTING, FALSE);
            dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
            dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
            dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
            dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
            dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
            dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
            dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
            dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
            dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
            D3DSURFACE_DESC d;
            if (SUCCEEDED(bb->GetDesc(&d))) {
                D3DVIEWPORT9 vp = { 0, 0, d.Width, d.Height, 0.f, 1.f };
                dev->SetViewport(&vp);
            }
            for (int i = 0; i < c; ++i) {
                Vtx v[(kSeg + 1) * 2];
                for (int k = 0; k < r[i].n; ++k) {
                    v[k].x = r[i].x[k]; v[k].y = r[i].y[k];
                    v[k].z = 0.f; v[k].rhw = 1.f; v[k].c = r[i].argb;
                }
                dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, r[i].n - 2, v, sizeof(Vtx));
            }
            dev->EndScene();
        }
        bb->Release();
    }
    if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
    dev->SetDepthStencilSurface(oldDs);
    if (oldDs) oldDs->Release();
    sb->Apply();
    sb->Release();
}

void RingsInit(const RingSettings& s)
{
    g_s = s;
    if (g_s.radius < 0.3f) g_s.radius = 0.3f;
    if (g_s.radius > 2.f) g_s.radius = 2.f;
    if (!g_init) { InitializeCriticalSection(&g_lock); g_init = true; }
    if (g_s.mode <= 0) { Log("Player rings: off"); D3D9SetOverlay(nullptr); return; }
    D3D9SetOverlay(&Draw);
    Log("Player rings: on (%s, %.1f m)", g_s.mode == 2 ? "always" : "in combat", g_s.radius);
}
