#include "scaling.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <cmath>
#include <set>

static ScalingSettings g_s;
static unsigned g_next = 0;
static std::set<uint32_t> g_done;        // this area's scaled creatures (backup for the Age mark)
static uint32_t g_area = 0xFFFFFFFF;

static const int kHealth = 7, kAge = 18;
static const int kAttr[] = { 1, 2, 4 };          // Strength, Dexterity, Magic
static const int kBase = 2, kCurrent = 3;
static const float kMark = 1777.f;

void ScalingInit(const ScalingSettings& s)
{
    g_s = s;
    Log("Enemy scaling: %s (+%.0f%% per extra player%s)", s.enabled ? "on" : "off", s.perPlayer * 100.f,
        s.attributes ? ", health and damage" : ", health only");
}

static void ScaleOne(uint32_t c, float f)
{
    if (g_done.count(c)) return;
    float age = script::GetCreatureProperty(c, kAge, kBase);
    if (std::fabs(age - kMark) < 0.5f) return;                  // already scaled (also after loading)
    float maxHp = script::GetCreatureProperty(c, kHealth, kBase);
    float hp = script::GetCreatureProperty(c, kHealth, kCurrent);
    if (!(maxHp > 0.f) || hp < 0.f) return;
    script::SetCreatureProperty(c, kHealth, maxHp * f, kBase);
    script::SetCreatureProperty(c, kHealth, hp * f, kCurrent);
    if (g_s.attributes) {
        for (int a : kAttr) {
            float v = script::GetCreatureProperty(c, a, kBase);
            if (v > 10.f) script::SetCreatureProperty(c, a, 10.f + (v - 10.f) * f, kBase);
        }
    }
    script::SetCreatureProperty(c, kAge, kMark, kBase);
    g_done.insert(c);
    if (std::fabs(script::GetCreatureProperty(c, kAge, kBase) - kMark) > 0.5f) {
        static bool warned = false;
        if (!warned) { warned = true; Log("Enemy scaling: the Age mark doesn't stick - a save/load may scale enemies again"); }
    }
    static int logged = 0;
    if (logged < 25) {
        ++logged;
        wchar_t name[64];
        if (!script::GetName(c, name, 64)) name[0] = 0;
        Log("Enemy scaling: \"%ls\" x%.2f (health %.0f -> %.0f)", name, f, maxHp, maxHp * f);
    }
}

void ScalingTick(unsigned now, uint32_t hero, int creatureType, int players)
{
    if (!g_s.enabled || players < 2 || hero == game::kInvalidObject) return;
    if ((int)(now - g_next) < 0) return;
    g_next = now + 1500;
    uint32_t area = script::GetArea(hero);
    if (area != g_area) { g_area = area; g_done.clear(); }      // object ids are per area load
    float f = 1.f + g_s.perPlayer * (players - 1);
    // Hostiles near the party, perceived or not (scaled before the fight starts).
    uint32_t list[32];
    int n = script::GetNearestByHostility(hero, true, creatureType, list, 32, true, false);
    for (int i = 0; i < n; ++i) ScaleOne(list[i], f);
}
