#pragma once
// In-game probes: the mod's own "debugger". Hooks on engine functions that
// only write to DAOCoop.log (who called, with what, what came back), rate
// limited. [Debug] Probes=1 (default on while we investigate).
void ProbesInit(bool on);
void ProbesTick(unsigned nowMs, bool playable);   // control-switch experiment
