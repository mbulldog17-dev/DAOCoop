#pragma once
// Minimal x86 detours for DAOrigins.exe functions whose first instructions
// we have checked by hand (no relative jumps/calls in the stolen bytes).
#include <cstdint>
#include <cstddef>

// Replaces the first `stolen` bytes at `target` with a JMP to `hook` after
// checking they equal `expect`. Returns a trampoline that runs the original
// function, or nullptr (logged) on failure.
void* HookInstall(uintptr_t target, void* hook, size_t stolen, const uint8_t* expect, const char* name);

// Writes `count` bytes at `address` after checking the old bytes. Logged.
bool PatchBytes(uintptr_t address, const uint8_t* expect, const uint8_t* bytes, size_t count, const char* name);
