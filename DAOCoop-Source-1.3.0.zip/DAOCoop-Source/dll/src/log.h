#pragma once
// Simple thread-safe file logger.
// LogInit returns false when the file can't be created (for example a folder
// the game isn't allowed to write to), so the caller can try somewhere else.
bool LogInit(const wchar_t* path);
void Log(const char* fmt, ...);
void LogShutdown();
