#pragma once
// 1.2.44: shared-screen wall. Nobody can walk off the screen, and nobody can walk away
// from a player who is already at the edge of it (the camera would follow and push that
// player out). Everyone slides along the edge instead, like couch co-op games.
//
// Screen positions come from the game's own projection (the one the off-screen arrows
// use): renderer *0xC31650 -> vtbl+0x24 -> +0xC0 = camera, camera vtbl+0x4C
// thiscall(cam, vec4 world, float* x, float* y, bool* onScreen), x/y in back buffer pixels.
// Player 1's stick/WASD movement goes through 0x6ADCF0 (hooked here); Players 2/3 call
// ScreenWallFilter from the controller code.
#include <cstdint>

struct ScreenWallSettings {
    bool  enabled;
    float edge;          // fraction of the screen kept free at each side (0.08 = 8%)
    float pullSeconds;   // Player 1 pushing this long against a co-op player who isn't
                         // moving -> that player is brought over (0 = never)
    bool  verbose;
};

void ScreenWallInit(const ScreenWallSettings& s);
// Main tick: who is on screen (Player 1's character first). num = player number (1-3).
void ScreenWallSetPlayers(const uint32_t* ids, const int* num, const float (*pos)[3], int n,
                          bool active, uint32_t hero, unsigned now);
// Trims a ground move direction (dx, dy; unit) for `mover`. Returns false when nothing of
// it is left (stop). dx, dy stay unit length when it returns true.
bool ScreenWallFilter(uint32_t mover, float& dx, float& dy);
// The game's projection: world point -> 0..1 screen position (top left 0 0). Game thread only.
bool ScreenWallProject(const float p[3], float* nx, float* ny, bool* on);
