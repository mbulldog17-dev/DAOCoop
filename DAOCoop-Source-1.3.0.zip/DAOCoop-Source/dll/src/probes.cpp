#include "probes.h"
#include "hooks.h"
#include "game.h"
#include "script.h"
#include "log.h"
#include "equiplock.h"
#include <windows.h>
#include <vector>
#include <cstring>

// Which creature is this client object? (Warden / Player 2 / Player 3 / other)
static const char* Who(void* obj)
{
    if (!obj) return "null";
    if (obj == game::ClientCreature(game::HeroId())) return "Warden";
    if (obj == game::ClientCreature(CoopCharacterOf(2))) return "Player2";
    if (obj == game::ClientCreature(CoopCharacterOf(3))) return "Player3";
    return "other";
}

// At most `max` lines per 10 s per probe.
struct Budget { unsigned windowStart = 0; int used = 0; };
static bool Allow(Budget& b, int max)
{
    unsigned now = GetTickCount();
    if (now - b.windowStart > 10000) { b.windowStart = now; b.used = 0; }
    return b.used++ < max;
}

#ifdef _MSC_VER
static int ReadByte(void* p, int off) { __try { return *((unsigned char*)p + off); } __except (1) { return -1; } }
static int ReadInt(void* p, int off)  { __try { return *(int*)((char*)p + off); } __except (1) { return -1; } }
#else
static int ReadByte(void* p, int off) { return p ? *((unsigned char*)p + off) : -1; }
static int ReadInt(void* p, int off)  { return p ? *(int*)((char*)p + off) : -1; }
#endif

// --- 0x6ADCF0: free movement entry (creature, moveDeg, faceDeg, camDeg, run) ---
typedef void (__thiscall* Dm_t)(void*, float, float, float, unsigned);
static Dm_t g_dm = nullptr;
static Budget g_bDm;
static void __fastcall ProbeDm(void* c, void*, float m, float f, float cam, unsigned run)
{
    if (Allow(g_bDm, 30))
        Log("PROBE free-move %s %p move %.0f face %.0f cam %.0f run %u | isHero %d state %d moving %d",
            Who(c), c, m, f, cam, run, ReadByte(c, 0x7D4), ReadInt(c, 0xB20), ReadByte(c, 0xB24));
    g_dm(c, m, f, cam, run);
}

// --- 0x6A21C0: builds the type-0x21 move action on the creature ---
typedef int (__thiscall* Act_t)(void*, float, float, float, unsigned char);
static Act_t g_act = nullptr;
static Budget g_bAct;
static int __fastcall ProbeAct(void* c, void*, float m, float f, float cam, unsigned char run)
{
    int r = g_act(c, m, f, cam, run);
    if (Allow(g_bAct, 30)) Log("PROBE   move-action queued on %s %p -> %d", Who(c), c, r);
    return r;
}

// --- 0x7A4100: type-0x21 action handler (stdcall(param, action)) ---
typedef int (__stdcall* H21_t)(void*, int*);
static H21_t g_h21 = nullptr;
static Budget g_bH21;
typedef void* (__thiscall* Owner_t)(int*);
static void* ActionOwner(int* a)
{
#ifdef _MSC_VER
    __try { return reinterpret_cast<Owner_t>((*reinterpret_cast<void***>(a))[0x10 / 4])(a); }
    __except (1) { return nullptr; }
#else
    return reinterpret_cast<Owner_t>((*reinterpret_cast<void***>(a))[0x10 / 4])(a);
#endif
}
static int __stdcall ProbeH21(void* p, int* action)
{
    void* owner = action ? ActionOwner(action) : nullptr;
    int r = g_h21(p, action);
    if (Allow(g_bH21, 30)) Log("PROBE     action-21 handler for %s %p -> %d (1 = moved, 0 = skipped, -1 = rejected)", Who(owner), owner, r);
    return r;
}

// --- 0x73CD10: add an action to a creature's queue (creature, action, front, clearMode) ---
typedef int (__thiscall* Q_t)(void*, void*, int, int);
static Q_t g_q = nullptr;
static Budget g_bQ;
static int __fastcall ProbeQ(void* c, void*, void* action, int front, int mode)
{
    const char* who = Who(c);
    int type = action ? ReadByte(action, 2) : -1;
    int r = g_q(c, action, front, mode);
    if ((who[0] != 'o') && Allow(g_bQ, 40))
        Log("PROBE       queue add on %s %p: action type 0x%02X front %d mode %d -> %d", who, c, type, front, mode, r);
    return r;
}


// --- 1.2.42: the direct-move path past the queue -------------------------
// 0x745870 thiscall(cmd, x, creature): starts a queued type-0x21 command (-> action 0x10)
typedef int (__thiscall* Start21_t)(void*, void*, int*);
static Start21_t g_start21 = nullptr;
static Budget g_bStart21;
static int __fastcall ProbeStart21(void* cmd, void*, void* x, int* h)
{
    int r = g_start21(cmd, x, h);
    if (Allow(g_bStart21, 30)) Log("PROBE   free-move command started for %s %p -> %d", Who(h), h, r);
    return r;
}

// 0x7A2AE0 stdcall(creature): "should this move stop" check used by the executor
typedef char (__stdcall* Stop_t)(void*);
static Stop_t g_stop = nullptr;
static Budget g_bStop;
static char __stdcall ProbeStop(void* c)
{
    char r = g_stop(c);
    const char* who = Who(c);
    if (who[0] != 'o' && r && Allow(g_bStop, 20))
        Log("PROBE       stop-check on %s %p says STOP (+0x70 flags %08X)", who, c, ReadInt(c, 0x70));
    return r;
}

// 0x73D320 thiscall(creature, a, b): per-creature command update
typedef void (__thiscall* Upd_t)(void*, void*, void*);
static Upd_t g_upd = nullptr;
struct UpdStat { unsigned at = 0; int calls = 0, active = 0; };
static UpdStat g_updStat[3];
static void __fastcall ProbeUpd(void* c, void*, void* a, void* b)
{
    const char* who = Who(c);
    int k = who[0] == 'W' ? 0 : (who[6] == '2' ? 1 : (who[6] == '3' ? 2 : -1));
    if (who[0] == 'o' || who[0] == 'n') k = -1;
    if (k >= 0) {
        UpdStat& s = g_updStat[k];
        ++s.calls;
        if (ReadByte(c, 0x2C5) > 0) ++s.active;
        unsigned now = GetTickCount();
        if (now - s.at > 3000) {
            int q = ReadInt(c, 0x2DC), front = q > 0 ? ReadInt((void*)q, 0) : -1;
            Log("PROBE command update %s %p: %d calls / %d with +0x2C5 on in 3 s | now +0x2C5 %d queue front type 0x%02X busy %d",
                who, c, s.calls, s.active, ReadByte(c, 0x2C5), front > 0 ? ReadByte((void*)front, 2) : -1,
                q > 0 ? ReadInt((void*)q, 0x14) : -1);
            s.at = now; s.calls = 0; s.active = 0;
        }
    }
    g_upd(c, a, b);
}

void ProbesInit(bool on)
{
    if (!on) { Log("Probes: off"); return; }
    static const uint8_t kDm[]  = { 0x83, 0xEC, 0x10, 0xD9, 0x05, 0x70, 0x26, 0xAF, 0x00 };
    static const uint8_t kAct[] = { 0x6A, 0xFF, 0x68, 0x1B, 0xD5, 0xAB, 0x00 };
    static const uint8_t kH21[] = { 0x55, 0x8B, 0xEC, 0x83, 0xE4, 0xF0, 0x83, 0xEC, 0x54 };
    g_dm  = reinterpret_cast<Dm_t>(HookInstall(0x6ADCF0, reinterpret_cast<void*>(&ProbeDm), 9, kDm, "probe free-move"));
    g_act = reinterpret_cast<Act_t>(HookInstall(0x6A21C0, reinterpret_cast<void*>(&ProbeAct), 7, kAct, "probe move-action"));
    g_h21 = reinterpret_cast<H21_t>(HookInstall(0x7A4100, reinterpret_cast<void*>(&ProbeH21), 9, kH21, "probe action-21 handler"));
    static const uint8_t kQ[] = { 0x6A, 0xFF, 0x68, 0x8B, 0xC3, 0xA9, 0x00 };
    g_q = reinterpret_cast<Q_t>(HookInstall(0x73CD10, reinterpret_cast<void*>(&ProbeQ), 7, kQ, "probe action queue"));
    static const uint8_t kStart21[] = { 0x6A, 0xFF, 0x68, 0xCB, 0x6E, 0xAB, 0x00 };
    static const uint8_t kStop[]    = { 0x56, 0x8B, 0x74, 0x24, 0x08 };
    static const uint8_t kUpd[]     = { 0x6A, 0xFF, 0x68, 0xB6, 0xF5, 0xAA, 0x00 };
    g_start21 = reinterpret_cast<Start21_t>(HookInstall(0x745870, reinterpret_cast<void*>(&ProbeStart21), 7, kStart21, "probe free-move start"));
    g_stop    = reinterpret_cast<Stop_t>(HookInstall(0x7A2AE0, reinterpret_cast<void*>(&ProbeStop), 5, kStop, "probe stop check"));
    g_upd     = reinterpret_cast<Upd_t>(HookInstall(0x73D320, reinterpret_cast<void*>(&ProbeUpd), 7, kUpd, "probe command update"));
    Log("Probes: on (free movement path)");
}

// ---------------------------------------------------------------------------
// Control-switch experiment (once per run, probes on): what in Player 2's
// client creature changes when it becomes the character Player 1 controls?
// Snapshot it, select it for one tick, snapshot again, select the Warden back.
// The differences are the "this creature is driven locally" state that free
// movement needs (the Warden's free-move actions start, Player 2's never do).
// ---------------------------------------------------------------------------
static const int kObjSize = 0xD20;               // client creature size (new 0xD20 in 0x6B9ED0)
static std::vector<unsigned char> g_snapA, g_snapB;
static int g_expStage = -1;   // done (1.2.19): off
static unsigned g_expAt = 0;
static uint32_t g_expP2 = 0xFFFFFFFF, g_expWarden = 0xFFFFFFFF;

static bool Snap(uint32_t id, std::vector<unsigned char>& out)
{
    void* o = game::ClientCreature(id);
    if (!o) return false;
    out.resize(kObjSize);
#ifdef _MSC_VER
    __try { memcpy(out.data(), o, kObjSize); } __except (1) { return false; }
#else
    memcpy(out.data(), o, kObjSize);
#endif
    return true;
}

static void LogDiff(const char* what, const std::vector<unsigned char>& a, const std::vector<unsigned char>& b)
{
    int shown = 0;
    for (int off = 0; off + 4 <= kObjSize && shown < 80; off += 4) {
        uint32_t x, y;
        memcpy(&x, &a[off], 4); memcpy(&y, &b[off], 4);
        if (x == y) continue;
        Log("PROBE diff %s +0x%03X: %08X -> %08X", what, off, x, y);
        ++shown;
    }
    Log("PROBE diff %s: %d changed dwords shown", what, shown);
}

void ProbesTick(unsigned now, bool playable)
{
    if (!g_q || g_expStage < 0 || !playable) return;
    if (g_expStage == 0) {
        uint32_t p2 = CoopCharacterOf(2), w = game::HeroId();
        if (p2 == 0xFFFFFFFF || w == 0xFFFFFFFF || script::GetControlled() != w) return;
        if (!g_expAt) { g_expAt = now + 5000; return; }            // let things settle after loading
        if ((int)(now - g_expAt) < 0) return;
        if (!Snap(p2, g_snapA)) return;
        g_expP2 = p2; g_expWarden = w;
        EquipLockAllowControl(3000);
        script::SetPrimaryControlled(p2);
        Log("PROBE control experiment: Player 2 (0x%08X) selected for a moment", p2);
        g_expStage = 1; g_expAt = now + 300;
        return;
    }
    if ((int)(now - g_expAt) < 0) return;
    if (g_expStage == 1) {
        Snap(g_expP2, g_snapB);
        script::SetPrimaryControlled(g_expWarden);
        Log("PROBE control experiment: the Warden selected again (controlled now 0x%08X)", script::GetControlled());
        if (g_snapA.size() == (size_t)kObjSize && g_snapB.size() == (size_t)kObjSize) LogDiff("Player2 not-controlled -> controlled", g_snapA, g_snapB);
        g_expStage = 2; g_expAt = now + 300;
        return;
    }
    if (g_expStage == 2) {
        std::vector<unsigned char> c;
        if (Snap(g_expP2, c) && g_snapB.size() == (size_t)kObjSize) LogDiff("Player2 controlled -> released", g_snapB, c);
        g_expStage = -1;
    }
}
