#include "tick.h"
#include "log.h"
#include "hooks.h"
#include <windows.h>

static HWND     g_wnd = nullptr;
static WNDPROC  g_oldProc = nullptr;
static TickFn   g_fn = nullptr;
static bool     g_timerOn = false;
static const UINT_PTR kTimerId = 0xDA0C;
static const UINT     kStartMsg = WM_APP + 0x3A1;   // "start the timer" (sent from our thread)

// The game runs its frames on a worker thread, not on the window's thread
// (seen in a crash dump: the frame 0x412EB0 is called from a task thread),
// so the real "main thread" tick comes from a hook on the frame function.
// The window timer is only a fallback when that hook can't be installed.
typedef unsigned (__fastcall* Frame_t)(void* app, void* edx);
static Frame_t g_origFrame = nullptr;
static volatile LONG g_frameTicks = 0;
static DWORD g_lastFrameTick = 0;

static unsigned __fastcall HookFrame(void* app, void* edx)
{
    unsigned r = g_origFrame(app, edx);
    DWORD now = GetTickCount();
    if (g_fn && now - g_lastFrameTick >= 30) {
        g_lastFrameTick = now;
        if (InterlockedIncrement(&g_frameTicks) == 1)
            Log("Main-thread tick: running in the game's frame (thread %lu)", GetCurrentThreadId());
        g_fn(now);
    }
    return r;
}

static void InstallFrameHook()
{
    if (g_origFrame) return;
    static const uint8_t kPrologue[] = { 0x83, 0xEC, 0x08, 0x56, 0x8B, 0xF1 };   // sub esp,8; push esi; mov esi,ecx
    g_origFrame = reinterpret_cast<Frame_t>(HookInstall(0x412EB0, reinterpret_cast<void*>(&HookFrame), 6, kPrologue, "game frame"));
}

static LRESULT CALLBACK HookProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    if (msg == kStartMsg) {
        if (!g_timerOn) {
            g_timerOn = SetTimer(hwnd, kTimerId, 16, nullptr) != 0;
            Log("Main-thread tick %s (thread %lu)", g_timerOn ? "started" : "FAILED to start", GetCurrentThreadId());
        }
        return 0;
    }
    if (msg == WM_TIMER && wp == kTimerId) {
        if (g_fn && !g_origFrame) g_fn(GetTickCount());     // fallback only: wrong thread for the game
        return 0;
    }
    if (msg == WM_NCDESTROY) {
        KillTimer(hwnd, kTimerId);
        g_timerOn = false;
        WNDPROC old = g_oldProc;
        SetWindowLongPtrW(hwnd, GWLP_WNDPROC, (LONG_PTR)old);
        g_wnd = nullptr;
        return CallWindowProcW(old, hwnd, msg, wp, lp);
    }
    return CallWindowProcW(g_oldProc, hwnd, msg, wp, lp);
}

struct FindCtx { DWORD pid; HWND best; };

static BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lp)
{
    FindCtx* ctx = reinterpret_cast<FindCtx*>(lp);
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != ctx->pid || !IsWindowVisible(hwnd) || GetWindow(hwnd, GW_OWNER)) return TRUE;
    RECT r;
    GetClientRect(hwnd, &r);
    if (r.right - r.left < 320) return TRUE;   // skip splash / tiny helper windows
    ctx->best = hwnd;
    return FALSE;
}

bool TickStart(TickFn fn, unsigned timeoutMs)
{
    g_fn = fn;
    InstallFrameHook();
    if (g_origFrame) {
        Log("Main-thread tick: hooked the game frame (window timer not used)");
        return true;
    }
    DWORD start = GetTickCount();
    FindCtx ctx = { GetCurrentProcessId(), nullptr };
    while (!ctx.best) {
        EnumWindows(EnumProc, (LPARAM)&ctx);
        if (ctx.best) break;
        if (GetTickCount() - start > timeoutMs) {
            Log("Main-thread tick: game window not found after %u ms", timeoutMs);
            return false;
        }
        Sleep(250);
    }
    // Give the game a moment to finish creating its device on that window.
    Sleep(1000);
    g_wnd = ctx.best;
    wchar_t title[128] = L"";
    GetWindowTextW(g_wnd, title, 128);
    g_oldProc = (WNDPROC)SetWindowLongPtrW(g_wnd, GWLP_WNDPROC, (LONG_PTR)HookProc);
    if (!g_oldProc) {
        Log("Main-thread tick: could not hook the game window (error %lu)", GetLastError());
        return false;
    }
    Log("Hooked game window 0x%p \"%ls\"", g_wnd, title);
    PostMessageW(g_wnd, kStartMsg, 0, 0);
    return true;
}

void TickStop()
{
    g_fn = nullptr;
}
