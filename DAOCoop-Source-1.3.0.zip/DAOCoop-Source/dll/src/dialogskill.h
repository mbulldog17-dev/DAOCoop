#pragma once
// Dialogue skill checks with the player who holds the conversation.
//
// The persuade / intimidate checks (gen00pt_skills.ncs) always test GetHero():
// the Coercion abilities (4020 and ranks 100001-100004) plus Cunning
// (property 5) or Strength (property 1). While Player 2/3 holds a
// conversation, the Warden temporarily gets that player's Coercion ranks and
// attribute totals; everything is put back exactly when the conversation is
// handed back or ends. (Saving isn't possible during a conversation.)
#include <cstdint>

void DialogSkillInit(bool enabled);
// player 1 = the Warden's own skills (restore), 2/3 = use that player's character.
void DialogSkillUse(int player, uint32_t character);
void DialogSkillRestore();
