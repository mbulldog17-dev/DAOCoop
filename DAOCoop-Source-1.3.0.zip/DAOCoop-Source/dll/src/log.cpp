#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include "log.h"

static CRITICAL_SECTION g_lock;
static FILE* g_file = nullptr;
static bool g_ready = false;

bool LogInit(const wchar_t* path)
{
    if (!g_ready) {
        InitializeCriticalSection(&g_lock);
        g_ready = true;
    }
    EnterCriticalSection(&g_lock);
    if (!g_file) g_file = _wfopen(path, L"w");
    bool ok = g_file != nullptr;
    LeaveCriticalSection(&g_lock);
    return ok;
}

void Log(const char* fmt, ...)
{
    if (!g_ready || !g_file) return;
    EnterCriticalSection(&g_lock);
    SYSTEMTIME t;
    GetLocalTime(&t);
    fprintf(g_file, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list args;
    va_start(args, fmt);
    vfprintf(g_file, fmt, args);
    va_end(args);
    fputc('\n', g_file);
    fflush(g_file);
    LeaveCriticalSection(&g_lock);
}

void LogShutdown()
{
    if (!g_ready) return;
    EnterCriticalSection(&g_lock);
    if (g_file) { fclose(g_file); g_file = nullptr; }
    LeaveCriticalSection(&g_lock);
}
