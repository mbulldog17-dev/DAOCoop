#pragma once
// 1.2.46: a ring on the ground under each co-op character in their player colour
// (blue Player 2, green Player 3), so everyone can find their own character in a fight.
// The ring's points are projected with the game's own camera (screenwall.cpp) on the game
// thread and drawn on the finished frame (d3d9hook.cpp overlay), so it sits on top of the
// picture like a HUD element.
#include <cstdint>

struct RingSettings {
    int   mode;          // 0 off, 1 in combat, 2 always
    float radius;        // metres
    int   alpha;         // 0-255
};
void RingsInit(const RingSettings& s);
// Main tick: the co-op characters (feet positions + colours) and whether to show them now.
void RingsSetPlayers(const float (*pos)[3], const uint32_t* rgb, int n, bool combat, bool active);
