#include "OnlineVideo.h"
// Online play, the picture (DAOCoop, DirectX 9). From the Amalur co-op mod's OnlineVideo.cpp: the
// Media Foundation H.264 encoder / decoder are the same; the GPU side is new (Amalur drew with D3D11):
//   host:   back buffer -> StretchRect to a stream-size render target -> GetRenderTargetData (one
//           frame later, so the GPU is done) -> BGRA -> NV12 on the encoder thread -> H.264;
//   friend: H.264 -> NV12 -> BGRA on the decoder thread -> system-memory surface -> UpdateSurface ->
//           StretchRect over the whole back buffer (black bars keep the shape).
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <objbase.h>
#include <oleauto.h>
#include <d3d9.h>
#include <mfapi.h>
#include <mferror.h>
#include <mfidl.h>
#include <mftransform.h>
#include <strmif.h>
#include <codecapi.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "Logger.h"
#include "OnlineClock.h"
#include "Paths.h"

#ifdef _MSC_VER
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#endif

#ifdef __MINGW32__
__CRT_UUID_DECL(ICodecAPI, 0x901db4c7, 0x31ce, 0x41a2, 0x85, 0xdc, 0x8f, 0xa0, 0xbf, 0x41, 0xb8, 0xda)   // (test builds; MSVC has it)
#endif

using Microsoft::WRL::ComPtr;

namespace
{
    bool MediaFoundationThere()
    {
        static const bool there = [] {
            const bool ok = LoadLibraryExW(L"mfplat.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32) != nullptr;
            if (!ok) Logger::Write(Logger::Level::Error, "Online: Windows' Media Foundation (mfplat.dll) is missing - on Windows N editions install the Media Feature Pack; no picture until then");
            return ok;
        }();
        return there;
    }

    int64_t QpcNow() { LARGE_INTEGER t; QueryPerformanceCounter(&t); return t.QuadPart; }
    int64_t QpcFreq() { static const int64_t f = [] { LARGE_INTEGER q; QueryPerformanceFrequency(&q); return q.QuadPart; }(); return f; }
    double QpcMs(int64_t from, int64_t to) { return static_cast<double>(to - from) * 1000.0 / static_cast<double>(QpcFreq()); }

    // ======================================================================================
    // Host: frames -> encoder thread
    // ======================================================================================
    struct RawFrame { std::vector<uint8_t> nv12, bgra; int w = 0, h = 0; int64_t us = 0; };

    std::mutex g_hostMutex;              // start / stop
    std::atomic<bool> g_hostOn{ false };
    OnlineVideo::Settings g_settings;
    OnlineVideo::FrameSink g_sink;
    std::thread& g_encThread = *new std::thread();
    std::atomic<bool> g_encRun{ false };
    std::atomic<bool> g_forceKey{ false };
    std::atomic<int> g_newBitrate{ 0 };

    std::mutex g_frameMutex;
    std::condition_variable g_frameCv;
    RawFrame g_pending;
    bool g_hasPending = false;
    std::atomic<uint32_t> g_captured{ 0 }, g_replaced{ 0 }, g_skippedBusy{ 0 }, g_encoded{ 0 };

    std::mutex g_statusMutex;
    std::string g_encName = "starting";
    double g_encMs = 0, g_readbackWaitMs = 0;
    int g_streamW = 0, g_streamH = 0;
    int g_bitrateNow = 0;

    // D3D9: the readback (BGRA rows, any pitch) -> the encoder thread, which makes NV12 itself.
    void PushFrame(const uint8_t* bits, int pitch, int w, int h, int64_t us)
    {
        {
            std::lock_guard<std::mutex> lock(g_frameMutex);
            if (g_hasPending) g_replaced.fetch_add(1, std::memory_order_relaxed);
            g_pending.bgra.resize(static_cast<size_t>(w) * h * 4);
            for (int y = 0; y < h; ++y) std::memcpy(g_pending.bgra.data() + static_cast<size_t>(y) * w * 4, bits + static_cast<size_t>(y) * pitch, static_cast<size_t>(w) * 4);
            g_pending.w = w;
            g_pending.h = h;
            g_pending.us = us;
            g_hasPending = true;
        }
        g_frameCv.notify_one();
        g_captured.fetch_add(1, std::memory_order_relaxed);
    }

    // BT.601 limited range, the decoders' default for H.264 without colour info.
    void BgraToNv12(const uint8_t* bgra, int w, int h, std::vector<uint8_t>& out)
    {
        out.resize(static_cast<size_t>(w) * h * 3 / 2);
        uint8_t* Y = out.data();
        uint8_t* UV = out.data() + static_cast<size_t>(w) * h;
        for (int y = 0; y < h; y += 2)
        {
            const uint8_t* r0 = bgra + static_cast<size_t>(y) * w * 4;
            const uint8_t* r1 = r0 + static_cast<size_t>(w) * 4;
            uint8_t* y0 = Y + static_cast<size_t>(y) * w;
            uint8_t* y1 = y0 + w;
            uint8_t* uv = UV + static_cast<size_t>(y / 2) * w;
            for (int x = 0; x < w; x += 2)
            {
                int rs = 0, gs = 0, bs = 0;
                const uint8_t* p[4] = { r0 + x * 4, r0 + x * 4 + 4, r1 + x * 4, r1 + x * 4 + 4 };
                uint8_t* yo[4] = { y0 + x, y0 + x + 1, y1 + x, y1 + x + 1 };
                for (int k = 0; k < 4; ++k)
                {
                    const int b = p[k][0], g = p[k][1], r = p[k][2];
                    *yo[k] = static_cast<uint8_t>(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
                    rs += r; gs += g; bs += b;
                }
                rs >>= 2; gs >>= 2; bs >>= 2;
                uv[x] = static_cast<uint8_t>(((-38 * rs - 74 * gs + 112 * bs + 128) >> 8) + 128);
                uv[x + 1] = static_cast<uint8_t>(((112 * rs - 94 * gs - 18 * bs + 128) >> 8) + 128);
            }
        }
    }

    inline uint8_t Clamp255(int v) { return static_cast<uint8_t>(v < 0 ? 0 : v > 255 ? 255 : v); }
    // NV12 rows (any pitch) -> BGRX.
    void Nv12ToBgra(const uint8_t* y, const uint8_t* uv, int pitch, int w, int h, uint8_t* out)
    {
        for (int r = 0; r < h; ++r)
        {
            const uint8_t* yr = y + static_cast<size_t>(r) * pitch;
            const uint8_t* cr = uv + static_cast<size_t>(r / 2) * pitch;
            uint8_t* o = out + static_cast<size_t>(r) * w * 4;
            for (int x = 0; x < w; ++x)
            {
                const int c = 298 * (yr[x] - 16), d = cr[x & ~1] - 128, e = cr[(x & ~1) + 1] - 128;
                o[x * 4 + 0] = Clamp255((c + 516 * d + 128) >> 8);
                o[x * 4 + 1] = Clamp255((c - 100 * d - 208 * e + 128) >> 8);
                o[x * 4 + 2] = Clamp255((c + 409 * e + 128) >> 8);
                o[x * 4 + 3] = 255;
            }
        }
    }


    // ======================================================================================
    // Media Foundation helpers
    // (MF_LOW_LATENCY is the same GUID as CODECAPI_AVLowLatencyMode, which needs no library; it is
    // used as the attribute key below)
    // ======================================================================================
    void SetUi4(ICodecAPI* api, const GUID& key, UINT32 v)
    {
        if (!api) return;
        VARIANT var;
        VariantInit(&var);
        var.vt = VT_UI4;
        var.ulVal = v;
        api->SetValue(&key, &var);
    }
    void SetBool(ICodecAPI* api, const GUID& key, bool v)
    {
        if (!api) return;
        VARIANT var;
        VariantInit(&var);
        var.vt = VT_BOOL;
        var.boolVal = v ? VARIANT_TRUE : VARIANT_FALSE;
        api->SetValue(&key, &var);
    }
    std::string FriendlyName(IMFActivate* act)
    {
        WCHAR* name = nullptr;
        UINT32 len = 0;
        std::string out = "?";
        if (SUCCEEDED(act->GetAllocatedString(MFT_FRIENDLY_NAME_Attribute, &name, &len)) && name)
        {
            const int n = WideCharToMultiByte(CP_UTF8, 0, name, -1, nullptr, 0, nullptr, nullptr);
            if (n > 1) { out.assign(static_cast<size_t>(n - 1), '\0'); WideCharToMultiByte(CP_UTF8, 0, name, -1, &out[0], n, nullptr, nullptr); }
            CoTaskMemFree(name);
        }
        return out;
    }

    // NAL units of an Annex B stream: does it carry SPS / an IDR slice, and where the first slice starts.
    void ScanNals(const uint8_t* d, size_t n, bool& sps, bool& idr, size_t& firstSlice)
    {
        sps = idr = false;
        firstSlice = n;
        for (size_t i = 0; i + 3 < n; ++i)
        {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1)
            {
                const size_t start = (i > 0 && d[i - 1] == 0) ? i - 1 : i;
                const int type = d[i + 3] & 0x1F;
                if (type == 7) sps = true;
                if (type == 5) idr = true;
                if ((type == 1 || type == 5) && firstSlice == n) firstSlice = start;
                i += 2;
            }
        }
    }

    // ---- The H.264 encoder (encoder thread) ----
    struct Encoder
    {
        ComPtr<IMFTransform> mft;
        ComPtr<ICodecAPI> api;
        ComPtr<IMFMediaEventGenerator> events;
        bool async = false, providesSamples = false, hardware = false;
        DWORD inId = 0, outId = 0, outSize = 0;
        int w = 0, h = 0, needInput = 0;
        std::string name;
        std::vector<uint8_t> header;   // SPS + PPS, put in front of keyframes that lack them
        std::vector<uint8_t> scratch;
        int64_t pendingUs = 0;

        void Close()
        {
            if (mft)
            {
                mft->ProcessMessage(MFT_MESSAGE_NOTIFY_END_OF_STREAM, 0);
                mft->ProcessMessage(MFT_MESSAGE_NOTIFY_END_STREAMING, 0);
                if (async)
                {
                    ComPtr<IMFShutdown> sd;
                    if (SUCCEEDED(mft.As(&sd))) sd->Shutdown();
                }
            }
            events.Reset(); api.Reset(); mft.Reset();
            needInput = 0;
            header.clear();
        }

        void SetProps(const OnlineVideo::Settings& s, int kbps)
        {
            SetBool(api.Get(), CODECAPI_AVLowLatencyMode, true);
            SetUi4(api.Get(), CODECAPI_AVEncCommonRateControlMode, eAVEncCommonRateControlMode_CBR);
            SetUi4(api.Get(), CODECAPI_AVEncCommonMeanBitRate, static_cast<UINT32>(kbps) * 1000u);
            // decoder buffer of about two frames: frame sizes stay even, so nothing waits in a queue
            SetUi4(api.Get(), CODECAPI_AVEncCommonBufferSize, static_cast<UINT32>(kbps) * 1000u / static_cast<UINT32>(std::max(1, s.fps)) * 2u);
            SetUi4(api.Get(), CODECAPI_AVEncMPVGOPSize, static_cast<UINT32>(std::max(1, s.gopSeconds) * std::max(1, s.fps)));
            SetUi4(api.Get(), CODECAPI_AVEncMPVDefaultBPictureCount, 0);
            SetUi4(api.Get(), CODECAPI_AVEncCommonQualityVsSpeed, static_cast<UINT32>(std::clamp(s.qualityVsSpeed, 0, 100)));
        }

        bool Configure(IMFTransform* t, bool hw, int width, int height, const OnlineVideo::Settings& s)
        {
            mft = t;
            hardware = hw;
            ComPtr<IMFAttributes> attrs;
            UINT32 isAsync = 0;
            if (SUCCEEDED(t->GetAttributes(&attrs)) && attrs)
            {
                attrs->GetUINT32(MF_TRANSFORM_ASYNC, &isAsync);
                if (isAsync) attrs->SetUINT32(MF_TRANSFORM_ASYNC_UNLOCK, TRUE);
                attrs->SetUINT32(CODECAPI_AVLowLatencyMode, TRUE);
            }
            async = isAsync != 0;
            t->QueryInterface(IID_PPV_ARGS(&api));
            const int kbps = g_bitrateNow > 0 ? g_bitrateNow : s.bitrateKbps;
            SetProps(s, kbps);
            DWORD inCount = 0, outCount = 0;
            inId = outId = 0;
            if (SUCCEEDED(t->GetStreamCount(&inCount, &outCount)) && inCount == 1 && outCount == 1)
            {
                DWORD i = 0, o = 0;
                if (SUCCEEDED(t->GetStreamIDs(1, &i, 1, &o))) { inId = i; outId = o; }
            }
            ComPtr<IMFMediaType> out;
            MFCreateMediaType(&out);
            out->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
            out->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
            out->SetUINT32(MF_MT_AVG_BITRATE, static_cast<UINT32>(kbps) * 1000u);
            MFSetAttributeSize(out.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
            MFSetAttributeRatio(out.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
            MFSetAttributeRatio(out.Get(), MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
            out->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
            out->SetUINT32(MF_MT_MPEG2_PROFILE, static_cast<UINT32>(s.profile));
            HRESULT hr = t->SetOutputType(outId, out.Get(), 0);
            if (FAILED(hr)) { Logger::WriteFormat(Logger::Level::Warning, "Online: %s refused the H.264 settings (0x%08lX)", name.c_str(), static_cast<unsigned long>(hr)); return false; }
            ComPtr<IMFMediaType> in;
            MFCreateMediaType(&in);
            in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
            in->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
            MFSetAttributeSize(in.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
            MFSetAttributeRatio(in.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
            MFSetAttributeRatio(in.Get(), MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
            in->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
            hr = t->SetInputType(inId, in.Get(), 0);
            if (FAILED(hr))
            {
                // its own NV12 type, with our size
                bool set = false;
                for (DWORD i = 0; !set; ++i)
                {
                    ComPtr<IMFMediaType> av;
                    if (FAILED(t->GetInputAvailableType(inId, i, &av))) break;
                    GUID sub{};
                    av->GetGUID(MF_MT_SUBTYPE, &sub);
                    if (sub != MFVideoFormat_NV12) continue;
                    MFSetAttributeSize(av.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
                    MFSetAttributeRatio(av.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
                    set = SUCCEEDED(t->SetInputType(inId, av.Get(), 0));
                }
                if (!set) { Logger::WriteFormat(Logger::Level::Warning, "Online: %s takes no NV12 %dx%d (0x%08lX)", name.c_str(), width, height, static_cast<unsigned long>(hr)); return false; }
            }
            SetProps(s, kbps);
            MFT_OUTPUT_STREAM_INFO info{};
            t->GetOutputStreamInfo(outId, &info);
            providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
            outSize = std::max<DWORD>(info.cbSize, static_cast<DWORD>(width * height * 3 / 2 + 4096));
            if (async && FAILED(t->QueryInterface(IID_PPV_ARGS(&events)))) return false;
            t->ProcessMessage(MFT_MESSAGE_NOTIFY_BEGIN_STREAMING, 0);
            t->ProcessMessage(MFT_MESSAGE_NOTIFY_START_OF_STREAM, 0);
            w = width; h = height;
            needInput = 0;
            return true;
        }

        bool Open(int width, int height, const OnlineVideo::Settings& s)
        {
            Close();
            MFT_REGISTER_TYPE_INFO inInfo{ MFMediaType_Video, MFVideoFormat_NV12 };
            MFT_REGISTER_TYPE_INFO outInfo{ MFMediaType_Video, MFVideoFormat_H264 };
            for (int pass = s.hardware ? 0 : 1; pass < 2; ++pass)
            {
                const UINT32 flags = pass == 0 ? (MFT_ENUM_FLAG_HARDWARE | MFT_ENUM_FLAG_SORTANDFILTER)
                                               : (MFT_ENUM_FLAG_SYNCMFT | MFT_ENUM_FLAG_LOCALMFT | MFT_ENUM_FLAG_SORTANDFILTER);
                IMFActivate** acts = nullptr;
                UINT32 count = 0;
                if (FAILED(MFTEnumEx(MFT_CATEGORY_VIDEO_ENCODER, flags, &inInfo, &outInfo, &acts, &count))) count = 0;
                if (pass == 0) Logger::WriteFormat(Logger::Level::Info, "Online: %u hardware H.264 encoder(s) for this 32-bit game", count);
                bool ok = false;
                for (UINT32 i = 0; i < count; ++i)
                {
                    if (!ok)
                    {
                        name = FriendlyName(acts[i]);
                        ComPtr<IMFTransform> t;
                        if (SUCCEEDED(acts[i]->ActivateObject(IID_PPV_ARGS(&t))) && Configure(t.Get(), pass == 0, width, height, s)) ok = true;
                        else { Close(); acts[i]->ShutdownObject(); }
                    }
                    acts[i]->Release();
                }
                CoTaskMemFree(acts);
                if (ok)
                {
                    Logger::WriteFormat(Logger::Level::Success, "Online: encoder %s (%s, %s) %dx%d %d fps %d kbps", name.c_str(),
                        pass == 0 ? "hardware" : "software", async ? "async" : "sync", width, height, s.fps, g_bitrateNow > 0 ? g_bitrateNow : s.bitrateKbps);
                    std::lock_guard<std::mutex> lock(g_statusMutex);
                    g_encName = name + (pass == 0 ? " (GPU)" : " (CPU)");
                    return true;
                }
            }
            Logger::Write(Logger::Level::Error, "Online: no H.264 encoder could be set up");
            return false;
        }

        // One encoded sample out of the MFT, to the sink. False: none there.
        bool Drain()
        {
            MFT_OUTPUT_DATA_BUFFER out{};
            out.dwStreamID = outId;
            ComPtr<IMFSample> own;
            if (!providesSamples)
            {
                ComPtr<IMFMediaBuffer> buf;
                if (FAILED(MFCreateSample(&own)) || FAILED(MFCreateMemoryBuffer(outSize, &buf))) return false;
                own->AddBuffer(buf.Get());
                out.pSample = own.Get();
            }
            DWORD status = 0;
            const HRESULT hr = mft->ProcessOutput(0, 1, &out, &status);
            if (out.pEvents) out.pEvents->Release();
            if (hr == MF_E_TRANSFORM_NEED_MORE_INPUT) return false;
            if (hr == MF_E_TRANSFORM_STREAM_CHANGE)
            {
                ComPtr<IMFMediaType> t;
                if (SUCCEEDED(mft->GetOutputAvailableType(outId, 0, &t))) mft->SetOutputType(outId, t.Get(), 0);
                MFT_OUTPUT_STREAM_INFO info{};
                mft->GetOutputStreamInfo(outId, &info);
                providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
                outSize = std::max<DWORD>(info.cbSize, outSize);
                return true;
            }
            if (FAILED(hr) || !out.pSample)
            {
                if (providesSamples && out.pSample) out.pSample->Release();
                return false;
            }
            IMFSample* sample = out.pSample;
            ComPtr<IMFMediaBuffer> buf;
            if (SUCCEEDED(sample->ConvertToContiguousBuffer(&buf)))
            {
                BYTE* data = nullptr;
                DWORD len = 0;
                if (SUCCEEDED(buf->Lock(&data, nullptr, &len)) && data && len)
                {
                    UINT32 clean = 0;
                    sample->GetUINT32(MFSampleExtension_CleanPoint, &clean);
                    bool sps = false, idr = false;
                    size_t firstSlice = 0;
                    ScanNals(data, len, sps, idr, firstSlice);
                    if (sps && firstSlice > 0 && firstSlice <= len) header.assign(data, data + firstSlice);
                    const bool key = idr || clean != 0;
                    if (key && !sps && header.empty())
                    {
                        ComPtr<IMFMediaType> t;
                        UINT32 blob = 0;
                        if (SUCCEEDED(mft->GetOutputCurrentType(outId, &t)) && SUCCEEDED(t->GetBlobSize(MF_MT_MPEG_SEQUENCE_HEADER, &blob)) && blob)
                        {
                            header.resize(blob);
                            t->GetBlob(MF_MT_MPEG_SEQUENCE_HEADER, header.data(), blob, nullptr);
                        }
                    }
                    LONGLONG time = 0;
                    sample->GetSampleTime(&time);
                    const uint32_t captureMs = static_cast<uint32_t>(static_cast<int64_t>(time) / 10000);
                    const uint8_t* bytes = data;
                    size_t size = len;
                    if (key && !sps && !header.empty())
                    {
                        scratch.assign(header.begin(), header.end());
                        scratch.insert(scratch.end(), data, data + len);
                        bytes = scratch.data();
                        size = scratch.size();
                    }
                    if (g_sink) g_sink(bytes, size, key, static_cast<uint16_t>(w), static_cast<uint16_t>(h), captureMs);
                    g_encoded.fetch_add(1, std::memory_order_relaxed);
                    if (async)
                    {
                        // GPU encoder: time from the picture being taken to its output
                        const double ms = static_cast<double>(OnlineClock::NowUs() - static_cast<int64_t>(time) / 10) / 1000.0;
                        if (ms >= 0 && ms < 1000)
                        {
                            std::lock_guard<std::mutex> lock(g_statusMutex);
                            g_encMs = g_encMs <= 0 ? ms : g_encMs * 0.95 + ms * 0.05;
                        }
                    }
                    buf->Unlock();
                }
            }
            if (providesSamples) sample->Release();
            return true;
        }

        // Async MFT events waiting now: input requests counted, outputs taken. waitInputMs > 0: wait
        // that long for an input request (right after opening).
        void Pump(double waitInputMs = 0.0)
        {
            const int64_t start = QpcNow();
            for (;;)
            {
                ComPtr<IMFMediaEvent> ev;
                const HRESULT hr = events->GetEvent(MF_EVENT_FLAG_NO_WAIT, &ev);
                if (hr == MF_E_NO_EVENTS_AVAILABLE)
                {
                    if (needInput > 0 || waitInputMs <= 0) return;
                    const double ms = QpcMs(start, QpcNow());
                    if (ms >= waitInputMs) return;
                    if (ms < 1.5) SwitchToThread(); else Sleep(1);
                    continue;
                }
                if (FAILED(hr) || !ev) return;
                MediaEventType type = MEUnknown;
                ev->GetType(&type);
                if (type == METransformNeedInput) ++needInput;
                else if (type == METransformHaveOutput) Drain();
            }
        }

        bool Encode(const RawFrame& f)
        {
            ComPtr<IMFSample> sample;
            ComPtr<IMFMediaBuffer> buf;
            const DWORD size = static_cast<DWORD>(f.nv12.size());
            if (FAILED(MFCreateSample(&sample)) || FAILED(MFCreateMemoryBuffer(size, &buf))) return false;
            BYTE* dst = nullptr;
            if (FAILED(buf->Lock(&dst, nullptr, nullptr))) return false;
            std::memcpy(dst, f.nv12.data(), size);
            buf->Unlock();
            buf->SetCurrentLength(size);
            sample->AddBuffer(buf.Get());
            sample->SetSampleTime(f.us * 10);
            sample->SetSampleDuration(10000000LL / std::max(1, g_settings.fps));
            if (async)
            {
                if (needInput <= 0) Pump(30.0);
                if (needInput <= 0) return false;
                if (FAILED(mft->ProcessInput(inId, sample.Get(), 0))) return false;
                --needInput;
                ++inputsWaiting;
                Pump();   // an output that is already there (the loop keeps looking every millisecond)
                return true;
            }
            HRESULT hr = mft->ProcessInput(inId, sample.Get(), 0);
            if (hr == MF_E_NOTACCEPTING) { while (Drain()) {} hr = mft->ProcessInput(inId, sample.Get(), 0); }
            if (FAILED(hr)) return false;
            while (Drain()) {}
            return true;
        }
        int inputsWaiting = 0;   // async: frames given since the last output
    };

    void EncoderMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool mfOk = MediaFoundationThere() && SUCCEEDED(MFStartup(MF_VERSION, MFSTARTUP_LITE));
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
        Encoder enc;
        RawFrame frame;
        int failures = 0;
        DWORD retryAt = 0;
        if (!mfOk)
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_encName = "no Media Foundation in this Windows (Media Feature Pack)";
        }
        while (g_encRun.load())
        {
            const bool polling = enc.mft && enc.async;
            bool have = false;
            {
                std::unique_lock<std::mutex> lock(g_frameMutex);
                // a GPU encoder answers through events: looked at every millisecond
                if (!g_hasPending)
                    g_frameCv.wait_for(lock, std::chrono::milliseconds(polling ? 1 : 50), [] { return g_hasPending || !g_encRun.load(); });
                if (!g_encRun.load()) break;
                // a GPU encoder takes a frame only when it asks for one (until then a newer frame replaces it)
                if (g_hasPending && (!polling || enc.needInput > 0))
                {
                    std::swap(frame.bgra, g_pending.bgra);
                    frame.w = g_pending.w; frame.h = g_pending.h; frame.us = g_pending.us;
                    g_hasPending = false;
                    have = true;
                }
            }
            if (polling)
            {
                const uint32_t before = g_encoded.load(std::memory_order_relaxed);
                enc.Pump();
                if (g_encoded.load(std::memory_order_relaxed) != before) enc.inputsWaiting = 0;
                // frames go in and nothing comes out (2 s): this encoder does not work here
                if (enc.inputsWaiting > std::max(30, g_settings.fps * 2))
                {
                    Logger::WriteFormat(Logger::Level::Warning, "Online: %s gives no output; trying the next encoder", enc.name.c_str());
                    g_settings.hardware = false;
                    enc.Close();
                    enc.inputsWaiting = 0;
                    continue;
                }
            }
            if (!have || !mfOk) continue;
            BgraToNv12(frame.bgra.data(), frame.w, frame.h, frame.nv12);
            if (!enc.mft || frame.w != enc.w || frame.h != enc.h)
            {
                if (retryAt && static_cast<int>(GetTickCount() - retryAt) < 0) continue;
                if (!enc.Open(frame.w, frame.h, g_settings))
                {
                    retryAt = GetTickCount() + 3000;
                    std::lock_guard<std::mutex> lock(g_statusMutex);
                    g_encName = "no H.264 encoder found";
                    continue;
                }
                retryAt = 0;
                enc.inputsWaiting = 0;
                g_forceKey.store(true);
            }
            if (const int kbps = g_newBitrate.exchange(0))
            {
                SetUi4(enc.api.Get(), CODECAPI_AVEncCommonMeanBitRate, static_cast<UINT32>(kbps) * 1000u);
                SetUi4(enc.api.Get(), CODECAPI_AVEncCommonBufferSize, static_cast<UINT32>(kbps) * 1000u / static_cast<UINT32>(std::max(1, g_settings.fps)) * 2u);
            }
            if (g_forceKey.exchange(false)) SetUi4(enc.api.Get(), CODECAPI_AVEncVideoForceKeyFrame, 1);
            const int64_t t0 = QpcNow();
            if (!enc.Encode(frame))
            {
                if (++failures == 30)
                {
                    Logger::WriteFormat(Logger::Level::Warning, "Online: %s keeps failing; trying the next encoder", enc.name.c_str());
                    if (enc.hardware) g_settings.hardware = false;   // a broken GPU encoder: the CPU one
                    enc.Close();
                    failures = 0;
                }
                continue;
            }
            failures = 0;
            if (!enc.async)
            {
                const double ms = QpcMs(t0, QpcNow());
                std::lock_guard<std::mutex> lock(g_statusMutex);
                g_encMs = g_encMs <= 0 ? ms : g_encMs * 0.95 + ms * 0.05;
            }
        }
        enc.Close();
        if (mfOk) MFShutdown();
        if (SUCCEEDED(co)) CoUninitialize();
    }

    // ======================================================================================
    // Friend: decoder thread and the picture on screen
    // ======================================================================================
    std::atomic<bool> g_viewOn{ false };
    std::atomic<bool> g_viewReset{ false };    // a new session: the last picture of the old one goes
    std::atomic<bool> g_wantKey{ false };      // the decoder needs a keyframe (the network thread asks the host)
    std::atomic<bool> g_decNeedKey{ false };   // frames were dropped before the decoder: skip to a keyframe
    std::thread& g_decThread = *new std::thread();
    std::mutex g_decMutex;
    std::condition_variable g_decCv;
    std::deque<OnlineProtocol::VideoFrame> g_decQueue;

    std::mutex g_picMutex;
    std::vector<uint8_t> g_pic;   // BGRX, w x h (made from NV12 on the decoder thread)
    int g_picW = 0, g_picH = 0;
    uint32_t g_picSeq = 0, g_picCaptureMs = 0;

    std::mutex g_viewStatsMutex;
    OnlineVideo::ViewerStats g_viewStats;

    struct Decoder
    {
        ComPtr<IMFTransform> mft;
        bool providesSamples = false, haveOutput = false;
        DWORD outSize = 0;
        UINT32 frameW = 0, frameH = 0;
        LONG stride = 0;
        int inW = 0, inH = 0;
        std::string name;

        void Close() { mft.Reset(); haveOutput = false; inW = inH = 0; }

        bool PickOutput()
        {
            for (DWORD i = 0;; ++i)
            {
                ComPtr<IMFMediaType> t;
                if (FAILED(mft->GetOutputAvailableType(0, i, &t))) return false;
                GUID sub{};
                t->GetGUID(MF_MT_SUBTYPE, &sub);
                if (sub != MFVideoFormat_NV12) continue;
                if (FAILED(mft->SetOutputType(0, t.Get(), 0))) return false;
                MFGetAttributeSize(t.Get(), MF_MT_FRAME_SIZE, &frameW, &frameH);
                UINT32 s = 0;
                stride = SUCCEEDED(t->GetUINT32(MF_MT_DEFAULT_STRIDE, &s)) ? static_cast<LONG>(s) : static_cast<LONG>(frameW);
                MFT_OUTPUT_STREAM_INFO info{};
                mft->GetOutputStreamInfo(0, &info);
                providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
                outSize = std::max<DWORD>(info.cbSize, frameW * frameH * 3 / 2);
                haveOutput = true;
                return true;
            }
        }

        bool Open(int w, int h)
        {
            Close();
            MFT_REGISTER_TYPE_INFO inInfo{ MFMediaType_Video, MFVideoFormat_H264 };
            IMFActivate** acts = nullptr;
            UINT32 count = 0;
            if (FAILED(MFTEnumEx(MFT_CATEGORY_VIDEO_DECODER, MFT_ENUM_FLAG_SYNCMFT | MFT_ENUM_FLAG_LOCALMFT | MFT_ENUM_FLAG_SORTANDFILTER,
                &inInfo, nullptr, &acts, &count))) count = 0;
            for (UINT32 i = 0; i < count; ++i)
            {
                if (!mft)
                {
                    ComPtr<IMFTransform> t;
                    if (SUCCEEDED(acts[i]->ActivateObject(IID_PPV_ARGS(&t))))
                    {
                        name = FriendlyName(acts[i]);
                        ComPtr<IMFAttributes> attrs;
                        if (SUCCEEDED(t->GetAttributes(&attrs)) && attrs) attrs->SetUINT32(CODECAPI_AVLowLatencyMode, TRUE);
                        ComPtr<ICodecAPI> api;
                        if (SUCCEEDED(t.As(&api))) SetBool(api.Get(), CODECAPI_AVLowLatencyMode, true);
                        ComPtr<IMFMediaType> in;
                        MFCreateMediaType(&in);
                        in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
                        in->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
                        MFSetAttributeSize(in.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(w), static_cast<UINT32>(h));
                        in->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
                        if (SUCCEEDED(t->SetInputType(0, in.Get(), 0)))
                        {
                            mft = t;
                            if (!PickOutput()) haveOutput = false;   // comes with the first frame (stream change)
                            mft->ProcessMessage(MFT_MESSAGE_NOTIFY_BEGIN_STREAMING, 0);
                            mft->ProcessMessage(MFT_MESSAGE_NOTIFY_START_OF_STREAM, 0);
                        }
                    }
                }
                acts[i]->Release();
            }
            CoTaskMemFree(acts);
            if (!mft) { Logger::Write(Logger::Level::Error, "Online: no H.264 decoder found"); return false; }
            inW = w; inH = h;
            Logger::WriteFormat(Logger::Level::Success, "Online: decoder %s for %dx%d", name.c_str(), w, h);
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            g_viewStats.decoder = name;
            return true;
        }

        void Publish(IMFSample* sample, int w, int h, uint32_t captureMs)
        {
            ComPtr<IMFMediaBuffer> buf;
            if (FAILED(sample->GetBufferByIndex(0, &buf))) return;
            ComPtr<IMF2DBuffer> b2;
            BYTE* base = nullptr;
            LONG pitch = 0;
            bool twoD = false;
            DWORD len = 0;
            if (SUCCEEDED(buf.As(&b2)) && SUCCEEDED(b2->Lock2D(&base, &pitch))) twoD = true;
            else
            {
                if (FAILED(buf->Lock(&base, nullptr, &len))) return;
                pitch = stride;
            }
            const int cw = std::min<int>(w, static_cast<int>(frameW)) & ~1, ch = std::min<int>(h, static_cast<int>(frameH)) & ~1;
            if (base && pitch > 0 && cw > 0 && ch > 0 && (twoD || len >= static_cast<DWORD>(pitch) * frameH * 3 / 2))
            {
                std::lock_guard<std::mutex> lock(g_picMutex);
                g_pic.resize(static_cast<size_t>(cw) * ch * 4);
                Nv12ToBgra(base, base + static_cast<size_t>(pitch) * frameH, pitch, cw, ch, g_pic.data());
                g_picW = cw; g_picH = ch;
                g_picCaptureMs = captureMs;
                ++g_picSeq;
            }
            if (twoD) b2->Unlock2D(); else buf->Unlock();
        }

        bool Decode(const OnlineProtocol::VideoFrame& f)
        {
            if (!mft || f.width != inW || f.height != inH)
            {
                if (!f.key) return false;
                if (!Open(f.width, f.height)) return false;
            }
            ComPtr<IMFSample> sample;
            ComPtr<IMFMediaBuffer> buf;
            if (FAILED(MFCreateSample(&sample)) || FAILED(MFCreateMemoryBuffer(static_cast<DWORD>(f.data.size()), &buf))) return false;
            BYTE* dst = nullptr;
            if (FAILED(buf->Lock(&dst, nullptr, nullptr))) return false;
            std::memcpy(dst, f.data.data(), f.data.size());
            buf->Unlock();
            buf->SetCurrentLength(static_cast<DWORD>(f.data.size()));
            sample->AddBuffer(buf.Get());
            sample->SetSampleTime(static_cast<LONGLONG>(f.frame) * 166667);
            if (f.key) sample->SetUINT32(MFSampleExtension_CleanPoint, TRUE);
            HRESULT hr = mft->ProcessInput(0, sample.Get(), 0);
            if (hr == MF_E_NOTACCEPTING) { Output(f); hr = mft->ProcessInput(0, sample.Get(), 0); }
            if (FAILED(hr)) return false;
            Output(f);
            return true;
        }

        void Output(const OnlineProtocol::VideoFrame& f)
        {
            for (int guard = 0; guard < 8; ++guard)
            {
                MFT_OUTPUT_DATA_BUFFER out{};
                ComPtr<IMFSample> own;
                if (!providesSamples)
                {
                    // (before the first stream change the size is not known: room for the frame, 16-aligned)
                    const DWORD need = haveOutput ? outSize : static_cast<DWORD>(((f.width + 15) & ~15) * ((f.height + 15) & ~15) * 3 / 2);
                    ComPtr<IMFMediaBuffer> buf;
                    if (FAILED(MFCreateSample(&own)) || FAILED(MFCreateMemoryBuffer(need, &buf))) return;
                    own->AddBuffer(buf.Get());
                    out.pSample = own.Get();
                }
                DWORD status = 0;
                const HRESULT hr = mft->ProcessOutput(0, 1, &out, &status);
                if (out.pEvents) out.pEvents->Release();
                if (hr == MF_E_TRANSFORM_NEED_MORE_INPUT) return;
                if (hr == MF_E_TRANSFORM_STREAM_CHANGE) { if (!PickOutput()) return; continue; }
                if (FAILED(hr)) { if (providesSamples && out.pSample) out.pSample->Release(); return; }
                if (out.pSample) Publish(out.pSample, f.width, f.height, f.captureMs);
                if (providesSamples && out.pSample) out.pSample->Release();
            }
        }
    };

    void DecoderMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool mfOk = MediaFoundationThere() && SUCCEEDED(MFStartup(MF_VERSION, MFSTARTUP_LITE));
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
        Decoder dec;
        OnlineProtocol::VideoFrame f;
        bool needKey = true;
        while (g_viewOn.load())
        {
            {
                std::unique_lock<std::mutex> lock(g_decMutex);
                g_decCv.wait_for(lock, std::chrono::milliseconds(100), [] { return !g_decQueue.empty() || !g_viewOn.load(); });
                if (!g_viewOn.load()) break;
                if (g_decQueue.empty()) continue;
                f = std::move(g_decQueue.front());
                g_decQueue.pop_front();
            }
            if (!mfOk) continue;
            if (g_decNeedKey.exchange(false)) needKey = true;
            if (needKey && !f.key) { g_wantKey.store(true); continue; }
            const int64_t t0 = QpcNow();
            const bool ok = dec.Decode(f);
            const double ms = QpcMs(t0, QpcNow());
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            if (ok)
            {
                needKey = false;
                ++g_viewStats.decoded;
                g_viewStats.decodeMs = g_viewStats.decodeMs <= 0 ? ms : g_viewStats.decodeMs * 0.95 + ms * 0.05;
            }
            else
            {
                ++g_viewStats.failures;
                if (f.key) { dec.Close(); }
                needKey = true;
                g_wantKey.store(true);
            }
        }
        dec.Close();
        if (mfOk) MFShutdown();
        if (SUCCEEDED(co)) CoUninitialize();
    }


    // ======================================================================================
    // D3D9 (render thread: the game's Present)
    // ======================================================================================
    template <typename T> void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

    struct Capture9
    {
        static constexpr int kRing = 2;
        IDirect3DSurface9* rt[kRing] = {};      // stream size, D3DPOOL_DEFAULT
        IDirect3DSurface9* sys[kRing] = {};     // stream size, system memory (readback)
        bool filled[kRing] = {};
        int64_t us[kRing] = {};
        int next = 0, w = 0, h = 0;
        int64_t lastQpc = 0;
        bool logged = false;
        void Reset()
        {
            for (int i = 0; i < kRing; ++i) { SafeRelease(rt[i]); SafeRelease(sys[i]); filled[i] = false; }
            w = h = 0; next = 0;
        }
        bool Ensure(IDirect3DDevice9* dev, int ow, int oh)
        {
            if (rt[0] && w == ow && h == oh) return true;
            Reset();
            for (int i = 0; i < kRing; ++i)
                if (FAILED(dev->CreateRenderTarget(ow, oh, D3DFMT_X8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &rt[i], nullptr)) ||
                    FAILED(dev->CreateOffscreenPlainSurface(ow, oh, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &sys[i], nullptr)))
                { Reset(); return false; }
            w = ow; h = oh;
            return true;
        }
    };
    Capture9& g_cap = *new Capture9();

    struct View9
    {
        IDirect3DSurface9* sys = nullptr;       // picture size, system memory
        IDirect3DSurface9* gpu = nullptr;       // picture size, D3DPOOL_DEFAULT
        int w = 0, h = 0;
        uint32_t seq = 0;
        bool have = false;
        void Reset() { SafeRelease(sys); SafeRelease(gpu); w = h = 0; have = false; seq = 0; }
    };
    View9& g_view = *new View9();
}

namespace OnlineVideo
{
    // ---------------- host ----------------
    bool StartHost(const Settings& settings, FrameSink sink)
    {
        std::lock_guard<std::mutex> lock(g_hostMutex);
        if (g_hostOn.load()) return true;
        g_settings = settings;
        g_settings.fps = std::clamp(g_settings.fps, 15, 144);
        g_settings.height = std::clamp(g_settings.height, 240, 2160) & ~7;
        g_settings.bitrateKbps = std::clamp(g_settings.bitrateKbps, 500, 100000);
        g_sink = std::move(sink);
        {
            std::lock_guard<std::mutex> s(g_statusMutex);
            g_bitrateNow = g_settings.bitrateKbps;
            g_encName = "starting";
            g_encMs = 0;
        }
        g_captured = g_replaced = g_skippedBusy = g_encoded = 0;
        g_encRun.store(true);
        g_encThread = std::thread(EncoderMain);
        g_hostOn.store(true);
        g_forceKey.store(true);
        return true;
    }

    void StopHost()
    {
        std::lock_guard<std::mutex> lock(g_hostMutex);
        if (!g_hostOn.exchange(false)) return;
        g_encRun.store(false);
        g_frameCv.notify_all();
        if (g_encThread.joinable()) g_encThread.join();
        {
            std::lock_guard<std::mutex> f(g_frameMutex);
            g_hasPending = false;
        }
        g_sink = nullptr;
        Logger::WriteFormat(Logger::Level::Info, "Online: stream stopped (frames taken %u, encoded %u, replaced before encoding %u, skipped %u)",
            g_captured.load(), g_encoded.load(), g_replaced.load(), g_skippedBusy.load());
    }

    bool HostRunning() { return g_hostOn.load(); }
    void RequestKeyframe() { g_forceKey.store(true); }
    void SetBitrate(int kbps)
    {
        kbps = std::clamp(kbps, 500, 100000);
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            if (kbps == g_bitrateNow) return;
            g_bitrateNow = kbps;
        }
        g_newBitrate.store(kbps);
    }

    std::string HostStatus()
    {
        std::lock_guard<std::mutex> lock(g_statusMutex);
        char line[256];
        std::snprintf(line, sizeof(line), "%s %dx%d %d kbps, encode %.1f ms, GPU wait %.1f ms", g_encName.c_str(), g_streamW, g_streamH,
            g_bitrateNow, g_encMs, g_readbackWaitMs);
        return line;
    }

    void CaptureD3D9(IDirect3DDevice9* dev)
    {
        if (!g_hostOn.load() || !dev) return;
        // the copy made a frame ago: done on the GPU by now
        for (int k = 0; k < Capture9::kRing; ++k)
        {
            const int i = (g_cap.next + k) % Capture9::kRing;
            if (!g_cap.filled[i]) continue;
            g_cap.filled[i] = false;
            const int64_t t0 = QpcNow();
            if (SUCCEEDED(dev->GetRenderTargetData(g_cap.rt[i], g_cap.sys[i])))
            {
                D3DLOCKED_RECT lr{};
                if (SUCCEEDED(g_cap.sys[i]->LockRect(&lr, nullptr, D3DLOCK_READONLY)))
                {
                    PushFrame(static_cast<const uint8_t*>(lr.pBits), lr.Pitch, g_cap.w, g_cap.h, g_cap.us[i]);
                    g_cap.sys[i]->UnlockRect();
                }
            }
            const double ms = QpcMs(t0, QpcNow());
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_readbackWaitMs = g_readbackWaitMs <= 0 ? ms : g_readbackWaitMs * 0.95 + ms * 0.05;
        }
        const int64_t now = QpcNow();
        const double interval = 1000.0 / std::max(1, g_settings.fps) - 1.5;
        if (g_cap.lastQpc && QpcMs(g_cap.lastQpc, now) < interval) return;
        IDirect3DSurface9* bb = nullptr;
        if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) || !bb) return;
        D3DSURFACE_DESC bd{};
        bb->GetDesc(&bd);
        int outH = std::min<int>(g_settings.height, static_cast<int>(bd.Height)) & ~7;
        int outW = static_cast<int>(static_cast<double>(outH) * bd.Width / std::max<UINT>(1, bd.Height) + 4) & ~7;
        if (outH < 64 || outW < 64 || !g_cap.Ensure(dev, outW, outH))
        {
            bb->Release();
            if (!g_cap.logged) { g_cap.logged = true; Logger::Write(Logger::Level::Error, "Online: stream surfaces could not be made"); }
            return;
        }
        const int slot = g_cap.next;
        g_cap.next = (g_cap.next + 1) % Capture9::kRing;
        if (SUCCEEDED(dev->StretchRect(bb, nullptr, g_cap.rt[slot], nullptr, D3DTEXF_LINEAR)))
        {
            g_cap.filled[slot] = true;
            g_cap.us[slot] = OnlineClock::NowUs();
        }
        bb->Release();
        g_cap.lastQpc = now;
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_streamW = outW; g_streamH = outH;
        }
        if (!g_cap.logged)
        {
            g_cap.logged = true;
            Logger::WriteFormat(Logger::Level::Info, "Online: stream picture %dx%d from the game's %ux%u (format %d)", outW, outH, bd.Width, bd.Height, static_cast<int>(bd.Format));
        }
    }

    void DeviceLost()
    {
        g_cap.Reset();
        g_view.Reset();
    }

    // ---------------- friend ----------------
    bool StartViewer()
    {
        if (g_viewOn.exchange(true)) return true;
        {
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            g_viewStats = ViewerStats{};
        }
        {
            std::lock_guard<std::mutex> lock(g_picMutex);
            g_pic.clear();
            g_picW = g_picH = 0;
        }
        g_viewReset.store(true);
        g_wantKey.store(false);
        g_decNeedKey.store(false);
        g_decThread = std::thread(DecoderMain);
        return true;
    }

    void StopViewer()
    {
        if (!g_viewOn.exchange(false)) return;
        g_decCv.notify_all();
        if (g_decThread.joinable()) g_decThread.join();
        std::lock_guard<std::mutex> lock(g_decMutex);
        g_decQueue.clear();
    }

    bool ViewerRunning() { return g_viewOn.load(); }

    void SubmitFrame(OnlineProtocol::VideoFrame&& frame)
    {
        if (!g_viewOn.load()) return;
        {
            std::lock_guard<std::mutex> lock(g_decMutex);
            // a keyframe makes everything still waiting unnecessary
            if (frame.key) g_decQueue.clear();
            else if (g_decQueue.size() > 30)
            {
                // far behind: drop what waits and restart from the next keyframe (asked for now)
                g_decQueue.clear();
                g_decNeedKey.store(true);
                g_wantKey.store(true);
            }
            g_decQueue.push_back(std::move(frame));
        }
        g_decCv.notify_one();
    }

    bool DrawViewerD3D9(IDirect3DDevice9* dev)
    {
        if (!g_viewOn.load() || !dev) return false;
        if (g_viewReset.exchange(false)) g_view.Reset();
        uint32_t captureMs = 0;
        {
            std::lock_guard<std::mutex> lock(g_picMutex);
            if (g_picSeq != g_view.seq && g_picW > 0 && g_pic.size() >= static_cast<size_t>(g_picW) * g_picH * 4)
            {
                if (g_view.w != g_picW || g_view.h != g_picH || !g_view.gpu)
                {
                    g_view.Reset();
                    if (FAILED(dev->CreateOffscreenPlainSurface(g_picW, g_picH, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &g_view.sys, nullptr)) ||
                        FAILED(dev->CreateOffscreenPlainSurface(g_picW, g_picH, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &g_view.gpu, nullptr)))
                    { g_view.Reset(); return false; }
                    g_view.w = g_picW; g_view.h = g_picH;
                }
                D3DLOCKED_RECT lr{};
                if (SUCCEEDED(g_view.sys->LockRect(&lr, nullptr, 0)))
                {
                    for (int r = 0; r < g_picH; ++r)
                        std::memcpy(static_cast<uint8_t*>(lr.pBits) + static_cast<size_t>(r) * lr.Pitch, g_pic.data() + static_cast<size_t>(r) * g_picW * 4, static_cast<size_t>(g_picW) * 4);
                    g_view.sys->UnlockRect();
                    if (SUCCEEDED(dev->UpdateSurface(g_view.sys, nullptr, g_view.gpu, nullptr))) g_view.have = true;
                }
                g_view.seq = g_picSeq;
                captureMs = g_picCaptureMs;
            }
        }
        if (!g_view.have) return false;
        IDirect3DSurface9* bb = nullptr;
        if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) || !bb) return false;
        D3DSURFACE_DESC bd{};
        bb->GetDesc(&bd);
        const float sw = static_cast<float>(bd.Width), sh = static_cast<float>(bd.Height);
        const float scale = std::min(sw / g_view.w, sh / g_view.h);
        const int dw = static_cast<int>(g_view.w * scale), dh = static_cast<int>(g_view.h * scale);
        RECT dst{ static_cast<LONG>((bd.Width - dw) / 2), static_cast<LONG>((bd.Height - dh) / 2), 0, 0 };
        dst.right = dst.left + dw; dst.bottom = dst.top + dh;
        IDirect3DSurface9* oldRt = nullptr;
        dev->GetRenderTarget(0, &oldRt);
        dev->SetRenderTarget(0, bb);
        dev->Clear(0, nullptr, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);
        if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
        dev->StretchRect(g_view.gpu, nullptr, bb, &dst, D3DTEXF_LINEAR);
        bb->Release();
        if (captureMs)
        {
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            ++g_viewStats.shown;
            g_viewStats.captureMs = captureMs;
            g_viewStats.shownAtMs = OnlineClock::NowMs();
            g_viewStats.width = static_cast<uint16_t>(g_view.w);
            g_viewStats.height = static_cast<uint16_t>(g_view.h);
            g_viewStats.picture = true;
        }
        return true;
    }

    bool TakeKeyframeRequest() { return g_wantKey.exchange(false); }

    ViewerStats GetViewerStats()
    {
        std::lock_guard<std::mutex> lock(g_viewStatsMutex);
        return g_viewStats;
    }

    void Shutdown()
    {
        StopHost();
        StopViewer();
        g_cap.Reset();
        g_view.Reset();
    }
}
