#include "OnlineAudio.h"
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <objbase.h>
#include <mmreg.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <audiopolicy.h>
#include <ks.h>
#include <ksmedia.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "Logger.h"
#include "OnlineProtocol.h"
#include "Paths.h"

#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "Mmdevapi.lib")

using Microsoft::WRL::ComPtr;

namespace
{
    // AUDIOCLIENT_ACTIVATION_PARAMS (audioclientactivationparams.h, Windows SDK 10.0.20348+), declared
    // here so older SDKs build too.
    struct LoopbackParams { DWORD targetProcessId; DWORD mode; };             // mode 0: this process and its children
    struct ActivationParams { DWORD type; LoopbackParams loopback; };         // type 1: process loopback

    WAVEFORMATEX StreamFormat()
    {
        WAVEFORMATEX f{};
        f.wFormatTag = WAVE_FORMAT_PCM;
        f.nChannels = 2;
        f.nSamplesPerSec = OnlineAudio::kRate;
        f.wBitsPerSample = 16;
        f.nBlockAlign = 4;
        f.nAvgBytesPerSec = OnlineAudio::kRate * 4;
        return f;
    }

    std::atomic<bool> g_capOn{ false };

    // ActivateAudioInterfaceAsync's completion: hands the audio client over and wakes the waiting thread.
    class ActivateHandler final : public IActivateAudioInterfaceCompletionHandler, public IAgileObject
    {
    public:
        ActivateHandler() { m_done = CreateEventW(nullptr, TRUE, FALSE, nullptr); }
        ~ActivateHandler() { if (m_done) CloseHandle(m_done); }
        STDMETHODIMP QueryInterface(REFIID riid, void** ppv) override
        {
            if (!ppv) return E_POINTER;
            if (riid == __uuidof(IUnknown) || riid == __uuidof(IActivateAudioInterfaceCompletionHandler))
                *ppv = static_cast<IActivateAudioInterfaceCompletionHandler*>(this);
            else if (riid == __uuidof(IAgileObject)) *ppv = static_cast<IAgileObject*>(this);
            else { *ppv = nullptr; return E_NOINTERFACE; }
            AddRef();
            return S_OK;
        }
        STDMETHODIMP_(ULONG) AddRef() override { return static_cast<ULONG>(InterlockedIncrement(&m_ref)); }
        STDMETHODIMP_(ULONG) Release() override
        {
            const LONG r = InterlockedDecrement(&m_ref);
            if (r == 0) delete this;
            return static_cast<ULONG>(r);
        }
        STDMETHODIMP ActivateCompleted(IActivateAudioInterfaceAsyncOperation* op) override
        {
            HRESULT hr = E_FAIL;
            ComPtr<IUnknown> unk;
            if (op && SUCCEEDED(op->GetActivateResult(&hr, &unk)) && SUCCEEDED(hr) && unk) unk.As(&client);
            result = hr;
            SetEvent(m_done);
            return S_OK;
        }
        HANDLE Done() const { return m_done; }
        ComPtr<IAudioClient> client;
        HRESULT result = E_PENDING;
    private:
        LONG m_ref = 1;
        HANDLE m_done = nullptr;
    };

    // Any PCM / float format -> 48 kHz stereo s16.
    struct Converter
    {
        int channels = 2, rate = OnlineAudio::kRate, bits = 16;
        bool isFloat = false, passThrough = true;
        double step = 1.0, pos = 0.0;
        std::vector<float> hist;   // stereo float frames not used up yet

        void Setup(const WAVEFORMATEX* f)
        {
            channels = std::max<int>(1, f->nChannels);
            rate = static_cast<int>(f->nSamplesPerSec);
            bits = f->wBitsPerSample;
            isFloat = f->wFormatTag == WAVE_FORMAT_IEEE_FLOAT;
            if (f->wFormatTag == WAVE_FORMAT_EXTENSIBLE && f->cbSize >= 22)
            {
                const auto* ext = reinterpret_cast<const WAVEFORMATEXTENSIBLE*>(f);
                isFloat = IsEqualGUID(ext->SubFormat, KSDATAFORMAT_SUBTYPE_IEEE_FLOAT) != 0;
                if (ext->Samples.wValidBitsPerSample) bits = f->wBitsPerSample;
            }
            passThrough = !isFloat && bits == 16 && channels == 2 && rate == OnlineAudio::kRate;
            step = static_cast<double>(rate) / OnlineAudio::kRate;
            pos = 0;
            hist.clear();
        }

        float Sample(const BYTE* p) const
        {
            if (isFloat) { float v; std::memcpy(&v, p, 4); return v; }
            switch (bits)
            {
            case 16: { int16_t v; std::memcpy(&v, p, 2); return v / 32768.0f; }
            case 24: { const int32_t v = (static_cast<int32_t>(p[2]) << 24 | p[1] << 16 | p[0] << 8) >> 8; return v / 8388608.0f; }
            case 32: { int32_t v; std::memcpy(&v, p, 4); return static_cast<float>(v / 2147483648.0); }
            default: return 0.0f;
            }
        }

        void Feed(const BYTE* data, UINT32 frames, bool silent, std::vector<int16_t>& out)
        {
            if (passThrough)
            {
                const size_t at = out.size();
                out.resize(at + size_t(frames) * 2);
                if (silent || !data) std::memset(out.data() + at, 0, size_t(frames) * 4);
                else std::memcpy(out.data() + at, data, size_t(frames) * 4);
                return;
            }
            const int bytes = (isFloat ? 32 : bits) / 8, block = bytes * channels;
            for (UINT32 i = 0; i < frames; ++i)
            {
                float l = 0, r = 0;
                if (!silent && data)
                {
                    const BYTE* f = data + size_t(i) * block;
                    l = Sample(f);
                    r = channels > 1 ? Sample(f + bytes) : l;
                }
                hist.push_back(l);
                hist.push_back(r);
            }
            const size_t have = hist.size() / 2;
            while (pos + 1.0 < static_cast<double>(have))
            {
                const size_t i = static_cast<size_t>(pos);
                const float t = static_cast<float>(pos - static_cast<double>(i));
                for (int c = 0; c < 2; ++c)
                {
                    const float v = hist[i * 2 + c] * (1.0f - t) + hist[(i + 1) * 2 + c] * t;
                    out.push_back(static_cast<int16_t>(std::clamp(v, -1.0f, 1.0f) * 32767.0f));
                }
                pos += step;
            }
            const size_t used = std::min(static_cast<size_t>(pos), have > 0 ? have - 1 : 0);
            hist.erase(hist.begin(), hist.begin() + static_cast<std::ptrdiff_t>(used * 2));
            pos -= static_cast<double>(used);
        }
    };

    // ---------------- host: capture ----------------
    // (never destroyed: the game can close while online, and a joinable std::thread at exit ends the process)
    std::thread& g_capThread = *new std::thread();
    OnlineAudio::ChunkSink g_sink;
    std::mutex g_statusMutex;
    std::string g_capStatus = "off", g_playStatus = "off";

    ComPtr<IAudioClient> ProcessLoopbackClient(std::string& why)
    {
        ActivationParams ap{};
        ap.type = 1;
        ap.loopback.targetProcessId = GetCurrentProcessId();
        ap.loopback.mode = 0;
        PROPVARIANT pv;
        PropVariantInit(&pv);
        pv.vt = VT_BLOB;
        pv.blob.cbSize = sizeof(ap);
        pv.blob.pBlobData = reinterpret_cast<BYTE*>(&ap);
        ActivateHandler* handler = new ActivateHandler();
        ComPtr<IActivateAudioInterfaceAsyncOperation> op;
        HRESULT hr = ActivateAudioInterfaceAsync(L"VAD\\Process_Loopback", __uuidof(IAudioClient), &pv, handler, &op);
        ComPtr<IAudioClient> client;
        if (SUCCEEDED(hr))
        {
            // (in short steps: stopping the stream must not wait for Windows' answer)
            DWORD waited = 0;
            DWORD r = WAIT_TIMEOUT;
            while (waited < 4000 && g_capOn.load() && (r = WaitForSingleObject(handler->Done(), 50)) == WAIT_TIMEOUT) waited += 50;
            if (r == WAIT_OBJECT_0)
            {
                client = handler->client;
                hr = handler->result;
            }
            else hr = HRESULT_FROM_WIN32(ERROR_TIMEOUT);
        }
        handler->Release();
        if (!client)
        {
            char t[96];
            std::snprintf(t, sizeof(t), "process loopback not available (0x%08lX)", static_cast<unsigned long>(hr));
            why = t;
        }
        return client;
    }

    void CaptureMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
        std::string why, mode;
        WAVEFORMATEX want = StreamFormat();
        ComPtr<IAudioClient> client = ProcessLoopbackClient(why);
        Converter conv;
        conv.Setup(&want);
        bool ok = false;
        if (client)
        {
            // the process loopback stream takes the format it is given (no mix format)
            const HRESULT hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK | AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM,
                200000, 0, &want, nullptr);
            ok = SUCCEEDED(hr);
            if (ok) mode = "the game's sound only";
            else { char t[96]; std::snprintf(t, sizeof(t), "process loopback start failed (0x%08lX)", static_cast<unsigned long>(hr)); why = t; client.Reset(); }
        }
        if (!ok)
        {
            // everything the PC plays (the default speakers)
            ComPtr<IMMDeviceEnumerator> en;
            ComPtr<IMMDevice> dev;
            if (SUCCEEDED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, IID_PPV_ARGS(&en))) &&
                SUCCEEDED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) &&
                SUCCEEDED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf()))))
            {
                HRESULT hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK | AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM |
                    AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY, 200000, 0, &want, nullptr);
                if (FAILED(hr))
                {
                    // the mix format, converted here
                    client.Reset();
                    dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf()));
                    WAVEFORMATEX* mix = nullptr;
                    if (client && SUCCEEDED(client->GetMixFormat(&mix)) && mix)
                    {
                        hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK, 200000, 0, mix, nullptr);
                        if (SUCCEEDED(hr)) conv.Setup(mix);
                        CoTaskMemFree(mix);
                    }
                }
                ok = client && SUCCEEDED(hr);
                if (ok) mode = "everything this PC plays (" + why + ")";
            }
        }
        ComPtr<IAudioCaptureClient> cap;
        if (ok && (FAILED(client->GetService(IID_PPV_ARGS(&cap))) || FAILED(client->Start()))) ok = false;
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_capStatus = ok ? "sound: " + mode : "no sound (" + why + ")";
        }
        Logger::WriteFormat(ok ? Logger::Level::Info : Logger::Level::Warning, "Online: %s", ok ? ("sound recorded: " + mode).c_str() : ("no sound to send: " + why).c_str());
        std::vector<int16_t> pcm;
        bool heard = false;
        while (ok && g_capOn.load())
        {
            Sleep(4);
            UINT32 next = 0;
            while (SUCCEEDED(cap->GetNextPacketSize(&next)) && next > 0)
            {
                BYTE* data = nullptr;
                UINT32 frames = 0;
                DWORD flags = 0;
                if (FAILED(cap->GetBuffer(&data, &frames, &flags, nullptr, nullptr))) break;
                const bool silent = (flags & AUDCLNT_BUFFERFLAGS_SILENT) != 0;
                if (!heard && !silent && frames)
                {
                    heard = true;
                    Logger::Write(Logger::Level::Info, "Online: the game's sound is coming through");
                }
                conv.Feed(data, frames, silent, pcm);
                cap->ReleaseBuffer(frames);
            }
            size_t at = 0;
            while (pcm.size() - at >= size_t(OnlineAudio::kChunk) * 2)
            {
                if (g_sink) g_sink(pcm.data() + at, OnlineAudio::kChunk);
                at += size_t(OnlineAudio::kChunk) * 2;
            }
            if (at) pcm.erase(pcm.begin(), pcm.begin() + static_cast<std::ptrdiff_t>(at));
            if (pcm.size() > size_t(OnlineAudio::kRate)) pcm.clear();
        }
        if (client) client->Stop();
        cap.Reset();
        client.Reset();
        if (SUCCEEDED(co)) CoUninitialize();
    }

    // ---------------- friend: playback ----------------
    std::atomic<bool> g_playOn{ false };
    std::thread& g_playThread = *new std::thread();
    OnlineProtocol::AudioBuffer g_buffer;
    GUID g_session{};
    std::vector<ComPtr<ISimpleAudioVolume>>& g_muted = *new std::vector<ComPtr<ISimpleAudioVolume>>();

    // Windows remembers a program's mute. A friend's game that closed while watching (crash, Alt+F4)
    // would start muted next time, so the ini notes it until the sound is put back.
    void NoteMuted(bool muted)
    {
        WritePrivateProfileStringA("Online", "GameSoundMuted", muted ? "1" : "0", Paths::GetConfigPath().c_str());
    }

    // The game's own sound sessions (this process, not ours) muted, or put back. all: every session of
    // this process (the repair after a session that never ended).
    void MuteGame(bool mute, IAudioClient* ours, bool all = false)
    {
        if (!mute && !all)
        {
            for (auto& v : g_muted) v->SetMute(FALSE, nullptr);
            if (!g_muted.empty()) NoteMuted(false);
            g_muted.clear();
            return;
        }
        std::wstring ourId;
        {
            ComPtr<IAudioSessionControl> c;
            ComPtr<IAudioSessionControl2> c2;
            LPWSTR id = nullptr;
            if (ours && SUCCEEDED(ours->GetService(IID_PPV_ARGS(&c))) && SUCCEEDED(c.As(&c2)) && SUCCEEDED(c2->GetSessionInstanceIdentifier(&id)) && id)
            {
                ourId = id;
                CoTaskMemFree(id);
            }
        }
        ComPtr<IMMDeviceEnumerator> en;
        ComPtr<IMMDevice> dev;
        ComPtr<IAudioSessionManager2> mgr;
        ComPtr<IAudioSessionEnumerator> list;
        if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, IID_PPV_ARGS(&en))) ||
            FAILED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) ||
            FAILED(dev->Activate(__uuidof(IAudioSessionManager2), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(mgr.GetAddressOf()))) ||
            FAILED(mgr->GetSessionEnumerator(&list))) return;
        int count = 0;
        list->GetCount(&count);
        const DWORD pid = GetCurrentProcessId();
        for (int i = 0; i < count; ++i)
        {
            ComPtr<IAudioSessionControl> c;
            ComPtr<IAudioSessionControl2> c2;
            if (FAILED(list->GetSession(i, &c)) || FAILED(c.As(&c2))) continue;
            DWORD sp = 0;
            if (FAILED(c2->GetProcessId(&sp)) || sp != pid) continue;
            LPWSTR id = nullptr;
            std::wstring sid;
            if (SUCCEEDED(c2->GetSessionInstanceIdentifier(&id)) && id) { sid = id; CoTaskMemFree(id); }
            if (!ourId.empty() && sid == ourId) continue;
            ComPtr<ISimpleAudioVolume> vol;
            if (FAILED(c.As(&vol))) continue;
            BOOL already = FALSE;
            vol->GetMute(&already);
            if (!mute)
            {
                if (already && SUCCEEDED(vol->SetMute(FALSE, nullptr)))
                    Logger::Write(Logger::Level::Info, "Online: this game's sound was still muted from an online session that did not end; unmuted");
                continue;
            }
            if (already) continue;
            if (g_muted.empty()) NoteMuted(true);
            if (SUCCEEDED(vol->SetMute(TRUE, nullptr)))
            {
                g_muted.push_back(vol);
                Logger::Write(Logger::Level::Info, "Online: this game's own sound muted while watching the host's game");
            }
        }
    }

    void PlaybackMain(int bufferMs)
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
        WAVEFORMATEX want = StreamFormat();
        ComPtr<IMMDeviceEnumerator> en;
        ComPtr<IMMDevice> dev;
        ComPtr<IAudioClient> client;
        ComPtr<IAudioRenderClient> render;
        std::string why;
        bool ok = SUCCEEDED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, IID_PPV_ARGS(&en))) &&
            SUCCEEDED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) &&
            SUCCEEDED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf())));
        if (ok)
        {
            CoCreateGuid(&g_session);   // our own session: the game's can be muted without muting this
            const HRESULT hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
                300000, 0, &want, &g_session);
            ok = SUCCEEDED(hr) && SUCCEEDED(client->GetService(IID_PPV_ARGS(&render)));
            if (!ok) { char t[64]; std::snprintf(t, sizeof(t), "0x%08lX", static_cast<unsigned long>(hr)); why = t; }
        }
        else why = "no speakers";
        UINT32 bufferFrames = 0;
        if (ok) ok = SUCCEEDED(client->GetBufferSize(&bufferFrames)) && SUCCEEDED(client->Start());
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_playStatus = ok ? "playing the host's sound" : "no sound (" + why + ")";
        }
        Logger::WriteFormat(ok ? Logger::Level::Info : Logger::Level::Warning, "Online: %s", ok ? "playing the host's sound" : ("cannot play the host's sound: " + why).c_str());
        if (ok) MuteGame(true, client.Get());
        // in the speakers' queue: about 15 ms (the rest waits in the jitter buffer)
        const UINT32 queue = std::min<UINT32>(bufferFrames, OnlineAudio::kRate * 15 / 1000);
        DWORD lastMute = GetTickCount();
        while (ok && g_playOn.load())
        {
            Sleep(3);
            UINT32 padding = 0;
            if (FAILED(client->GetCurrentPadding(&padding))) break;
            if (padding < queue)
            {
                const UINT32 n = queue - padding;
                BYTE* data = nullptr;
                if (SUCCEEDED(render->GetBuffer(n, &data)) && data)
                {
                    g_buffer.Pull(reinterpret_cast<int16_t*>(data), static_cast<int>(n));
                    render->ReleaseBuffer(n, 0);
                }
            }
            if (GetTickCount() - lastMute > 2000) { lastMute = GetTickCount(); MuteGame(true, client.Get()); }   // sessions the game opens later
        }
        MuteGame(false, nullptr);
        if (client) client->Stop();
        render.Reset();
        client.Reset();
        dev.Reset();
        en.Reset();
        if (SUCCEEDED(co)) CoUninitialize();
        (void)bufferMs;
    }
}

namespace OnlineAudio
{
    bool StartCapture(ChunkSink sink)
    {
        if (g_capOn.exchange(true)) return true;
        g_sink = std::move(sink);
        g_capThread = std::thread(CaptureMain);
        return true;
    }

    void StopCapture()
    {
        if (!g_capOn.exchange(false)) return;
        if (g_capThread.joinable()) g_capThread.join();
        g_sink = nullptr;
        std::lock_guard<std::mutex> lock(g_statusMutex);
        g_capStatus = "off";
    }

    bool StartPlayback(int bufferMs)
    {
        if (g_playOn.exchange(true)) return true;
        bufferMs = std::clamp(bufferMs, 10, 500);
        g_buffer.Configure(kRate * bufferMs / 1000, kRate * (bufferMs * 3 + 60) / 1000);
        g_buffer.Clear();
        g_playThread = std::thread(PlaybackMain, bufferMs);
        return true;
    }

    void StopPlayback()
    {
        if (!g_playOn.exchange(false)) return;
        if (g_playThread.joinable()) g_playThread.join();
        g_buffer.Clear();
        std::lock_guard<std::mutex> lock(g_statusMutex);
        g_playStatus = "off";
    }

    void Push(uint32_t seq, const int16_t* stereo, int frames)
    {
        if (g_playOn.load()) g_buffer.Push(seq, stereo, frames);
    }

    int BufferedMs() { return g_buffer.Level() * 1000 / kRate; }

    void RepairMuteOnce()
    {
        static std::atomic<bool> done{ false };
        if (done.exchange(true)) return;
        if (GetPrivateProfileIntA("Online", "GameSoundMuted", 0, Paths::GetConfigPath().c_str()) == 0) return;
        std::thread([] {
            const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
            MuteGame(false, nullptr, true);
            NoteMuted(false);
            if (SUCCEEDED(co)) CoUninitialize();
        }).detach();
    }

    std::string Status()
    {
        std::lock_guard<std::mutex> lock(g_statusMutex);
        if (g_capOn.load()) return g_capStatus;
        return g_playStatus;
    }
}
