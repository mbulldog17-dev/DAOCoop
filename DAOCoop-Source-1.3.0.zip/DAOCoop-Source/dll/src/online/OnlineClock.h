#pragma once
// Online play: one clock for the stream (frame times, pings), from the performance counter.
// GetTickCount moves in 10-16 ms steps, too coarse for frame times.
#include <cstdint>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>

namespace OnlineClock
{
    inline int64_t NowUs()
    {
        static const int64_t freq = [] { LARGE_INTEGER f; QueryPerformanceFrequency(&f); return f.QuadPart; }();
        LARGE_INTEGER t;
        QueryPerformanceCounter(&t);
        return (t.QuadPart / freq) * 1000000 + (t.QuadPart % freq) * 1000000 / freq;
    }
    inline uint32_t NowMs() { return static_cast<uint32_t>(NowUs() / 1000); }
}
