#pragma once
// Online play came from the Amalur co-op mod; this maps its logger onto DAOCoop.log.
#include <string>
#include "../log.h"

namespace Logger
{
    enum class Level { Info, Success, Warning, Error };
    template <typename... A> inline void WriteFormat(Level, const char* fmt, A... a) { Log(fmt, a...); }
    inline void Write(Level, const char* text) { Log("%s", text); }
    inline void Write(Level, const std::string& text) { Log("%s", text.c_str()); }
}
