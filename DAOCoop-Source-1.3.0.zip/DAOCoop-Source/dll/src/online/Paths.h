#pragma once
// DAOCoop.ini (narrow path) for the online settings - see online.cpp.
#include <string>

namespace Paths
{
    std::string GetConfigPath();
}
