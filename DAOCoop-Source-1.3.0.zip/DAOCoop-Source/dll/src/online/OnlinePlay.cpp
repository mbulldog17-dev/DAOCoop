#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#include <Xinput.h>
#include <objbase.h>
#include <oleauto.h>
#include <mmsystem.h>

#include "OnlinePlay.h"
#include "OnlineAudio.h"
#include "OnlineClock.h"
#include "OnlineProtocol.h"
#include "OnlineVideo.h"
#include "Logger.h"
#include "Paths.h"
#include "../vpad.h"
#include "../xinputroute.h"

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

#ifdef _MSC_VER
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#endif

#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif

static std::string g_iniA;
std::string Paths::GetConfigPath() { return g_iniA; }

namespace
{
    namespace P = OnlineProtocol;
    uint32_t Now() { return OnlineClock::NowMs(); }
    constexpr int kMaxFriends = 2;   // Player 2 and Player 3

    // ---------------- settings: [Online] in DAOCoop.ini ----------------
    struct Options
    {
        int port = P::kDefaultPort;
        int height = 720, fps = 60, bitrate = 8000, minBitrate = 2000;
        bool hardware = true;
        int keyframeSeconds = 4, profile = 66, effort = 33, fec = 10;
        int audioMs = 30;
        bool upnp = true, stun = true;
        std::string name;
    };

    Options LoadOptions()
    {
        const std::string ini = Paths::GetConfigPath();
        auto get = [&](const char* key, int def) {
            const int none = -987654;
            const int v = static_cast<int>(GetPrivateProfileIntA("Online", key, none, ini.c_str()));
            if (v == none) { WritePrivateProfileStringA("Online", key, std::to_string(def).c_str(), ini.c_str()); return def; }
            return v;
        };
        Options o;
        o.port = std::clamp(get("Port", o.port), 1024, 65535);
        o.height = get("StreamHeight", o.height);
        o.fps = get("StreamFPS", o.fps);
        o.bitrate = get("BitrateKbps", o.bitrate);
        o.minBitrate = get("MinBitrateKbps", o.minBitrate);
        o.hardware = get("HardwareEncoder", 1) != 0;
        o.keyframeSeconds = get("KeyframeSeconds", o.keyframeSeconds);
        o.profile = get("H264Profile", o.profile);
        o.effort = get("EncoderEffort", o.effort);
        o.fec = std::clamp(get("ParityEvery", o.fec), 0, 64);
        o.audioMs = get("AudioBufferMs", o.audioMs);
        o.upnp = get("UPnP", 1) != 0;
        o.stun = get("FindPublicAddress", 1) != 0;
        char name[64]{};
        GetPrivateProfileStringA("Online", "Name", "", name, sizeof(name), ini.c_str());
        o.name = name;
        if (o.name.empty())
        {
            char user[64]{};
            DWORD n = sizeof(user);
            if (GetUserNameA(user, &n) && user[0]) o.name = user;
        }
        return o;
    }

    // ---------------- state ----------------
    enum class Role { Off, Host, Join };
    enum class Stage { None, Window, Connecting, Watching };

    struct Peer
    {
        bool on = false;
        sockaddr_in addr{};
        uint32_t clientId = 0, heardMs = 0, rtt = 0, inputSeq = 0, lastInputAt = 0, connectedAt = 0, lastStatsLog = 0;
        bool haveSeq = false, rested = true, haveStats = false;
        std::string name;
        int slot = -1;                 // host: controller slot 4/5 this friend plays with
        P::StatsMsg stats{}, prevStats{};
        int bitrate = 0, calm = 0;     // host: what this friend's link takes
    };
    struct LanGame { sockaddr_in addr{}; std::string name; uint32_t token = 0; bool full = false; uint32_t seenMs = 0; };

    std::mutex g_lifeMutex;             // start / stop
    std::mutex g_mutex;                 // everything below, unless noted
    Options g_opt;
    std::atomic<int> g_role{ static_cast<int>(Role::Off) };
    Stage g_stage = Stage::None;
    SOCKET g_sock = INVALID_SOCKET;
    uint16_t g_boundPort = 0;
    // (never destroyed: the game can close while online, and a joinable std::thread at exit ends the process)
    std::thread& g_net = *new std::thread();
    std::thread& g_setup = *new std::thread();
    std::atomic<bool> g_netRun{ false };
    bool g_timerRes = false;
    std::deque<std::wstring> g_messages;

    // host
    uint32_t g_token = 0, g_session = 0;
    std::string g_code, g_codeNote, g_codeWarn;
    bool g_setupDone = false;
    std::atomic<uint32_t> g_stunIp{ 0 };
    std::atomic<uint16_t> g_stunPort{ 0 };
    uint8_t g_stunTx[12]{};
    bool g_upnpMapped = false;
    uint16_t g_upnpPort = 0;
    Peer g_peers[kMaxFriends];
    std::atomic<bool> g_streaming{ false };
    std::mutex g_streamMutex;           // the friends' addresses for the encoder / sound threads
    sockaddr_in g_streamAddr[kMaxFriends]{};
    bool g_streamOn[kMaxFriends]{};
    P::VideoHistory g_history(150);
    std::atomic<uint32_t> g_nextFrame{ 1 }, g_audioSeq{ 0 };
    std::atomic<int> g_fec{ 10 };
    std::atomic<uint32_t> g_hostGen{ 0 };
    P::AdpcmState g_adpcm[2];           // sound thread only
    std::atomic<uint64_t> g_bytesOut{ 0 };
    double g_kbpsOut = 0;
    int g_bitrateNow = 0;
    uint32_t g_lastKeyReq = 0;

    // friend
    Peer g_host;
    P::VideoReceiver g_rx;              // network thread only
    uint32_t g_helloAt = 0, g_connectStart = 0, g_discoverAt = 0, g_clipAt = 0;
    uint32_t g_joinToken = 0, g_clientId = 0;
    std::string g_error, g_lastClip;
    std::vector<LanGame> g_lan;
    int32_t g_clockOffset = 0;          // host clock - our clock
    uint32_t g_bestRtt = UINT32_MAX, g_offsetAt = 0, g_latencyMs = 0;
    bool g_haveOffset = false;
    int g_padUser = -1;
    uint32_t g_padScanAt = 0, g_inputSeq = 0, g_leaveHold = 0, g_escHold = 0, g_lastInputSent = 0;
    WORD g_prevButtons = 0;
    XINPUT_GAMEPAD g_lastSent{};

    Role RoleNow() { return static_cast<Role>(g_role.load()); }
    std::wstring Wide(const std::string& s)
    {
        std::wstring w;
        const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n); }
        return w;
    }
    // g_mutex held.
    void Message(const std::string& text)
    {
        Logger::WriteFormat(Logger::Level::Info, "Online: %s", text.c_str());
        if (g_messages.size() < 16) g_messages.push_back(Wide(text));
    }

    std::string AddrText(const sockaddr_in& a)
    {
        char ip[INET_ADDRSTRLEN]{};
        inet_ntop(AF_INET, &a.sin_addr, ip, sizeof(ip));
        return std::string(ip) + ":" + std::to_string(ntohs(a.sin_port));
    }
    std::string IpText(uint32_t ip)
    {
        char t[32];
        std::snprintf(t, sizeof(t), "%u.%u.%u.%u", ip >> 24, (ip >> 16) & 255, (ip >> 8) & 255, ip & 255);
        return t;
    }
    bool SameAddr(const sockaddr_in& a, const sockaddr_in& b)
    {
        return a.sin_addr.s_addr == b.sin_addr.s_addr && a.sin_port == b.sin_port;
    }
    uint32_t Random32()
    {
        static std::mt19937 rng([] { std::random_device rd; return rd() ^ static_cast<uint32_t>(OnlineClock::NowUs()); }());
        uint32_t v = 0;
        while (!v) v = rng();
        return v;
    }
    bool PrivateIp(uint32_t ip)
    {
        return (ip >> 24) == 10 || (ip >> 20) == 0xAC1 || (ip >> 16) == 0xC0A8 || (ip >> 22) == (100u << 2 | 1u) || (ip >> 24) == 127 || (ip >> 16) == 0xA9FE;
    }
    bool CarrierNat(uint32_t ip) { return (ip & 0xFFC00000u) == 0x64400000u; }   // 100.64.0.0/10

    void Send(const sockaddr_in& to, const void* data, size_t n)
    {
        if (g_sock == INVALID_SOCKET) return;
        const int r = sendto(g_sock, static_cast<const char*>(data), static_cast<int>(n), 0, reinterpret_cast<const sockaddr*>(&to), sizeof(to));
        if (r > 0) g_bytesOut.fetch_add(static_cast<uint64_t>(r), std::memory_order_relaxed);
    }
    template <typename T> void SendMsg(const sockaddr_in& to, T& m, uint8_t type, uint32_t session)
    {
        P::Fill(m, type, session);
        Send(to, &m, sizeof(m));
    }
    void SendRefuse(const sockaddr_in& to, uint32_t session, const std::string& why)
    {
        P::RefuseMsg m{};
        P::CopyName(m.reason, sizeof(m.reason), why);
        SendMsg(to, m, P::kRefuse, session);
    }
    void SendBye(const sockaddr_in& to, uint32_t session, const char* why)
    {
        P::ByeMsg m{};
        P::CopyName(m.reason, sizeof(m.reason), why);
        for (int i = 0; i < 3; ++i) SendMsg(to, m, P::kBye, session);
    }

    // ---------------- the friend's own controller (read straight from XInput, never routed) ----------------
    bool ReadOwnPad(XINPUT_GAMEPAD& pad)
    {
        const uint32_t now = Now();
        XINPUT_STATE st{};
        if (g_padUser >= 0 && XInputGetState(static_cast<DWORD>(g_padUser), &st) == ERROR_SUCCESS) { pad = st.Gamepad; return true; }
        if (g_padUser >= 0 || static_cast<int32_t>(now - g_padScanAt) >= 0)
        {
            g_padScanAt = now + 500;
            for (DWORD u = 0; u < 4; ++u)
                if (XInputGetState(u, &st) == ERROR_SUCCESS) { g_padUser = static_cast<int>(u); pad = st.Gamepad; return true; }
            g_padUser = -1;
        }
        pad = XINPUT_GAMEPAD{};
        return false;
    }

    bool OurWindowInFront()
    {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        return pid == GetCurrentProcessId();
    }

    // The game's main window (the clipboard needs an owner window).
    struct FindWindowCtx { HWND w; DWORD pid; };
    BOOL CALLBACK FindGameWindow(HWND w, LPARAM lp)
    {
        auto* f = reinterpret_cast<FindWindowCtx*>(lp);
        DWORD pid = 0;
        GetWindowThreadProcessId(w, &pid);
        if (pid == f->pid && IsWindowVisible(w) && !GetWindow(w, GW_OWNER)) { f->w = w; return FALSE; }
        return TRUE;
    }
    HWND GameWindow()
    {
        FindWindowCtx f{ nullptr, GetCurrentProcessId() };
        EnumWindows(FindGameWindow, reinterpret_cast<LPARAM>(&f));
        return f.w;
    }

    void CopyToClipboard(const std::string& text)
    {
        if (!OpenClipboard(GameWindow())) return;
        EmptyClipboard();
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
        if (h)
        {
            if (void* p = GlobalLock(h)) { std::memcpy(p, text.c_str(), text.size() + 1); GlobalUnlock(h); }
            if (!SetClipboardData(CF_TEXT, h)) GlobalFree(h);
        }
        CloseClipboard();
    }
    std::string ClipboardText()
    {
        std::string out;
        if (!OpenClipboard(nullptr)) return out;
        if (HANDLE h = GetClipboardData(CF_UNICODETEXT))
        {
            if (const wchar_t* w = static_cast<const wchar_t*>(GlobalLock(h)))
            {
                const int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
                if (n > 1 && n < 4096) { out.assign(static_cast<size_t>(n - 1), '\0'); WideCharToMultiByte(CP_UTF8, 0, w, -1, &out[0], n, nullptr, nullptr); }
                GlobalUnlock(h);
            }
        }
        CloseClipboard();
        return out;
    }

    // ---------------- the router: UPnP (Windows' own NAT traversal COM object, late bound) ----------------
    HRESULT DispCall(IDispatch* d, const wchar_t* name, WORD flags, VARIANT* args, UINT argc, VARIANT* result)
    {
        if (result) VariantInit(result);   // (callers clear it whatever happens)
        DISPID id = 0;
        LPOLESTR n = const_cast<LPOLESTR>(name);
        HRESULT hr = d->GetIDsOfNames(IID_NULL, &n, 1, LOCALE_USER_DEFAULT, &id);
        if (FAILED(hr)) return hr;
        DISPPARAMS dp{ args, nullptr, argc, 0 };
        EXCEPINFO ei{};
        UINT argErr = 0;
        hr = d->Invoke(id, IID_NULL, LOCALE_USER_DEFAULT, flags, &dp, result, &ei, &argErr);
        if (ei.bstrSource) SysFreeString(ei.bstrSource);
        if (ei.bstrDescription) SysFreeString(ei.bstrDescription);
        if (ei.bstrHelpFile) SysFreeString(ei.bstrHelpFile);
        return hr;
    }

    IDispatch* UpnpCollection(std::string& why)
    {
        CLSID clsid{};
        if (FAILED(CLSIDFromProgID(L"HNetCfg.NATUPnP", &clsid))) { why = "UPnP is not part of this Windows"; return nullptr; }
        IDispatch* nat = nullptr;
        if (FAILED(CoCreateInstance(clsid, nullptr, CLSCTX_INPROC_SERVER, IID_IDispatch, reinterpret_cast<void**>(&nat))) || !nat)
        {
            why = "UPnP could not start";
            return nullptr;
        }
        IDispatch* coll = nullptr;
        // the first ask searches the network for the router; it can come back empty while that runs
        for (int tries = 0; tries < 4 && !coll; ++tries)
        {
            VARIANT v;
            if (SUCCEEDED(DispCall(nat, L"StaticPortMappingCollection", DISPATCH_PROPERTYGET, nullptr, 0, &v)) && v.vt == VT_DISPATCH && v.pdispVal)
                coll = v.pdispVal;
            else
            {
                VariantClear(&v);
                Sleep(1200);
            }
        }
        nat->Release();
        if (!coll) why = "the router did not answer UPnP (it may be switched off in the router)";
        return coll;
    }

    bool UpnpMap(uint16_t port, uint32_t lanIp, uint32_t& externalIp, std::string& why)
    {
        IDispatch* coll = UpnpCollection(why);
        if (!coll) return false;
        // an old mapping of this port (from a game that closed without removing it) goes first
        {
            VARIANT args[2];
            args[1].vt = VT_I4; args[1].lVal = port;
            args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"UDP");
            VARIANT r;
            DispCall(coll, L"Remove", DISPATCH_METHOD, args, 2, &r);
            VariantClear(&r);
            SysFreeString(args[0].bstrVal);
        }
        const std::string lan = IpText(lanIp);
        const std::wstring wlan(lan.begin(), lan.end());
        VARIANT args[6];
        args[5].vt = VT_I4; args[5].lVal = port;                                    // external port
        args[4].vt = VT_BSTR; args[4].bstrVal = SysAllocString(L"UDP");
        args[3].vt = VT_I4; args[3].lVal = port;                                    // internal port
        args[2].vt = VT_BSTR; args[2].bstrVal = SysAllocString(wlan.c_str());       // this PC
        args[1].vt = VT_BOOL; args[1].boolVal = VARIANT_TRUE;
        args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"Dragon Age Origins co-op");
        VARIANT mapping;
        const HRESULT hr = DispCall(coll, L"Add", DISPATCH_METHOD, args, 6, &mapping);
        SysFreeString(args[4].bstrVal); SysFreeString(args[2].bstrVal); SysFreeString(args[0].bstrVal);
        bool ok = SUCCEEDED(hr) && mapping.vt == VT_DISPATCH && mapping.pdispVal;
        if (ok)
        {
            VARIANT ext;
            if (SUCCEEDED(DispCall(mapping.pdispVal, L"ExternalIPAddress", DISPATCH_PROPERTYGET, nullptr, 0, &ext)) && ext.vt == VT_BSTR && ext.bstrVal)
            {
                char ip[64]{};
                WideCharToMultiByte(CP_UTF8, 0, ext.bstrVal, -1, ip, sizeof(ip) - 1, nullptr, nullptr);
                in_addr a{};
                if (inet_pton(AF_INET, ip, &a) == 1) externalIp = ntohl(a.s_addr);
            }
            VariantClear(&ext);
        }
        else
        {
            char t[96];
            std::snprintf(t, sizeof(t), "the router refused to open the port (0x%08lX)", static_cast<unsigned long>(hr));
            why = t;
        }
        VariantClear(&mapping);
        coll->Release();
        return ok;
    }

    std::mutex g_upnpMutex;                       // one UPnP job at a time
    std::atomic<uint32_t> g_upnpMappedGen{ 0 };   // the hosting session whose mapping is on the router (0: none)

    // COM is initialized by the caller.
    void UpnpRemoveNow(uint16_t port)
    {
        std::string why;
        if (IDispatch* coll = UpnpCollection(why))
        {
            VARIANT args[2];
            args[1].vt = VT_I4; args[1].lVal = port;
            args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"UDP");
            VARIANT r;
            DispCall(coll, L"Remove", DISPATCH_METHOD, args, 2, &r);
            VariantClear(&r);
            SysFreeString(args[0].bstrVal);
            coll->Release();
        }
    }

    // The mapping of hosting session `gen`, removed in the background (not if a newer session made its own).
    void UpnpUnmap(uint16_t port, uint32_t gen)
    {
        std::thread([port, gen] {
            std::lock_guard<std::mutex> up(g_upnpMutex);
            if (g_upnpMappedGen.load() != gen) return;
            if (FAILED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED))) return;
            UpnpRemoveNow(port);
            g_upnpMappedGen.store(0);
            CoUninitialize();
        }).detach();
    }

    // ---------------- this PC's address on its network, and on the internet (STUN) ----------------
    uint32_t LocalIp()
    {
        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (s == INVALID_SOCKET) return 0;
        sockaddr_in to{};
        to.sin_family = AF_INET;
        to.sin_port = htons(53);
        inet_pton(AF_INET, "8.8.8.8", &to.sin_addr);   // no packet is sent: this only picks the route
        uint32_t ip = 0;
        if (connect(s, reinterpret_cast<sockaddr*>(&to), sizeof(to)) == 0)
        {
            sockaddr_in me{};
            int len = sizeof(me);
            if (getsockname(s, reinterpret_cast<sockaddr*>(&me), &len) == 0) ip = ntohl(me.sin_addr.s_addr);
        }
        closesocket(s);
        return ip;
    }

    void StunAsk()
    {
        const char* servers[][2] = { { "stun.l.google.com", "19302" }, { "stun.cloudflare.com", "3478" }, { "stun1.l.google.com", "19302" } };
        uint8_t req[20]{};
        req[0] = 0x00; req[1] = 0x01;                 // binding request, no attributes
        req[4] = 0x21; req[5] = 0x12; req[6] = 0xA4; req[7] = 0x42;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            for (int i = 0; i < 12; ++i) g_stunTx[i] = static_cast<uint8_t>(Random32());
            std::memcpy(req + 8, g_stunTx, 12);
        }
        for (auto& s : servers)
        {
            addrinfo hints{};
            hints.ai_family = AF_INET;
            hints.ai_socktype = SOCK_DGRAM;
            addrinfo* res = nullptr;
            if (getaddrinfo(s[0], s[1], &hints, &res) != 0 || !res) continue;
            sockaddr_in to{};
            std::memcpy(&to, res->ai_addr, std::min<size_t>(sizeof(to), res->ai_addrlen));
            freeaddrinfo(res);
            Send(to, req, sizeof(req));
        }
    }

    bool IsStun(const uint8_t* d, int n)
    {
        return n >= 20 && d[4] == 0x21 && d[5] == 0x12 && d[6] == 0xA4 && d[7] == 0x42 && (d[0] & 0xC0) == 0;
    }

    void HandleStun(const uint8_t* d, int n)
    {
        if (d[0] != 0x01 || d[1] != 0x01) return;   // binding success
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (std::memcmp(d + 8, g_stunTx, 12) != 0) return;
        }
        const int len = (d[2] << 8) | d[3];
        int at = 20;
        while (at + 4 <= n && at + 4 <= 20 + len)
        {
            const int type = (d[at] << 8) | d[at + 1], alen = (d[at + 2] << 8) | d[at + 3];
            const uint8_t* v = d + at + 4;
            if (at + 4 + alen > n) break;
            if ((type == 0x0020 || type == 0x0001) && alen >= 8 && v[1] == 0x01)
            {
                uint16_t port = static_cast<uint16_t>((v[2] << 8) | v[3]);
                uint32_t ip = (uint32_t(v[4]) << 24) | (uint32_t(v[5]) << 16) | (uint32_t(v[6]) << 8) | v[7];
                if (type == 0x0020) { port ^= 0x2112; ip ^= 0x2112A442u; }
                if (!g_stunIp.load()) { g_stunPort.store(port); g_stunIp.store(ip); }
                return;
            }
            at += 4 + ((alen + 3) & ~3);
        }
    }
    // ---------------- host: the stream (one encoder, sent to every friend) ----------------
    void OnEncoded(const uint8_t* data, size_t size, bool key, uint16_t w, uint16_t h, uint32_t captureMs)
    {
        if (!g_streaming.load(std::memory_order_relaxed)) return;
        sockaddr_in to[kMaxFriends]{};
        bool on[kMaxFriends]{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_streamMutex);
            for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
            session = g_session;
        }
        std::vector<std::vector<uint8_t>> packets;
        const uint32_t frame = g_nextFrame.fetch_add(1);
        P::BuildVideoPackets(session, frame, data, size, key, w, h, captureMs, g_fec.load(), packets);
        for (int i = 0; i < kMaxFriends; ++i)
            if (on[i]) for (const auto& p : packets) Send(to[i], p.data(), p.size());
        g_history.Store(frame, packets);
    }

    void OnSound(const int16_t* stereo, int frames)
    {
        if (!g_streaming.load(std::memory_order_relaxed)) { g_adpcm[0] = g_adpcm[1] = P::AdpcmState{}; return; }
        sockaddr_in to[kMaxFriends]{};
        bool on[kMaxFriends]{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_streamMutex);
            for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
            session = g_session;
        }
        const auto pkt = P::BuildAudioPacket(session, g_audioSeq.fetch_add(1), stereo, frames, g_adpcm);
        for (int i = 0; i < kMaxFriends; ++i) if (on[i]) Send(to[i], pkt.data(), pkt.size());
    }

    // g_mutex held: the stream's list of friends follows g_peers.
    void SyncStreamTargets()
    {
        std::lock_guard<std::mutex> lock(g_streamMutex);
        for (int i = 0; i < kMaxFriends; ++i) { g_streamOn[i] = g_peers[i].on; g_streamAddr[i] = g_peers[i].addr; }
    }

    void StartStream(const Options& o)
    {
        if (g_streaming.exchange(true)) { OnlineVideo::RequestKeyframe(); return; }
        g_history.Clear();
        OnlineVideo::Settings vs;
        vs.height = o.height; vs.fps = o.fps; vs.bitrateKbps = o.bitrate; vs.gopSeconds = o.keyframeSeconds;
        vs.profile = o.profile; vs.qualityVsSpeed = o.effort; vs.hardware = o.hardware;
        g_bitrateNow = o.bitrate;
        OnlineVideo::StartHost(vs, OnEncoded);
        OnlineVideo::RequestKeyframe();
        OnlineAudio::StartCapture(OnSound);
    }
    void StopStream()
    {
        if (!g_streaming.exchange(false)) return;
        OnlineVideo::StopHost();
        OnlineAudio::StopCapture();
    }

    // The stream's bitrate: what the weakest friend's link takes. g_mutex held.
    void ApplyBitrate()
    {
        int kbps = 0;
        for (const Peer& p : g_peers) if (p.on && p.bitrate > 0) kbps = kbps ? std::min(kbps, p.bitrate) : p.bitrate;
        if (kbps > 0 && kbps != g_bitrateNow) { g_bitrateNow = kbps; OnlineVideo::SetBitrate(kbps); }
    }

    void HostSetup(uint16_t port, uint32_t gen)
    {
        const uint32_t lan = LocalIp();
        Options o;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            o = g_opt;
        }
        if (o.stun) StunAsk();
        uint32_t upnpIp = 0;
        std::string upnpWhy = "UPnP off ([Online] UPnP=0)";
        bool mapped = false;
        if (o.upnp && lan)
        {
            std::lock_guard<std::mutex> up(g_upnpMutex);
            if (gen == g_hostGen.load() && SUCCEEDED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED)))
            {
                mapped = UpnpMap(port, lan, upnpIp, upnpWhy);
                if (mapped) g_upnpMappedGen.store(gen);
                if (mapped && gen != g_hostGen.load())
                {
                    UpnpRemoveNow(port);
                    g_upnpMappedGen.store(0);
                    mapped = false;
                }
                CoUninitialize();
            }
        }
        if (gen != g_hostGen.load()) return;
        for (int i = 0; i < 30 && o.stun && !g_stunIp.load(); ++i)
        {
            if (i == 10) StunAsk();
            Sleep(100);
        }
        if (gen != g_hostGen.load()) return;
        const uint32_t stunIp = g_stunIp.load();
        const uint16_t stunPort = g_stunPort.load();
        uint32_t ip = stunIp ? stunIp : (upnpIp && !PrivateIp(upnpIp) ? upnpIp : lan);
        uint16_t codePort = port;
        if (!mapped && stunIp && stunPort) codePort = stunPort;
        std::string note, warn;
        if (mapped) note = "Router: port " + std::to_string(port) + " opened by itself (UPnP).";
        else note = "Router: " + upnpWhy + ". If friends cannot connect, forward UDP port " + std::to_string(port) + " to this PC (" + IpText(lan) + ").";
        if (upnpIp && stunIp && upnpIp != stunIp)
            warn = CarrierNat(upnpIp) || PrivateIp(upnpIp)
                ? "Your router sits behind another one (or your internet provider's): friends outside may not reach you."
                : "The router reports a different internet address than the internet sees.";
        if (!stunIp && !upnpIp) warn = "Could not find this PC's internet address: the code only works on this network.";
        if (stunIp && !mapped && stunPort != port) warn = "Your router changes the game's port: friends outside may not reach you unless the port is forwarded.";
        const std::string code = P::MakeJoinCode(ip, codePort, g_token);
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (RoleNow() != Role::Host || gen != g_hostGen.load()) return;
            g_code = code;
            g_codeNote = note;
            g_codeWarn = warn;
            g_setupDone = true;
            g_upnpMapped = mapped;
            g_upnpPort = port;
        }
        CopyToClipboard(code);
        Logger::WriteFormat(Logger::Level::Success, "Online: hosting on port %u, invite code %s (address %s:%u; LAN %s; UPnP %s; internet address seen %s:%u)",
            port, code.c_str(), IpText(ip).c_str(), codePort, IpText(lan).c_str(), mapped ? ("mapped, router says " + IpText(upnpIp)).c_str() : upnpWhy.c_str(),
            stunIp ? IpText(stunIp).c_str() : "none", stunPort);
        if (!warn.empty()) Logger::WriteFormat(Logger::Level::Warning, "Online: %s", warn.c_str());
    }

    int PeerAt(const sockaddr_in& from)
    {
        for (int i = 0; i < kMaxFriends; ++i) if (g_peers[i].on && SameAddr(g_peers[i].addr, from)) return i;
        return -1;
    }

    // g_mutex held.
    void DropPeer(int i, const std::string& why)
    {
        Peer& p = g_peers[i];
        if (!p.on) return;
        Message(p.name + " " + why);
        VPadSetRemote(p.slot, nullptr);
        p = Peer{};
        SyncStreamTargets();
    }

    void HostHandle(const P::Header* h, const uint8_t* d, int n, const sockaddr_in& from, uint32_t now)
    {
        bool startStream = false, stopStream = false;
        Options o;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            o = g_opt;
            int pi = PeerAt(from);
            const bool known = pi >= 0 && h->session == g_session;
            if (known) g_peers[pi].heardMs = now;
            switch (h->type)
            {
            case P::kDiscover:
            {
                const auto* m = P::As<P::DiscoverMsg>(d, n);
                if (!m) break;
                int used = 0;
                for (const Peer& p : g_peers) used += p.on ? 1 : 0;
                P::OfferMsg r{};
                r.nonce = m->nonce;
                r.token = g_token;
                r.port = g_boundPort;
                r.slotTaken = used >= kMaxFriends ? 1 : 0;
                r.busy = r.slotTaken;
                P::CopyName(r.name, sizeof(r.name), o.name.empty() ? "Host" : o.name);
                SendMsg(from, r, P::kOffer, 0);
                break;
            }
            case P::kHello:
            {
                const auto* m = P::As<P::HelloMsg>(d, n);
                if (!m) break;
                if (m->token != g_token) { SendRefuse(from, 0, "That invite code is not for this game (an old code?). Ask for the new one."); break; }
                // the same friend from another address (their router moved, or the near address at home)
                if (pi < 0 && m->clientId)
                    for (int i = 0; i < kMaxFriends; ++i)
                        if (g_peers[i].on && g_peers[i].clientId == m->clientId)
                        {
                            Logger::WriteFormat(Logger::Level::Info, "Online: %s now comes from %s", g_peers[i].name.c_str(), AddrText(from).c_str());
                            g_peers[i].addr = from;
                            pi = i;
                            SyncStreamTargets();
                        }
                if (pi < 0)
                {
                    for (int i = 0; i < kMaxFriends && pi < 0; ++i) if (!g_peers[i].on) pi = i;
                    if (pi < 0) { SendRefuse(from, 0, "This game already has two friends connected."); break; }
                    Peer& p = g_peers[pi];
                    p = Peer{};
                    p.on = true;
                    p.addr = from;
                    p.clientId = m->clientId;
                    p.name = P::ReadName(m->name, sizeof(m->name));
                    if (p.name.empty()) p.name = pi == 0 ? "Friend 1" : "Friend 2";
                    p.slot = kVPadFirst + pi;
                    p.bitrate = o.bitrate;
                    p.connectedAt = now;
                    XINPUT_GAMEPAD rest{};
                    VPadSetRemote(p.slot, &rest);   // "plugged in": the lobby can give it to Player 2/3
                    SyncStreamTargets();
                    startStream = true;
                    Message(p.name + " joined online (" + AddrText(from) + ") - press START on their controller to play");
                }
                g_peers[pi].heardMs = now;
                P::WelcomeMsg w{};
                w.width = 0;
                w.height = static_cast<uint16_t>(o.height);
                w.fps = static_cast<uint8_t>(std::clamp(o.fps, 1, 255));
                w.slotTaken = 0;
                w.hostMs = now;
                P::CopyName(w.name, sizeof(w.name), o.name.empty() ? "Host" : o.name);
                SendMsg(from, w, P::kWelcome, g_session);
                if (startStream) OnlineVideo::RequestKeyframe();
                break;
            }
            case P::kInput:
            {
                const auto* m = P::As<P::InputMsg>(d, n);
                if (!m || !known) break;
                Peer& p = g_peers[pi];
                if (p.haveSeq && static_cast<int32_t>(m->seq - p.inputSeq) <= 0) break;
                p.inputSeq = m->seq;
                p.haveSeq = true;
                p.lastInputAt = now;
                p.rested = false;
                XINPUT_GAMEPAD pad{};
                pad.wButtons = m->buttons;
                pad.bLeftTrigger = m->lt; pad.bRightTrigger = m->rt;
                pad.sThumbLX = m->lx; pad.sThumbLY = m->ly; pad.sThumbRX = m->rx; pad.sThumbRY = m->ry;
                VPadSetRemote(p.slot, &pad);
                break;
            }
            case P::kNack:
            {
                if (!known) break;
                uint32_t frame = 0;
                std::vector<uint16_t> idx;
                std::vector<std::vector<uint8_t>> again;
                if (P::ReadNack(d, static_cast<size_t>(n), frame, idx) && g_history.Get(frame, idx, again))
                    for (const auto& p : again) Send(from, p.data(), p.size());
                break;
            }
            case P::kKeyRequest:
                if (known && now - g_lastKeyReq > 100) { g_lastKeyReq = now; OnlineVideo::RequestKeyframe(); }
                break;
            case P::kPing:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                P::PingMsg r{};
                r.sentMs = now; r.echoMs = m->sentMs; r.rttMs = g_peers[pi].rtt;
                SendMsg(from, r, P::kPong, g_session);
                break;
            }
            case P::kPong:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                const uint32_t rtt = now - m->echoMs;
                Peer& p = g_peers[pi];
                if (rtt < 10000) p.rtt = p.rtt ? (p.rtt * 3 + rtt) / 4 : rtt;
                break;
            }
            case P::kStats:
            {
                const auto* m = P::As<P::StatsMsg>(d, n);
                if (!m || !known) break;
                Peer& p = g_peers[pi];
                p.prevStats = p.haveStats ? p.stats : *m;
                p.stats = *m;
                p.haveStats = true;
                // this friend's share of the stream follows what arrives: lower on loss, back up when calm
                const uint32_t got = m->packets - p.prevStats.packets, asked = m->resendAsked - p.prevStats.resendAsked;
                const uint32_t keys = m->keyAsks - p.prevStats.keyAsks;
                const double loss = got ? static_cast<double>(asked) / got : 0.0;
                if (p.bitrate <= 0) p.bitrate = o.bitrate;
                if (loss > 0.03 || keys > 1) { p.bitrate = std::max(o.minBitrate, p.bitrate * 4 / 5); p.calm = 0; }
                else if (loss < 0.005 && ++p.calm >= 5 && p.bitrate < o.bitrate) { p.bitrate = std::min(o.bitrate, p.bitrate * 11 / 10 + 100); p.calm = 0; }
                ApplyBitrate();
                if (now - p.lastStatsLog > 10000)
                {
                    p.lastStatsLog = now;
                    Logger::WriteFormat(Logger::Level::Info,
                        "Online: %s: ping %u ms, picture %u ms after it was drawn here, %u/%u packets resent/rebuilt of %u, keyframes asked %u, frames shown %u lost %u, decode %.1f ms, sound buffer %u ms; sending %.0f kbps (target %d); %s",
                        p.name.c_str(), p.rtt, m->latencyMs, m->resendAsked, m->recovered, m->packets, m->keyAsks, m->framesShown, m->framesLost,
                        m->decodeUs100 / 10.0, m->audioMs, g_kbpsOut, g_bitrateNow, OnlineVideo::HostStatus().c_str());
                }
                break;
            }
            case P::kBye:
                if (known)
                {
                    const auto* m = P::As<P::ByeMsg>(d, n);
                    DropPeer(pi, "left" + (m ? std::string(" (") + P::ReadName(m->reason, sizeof(m->reason)) + ")" : std::string()));
                    bool any = false;
                    for (const Peer& p : g_peers) any = any || p.on;
                    stopStream = !any;
                }
                break;
            default:
                break;
            }
        }
        if (stopStream) StopStream();
        if (startStream) StartStream(o);
    }

    void HostTick(uint32_t now)
    {
        bool stopStream = false;
        static uint32_t lastPing = 0, lastBw = 0;
        std::lock_guard<std::mutex> lock(g_mutex);
        bool any = false;
        for (int i = 0; i < kMaxFriends; ++i)
        {
            Peer& p = g_peers[i];
            if (!p.on) continue;
            if (now - p.heardMs > 6000) { DropPeer(i, "lost the connection"); stopStream = true; continue; }
            any = true;
            // nothing from the friend's controller for a moment (the connection hiccups): let go of everything
            if (now - p.lastInputAt > 150 && !p.rested)
            {
                p.rested = true;
                XINPUT_GAMEPAD rest{};
                VPadSetRemote(p.slot, &rest);
            }
            if (now - lastPing >= 500)
            {
                P::PingMsg m{};
                m.sentMs = now; m.rttMs = p.rtt;
                SendMsg(p.addr, m, P::kPing, g_session);
            }
        }
        if (now - lastPing >= 500) lastPing = now;
        if (now - lastBw >= 1000)
        {
            const double secs = (now - lastBw) / 1000.0;
            lastBw = now;
            g_kbpsOut = g_bytesOut.exchange(0) * 8.0 / 1000.0 / std::max(0.001, secs);
        }
        if (stopStream && !any)
        {
            g_mutex.unlock();
            StopStream();
            g_mutex.lock();
        }
    }

    // ---------------- friend ----------------
    void ConnectTo(const sockaddr_in& at, uint32_t token);   // g_mutex held

    void JoinHandle(const P::Header* h, const uint8_t* d, int n, const sockaddr_in& from, uint32_t now)
    {
        bool startView = false, stopAll = false;
        int bufferMs = 30;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            bufferMs = g_opt.audioMs;
            const bool fromHost = (g_stage == Stage::Connecting || g_stage == Stage::Watching) && SameAddr(from, g_host.addr);
            const bool known = fromHost && g_host.on && h->session == g_session;
            if (known) g_host.heardMs = now;
            switch (h->type)
            {
            case P::kOffer:
            {
                const auto* m = P::As<P::OfferMsg>(d, n);
                if (!m) break;
                sockaddr_in at = from;
                at.sin_port = htons(m->port);
                // joining with a code, and the same game answers on this network: use the near address
                if (g_stage == Stage::Connecting && !g_host.on && m->token == g_joinToken && !SameAddr(at, g_host.addr))
                {
                    Logger::WriteFormat(Logger::Level::Info, "Online: the host is on this network (%s): joining there", AddrText(at).c_str());
                    g_host.addr = at;
                    g_helloAt = 0;
                }
                bool found = false;
                for (auto& g : g_lan)
                    if (SameAddr(g.addr, at)) { g.name = P::ReadName(m->name, sizeof(m->name)); g.token = m->token; g.full = m->busy != 0; g.seenMs = now; found = true; }
                if (!found && g_lan.size() < 8)
                {
                    LanGame g;
                    g.addr = at; g.name = P::ReadName(m->name, sizeof(m->name)); g.token = m->token; g.full = m->busy != 0; g.seenMs = now;
                    g_lan.push_back(g);
                }
                break;
            }
            case P::kWelcome:
            {
                const auto* m = P::As<P::WelcomeMsg>(d, n);
                if (!m || !fromHost || g_stage != Stage::Connecting) break;
                g_session = h->session;
                g_host.on = true;
                g_host.name = P::ReadName(m->name, sizeof(m->name));
                if (g_host.name.empty()) g_host.name = "the host";
                g_host.heardMs = now;
                g_stage = Stage::Watching;
                g_rx.Reset();
                g_haveOffset = false;
                g_bestRtt = UINT32_MAX;
                g_error.clear();
                g_prevButtons = 0xFFFF;
                startView = true;
                Message("Connected to " + g_host.name + "'s game");
                break;
            }
            case P::kRefuse:
            {
                const auto* m = P::As<P::RefuseMsg>(d, n);
                if (!m || !fromHost) break;
                const std::string why = P::ReadName(m->reason, sizeof(m->reason));
                if (g_stage == Stage::Connecting) { g_error = why; g_stage = Stage::Window; g_host = Peer{}; }
                Logger::WriteFormat(Logger::Level::Warning, "Online: the host said no: %s", why.c_str());
                break;
            }
            case P::kVideo:
                if (known)
                {
                    g_rx.Add(d, static_cast<size_t>(n), now);
                    P::VideoFrame f;
                    while (g_rx.Next(f)) OnlineVideo::SubmitFrame(std::move(f));
                }
                break;
            case P::kAudio:
                if (known)
                {
                    uint32_t seq = 0;
                    std::vector<int16_t> pcm;
                    if (P::ReadAudioPacket(d, static_cast<size_t>(n), seq, pcm)) OnlineAudio::Push(seq, pcm.data(), static_cast<int>(pcm.size() / 2));
                }
                break;
            case P::kPing:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                P::PingMsg r{};
                r.sentMs = now; r.echoMs = m->sentMs; r.rttMs = g_host.rtt;
                SendMsg(from, r, P::kPong, g_session);
                break;
            }
            case P::kPong:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                const uint32_t rtt = now - m->echoMs;
                if (rtt >= 10000) break;
                g_host.rtt = g_host.rtt ? (g_host.rtt * 3 + rtt) / 4 : rtt;
                if (!g_haveOffset || rtt <= g_bestRtt + 2 || now - g_offsetAt > 20000)
                {
                    const int32_t offset = static_cast<int32_t>(m->sentMs - (m->echoMs + rtt / 2));
                    g_clockOffset = g_haveOffset && now - g_offsetAt < 20000 ? (g_clockOffset * 3 + offset) / 4 : offset;
                    g_bestRtt = std::min(g_bestRtt, rtt);
                    g_offsetAt = now;
                    g_haveOffset = true;
                }
                break;
            }
            case P::kBye:
                if (known)
                {
                    const auto* m = P::As<P::ByeMsg>(d, n);
                    g_error = g_host.name + " closed the game" + (m ? " (" + P::ReadName(m->reason, sizeof(m->reason)) + ")" : std::string());
                    stopAll = true;
                }
                break;
            default:
                break;
            }
        }
        if (startView)
        {
            OnlineVideo::StartViewer();
            OnlineAudio::StartPlayback(bufferMs);
            XInputRouteBlank(true);
        }
        if (stopAll)
        {
            OnlineVideo::StopViewer();
            OnlineAudio::StopPlayback();
            XInputRouteBlank(false);
            std::lock_guard<std::mutex> lock(g_mutex);
            g_stage = Stage::Window;
            Message(g_error);
            g_host = Peer{};
        }
    }

    void SendInput(const XINPUT_GAMEPAD& pad)
    {
        P::InputMsg m{};
        m.seq = ++g_inputSeq;
        m.buttons = pad.wButtons;
        m.lt = pad.bLeftTrigger; m.rt = pad.bRightTrigger;
        m.lx = pad.sThumbLX; m.ly = pad.sThumbLY; m.rx = pad.sThumbRX; m.ry = pad.sThumbRY;
        SendMsg(g_host.addr, m, P::kInput, g_session);
    }

    void LeaveHost(const char* why)   // g_mutex NOT held
    {
        OnlineVideo::StopViewer();
        OnlineAudio::StopPlayback();
        XInputRouteBlank(false);
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_host.on) SendBye(g_host.addr, g_session, why);
        g_host = Peer{};
        g_stage = Stage::Window;
        g_lastClip.clear();   // the same code may be used again
        Message("You left the game.");
    }

    void JoinTick(uint32_t now)
    {
        static uint32_t lastPing = 0, lastStats = 0, lastInput = 0;
        bool lost = false, leave = false;
        std::vector<std::pair<uint32_t, std::vector<uint16_t>>> nacks;
        bool wantKey = false;
        std::string clip;
        bool checkClip = false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            checkClip = g_stage == Stage::Window && now - g_clipAt >= 500;
            if (checkClip) g_clipAt = now;
        }
        if (checkClip) clip = ClipboardText();   // (outside the lock: the clipboard can be slow)
        std::lock_guard<std::mutex> lock(g_mutex);
        // the join window: a code on the clipboard connects by itself; a game on this network: X
        if (g_stage == Stage::Window)
        {
            if (checkClip && !clip.empty() && clip.size() < 64 && clip != g_lastClip)
            {
                uint32_t ip = 0, token = 0;
                uint16_t port = 0;
                if (P::ParseJoinCode(clip, ip, port, token))
                {
                    g_lastClip = clip;
                    sockaddr_in at{};
                    at.sin_family = AF_INET;
                    at.sin_addr.s_addr = htonl(ip);
                    at.sin_port = htons(port);
                    ConnectTo(at, token);
                }
            }
            XINPUT_GAMEPAD pad{};
            ReadOwnPad(pad);
            const WORD pressed = static_cast<WORD>(pad.wButtons & ~g_prevButtons);
            g_prevButtons = pad.wButtons;
            if ((pressed & XINPUT_GAMEPAD_X) && OurWindowInFront())
                for (const LanGame& g : g_lan)
                    if (!g.full) { ConnectTo(g.addr, g.token); break; }
        }
        if ((g_stage == Stage::Window || g_stage == Stage::Connecting) && now - g_discoverAt >= 1000)
        {
            g_discoverAt = now;
            sockaddr_in bc{};
            bc.sin_family = AF_INET;
            bc.sin_port = htons(static_cast<u_short>(g_opt.port));
            bc.sin_addr.s_addr = htonl(INADDR_BROADCAST);
            P::DiscoverMsg m{};
            m.nonce = Random32();
            SendMsg(bc, m, P::kDiscover, 0);
            g_lan.erase(std::remove_if(g_lan.begin(), g_lan.end(), [&](const LanGame& g) { return now - g.seenMs > 3500; }), g_lan.end());
        }
        if (g_stage == Stage::Connecting)
        {
            if (now - g_helloAt >= 300 || !g_helloAt)
            {
                g_helloAt = now;
                P::HelloMsg m{};
                m.token = g_joinToken;
                m.clientId = g_clientId;
                P::CopyName(m.name, sizeof(m.name), g_opt.name.empty() ? "Your friend" : g_opt.name);
                SendMsg(g_host.addr, m, P::kHello, 0);
            }
            if (now - g_connectStart > 12000)
            {
                g_error = "No answer from " + AddrText(g_host.addr) + ". Check the code. The host's router must let the game in "
                    "(UPnP on, or UDP port " + std::to_string(ntohs(g_host.addr.sin_port)) + " forwarded to the host's PC), and Windows Firewall must allow the game there.";
                Logger::WriteFormat(Logger::Level::Warning, "Online: %s", g_error.c_str());
                g_stage = Stage::Window;
                g_host = Peer{};
            }
        }
        if (g_stage == Stage::Watching)
        {
            if (now - g_host.heardMs > 6000) { g_error = "Lost the connection to " + g_host.name + "."; lost = true; }
            if (now - lastPing >= 500)
            {
                lastPing = now;
                P::PingMsg p{};
                p.sentMs = now; p.rttMs = g_host.rtt;
                SendMsg(g_host.addr, p, P::kPing, g_session);
            }
            g_rx.Poll(now, g_host.rtt ? g_host.rtt : 50, nacks, wantKey);
            for (const auto& nk : nacks)
                for (size_t from = 0; from == 0 || from < nk.second.size(); from += P::kNackMax)
                {
                    const auto pkt = P::BuildNack(g_session, nk.first, nk.second, from);
                    Send(g_host.addr, pkt.data(), pkt.size());
                }
            static uint32_t lastDecoderAsk = 0;
            if (OnlineVideo::TakeKeyframeRequest() && now - lastDecoderAsk >= std::max<uint32_t>(100, g_host.rtt + 20))
            {
                lastDecoderAsk = now;
                wantKey = true;
            }
            if (wantKey)
            {
                P::KeyRequestMsg k{};
                SendMsg(g_host.addr, k, P::kKeyRequest, g_session);
            }
            if (now - lastStats >= 1000)
            {
                lastStats = now;
                const auto vs = OnlineVideo::GetViewerStats();
                if (g_haveOffset && vs.captureMs && vs.shownAtMs)
                {
                    const int32_t lat = static_cast<int32_t>(vs.shownAtMs - (vs.captureMs - static_cast<uint32_t>(g_clockOffset)));
                    g_latencyMs = static_cast<uint32_t>(std::clamp(lat, 0, 9999));
                }
                P::StatsMsg s{};
                s.packets = g_rx.stats.packets; s.recovered = g_rx.stats.recovered; s.resendAsked = g_rx.stats.resendAsked;
                s.duplicates = g_rx.stats.duplicates; s.framesShown = vs.shown; s.framesLost = g_rx.stats.framesLost; s.keyAsks = g_rx.stats.keyAsks;
                s.decodeUs100 = static_cast<uint16_t>(std::clamp(vs.decodeMs * 10.0, 0.0, 65535.0));
                s.latencyMs = static_cast<uint16_t>(g_latencyMs);
                s.audioMs = static_cast<uint16_t>(std::clamp(OnlineAudio::BufferedMs(), 0, 65535));
                SendMsg(g_host.addr, s, P::kStats, g_session);
            }
            // the controller goes to the host (changes at once, the same state again every 50 ms);
            // leave: Back + Start held 2 s, or Esc held 1.5 s
            if (now - lastInput >= 4)
            {
                lastInput = now;
                XINPUT_GAMEPAD pad{};
                ReadOwnPad(pad);
                if (g_prevButtons == 0xFFFF) g_prevButtons = pad.wButtons;   // what is held when the picture comes is not a press
                constexpr WORD kLeave = XINPUT_GAMEPAD_BACK | XINPUT_GAMEPAD_START;
                if ((pad.wButtons & kLeave) == kLeave)
                {
                    if (!g_leaveHold) g_leaveHold = now;
                    else if (now - g_leaveHold > 2000) leave = true;
                    pad.wButtons = static_cast<WORD>(pad.wButtons & ~kLeave);
                }
                else g_leaveHold = 0;
                const bool esc = OurWindowInFront() && (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0;
                if (esc) { if (!g_escHold) g_escHold = now; else if (now - g_escHold > 1500) leave = true; }
                else g_escHold = 0;
                // buttons held since the picture came reach the host only once let go
                g_prevButtons = static_cast<WORD>(g_prevButtons & pad.wButtons);
                pad.wButtons = static_cast<WORD>(pad.wButtons & ~g_prevButtons);
                if (std::memcmp(&pad, &g_lastSent, sizeof(pad)) != 0 || now - g_lastInputSent >= 50)
                {
                    g_lastSent = pad;
                    g_lastInputSent = now;
                    SendInput(pad);
                }
            }
        }
        if (lost)
        {
            g_stage = Stage::Window;
            Message(g_error);
            g_host = Peer{};
            g_mutex.unlock();
            OnlineVideo::StopViewer();
            OnlineAudio::StopPlayback();
            XInputRouteBlank(false);
            g_mutex.lock();
        }
        if (leave)
        {
            g_mutex.unlock();
            LeaveHost("left");
            g_mutex.lock();
        }
    }

    // g_mutex held.
    void ConnectTo(const sockaddr_in& at, uint32_t token)
    {
        g_host = Peer{};
        g_host.addr = at;
        g_joinToken = token;
        g_clientId = g_clientId ? g_clientId : Random32();
        g_stage = Stage::Connecting;
        g_connectStart = Now();
        g_helloAt = 0;
        g_error.clear();
        Logger::WriteFormat(Logger::Level::Info, "Online: joining %s", AddrText(at).c_str());
    }

    // ---------------- network thread ----------------
    void NetMain()
    {
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
        std::vector<uint8_t> buf(65536);
        while (g_netRun.load())
        {
            fd_set rs;
            FD_ZERO(&rs);
            FD_SET(g_sock, &rs);
            timeval tv{ 0, 1000 };
            select(0, &rs, nullptr, nullptr, &tv);
            for (int i = 0; i < 4096; ++i)
            {
                sockaddr_in from{};
                int fl = sizeof(from);
                const int n = recvfrom(g_sock, reinterpret_cast<char*>(buf.data()), static_cast<int>(buf.size()), 0, reinterpret_cast<sockaddr*>(&from), &fl);
                if (n <= 0) break;
                if (IsStun(buf.data(), n)) { HandleStun(buf.data(), n); continue; }
                const P::Header* h = P::Check(buf.data(), static_cast<size_t>(n));
                if (!h) continue;
                const uint32_t now = Now();
                if (RoleNow() == Role::Host) HostHandle(h, buf.data(), n, from, now);
                else if (RoleNow() == Role::Join) JoinHandle(h, buf.data(), n, from, now);
            }
            const uint32_t now = Now();
            if (RoleNow() == Role::Host) HostTick(now);
            else if (RoleNow() == Role::Join) JoinTick(now);
        }
    }

    bool OpenSocket(uint16_t port, bool host, std::string& why)
    {
        WSADATA wsa{};
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { why = "network start failed"; return false; }
        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (s == INVALID_SOCKET) { why = "no network socket"; WSACleanup(); return false; }
        BOOL no = FALSE;
        DWORD ret = 0;
        WSAIoctl(s, SIO_UDP_CONNRESET, &no, sizeof(no), nullptr, 0, &ret, nullptr, nullptr);
        int big = 4 * 1024 * 1024;
        setsockopt(s, SOL_SOCKET, SO_RCVBUF, reinterpret_cast<const char*>(&big), sizeof(big));
        setsockopt(s, SOL_SOCKET, SO_SNDBUF, reinterpret_cast<const char*>(&big), sizeof(big));
        BOOL yes = TRUE;
        setsockopt(s, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<const char*>(&yes), sizeof(yes));
        u_long nb = 1;
        ioctlsocket(s, FIONBIO, &nb);
        bool bound = false;
        for (int i = 0; i < (host ? 10 : 1) && !bound; ++i)
        {
            sockaddr_in me{};
            me.sin_family = AF_INET;
            me.sin_addr.s_addr = htonl(INADDR_ANY);
            me.sin_port = htons(host ? static_cast<u_short>(port + i) : 0);
            if (bind(s, reinterpret_cast<sockaddr*>(&me), sizeof(me)) == 0)
            {
                sockaddr_in got{};
                int len = sizeof(got);
                getsockname(s, reinterpret_cast<sockaddr*>(&got), &len);
                g_boundPort = ntohs(got.sin_port);
                bound = true;
            }
        }
        if (!bound) { why = "port " + std::to_string(port) + " is in use"; closesocket(s); WSACleanup(); return false; }
        g_sock = s;
        return true;
    }

    void StopAll()
    {
        std::lock_guard<std::mutex> life(g_lifeMutex);
        const Role role = RoleNow();
        if (role == Role::Off) return;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (role == Role::Host)
                for (int i = 0; i < kMaxFriends; ++i)
                    if (g_peers[i].on) { SendBye(g_peers[i].addr, g_session, "the host stopped"); VPadSetRemote(g_peers[i].slot, nullptr); }
            if (role == Role::Join && g_host.on) SendBye(g_host.addr, g_session, "left");
        }
        g_netRun.store(false);
        const uint32_t stoppedGen = g_hostGen.fetch_add(1);
        if (g_net.joinable()) g_net.join();
        if (g_setup.joinable()) g_setup.detach();
        if (role == Role::Host) StopStream();
        OnlineVideo::StopViewer();
        OnlineAudio::StopPlayback();
        XInputRouteBlank(false);
        bool unmap = false;
        uint16_t port = 0;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (g_sock != INVALID_SOCKET) { closesocket(g_sock); g_sock = INVALID_SOCKET; WSACleanup(); }
            unmap = g_upnpMapped;
            port = g_upnpPort;
            g_upnpMapped = false;
            for (Peer& p : g_peers) p = Peer{};
            SyncStreamTargets();
            g_host = Peer{};
            g_stage = Stage::None;
            g_code.clear();
            g_setupDone = false;
            g_lan.clear();
            g_role.store(static_cast<int>(Role::Off));
            if (g_timerRes) { timeEndPeriod(1); g_timerRes = false; }
        }
        if (unmap) UpnpUnmap(port, stoppedGen);
        Logger::Write(Logger::Level::Info, "Online: stopped");
    }
}

namespace OnlinePlay
{
    void Init(const wchar_t* iniPath)
    {
        char a[MAX_PATH * 2]{};
        WideCharToMultiByte(CP_ACP, 0, iniPath, -1, a, sizeof(a) - 1, nullptr, nullptr);
        g_iniA = a;
    }

    void AfterStartup() { OnlineAudio::RepairMuteOnce(); }   // not in DllMain (COM / audio)

    void OnPresent(IDirect3DDevice9* dev)
    {
        const Role r = RoleNow();
        if (r == Role::Host && g_streaming.load(std::memory_order_relaxed)) OnlineVideo::CaptureD3D9(dev);
        else if (r == Role::Join && OnlineVideo::ViewerRunning()) OnlineVideo::DrawViewerD3D9(dev);
    }

    void OnReset(IDirect3DDevice9*) { OnlineVideo::DeviceLost(); }

    std::string StartHosting()
    {
        if (RoleNow() == Role::Join) StopAll();
        std::lock_guard<std::mutex> life(g_lifeMutex);
        if (RoleNow() == Role::Host)
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            return g_code.empty() ? "Hosting: getting your invite code" : "Hosting - invite code " + g_code;
        }
        const Options o = LoadOptions();
        std::string why;
        if (!OpenSocket(static_cast<uint16_t>(o.port), true, why)) return "Cannot host: " + why;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_opt = o;
            g_fec.store(o.fec);
            g_token = Random32() & 0xFFFFFF;
            if (!g_token) g_token = 0x5A17;
            g_session = Random32();
            g_code.clear();
            g_codeNote = "Finding your internet address and opening the router...";
            g_codeWarn.clear();
            g_setupDone = false;
            for (Peer& p : g_peers) p = Peer{};
            SyncStreamTargets();
            g_stunIp.store(0);
            g_stunPort.store(0);
            g_role.store(static_cast<int>(Role::Host));
            if (!g_timerRes) g_timerRes = timeBeginPeriod(1) == TIMERR_NOERROR;
        }
        g_netRun.store(true);
        g_net = std::thread(NetMain);
        const uint16_t port = g_boundPort;
        const uint32_t gen = g_hostGen.fetch_add(1) + 1;
        if (g_setup.joinable()) g_setup.detach();
        g_setup = std::thread([port, gen] { HostSetup(port, gen); });
        Logger::WriteFormat(Logger::Level::Info, "Online: hosting started on UDP port %u (stream %dp %d fps %d kbps, parity every %d packets)",
            port, o.height, o.fps, o.bitrate, o.fec);
        return "Hosting";
    }

    std::string OpenJoin()
    {
        if (RoleNow() == Role::Host) StopAll();
        std::lock_guard<std::mutex> life(g_lifeMutex);
        if (RoleNow() == Role::Join)
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (g_stage == Stage::None) g_stage = Stage::Window;
            return "Join";
        }
        const Options o = LoadOptions();
        std::string why;
        if (!OpenSocket(0, false, why)) return "Cannot join: " + why;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_opt = o;
            g_stage = Stage::Window;
            g_host = Peer{};
            g_lan.clear();
            g_error.clear();
            g_lastClip = ClipboardText();   // a code already on the clipboard counts: it may be a fresh one
            if (g_lastClip.size() > 64) g_lastClip.clear();
            {
                uint32_t ip = 0, token = 0; uint16_t port = 0;
                if (P::ParseJoinCode(g_lastClip, ip, port, token)) g_lastClip.clear();
            }
            g_discoverAt = 0;
            g_prevButtons = 0xFFFF;
            g_role.store(static_cast<int>(Role::Join));
            if (!g_timerRes) g_timerRes = timeBeginPeriod(1) == TIMERR_NOERROR;
        }
        g_netRun.store(true);
        g_net = std::thread(NetMain);
        Logger::Write(Logger::Level::Info, "Online: join window open (watching the clipboard for an invite code)");
        return "Join";
    }

    void Stop() { StopAll(); }
    bool Hosting() { return RoleNow() == Role::Host; }
    bool Joining() { return RoleNow() == Role::Join; }
    bool Watching()
    {
        if (RoleNow() != Role::Join) return false;
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_stage == Stage::Watching;
    }

    void LobbyLines(std::vector<std::pair<wchar_t, std::wstring>>& out)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        const Role r = RoleNow();
        if (r == Role::Host)
        {
            if (g_code.empty()) out.push_back({ L'W', L"Getting your invite code..." });
            else out.push_back({ L'W', L"Invite code: " + Wide(g_code) + L"  (copied - send it to your friends)" });
            if (!g_codeWarn.empty()) out.push_back({ L'X', Wide(g_codeWarn) });
            else if (!g_codeNote.empty()) out.push_back({ L'X', Wide(g_codeNote) });
            return;
        }
        if (r != Role::Join) return;
        switch (g_stage)
        {
        case Stage::Window:
            out.push_back({ L'H', L"Join a friend's game" });
            out.push_back({ L'W', L"Copy your friend's invite code (select it, Ctrl+C) - this connects by itself" });
            for (const LanGame& g : g_lan)
            {
                out.push_back({ g.full ? L'X' : L'W', (g.full ? L"On this network: " + Wide(g.name) + L"'s game (full)"
                                                              : L"On this network: " + Wide(g.name) + L"'s game - press X on your controller to join") });
                break;
            }
            if (!g_error.empty()) out.push_back({ L'X', Wide(g_error) });
            out.push_back({ L'X', L"In the game: your controller plays; hold Back + Start (or Esc) to leave" });
            break;
        case Stage::Connecting:
            out.push_back({ L'H', L"Join a friend's game" });
            out.push_back({ L'W', L"Connecting to " + Wide(AddrText(g_host.addr)) + L"..." });
            break;
        case Stage::Watching:
            out.push_back({ L'H', L"Connected to " + Wide(g_host.name) });
            out.push_back({ L'R', L"Waiting for the picture..." });
            break;
        default:
            break;
        }
    }

    std::wstring FriendName(int slot)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        for (const Peer& p : g_peers) if (p.on && p.slot == slot) return Wide(p.name);
        return L"";
    }

    bool TakeMessage(std::wstring& out)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_messages.empty()) return false;
        out = g_messages.front();
        g_messages.pop_front();
        return true;
    }

    void Shutdown() { StopAll(); }
}
