#pragma once
// Online play (Players 2 and 3 over the internet; from the Amalur co-op mod): the wire format, and the parts of the stream that need no
// Windows API (so they are tested on their own, see DevNotes tests/online_protocol_test.cpp):
//   - UDP packets (little-endian, packed, one header for all);
//   - join codes (the host's address, port and a secret, as 15 letters/digits);
//   - video: an encoded frame -> numbered packets plus XOR parity packets (one lost packet in a group
//     is rebuilt with no wait), back into whole frames in order, with resend requests for what is
//     still missing and "wait for a keyframe" once a frame is lost for good;
//   - audio: IMA ADPCM (4 bits a sample) in 10 ms packets, and a small jitter buffer.
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

namespace OnlineProtocol
{
    constexpr uint32_t kMagic = 0x31434144u;   // "DAC1" (DAOCoop; Amalur used "AMC1")
    constexpr uint8_t kVersion = 1;
    constexpr uint16_t kDefaultPort = 27615;
    constexpr size_t kMaxDatagram = 1200;      // under the usual internet MTU, VPN overhead included

    enum Type : uint8_t
    {
        kHello = 1,     // friend -> host: join (with the code's secret)
        kWelcome,       // host -> friend: accepted (stream size, whether the Player 2 slot is free)
        kRefuse,        // host -> friend: not accepted (reason)
        kClaim,         // friend -> host: take the Player 2 slot
        kClaimed,       // host -> friend: the slot is yours
        kPing,          // either way, twice a second
        kPong,
        kInput,         // friend -> host: the friend's controller, as controller 2
        kVideo,         // host -> friend
        kNack,          // friend -> host: resend these packets of a frame
        kKeyRequest,    // friend -> host: send a keyframe (a frame was lost)
        kAudio,         // host -> friend
        kBye,           // either way: leaving
        kDiscover,      // friend -> LAN broadcast: any games here?
        kOffer,         // host -> friend: this game (LAN)
        kStats,         // friend -> host: how the stream arrives (once a second)
        kRelease        // friend -> host: give the Player 2 slot back (still watching)
    };

#pragma pack(push, 1)
    struct Header { uint32_t magic; uint8_t type; uint8_t version; uint16_t size; uint32_t session; };
    struct HelloMsg { Header h; uint32_t token; uint32_t clientId; char name[32]; };   // clientId: the same friend from a new address
    struct WelcomeMsg { Header h; uint16_t width, height; uint8_t fps; uint8_t slotTaken; char name[32]; uint32_t hostMs; };
    struct RefuseMsg { Header h; char reason[96]; };
    struct EmptyMsg { Header h; };
    struct PingMsg { Header h; uint32_t sentMs; uint32_t echoMs; uint32_t rttMs; };
    struct InputMsg { Header h; uint32_t seq; uint16_t buttons; uint8_t lt, rt; int16_t lx, ly, rx, ry; };
    struct VideoHeader
    {
        Header h;
        uint32_t frame;        // counts up by one per frame
        uint32_t frameSize;    // encoded bytes of the whole frame
        uint32_t captureMs;    // host clock, when the picture was taken
        uint16_t index;        // data packet 0..count-1, or kParity | group number
        uint16_t count;        // data packets in the frame
        uint16_t width, height;
        uint8_t flags;         // kVideoKey
        uint8_t group;         // data packets per parity packet (0: none)
    };
    struct NackHeader { Header h; uint32_t frame; uint16_t n; /* uint16_t index[n] */ };
    struct KeyRequestMsg { Header h; uint32_t expected; };
    struct AudioHeader
    {
        Header h;
        uint32_t seq;
        uint16_t frames;       // samples per channel in this packet
        uint8_t channels;      // 2
        uint8_t codec;         // kAudioAdpcm / kAudioPcm16
        int16_t predictor[2];  // ADPCM state at the start of the packet (each packet decodes on its own)
        uint8_t stepIndex[2];
    };
    struct ByeMsg { Header h; char reason[64]; };
    struct DiscoverMsg { Header h; uint32_t nonce; };
    struct OfferMsg { Header h; uint32_t nonce; uint32_t token; uint16_t port; uint8_t slotTaken; uint8_t busy; char name[32]; };
    struct StatsMsg
    {
        Header h;
        uint32_t packets, recovered, resendAsked, duplicates;
        uint32_t framesShown, framesLost, keyAsks;
        uint16_t decodeUs100;  // average decode time, 0.1 ms
        uint16_t latencyMs;    // picture taken on the host -> on the friend's screen (estimate)
        uint16_t audioMs;      // audio buffered on the friend's side
        uint16_t reserved;
    };
#pragma pack(pop)

    constexpr uint16_t kParity = 0x8000;
    constexpr uint8_t kVideoKey = 1;
    constexpr uint8_t kAudioPcm16 = 0, kAudioAdpcm = 1;
    constexpr size_t kVideoPayload = kMaxDatagram - sizeof(VideoHeader);

    template <typename T> inline void Fill(T& msg, uint8_t type, uint32_t session, size_t size = sizeof(T))
    {
        msg.h.magic = kMagic;
        msg.h.type = type;
        msg.h.version = kVersion;
        msg.h.size = static_cast<uint16_t>(size);
        msg.h.session = session;
    }
    inline void FillHeader(Header& h, uint8_t type, uint32_t session, size_t size)
    {
        h.magic = kMagic; h.type = type; h.version = kVersion; h.size = static_cast<uint16_t>(size); h.session = session;
    }
    // The header of a datagram, or nullptr when it is not ours (wrong magic / version / length).
    inline const Header* Check(const void* data, size_t n)
    {
        if (n < sizeof(Header) || n > 65535) return nullptr;
        const Header* h = static_cast<const Header*>(data);
        if (h->magic != kMagic || h->version != kVersion || h->size != n) return nullptr;
        return h;
    }
    // Packets of a fixed layout must be at least that long.
    template <typename T> inline const T* As(const void* data, size_t n)
    {
        return n >= sizeof(T) ? static_cast<const T*>(data) : nullptr;
    }
    inline void CopyName(char* dst, size_t cap, const std::string& s)
    {
        std::memset(dst, 0, cap);
        std::memcpy(dst, s.data(), std::min(cap - 1, s.size()));
    }
    inline std::string ReadName(const char* src, size_t cap)
    {
        size_t n = 0;
        while (n < cap && src[n]) ++n;
        std::string s(src, n);
        for (char& c : s) if (static_cast<unsigned char>(c) < 32) c = ' ';
        return s;
    }

    // ---- Join code: IPv4 + port + 24-bit secret (9 bytes) and a 3-bit check, as 15 base-32 digits ----
    // "0123456789ABCDEFGHJKMNPQRSTVWXYZ" (no I, L, O, U: typed I/L read as 1, O as 0), shown as XXXXX-XXXXX-XXXXX.
    inline unsigned JoinCodeCheck(const uint8_t* b)
    {
        uint32_t h = 2166136261u;   // FNV-1a: a typed digit changed is caught 7 times in 8
        for (int i = 0; i < 9; ++i) { h ^= b[i]; h *= 16777619u; }
        return h >> 29;
    }
    inline std::string MakeJoinCode(uint32_t ip, uint16_t port, uint32_t token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        const uint8_t b[9] = { static_cast<uint8_t>(ip >> 24), static_cast<uint8_t>(ip >> 16), static_cast<uint8_t>(ip >> 8),
            static_cast<uint8_t>(ip), static_cast<uint8_t>(port >> 8), static_cast<uint8_t>(port),
            static_cast<uint8_t>(token >> 16), static_cast<uint8_t>(token >> 8), static_cast<uint8_t>(token) };
        const unsigned check = JoinCodeCheck(b);
        std::string out;
        int bit = -3;   // 75 bits: the 3 check bits, then the 72 data bits
        for (int d = 0; d < 15; ++d)
        {
            unsigned v = 0;
            for (int k = 0; k < 5; ++k, ++bit)
            {
                const unsigned x = bit < 0 ? (check >> (-bit - 1)) & 1u : (b[bit / 8] >> (7 - bit % 8)) & 1u;
                v = (v << 1) | x;
            }
            if (d == 5 || d == 10) out += '-';
            out += kDigits[v];
        }
        return out;
    }
    inline bool ParseJoinCode(const std::string& text, uint32_t& ip, uint16_t& port, uint32_t& token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        unsigned vals[15];
        int n = 0;
        for (char c : text)
        {
            if (c == '-' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '"' || c == '\'') continue;
            if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
            if (c == 'I' || c == 'L') c = '1';
            if (c == 'O') c = '0';
            const char* at = std::strchr(kDigits, c);
            if (!at || !c) return false;
            if (n >= 15) return false;
            vals[n++] = static_cast<unsigned>(at - kDigits);
        }
        if (n != 15) return false;
        uint8_t b[9]{};
        unsigned check = 0;
        int bit = -3;
        for (int d = 0; d < 15; ++d)
            for (int k = 4; k >= 0; --k, ++bit)
            {
                const unsigned x = (vals[d] >> k) & 1u;
                if (bit < 0) check = (check << 1) | x;
                else if (x) b[bit / 8] = static_cast<uint8_t>(b[bit / 8] | (1u << (7 - bit % 8)));
            }
        if (JoinCodeCheck(b) != check) return false;
        ip = (uint32_t(b[0]) << 24) | (uint32_t(b[1]) << 16) | (uint32_t(b[2]) << 8) | b[3];
        port = static_cast<uint16_t>((b[4] << 8) | b[5]);
        token = (uint32_t(b[6]) << 16) | (uint32_t(b[7]) << 8) | b[8];
        return ip != 0 && port != 0;
    }

    // ---- Steam code: the host's Steam account number + the 24-bit secret, 12 base-32 digits ----
    // XXXX-XXXX-XXXX. The friend's game reaches the host through Steam with it (no open port needed).
    constexpr uint64_t kSteamIdIndividual = 0x0110000100000000ull;   // public universe, individual, desktop
    inline unsigned SteamCodeCheck(const uint8_t* b)
    {
        uint32_t h = 2166136261u ^ 0x5Au;
        for (int i = 0; i < 7; ++i) { h ^= b[i]; h *= 16777619u; }
        return h >> 29;
    }
    inline std::string MakeSteamCode(uint64_t steamId, uint32_t token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        const uint32_t account = static_cast<uint32_t>(steamId);
        const uint8_t b[7] = { static_cast<uint8_t>(account >> 24), static_cast<uint8_t>(account >> 16), static_cast<uint8_t>(account >> 8),
            static_cast<uint8_t>(account), static_cast<uint8_t>(token >> 16), static_cast<uint8_t>(token >> 8), static_cast<uint8_t>(token) };
        const unsigned check = SteamCodeCheck(b);
        std::string out;
        int bit = -4;   // 60 bits: a zero bit, the 3 check bits, then the 56 data bits
        for (int d = 0; d < 12; ++d)
        {
            unsigned v = 0;
            for (int k = 0; k < 5; ++k, ++bit)
            {
                unsigned x = 0;
                if (bit >= 0) x = (b[bit / 8] >> (7 - bit % 8)) & 1u;
                else if (bit >= -3) x = (check >> (-bit - 1)) & 1u;
                v = (v << 1) | x;
            }
            if (d == 4 || d == 8) out += '-';
            out += kDigits[v];
        }
        return out;
    }
    inline bool ParseSteamCode(const std::string& text, uint64_t& steamId, uint32_t& token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        unsigned vals[12];
        int n = 0;
        for (char c : text)
        {
            if (c == '-' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '"' || c == '\'') continue;
            if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
            if (c == 'I' || c == 'L') c = '1';
            if (c == 'O') c = '0';
            const char* at = std::strchr(kDigits, c);
            if (!at || !c || n >= 12) return false;
            vals[n++] = static_cast<unsigned>(at - kDigits);
        }
        if (n != 12) return false;
        uint8_t b[7]{};
        unsigned check = 0, pad = 0;
        int bit = -4;
        for (int d = 0; d < 12; ++d)
            for (int k = 4; k >= 0; --k, ++bit)
            {
                const unsigned x = (vals[d] >> k) & 1u;
                if (bit < -3) pad |= x;
                else if (bit < 0) check = (check << 1) | x;
                else if (x) b[bit / 8] = static_cast<uint8_t>(b[bit / 8] | (1u << (7 - bit % 8)));
            }
        if (pad || SteamCodeCheck(b) != check) return false;
        const uint32_t account = (uint32_t(b[0]) << 24) | (uint32_t(b[1]) << 16) | (uint32_t(b[2]) << 8) | b[3];
        steamId = kSteamIdIndividual | account;
        token = (uint32_t(b[4]) << 16) | (uint32_t(b[5]) << 8) | b[6];
        return account != 0;
    }

    // ---- Video: frame -> packets ----
    // Packets of one frame: each group's data packets, then that group's parity packet (XOR of the
    // group's payloads, zero-padded), so a group with one packet missing is rebuilt as soon as its
    // parity arrives.
    inline void BuildVideoPackets(uint32_t session, uint32_t frame, const uint8_t* data, size_t size, bool key,
        uint16_t width, uint16_t height, uint32_t captureMs, int group, std::vector<std::vector<uint8_t>>& out)
    {
        out.clear();
        const size_t P = kVideoPayload;
        const size_t count = size == 0 ? 1 : (size + P - 1) / P;
        if (count >= kParity) return;
        if (group < 0) group = 0;
        if (group > 64) group = 64;
        VideoHeader vh{};
        vh.frame = frame;
        vh.frameSize = static_cast<uint32_t>(size);
        vh.captureMs = captureMs;
        vh.count = static_cast<uint16_t>(count);
        vh.width = width;
        vh.height = height;
        vh.flags = key ? kVideoKey : 0;
        vh.group = static_cast<uint8_t>(group);
        std::vector<uint8_t> parity;
        for (size_t i = 0; i < count; ++i)
        {
            const size_t off = i * P, len = std::min(P, size - std::min(size, off));
            std::vector<uint8_t> pkt(sizeof(VideoHeader) + len);
            vh.index = static_cast<uint16_t>(i);
            FillHeader(vh.h, kVideo, session, pkt.size());
            std::memcpy(pkt.data(), &vh, sizeof(vh));
            if (len) std::memcpy(pkt.data() + sizeof(vh), data + off, len);
            out.push_back(std::move(pkt));
            if (group > 0)
            {
                if (i % group == 0) parity.assign(P, 0);
                for (size_t k = 0; k < len; ++k) parity[k] ^= data[off + k];
                const bool lastOfGroup = (i % group == static_cast<size_t>(group - 1)) || i + 1 == count;
                if (lastOfGroup)
                {
                    // a group of one packet gains nothing from parity (the copy is just as lost)
                    const size_t first = (i / group) * group;
                    if (i > first)
                    {
                        std::vector<uint8_t> pp(sizeof(VideoHeader) + P);
                        vh.index = static_cast<uint16_t>(kParity | (i / group));
                        FillHeader(vh.h, kVideo, session, pp.size());
                        std::memcpy(pp.data(), &vh, sizeof(vh));
                        std::memcpy(pp.data() + sizeof(vh), parity.data(), P);
                        out.push_back(std::move(pp));
                    }
                }
            }
        }
    }

    struct VideoFrame
    {
        uint32_t frame = 0, captureMs = 0;
        bool key = false;
        uint16_t width = 0, height = 0;
        std::vector<uint8_t> data;
    };

    // ---- Video: packets -> frames, in order ----
    class VideoReceiver
    {
    public:
        struct Stats { uint32_t packets = 0, recovered = 0, resendAsked = 0, duplicates = 0, framesDone = 0, framesLost = 0, keyAsks = 0; };
        Stats stats;

        void Reset()
        {
            m_slots.clear();
            m_haveExpected = false;
            m_waitKey = true;
            m_keyAsked = false;
            m_haveNewest = false;
        }

        void Add(const uint8_t* p, size_t n, uint32_t nowMs)
        {
            if (n < sizeof(VideoHeader)) return;
            VideoHeader vh;
            std::memcpy(&vh, p, sizeof(vh));
            const uint8_t* payload = p + sizeof(vh);
            const size_t len = n - sizeof(vh);
            const size_t P = kVideoPayload;
            if (vh.count == 0 || vh.count >= kParity || vh.frameSize > size_t(vh.count) * P ||
                (vh.count > 1 && vh.frameSize <= size_t(vh.count - 1) * P)) return;
            if (m_haveExpected && static_cast<int32_t>(vh.frame - m_expected) < 0) return;   // already shown or given up
            if (!m_haveNewest || static_cast<int32_t>(vh.frame - m_newest) > 0) { m_newest = vh.frame; m_haveNewest = true; }
            Slot& s = m_slots[vh.frame];
            if (!s.any)
            {
                s.any = true;
                s.size = vh.frameSize; s.count = vh.count; s.width = vh.width; s.height = vh.height;
                s.flags = vh.flags; s.group = vh.group; s.captureMs = vh.captureMs;
                s.data.assign(s.size, 0);
                s.have.assign(s.count, 0);
                s.firstMs = nowMs;
            }
            else if (s.size != vh.frameSize || s.count != vh.count || s.group != vh.group) return;
            s.lastMs = nowMs;
            ++stats.packets;
            if (vh.index & kParity)
            {
                const uint16_t g = static_cast<uint16_t>(vh.index & ~kParity);
                if (!s.group || size_t(g) * s.group >= s.count || len < P) return;
                if (s.parity.count(g)) { ++stats.duplicates; return; }
                s.parity[g].assign(payload, payload + P);
                if (g == (s.count - 1) / s.group) s.sawEnd = true;
                Recover(s, g);
            }
            else
            {
                const uint16_t i = vh.index;
                if (i >= s.count) return;
                const size_t off = size_t(i) * P, want = std::min(P, s.size - off);
                if (len != want) return;
                if (s.have[i]) { ++stats.duplicates; return; }
                if (want) std::memcpy(s.data.data() + off, payload, want);
                s.have[i] = 1;
                ++s.haveCount;
                if (i + 1u == s.count) s.sawEnd = true;
                if (s.group) Recover(s, static_cast<uint16_t>(i / s.group));
            }
            while (m_slots.size() > 240) m_slots.erase(m_slots.begin());
        }

        // The next frame to decode, in order. After a loss only from a keyframe on.
        bool Next(VideoFrame& out)
        {
            for (;;)
            {
                if (m_waitKey)
                {
                    // the newest complete keyframe (least delay)
                    auto key = m_slots.end();
                    for (auto it = m_slots.begin(); it != m_slots.end(); ++it)
                        if (it->second.Complete() && (it->second.flags & kVideoKey) &&
                            (!m_haveExpected || static_cast<int32_t>(it->first - m_expected) >= 0))
                            if (key == m_slots.end() || static_cast<int32_t>(it->first - key->first) > 0) key = it;
                    if (key == m_slots.end()) return false;
                    DropBefore(key->first);
                    m_expected = key->first;
                    m_haveExpected = true;
                    m_waitKey = false;
                    m_keyAsked = false;
                }
                auto it = m_slots.find(m_expected);
                if (it != m_slots.end() && it->second.Complete())
                {
                    Slot& s = it->second;
                    out.frame = it->first; out.captureMs = s.captureMs; out.key = (s.flags & kVideoKey) != 0;
                    out.width = s.width; out.height = s.height; out.data.swap(s.data);
                    m_slots.erase(it);
                    ++m_expected;
                    ++stats.framesDone;
                    return true;
                }
                // a newer complete keyframe: what is before it is not needed any more
                bool jumped = false;
                for (auto& kv : m_slots)
                    if (static_cast<int32_t>(kv.first - m_expected) > 0 && kv.second.Complete() && (kv.second.flags & kVideoKey))
                    {
                        stats.framesLost += kv.first - m_expected;
                        DropBefore(kv.first);
                        m_expected = kv.first;
                        jumped = true;
                        break;
                    }
                if (!jumped) return false;
            }
        }

        // Resend requests for what is missing, and whether to ask for a keyframe.
        void Poll(uint32_t nowMs, uint32_t rttMs, std::vector<std::pair<uint32_t, std::vector<uint16_t>>>& nacks, bool& wantKey)
        {
            nacks.clear();
            wantKey = false;
            if (rttMs < 1) rttMs = 1;
            if (rttMs > 1000) rttMs = 1000;
            const uint32_t giveUp = std::clamp<uint32_t>(rttMs * 3 + 40, 70, 300);
            if (!m_waitKey && m_haveExpected)
            {
                // the frame we wait for: given up once it (or the next frame, if none of it came) is too old
                uint32_t since = 0;
                bool have = false;
                auto it = m_slots.find(m_expected);
                if (it != m_slots.end()) { since = it->second.firstMs; have = true; }
                else
                    for (auto& kv : m_slots)
                        if (static_cast<int32_t>(kv.first - m_expected) > 0) { since = kv.second.firstMs; have = true; break; }
                if (have && static_cast<uint32_t>(nowMs - since) > giveUp)
                {
                    m_waitKey = true;
                    ++stats.framesLost;
                }
            }
            if (m_waitKey && (!m_keyAsked || static_cast<uint32_t>(nowMs - m_keyAskMs) > std::max<uint32_t>(rttMs * 2 + 20, 120)))
            {
                wantKey = true;
                m_keyAsked = true;
                m_keyAskMs = nowMs;
                ++stats.keyAsks;
            }
            // not one packet of the awaited frame came (and a later one did): ask for all of it
            if (!m_waitKey && m_haveExpected && !m_slots.count(m_expected))
            {
                for (auto& kv : m_slots)
                    if (static_cast<int32_t>(kv.first - m_expected) > 0)
                    {
                        if (m_wholeFrame != m_expected) { m_wholeFrame = m_expected; m_wholeAsks = 0; }
                        const uint32_t wait = m_wholeAsks ? std::max<uint32_t>(rttMs + rttMs / 2 + 5, 20) : 3;
                        if (m_wholeAsks < 3 && static_cast<uint32_t>(nowMs - (m_wholeAsks ? m_wholeAskMs : kv.second.firstMs)) >= wait)
                        {
                            ++m_wholeAsks;
                            m_wholeAskMs = nowMs;
                            nacks.emplace_back(m_expected, std::vector<uint16_t>());   // empty: the whole frame
                        }
                        break;
                    }
            }
            size_t asked = 0;
            for (auto& kv : m_slots)
            {
                Slot& s = kv.second;
                if (s.Complete()) continue;
                if (m_waitKey && !(s.flags & kVideoKey)) continue;   // only the keyframe matters now
                if (!m_waitKey && m_haveExpected && static_cast<int32_t>(kv.first - m_expected) < 0) continue;
                const bool newer = m_haveNewest && static_cast<int32_t>(m_newest - kv.first) > 0;
                const uint32_t quiet = static_cast<uint32_t>(nowMs - s.lastMs);
                // the end of the frame is known (or a later frame started), and nothing came for a moment
                if (!(s.sawEnd || newer || quiet > 6)) continue;
                if (!newer && quiet < 2) continue;
                if (s.nacks >= 4) continue;
                if (s.nacks && static_cast<uint32_t>(nowMs - s.nackMs) < std::max<uint32_t>(rttMs + rttMs / 2 + 5, 20)) continue;
                std::vector<uint16_t> missing;
                for (uint16_t i = 0; i < s.count && missing.size() < 256; ++i)
                {
                    if (s.have[i]) continue;
                    // one missing in a group whose parity has not come yet: the parity may still fix it
                    if (s.group && !s.nacks && !newer && quiet < 12)
                    {
                        const uint16_t g = static_cast<uint16_t>(i / s.group);
                        if (!s.parity.count(g) && Missing(s, g) == 1) continue;
                    }
                    missing.push_back(i);
                }
                if (missing.empty()) continue;
                s.nacks++;
                s.nackMs = nowMs;
                stats.resendAsked += static_cast<uint32_t>(missing.size());
                asked += missing.size();
                nacks.emplace_back(kv.first, std::move(missing));
                if (asked > 512) break;
            }
        }

        bool WaitingForKey() const { return m_waitKey; }

    private:
        struct Slot
        {
            uint32_t size = 0, captureMs = 0;
            uint16_t count = 0, width = 0, height = 0, haveCount = 0;
            uint8_t flags = 0, group = 0;
            std::vector<uint8_t> data, have;
            std::map<uint16_t, std::vector<uint8_t>> parity;
            uint32_t firstMs = 0, lastMs = 0, nackMs = 0;
            int nacks = 0;
            bool any = false, sawEnd = false;
            bool Complete() const { return count && haveCount == count; }
        };

        static int Missing(const Slot& s, uint16_t g)
        {
            const size_t first = size_t(g) * s.group, last = std::min<size_t>(first + s.group, s.count);
            int missing = 0;
            for (size_t i = first; i < last; ++i) if (!s.have[i]) ++missing;
            return missing;
        }

        void Recover(Slot& s, uint16_t g)
        {
            auto pit = s.parity.find(g);
            if (pit == s.parity.end()) return;
            const size_t P = kVideoPayload;
            const size_t first = size_t(g) * s.group, last = std::min<size_t>(first + s.group, s.count);
            size_t lost = SIZE_MAX;
            int missing = 0;
            for (size_t i = first; i < last; ++i)
                if (!s.have[i]) { lost = i; ++missing; }
            if (missing != 1) return;
            std::vector<uint8_t> x = pit->second;
            for (size_t i = first; i < last; ++i)
            {
                if (i == lost) continue;
                const size_t off = i * P, len = std::min(P, s.size - off);
                for (size_t k = 0; k < len; ++k) x[k] ^= s.data[off + k];
            }
            const size_t off = lost * P, len = std::min(P, s.size - off);
            if (len) std::memcpy(s.data.data() + off, x.data(), len);
            s.have[lost] = 1;
            ++s.haveCount;
            ++stats.recovered;
        }

        void DropBefore(uint32_t frame)
        {
            for (auto it = m_slots.begin(); it != m_slots.end();)
                if (static_cast<int32_t>(it->first - frame) < 0) it = m_slots.erase(it);
                else ++it;
        }

        std::map<uint32_t, Slot> m_slots;
        uint32_t m_expected = 0, m_newest = 0, m_keyAskMs = 0, m_wholeFrame = 0, m_wholeAskMs = 0;
        int m_wholeAsks = 0;
        bool m_haveExpected = false, m_waitKey = true, m_keyAsked = false, m_haveNewest = false;
    };

    // A resend request: these data packets of a frame (none listed: the whole frame).
    constexpr size_t kNackMax = (kMaxDatagram - sizeof(NackHeader)) / 2;
    inline std::vector<uint8_t> BuildNack(uint32_t session, uint32_t frame, const std::vector<uint16_t>& index, size_t from = 0)
    {
        const size_t n = std::min(kNackMax, index.size() - std::min(index.size(), from));
        std::vector<uint8_t> pkt(sizeof(NackHeader) + n * 2);
        NackHeader nh{};
        FillHeader(nh.h, kNack, session, pkt.size());
        nh.frame = frame;
        nh.n = static_cast<uint16_t>(n);
        std::memcpy(pkt.data(), &nh, sizeof(nh));
        if (n) std::memcpy(pkt.data() + sizeof(nh), index.data() + from, n * 2);
        return pkt;
    }
    inline bool ReadNack(const uint8_t* p, size_t n, uint32_t& frame, std::vector<uint16_t>& index)
    {
        if (n < sizeof(NackHeader)) return false;
        NackHeader nh;
        std::memcpy(&nh, p, sizeof(nh));
        if (n != sizeof(nh) + size_t(nh.n) * 2) return false;
        frame = nh.frame;
        index.resize(nh.n);
        if (nh.n) std::memcpy(index.data(), p + sizeof(nh), size_t(nh.n) * 2);
        return true;
    }

    // The host keeps the packets of the last frames it sent, for resend requests.
    class VideoHistory
    {
    public:
        explicit VideoHistory(size_t frames = 120) : m_keep(frames) {}
        void Store(uint32_t frame, const std::vector<std::vector<uint8_t>>& packets)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_frames[frame] = packets;
            while (m_frames.size() > m_keep) m_frames.erase(m_frames.begin());
        }
        void Clear() { std::lock_guard<std::mutex> lock(m_mutex); m_frames.clear(); }
        // The data packets asked for (an empty list: all of the frame's packets). False when the frame is gone.
        bool Get(uint32_t frame, const std::vector<uint16_t>& index, std::vector<std::vector<uint8_t>>& out)
        {
            out.clear();
            std::lock_guard<std::mutex> lock(m_mutex);
            auto it = m_frames.find(frame);
            if (it == m_frames.end()) return false;
            const auto& pk = it->second;
            if (index.empty()) { out = pk; return true; }
            for (uint16_t want : index)
                for (const auto& p : pk)
                {
                    if (p.size() < sizeof(VideoHeader)) continue;
                    VideoHeader vh;
                    std::memcpy(&vh, p.data(), sizeof(vh));
                    if (vh.index == want) { out.push_back(p); break; }
                }
            return true;
        }
    private:
        std::mutex m_mutex;
        std::map<uint32_t, std::vector<std::vector<uint8_t>>> m_frames;
        size_t m_keep;
    };

    // ---- Audio: IMA ADPCM, 4 bits a sample ----
    struct AdpcmState { int predictor = 0; int index = 0; };
    inline const int* AdpcmSteps()
    {
        static const int steps[89] = {
            7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
            107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
            876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
            5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623,
            27086, 29794, 32767 };
        return steps;
    }
    inline int AdpcmIndexDelta(int nibble)
    {
        static const int table[16] = { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
        return table[nibble & 15];
    }
    inline int16_t AdpcmDecode(AdpcmState& st, int nibble)
    {
        const int step = AdpcmSteps()[st.index];
        int diff = step >> 3;
        if (nibble & 4) diff += step;
        if (nibble & 2) diff += step >> 1;
        if (nibble & 1) diff += step >> 2;
        st.predictor += (nibble & 8) ? -diff : diff;
        st.predictor = std::clamp(st.predictor, -32768, 32767);
        st.index = std::clamp(st.index + AdpcmIndexDelta(nibble), 0, 88);
        return static_cast<int16_t>(st.predictor);
    }
    inline int AdpcmEncode(AdpcmState& st, int16_t sample)
    {
        const int step = AdpcmSteps()[st.index];
        int diff = sample - st.predictor;
        int nibble = 0;
        if (diff < 0) { nibble = 8; diff = -diff; }
        int s = step;
        if (diff >= s) { nibble |= 4; diff -= s; }
        s >>= 1;
        if (diff >= s) { nibble |= 2; diff -= s; }
        s >>= 1;
        if (diff >= s) nibble |= 1;
        AdpcmDecode(st, nibble);   // keep the encoder's state equal to the decoder's
        return nibble;
    }

    // One audio packet: stereo s16 frames -> ADPCM (one byte per frame: left low nibble, right high nibble).
    inline std::vector<uint8_t> BuildAudioPacket(uint32_t session, uint32_t seq, const int16_t* stereo, int frames, AdpcmState st[2])
    {
        std::vector<uint8_t> pkt(sizeof(AudioHeader) + static_cast<size_t>(frames));
        AudioHeader ah{};
        FillHeader(ah.h, kAudio, session, pkt.size());
        ah.seq = seq;
        ah.frames = static_cast<uint16_t>(frames);
        ah.channels = 2;
        ah.codec = kAudioAdpcm;
        for (int c = 0; c < 2; ++c) { ah.predictor[c] = static_cast<int16_t>(st[c].predictor); ah.stepIndex[c] = static_cast<uint8_t>(st[c].index); }
        std::memcpy(pkt.data(), &ah, sizeof(ah));
        uint8_t* out = pkt.data() + sizeof(ah);
        for (int i = 0; i < frames; ++i)
        {
            const int l = AdpcmEncode(st[0], stereo[i * 2]);
            const int r = AdpcmEncode(st[1], stereo[i * 2 + 1]);
            out[i] = static_cast<uint8_t>(l | (r << 4));
        }
        return pkt;
    }
    inline bool ReadAudioPacket(const uint8_t* p, size_t n, uint32_t& seq, std::vector<int16_t>& stereo)
    {
        if (n < sizeof(AudioHeader)) return false;
        AudioHeader ah;
        std::memcpy(&ah, p, sizeof(ah));
        if (ah.channels != 2 || ah.codec != kAudioAdpcm || n != sizeof(ah) + ah.frames) return false;
        AdpcmState st[2];
        for (int c = 0; c < 2; ++c) { st[c].predictor = ah.predictor[c]; st[c].index = std::clamp<int>(ah.stepIndex[c], 0, 88); }
        seq = ah.seq;
        stereo.resize(size_t(ah.frames) * 2);
        const uint8_t* in = p + sizeof(ah);
        for (int i = 0; i < ah.frames; ++i)
        {
            stereo[size_t(i) * 2] = AdpcmDecode(st[0], in[i] & 15);
            stereo[size_t(i) * 2 + 1] = AdpcmDecode(st[1], in[i] >> 4);
        }
        return true;
    }

    // Audio waiting to be played on the friend's side (stereo s16). Packets go in as they arrive;
    // the player takes what it needs. Holds about `target` frames: more is dropped, and after running
    // dry it waits until half of that is there again.
    class AudioBuffer
    {
    public:
        void Configure(int targetFrames, int maxFrames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_target = targetFrames;
            m_max = std::max(maxFrames, targetFrames * 2);
        }
        void Clear()
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_data.clear();
            m_haveSeq = false;
            m_refill = true;
        }
        void Push(uint32_t seq, const int16_t* stereo, int frames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_haveSeq)
            {
                const int32_t d = static_cast<int32_t>(seq - m_lastSeq);
                if (d <= 0) return;   // late or twice
                if (d > 1 && d <= 4) m_data.insert(m_data.end(), size_t(frames) * 2 * size_t(d - 1), 0);   // lost: keep the timing
            }
            m_lastSeq = seq;
            m_haveSeq = true;
            m_data.insert(m_data.end(), stereo, stereo + size_t(frames) * 2);
            const size_t have = m_data.size() / 2;
            if (have > size_t(m_max))
            {
                const size_t drop = have - size_t(m_target);
                m_data.erase(m_data.begin(), m_data.begin() + static_cast<std::ptrdiff_t>(drop * 2));
                ++m_dropped;
            }
        }
        // Always fills `frames` (silence where nothing is there); returns how many were real audio.
        int Pull(int16_t* out, int frames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            const size_t have = m_data.size() / 2;
            if (m_refill && have < size_t(std::max(1, m_target / 2)))
            {
                std::memset(out, 0, size_t(frames) * 4);
                return 0;
            }
            m_refill = false;
            const size_t n = std::min(have, size_t(frames));
            if (n) std::memcpy(out, m_data.data(), n * 4);
            if (n < size_t(frames)) { std::memset(out + n * 2, 0, (size_t(frames) - n) * 4); m_refill = true; ++m_underruns; }
            m_data.erase(m_data.begin(), m_data.begin() + static_cast<std::ptrdiff_t>(n * 2));
            return static_cast<int>(n);
        }
        int Level() const
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            return static_cast<int>(m_data.size() / 2);
        }
        unsigned Underruns() const { std::lock_guard<std::mutex> lock(m_mutex); return m_underruns; }
        unsigned Dropped() const { std::lock_guard<std::mutex> lock(m_mutex); return m_dropped; }

    private:
        mutable std::mutex m_mutex;
        std::vector<int16_t> m_data;
        uint32_t m_lastSeq = 0;
        bool m_haveSeq = false, m_refill = true;
        int m_target = 1920, m_max = 7200;
        unsigned m_underruns = 0, m_dropped = 0;
    };
}
