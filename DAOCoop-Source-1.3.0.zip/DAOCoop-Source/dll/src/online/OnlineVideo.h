#pragma once
// Online play, the picture: the host's frames -> H.264, and on the friend's side H.264 -> the whole
// screen. Media Foundation (built into Windows) does the codec work. DirectX 9 (DAOCoop).
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include "OnlineProtocol.h"

struct IDirect3DDevice9;

namespace OnlineVideo
{
    struct Settings
    {
        int height = 720;          // stream height; the width follows the game's aspect
        int fps = 60;
        int bitrateKbps = 8000;
        int gopSeconds = 4;        // a keyframe at least this often (and whenever a friend lost one)
        int profile = 66;          // H.264 profile: 66 baseline, 77 main, 100 high
        int qualityVsSpeed = 33;   // encoder effort 0..100 (lower: faster)
        bool hardware = true;      // the GPU's encoder when Windows has one for 32-bit programs
        int readbackWaitMs = 10;   // (not used with D3D9: the copy is read one frame later)
    };
    // One encoded frame (Annex B; SPS/PPS in front of every keyframe). Encoder thread.
    using FrameSink = std::function<void(const uint8_t* data, size_t size, bool key, uint16_t width, uint16_t height, uint32_t captureMs)>;

    // ---- Host ----
    bool StartHost(const Settings& settings, FrameSink sink);
    void StopHost();
    bool HostRunning();
    void RequestKeyframe();
    void SetBitrate(int kbps);
    std::string HostStatus();
    void CaptureD3D9(IDirect3DDevice9* dev);      // render thread, the game's Present (before the real one)
    void DeviceLost();                            // render thread, before the device's Reset

    // ---- Friend ----
    bool StartViewer();
    void StopViewer();
    bool ViewerRunning();
    void SubmitFrame(OnlineProtocol::VideoFrame&& frame);   // network thread, frames in order
    bool DrawViewerD3D9(IDirect3DDevice9* dev);   // render thread: the newest picture over the whole back buffer
    struct ViewerStats
    {
        bool picture = false;
        uint32_t decoded = 0, shown = 0, failures = 0;
        double decodeMs = 0;            // average
        uint32_t captureMs = 0;         // host clock, of the picture shown last
        uint32_t shownAtMs = 0;         // our clock (OnlineClock), when it was put on screen
        uint16_t width = 0, height = 0;
        std::string decoder;
    };
    ViewerStats GetViewerStats();
    bool TakeKeyframeRequest();
    void Shutdown();
}
