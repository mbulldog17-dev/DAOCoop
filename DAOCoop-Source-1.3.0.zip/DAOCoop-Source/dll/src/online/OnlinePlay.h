#pragma once
// Online play (DAOCoop 1.2.27): friends play Player 2 / Player 3 from their own PCs, inside the game.
// The host's game is the only world. It streams its picture and sound to each friend's game, and each
// friend's controller arrives as an extra controller (vpad.h slots 4 and 5), which the co-op lobby
// gives to Player 2 or 3 like a local one. A friend's own game is just a window onto the host's.
//   Host:   Co-op > Online Multiplayer > Host Game        (an invite code shows, copied to the clipboard)
//   Friend: Co-op > Online Multiplayer > Join Game        (copy the code: it connects by itself; or a game
//                                                           on the same network: press A)
// Ported from the Amalur co-op mod (OnlinePlay / OnlineVideo / OnlineAudio / OnlineProtocol); no Steam
// here (the GOG game has no Steam), only invite codes (UPnP opens the host's router port by itself).
// Settings: [Online] in DAOCoop.ini.
#include <string>
#include <vector>

struct IDirect3DDevice9;

namespace OnlinePlay
{
    void Init(const wchar_t* iniPath);   // DllMain: only remembers the ini
    void AfterStartup();                 // startup thread: puts the game's sound back if an old session muted it

    // The game's Present / Reset (render thread, d3d9hook.h).
    void OnPresent(IDirect3DDevice9* dev);
    void OnReset(IDirect3DDevice9* dev);

    // Lobby (main thread / menu).
    std::string StartHosting();          // returns a status line
    std::string OpenJoin();
    void Stop();                         // leave / stop hosting
    bool Hosting();
    bool Joining();                      // join window open or watching a host
    bool Watching();                     // a friend: connected to a host
    // Lobby lines: code letter ('H' heading, 'W' gold, 'R' green, 'X' grey) + text.
    void LobbyLines(std::vector<std::pair<wchar_t, std::wstring>>& out);
    // The friend's name for a controller slot (4/5), "" when none.
    std::wstring FriendName(int slot);

    // Messages for the host's screen (main thread shows them).
    bool TakeMessage(std::wstring& out);

    void Shutdown();
}
