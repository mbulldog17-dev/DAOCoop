#pragma once
// Save protection for co-op games.
//
// Backups: copies of the newest saves of the current Warden into
//   <game>\DAOCoop\Backups\<character folder>\<date>_<reason>\<save folder>\...
// (or %LOCALAPPDATA%\DAOCoop\Backups if the game folder isn't writable),
// taken on a background thread:
//   - once per game launch when a co-op game is first played ("session-start");
//   - right before a co-op character creator opens ("before-creator-pN"):
//     the game autosaves first (DoAutoSave, or a quick save if no new save
//     appears), the creator opens when the save is on disk.
// Only the newest BackupsPerCharacter sets are kept.
//
// Missing character: the names of Player 2's/3's own characters are recorded
// per Warden (Backups\coop-characters.ini). Loading a save of that Warden
// without them shows a message; the player can then restore the newest backup
// that still has their character as a NEW save in the game's Load list.
//
// Saves live in Documents\BioWare\Dragon Age\Characters\<name>\Saves\<save>\
// (engine format "%ls%ls\Saves\%ls%d"); [Saves] Folder overrides the
// Characters folder.
#include <cstdint>

struct SaveSafeSettings {
    bool    enabled;
    bool    autosaveBeforeCreator;
    int     keepSets;           // backup sets kept per character
    int     savesPerSet;        // newest saves copied into each set
    wchar_t charactersDir[260]; // empty = Documents\BioWare\Dragon Age\Characters
};

void SaveSafeInit(const SaveSafeSettings& s, const wchar_t* modDir);
void SaveSafeTick(unsigned nowMs);          // main thread (autosave wait)

// Starts a backup of `hero`'s newest saves. autosaveFirst: make a save first and
// wait for it (SaveSafeBusy() is true meanwhile). p2/p3: names of the co-op
// characters in the game right now ("" = none), written into the set's info.
void SaveSafeBackup(const wchar_t* reason, bool autosaveFirst, const wchar_t* hero,
                    const wchar_t* p2, const wchar_t* p3);
bool SaveSafeBusy();

// Co-op character names per Warden.
void SaveSafeRecord(const wchar_t* hero, int player, const wchar_t* name);
bool SaveSafeRecorded(const wchar_t* hero, int player, wchar_t* name, int cap);

// Copies the newest backup that has `player`'s character into the Warden's
// saves as a new save. Writes what happened into msg. Runs synchronously.
bool SaveSafeRestore(const wchar_t* hero, int player, wchar_t* msg, int cap);
