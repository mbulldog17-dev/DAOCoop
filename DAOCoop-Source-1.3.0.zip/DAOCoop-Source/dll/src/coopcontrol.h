#pragma once
// Players 2 and 3 each drive one party member with their own controller.
// Same controls for both (settings in [P2] and [P3]):
//
//   Left stick    move (camera-relative)
//   A             attack (combat) / use chest, door, body (exploring)
//   D-pad up      use the nearest object
//   RB            next enemy target
//   D-pad L / R   pick a friend for helpful spells (heals, buffs) - or none:
//                 then they go to whoever is hurt worst
//   X / Y / B     quickbar abilities (page 1)
//   hold RT       X / Y / B = page 2      hold LT   X / Y / B = page 3
//   LB (1.5 s)    teleport next to the Warden
//   View          leave (the AI plays your character) / rejoin
//   View + Start  pause / unpause the game for everyone
//   View + X/Y/B  your inventory / character record / journal
//   View + A      the controls sheet
//   Start         join; in the game: your own level-up screen
//
// Drop-in / drop-out: a controller that disconnects hands its character to
// the AI at once; a controller that connects later joins with START.
#include <cstdint>

struct CoopPlayerSettings {
    bool    enabled;
    wchar_t tags[512];      // comma-separated creature tags; empty = pick from the party
    float   leash;          // metres from the Warden, out of combat
    float   leashCombat;    // metres from the Warden, in combat
    float   deadzone;       // 0..1 stick deadzone
    int     slots[3][3];    // [page][X,Y,B] quickbar slots (0-based); page 0 plain, 1 RT, 2 LT
};

enum CoopIdle { COOP_IDLE_ATTACK, COOP_IDLE_STAND, COOP_IDLE_TACTICS };

struct CoopSettings {
    CoopPlayerSettings player[2];   // [0] = Player 2, [1] = Player 3
    bool autoJoin;          // controllers already connected when the game starts join by themselves
    bool debug;             // extra log lines (camera, positions)
    bool expCreate;         // experimental: View+Start held 2 s opens the creator for that player
    int  idleMode;          // CoopIdle: what a co-op character does in combat without input
    bool pauseCombo;        // View + Start pauses / unpauses the game
    bool rumble;            // rumble on hits, low health, knocked out
    float rumbleScale;      // 0..2
    bool helpOnce;          // show the controls sheet the first time each player joins
    wchar_t ini[260];       // DAOCoop.ini (remembers that the sheet was shown)
};

void CoopInit(const CoopSettings& s);
void CoopTick(unsigned nowMs);   // main thread only

// Players in this game, from the co-op lobby / [Session] (1 = single player:
// co-op controls off). fromLobby: everyone joined in the lobby already.
void CoopSetPlayers(int players, bool fromLobby);
void CoopLobbyLoadedSave();          // the lobby's game is a loaded save, not a new game
int  CoopPlayers();

// Joined with a connected controller (for the screen hand-over).
bool CoopPlayerActive(int player);

void CoopFreeMovementTest(bool on);   // [Debug] FreeMovementTest: always use free movement (debugging)
void CoopFreeMovementRetest();        // test free movement again (probes)
void CoopFollowTarget(bool on);       // [Debug] FollowTarget (default 1): chase an invisible target
void CoopDropMarkers();               // remove the follow targets (before saving / on quit)
bool CoopBarInfo(uint32_t creature, wchar_t* out, int cap);   // HUD bar: "player|page|ab1|ab2|ab3"
