#pragma once
// Hands the controller UI (Native Controller Framework) to another player.
//
// The framework (bin_ship\dinput8_chain.dll) reads the Xbox UI controller with
// XInputGetState(0) from XINPUT9_1_0.dll. We patch that one import in the
// framework only, so while a route is set:
//   - XInputGetState(0) returns the routed player's pad (plus a few buttons of
//     Player 1's pad that are passed through, e.g. to cycle character tabs);
//   - XInputGetState(routed pad) reports "not connected".
// Our own pad reading (pads.cpp) uses its own import and is not affected.
#include <windows.h>

bool XInputRouteInstall();               // false = framework not found / not patched
void XInputRouteSet(int padIndex);       // -1 = normal (Player 1 on pad 0)
void XInputRouteSetPassThrough(WORD buttons);
void XInputRouteBlank(bool on);
void XInputRoutePressA(unsigned delayMs);   // a short A press on the UI controller (after delayMs)
void XInputRouteP1None(bool on);        // Player 1 on keyboard + mouse: controller 0 belongs to a co-op player
bool XInputRouteP1NoneGet();         // online friend watching: the framework sees no controller
int  XInputRouteGet();
