#pragma once
// Party slots shown by the HUD.
//
// The engine itself has no party-size limit (CCParty::AddMember 0x63A020 never
// checks a count). The 4-slot limit is in the HUD data the engine hands to the
// Portraits Flash movie: the "Party.Members/MemberSelected/Summons/
// SummonSelected" token arrays are sized to 4 in the CCParty constructor and
// filled for at most 4 members in CCParty::UpdatePortraitTokens (0x635B60).
//
// PartySlotsApply(n) raises those limits to n (4..8). It must run before the
// CCParty object is constructed (i.e. at DLL load, before a game is loaded);
// the portraits movie also needs Portrait5_mc/Portrait6_mc (see
// docs/party-slots.md) before the extra members get a portrait on screen.
// Can be called again later (e.g. when a co-op game is started from the lobby):
// the per-update limits take effect at once, the constructor ones for the next
// CCParty that gets built.
bool PartySlotsApply(int slots);
int  PartySlotsCurrent();
