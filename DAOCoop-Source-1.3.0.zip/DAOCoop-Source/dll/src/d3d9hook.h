#pragma once
// The game's Direct3D 9 device (1.2.27, online play): Direct3DCreate9 in DAOrigins.exe's import table
// -> IDirect3D9::CreateDevice -> the device's Present and Reset (vtable).
struct IDirect3DDevice9;
typedef void (*D3D9PresentCallback)(IDirect3DDevice9* dev);   // before the real Present (scene ended)
typedef void (*D3D9ResetCallback)(IDirect3DDevice9* dev);     // before the real Reset (free D3DPOOL_DEFAULT things)
bool D3D9HookInstall(D3D9PresentCallback present, D3D9ResetCallback reset);
// The game's back buffer size in pixels (window client size if the device left it 0).
bool D3D9BackBufferSize(int* w, int* h);
// Something drawn on the finished frame, before Present (rings.cpp).
void D3D9SetOverlay(D3D9PresentCallback draw);
