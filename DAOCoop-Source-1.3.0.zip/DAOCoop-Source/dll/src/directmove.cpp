#include "directmove.h"
#include "hooks.h"
#include "game.h"
#include "log.h"
#include "equiplock.h"
#include <windows.h>
#include <cstring>

static bool g_verbose = false;
static int  g_execAs = -1;          // object id to report as "controlled", -1 = no override

#ifdef _MSC_VER
static void* Owner(int* action)
{
    typedef void* (__thiscall* Owner_t)(int*);
    __try { return reinterpret_cast<Owner_t>((*reinterpret_cast<void***>(action))[0x10 / 4])(action); }
    __except (1) { return nullptr; }
}
static int ReadI(void* p, int off) { __try { return *(int*)((char*)p + off); } __except (1) { return -1; } }
#else
static void* Owner(int* action)
{
    typedef void* (__thiscall* Owner_t)(int*);
    return reinterpret_cast<Owner_t>((*reinterpret_cast<void***>(action))[0x10 / 4])(action);
}
static int ReadI(void* p, int off) { return *(int*)((char*)p + off); }
#endif

static int CoopIndex(void* obj)
{
    if (!obj) return 0;
    for (int n = 2; n <= 3; ++n) {
        uint32_t id = CoopCharacterOf(n);
        if (id != 0xFFFFFFFF && obj == game::ClientCreature(id)) return n;
    }
    return 0;
}

// Replaces "call 0x606F10" (the controlled character's id) at the two call sites.
typedef int (*Ctrl_t)();
static int __fastcall ControlledId(void*, void*)
{
    if (g_execAs != -1) return g_execAs;
    return reinterpret_cast<Ctrl_t>(0x606F10)();
}

typedef int (__thiscall* Exec_t)(void*, void*, int*);
static Exec_t g_exec = nullptr;
static int g_logged[4] = {};
static int __fastcall HookExec(void* self, void*, void* p, int* action)
{
    void* owner = action ? Owner(action) : nullptr;
    int n = CoopIndex(owner);
    if (!n) return g_exec(self, p, action);
    int saved = g_execAs;
    g_execAs = ReadI(owner, 0x10);                     // the creature's object id (what 0x53CC40 on +4 reads)
    int r = g_exec(self, p, action);
    g_execAs = saved;
    if (g_verbose && g_logged[n] < 15) {
        ++g_logged[n];
        Log("Direct move: Player %d step -> %d (0 = moving, 1 = ended) | state %d moving %d",
            n, r, ReadI(owner, 0xB20), (int)*((unsigned char*)owner + 0xB24));
    }
    return r;
}

static bool PatchCall(uintptr_t at, uintptr_t oldTarget, void* fn, const char* name)
{
    uint8_t expect[5] = { 0xE8 }, bytes[5] = { 0xE8 };
    int32_t o = (int32_t)(oldTarget - (at + 5)), nw = (int32_t)((uintptr_t)fn - (at + 5));
    memcpy(expect + 1, &o, 4); memcpy(bytes + 1, &nw, 4);
    return PatchBytes(at, expect, bytes, 5, name);
}

void DirectMoveFixInstall(bool verbose)
{
    g_verbose = verbose;
    static const uint8_t kExec[] = { 0x55, 0x8B, 0xEC, 0x83, 0xE4, 0xF0, 0x6A, 0xFF };
    g_exec = reinterpret_cast<Exec_t>(HookInstall(0x7A8C20, reinterpret_cast<void*>(&HookExec), 8, kExec, "direct-move executor"));
    if (!g_exec) { Log("Direct move: executor hook failed - Player 2/3 keep move orders"); return; }
    bool a = PatchCall(0x7A8DAD, 0x606F10, reinterpret_cast<void*>(&ControlledId), "direct-move controlled check");
    bool b = PatchCall(0x7A3ADC, 0x606F10, reinterpret_cast<void*>(&ControlledId), "direct-move collision check");
    Log("Direct move: ready for Player 2/3 (%s, %s)", a ? "steer ok" : "steer FAILED", b ? "collide ok" : "collide FAILED");
}
