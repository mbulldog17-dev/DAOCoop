#pragma once
// Full path of the dinput8.dll our calls are passed on to (a chained mod or Windows' own).
const wchar_t* ProxyTargetPath();
