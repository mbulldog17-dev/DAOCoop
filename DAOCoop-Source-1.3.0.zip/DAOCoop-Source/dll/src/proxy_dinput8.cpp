// The game loads our DLL as dinput8.dll from bin_ship (it imports DirectInput8Create).
// Every call is passed on to the "real" dinput8:
//   1. bin_ship\dinput8_chain.dll, if present: another mod's dinput8.dll that the installer
//      renamed (for example the Native Controller Framework), so both mods run together;
//   2. otherwise Windows' own dinput8.dll from the system folder.
#include <windows.h>
#include <objbase.h>   // REFIID, REFCLSID, LPUNKNOWN
#include "proxy.h"

static HMODULE g_real = nullptr;
static wchar_t g_realPath[MAX_PATH] = L"";

static HMODULE LoadReal()
{
    if (g_real) return g_real;

    // 1. a chained mod next to us
    HMODULE self = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)&LoadReal, &self);
    wchar_t selfPath[MAX_PATH];
    GetModuleFileNameW(self, selfPath, MAX_PATH);
    wchar_t path[MAX_PATH];
    lstrcpyW(path, selfPath);
    wchar_t* slash = wcsrchr(path, L'\\');
    if (slash) {
        lstrcpyW(slash + 1, L"dinput8_chain.dll");
        // never chain to ourselves (that would pass every call back in here forever)
        if (lstrcmpiW(path, selfPath) != 0 && GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) {
            HMODULE m = LoadLibraryW(path);
            if (m == self) {
                FreeLibrary(m);
            } else if (m) {
                g_real = m;
                lstrcpyW(g_realPath, path);
                return g_real;
            }
        }
    }

    // 2. Windows' own (a 32-bit process is redirected to SysWOW64)
    GetSystemDirectoryW(path, MAX_PATH);
    lstrcatW(path, L"\\dinput8.dll");
    g_real = LoadLibraryW(path);
    if (g_real) lstrcpyW(g_realPath, path);
    return g_real;
}

static FARPROC Real(const char* name)
{
    HMODULE m = LoadReal();
    return m ? GetProcAddress(m, name) : nullptr;
}

const wchar_t* ProxyTargetPath()
{
    LoadReal();
    return g_realPath;
}

extern "C" HRESULT WINAPI Proxy_DirectInput8Create(HINSTANCE inst, DWORD version, REFIID riid, LPVOID* out, LPUNKNOWN outer)
{
    typedef HRESULT (WINAPI* fn_t)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
    static fn_t fn = (fn_t)Real("DirectInput8Create");
    return fn ? fn(inst, version, riid, out, outer) : E_FAIL;
}

extern "C" HRESULT WINAPI Proxy_DllCanUnloadNow()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllCanUnloadNow");
    return fn ? fn() : S_FALSE;
}

extern "C" HRESULT WINAPI Proxy_DllGetClassObject(REFCLSID clsid, REFIID riid, LPVOID* out)
{
    typedef HRESULT (WINAPI* fn_t)(REFCLSID, REFIID, LPVOID*);
    static fn_t fn = (fn_t)Real("DllGetClassObject");
    return fn ? fn(clsid, riid, out) : CLASS_E_CLASSNOTAVAILABLE;
}

extern "C" HRESULT WINAPI Proxy_DllRegisterServer()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllRegisterServer");
    return fn ? fn() : E_FAIL;
}

extern "C" HRESULT WINAPI Proxy_DllUnregisterServer()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllUnregisterServer");
    return fn ? fn() : E_FAIL;
}
