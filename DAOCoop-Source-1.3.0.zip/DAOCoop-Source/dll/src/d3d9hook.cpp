#include "d3d9hook.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cstring>

static D3D9PresentCallback g_onPresent = nullptr;
static D3D9PresentCallback g_overlay = nullptr;
void D3D9SetOverlay(D3D9PresentCallback draw) { g_overlay = draw; }
static D3D9ResetCallback g_onReset = nullptr;

typedef IDirect3D9* (WINAPI* Create9_t)(UINT);
typedef HRESULT (STDMETHODCALLTYPE* CreateDevice_t)(IDirect3D9*, UINT, D3DDEVTYPE, HWND, DWORD, D3DPRESENT_PARAMETERS*, IDirect3DDevice9**);
typedef HRESULT (STDMETHODCALLTYPE* Present_t)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
typedef HRESULT (STDMETHODCALLTYPE* Reset_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);

static Create9_t g_create9 = nullptr;
static CreateDevice_t g_createDevice = nullptr;
static Present_t g_present = nullptr;
static Reset_t g_reset = nullptr;
static bool g_loggedPresent = false;
static volatile int g_bbW = 0, g_bbH = 0;
static HWND g_wnd = nullptr;
static void NoteSize(const D3DPRESENT_PARAMETERS* pp, HWND w)
{
    if (w) g_wnd = w;
    if (pp && pp->hDeviceWindow) g_wnd = pp->hDeviceWindow;
    g_bbW = pp ? (int)pp->BackBufferWidth : 0; g_bbH = pp ? (int)pp->BackBufferHeight : 0;
}
bool D3D9BackBufferSize(int* w, int* h)
{
    int a = g_bbW, b = g_bbH;
    if ((a <= 0 || b <= 0) && g_wnd) { RECT r; if (GetClientRect(g_wnd, &r)) { a = r.right - r.left; b = r.bottom - r.top; } }
    if (a <= 0 || b <= 0) return false;
    *w = a; *h = b; return true;
}

static bool PatchSlot(void** slot, void* fn, void** original)
{
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) return false;
    if (original) *original = *slot;
    *slot = fn;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

static HRESULT STDMETHODCALLTYPE HookPresent(IDirect3DDevice9* dev, const RECT* s, const RECT* d, HWND w, const RGNDATA* r)
{
    if (!g_loggedPresent) { g_loggedPresent = true; Log("Direct3D 9: first Present seen (online picture hook working)"); }
    if (g_overlay) {                      // drawn first, so online friends see it too
#ifdef _MSC_VER
        __try { g_overlay(dev); } __except (EXCEPTION_EXECUTE_HANDLER) { Log("Direct3D 9: crash in the overlay - caught, overlay off"); g_overlay = nullptr; }
#else
        g_overlay(dev);
#endif
    }
    if (g_onPresent) {
#ifdef _MSC_VER
        __try { g_onPresent(dev); } __except (EXCEPTION_EXECUTE_HANDLER) { Log("Direct3D 9: crash in the online picture code - caught"); }
#else
        g_onPresent(dev);
#endif
    }
    return g_present(dev, s, d, w, r);
}

static HRESULT STDMETHODCALLTYPE HookReset(IDirect3DDevice9* dev, D3DPRESENT_PARAMETERS* pp)
{
    if (g_onReset) g_onReset(dev);
    HRESULT hr = g_reset(dev, pp);
    if (SUCCEEDED(hr)) NoteSize(pp, nullptr);
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookCreateDevice(IDirect3D9* d3d, UINT a, D3DDEVTYPE t, HWND w, DWORD f, D3DPRESENT_PARAMETERS* pp, IDirect3DDevice9** out)
{
    HRESULT hr = g_createDevice(d3d, a, t, w, f, pp, out);
    if (SUCCEEDED(hr)) NoteSize(pp, w);
    if (SUCCEEDED(hr) && out && *out && !g_present) {
        void** vt = *reinterpret_cast<void***>(*out);
        bool ok = PatchSlot(&vt[17], reinterpret_cast<void*>(&HookPresent), reinterpret_cast<void**>(&g_present)) &&
                  PatchSlot(&vt[16], reinterpret_cast<void*>(&HookReset), reinterpret_cast<void**>(&g_reset));
        Log("Direct3D 9: device made (%ux%u) - Present/Reset hooks %s", pp ? pp->BackBufferWidth : 0, pp ? pp->BackBufferHeight : 0, ok ? "on" : "FAILED");
    }
    return hr;
}

static IDirect3D9* WINAPI HookCreate9(UINT sdk)
{
    IDirect3D9* d3d = g_create9(sdk);
    if (d3d && !g_createDevice) {
        void** vt = *reinterpret_cast<void***>(d3d);
        PatchSlot(&vt[16], reinterpret_cast<void*>(&HookCreateDevice), reinterpret_cast<void**>(&g_createDevice));
    }
    return d3d;
}

static void** FindImport(HMODULE module, const char* dllName, const char* func)
{
    BYTE* base = reinterpret_cast<BYTE*>(module);
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const IMAGE_DATA_DIRECTORY& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress) return nullptr;
    for (auto* imp = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + dir.VirtualAddress); imp->Name; ++imp) {
        if (_stricmp(reinterpret_cast<char*>(base + imp->Name), dllName) != 0) continue;
        auto* names = reinterpret_cast<IMAGE_THUNK_DATA*>(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
        auto* slots = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imp->FirstThunk);
        for (; names->u1.AddressOfData; ++names, ++slots) {
            if (IMAGE_SNAP_BY_ORDINAL(names->u1.Ordinal)) continue;
            auto* byName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + names->u1.AddressOfData);
            if (strcmp(reinterpret_cast<char*>(byName->Name), func) == 0)
                return reinterpret_cast<void**>(&slots->u1.Function);
        }
    }
    return nullptr;
}

bool D3D9HookInstall(D3D9PresentCallback present, D3D9ResetCallback reset)
{
    g_onPresent = present;
    g_onReset = reset;
    void** slot = FindImport(GetModuleHandleW(nullptr), "d3d9.dll", "Direct3DCreate9");
    if (!slot) { Log("Direct3D 9: Direct3DCreate9 not in the game's imports - online picture off"); return false; }
    bool ok = PatchSlot(slot, reinterpret_cast<void*>(&HookCreate9), reinterpret_cast<void**>(&g_create9));
    Log("Direct3D 9: Direct3DCreate9 hook %s", ok ? "installed" : "FAILED");
    return ok;
}
