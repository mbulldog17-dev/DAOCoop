#include "camera.h"
#include "hooks.h"
#include "log.h"
#include "game.h"
#include <windows.h>
#include <cmath>
#include "screenwall.h"
#include "script.h"

static CameraSettings g_s;

// Target (from the main tick) and current (smoothed per frame) adjustment.
static float g_wantShift[3] = {}, g_wantZoom = 1.f;
static float g_shift[3] = {}, g_zoom = 1.f;
static bool  g_active = false;
// 1.2.47 combat zoom: the eye (+0x70, the view is built from it in 0x76EFA0) moves back
// along the camera's own forward axis. g_wantBack comes from the main tick (feedback on
// everyone's screen position), g_back is the smoothed value used per frame.
static float g_wantBack = 0.f, g_back = 0.f;
static float g_fwd[3] = { 0.f, 1.f, 0.f };
static float g_eye[3];                 // the eye as last used for the view
static bool  g_eyeOk = false;
static bool  g_fwdOk = false;
static volatile bool g_tactical = false;
bool CameraIsTactical() { return g_tactical; }

typedef void (__thiscall* FollowUpdate_t)(void* cam, float dt);
static FollowUpdate_t g_orig = nullptr;

static bool g_loggedDist = false;
static void Adjust(char* cam, float dt)
{
    if (!g_loggedDist && g_active) {                                // diagnostics for a later zoom-out (distance = lerp(+0x64, +0x68, node+0x24))
        g_loggedDist = true;
        char* node = *reinterpret_cast<char**>(cam + 4);
        Log("Camera: distance near %.2f far %.2f zoom %.3f, tactical %d, +0x48 %.2f",
            *reinterpret_cast<float*>(cam + 0x64), *reinterpret_cast<float*>(cam + 0x68),
            node ? *reinterpret_cast<float*>(node + 0x24) : -1.f, *reinterpret_cast<int*>(cam + 0x90),
            *reinterpret_cast<float*>(cam + 0x48));
    }
    g_tactical = *reinterpret_cast<int*>(cam + 0x90) == 1;
    if (g_tactical) return;                                         // tactical camera: player-panned
    if (!(dt > 0.f) || dt > 0.5f) dt = 0.016f;
    float k = 1.f - std::exp(-dt * 2.5f);                           // ~0.4 s to settle
    for (int i = 0; i < 3; ++i) g_shift[i] += ((g_active ? g_wantShift[i] : 0.f) - g_shift[i]) * k;
    g_zoom += ((g_active ? g_wantZoom : 1.f) - g_zoom) * k;
    float kb = 1.f - std::exp(-dt * 1.5f);                          // zoom settles a little slower
    g_back += ((g_active ? g_wantBack : 0.f) - g_back) * kb;
    if (g_back < 0.01f && !g_active) g_back = 0.f;
    if (std::fabs(g_shift[0]) + std::fabs(g_shift[1]) < 0.01f && g_back < 0.01f) {
        const float* e = reinterpret_cast<float*>(cam + 0x70);
        for (int i = 0; i < 3; ++i) g_eye[i] = e[i];
        g_eyeOk = true;
        return;
    }

    float* pos = reinterpret_cast<float*>(cam + 0x70);
    float* focus = reinterpret_cast<float*>(cam + 0x80);
    float nf[3], np[3];
    for (int i = 0; i < 3; ++i) {
        nf[i] = focus[i] + g_shift[i];
        np[i] = pos[i] + g_shift[i] - (g_fwdOk ? g_fwd[i] * g_back : 0.f);
    }
    for (int i = 0; i < 3; ++i) { focus[i] = nf[i]; pos[i] = np[i]; }
    for (int i = 0; i < 3; ++i) g_eye[i] = np[i];
    g_eyeOk = true;
    float* pos2 = reinterpret_cast<float*>(cam + 0xC0);             // copy the game keeps of +0x70
    for (int i = 0; i < 3; ++i) pos2[i] = np[i];
}

static void __fastcall HookFollowUpdate(void* cam, void*, float dt)
{
    g_orig(cam, dt);
#ifdef _MSC_VER
    __try { Adjust(static_cast<char*>(cam), dt); } __except (EXCEPTION_EXECUTE_HANDLER) {}
#else
    Adjust(static_cast<char*>(cam), dt);
#endif
}

void CameraInit(const CameraSettings& s)
{
    g_s = s;
    if (g_s.maxZoom < 1.f) g_s.maxZoom = 1.f;
    if (g_s.maxZoom > 2.f) g_s.maxZoom = 2.f;
    if (!s.enabled) { Log("Camera: keep-everyone-in-view off"); return; }
    static const uint8_t kPrologue[] = { 0x55, 0x8B, 0xEC, 0x83, 0xE4, 0xF0, 0x6A, 0xFF };
    g_orig = reinterpret_cast<FollowUpdate_t>(
        HookInstall(0x771250, reinterpret_cast<void*>(&HookFollowUpdate), 8, kPrologue, "camera follow"));
    Log("Camera: keep everyone in view %s (slide up to %.0f m; combat zoom %s, up to %.0f m)",
        g_orig ? "on" : "FAILED", g_s.maxShift, g_s.combatZoom ? "on" : "off", g_s.combatZoomMax);
}

// The camera's forward axis: horizontal look direction tilted by the pitch that puts a point
// 10 m ahead at the middle of the screen (game projection, last frame's view).
static void UpdateForward(const float eye[3])
{
    float fx = 0.f, fy = 1.f;
    if (!game::CameraLook(&fx, &fy)) return;
    float l = std::sqrt(fx * fx + fy * fy);
    if (l < 0.01f) return;
    fx /= l; fy /= l;
    float lo = -1.4f, hi = 0.6f;                       // pitch (radians): down .. up
    bool any = false;
    for (int it = 0; it < 18; ++it) {
        float m = (lo + hi) * 0.5f, c = std::cos(m), sn = std::sin(m);
        float q[3] = { eye[0] + 10.f * c * fx, eye[1] + 10.f * c * fy, eye[2] + 10.f * sn };
        float nx, ny; bool on;
        if (!ScreenWallProject(q, &nx, &ny, &on)) return;
        any = true;
        if (ny > 0.5f) lo = m; else hi = m;               // below the middle: look higher
    }
    if (!any) return;
    float m = (lo + hi) * 0.5f;
    g_fwd[0] = std::cos(m) * fx; g_fwd[1] = std::cos(m) * fy; g_fwd[2] = std::sin(m);
    g_fwdOk = true;
}

static uint32_t g_leadId = 0xFFFFFFFF;
void CameraSetLead(uint32_t id) { g_leadId = id; }

void CameraSetPlayers(const float (*p)[3], int n, bool active, bool combat)
{
    bool was = g_active;
    g_active = active && g_orig && n >= 2;
    if (g_active != was) Log("Camera: %s", g_active ? "following everyone (co-op characters in the area)" : "back to normal (only Player 1's character)");
    if (!g_active) return;
    // Middle of everyone (flat), and how far the farthest one is from it.
    float c[3] = {};
    for (int i = 0; i < n; ++i) for (int j = 0; j < 3; ++j) c[j] += p[i][j] / n;
    float spread = 0.f;
    for (int i = 0; i < n; ++i) {
        float dx = p[i][0] - c[0], dy = p[i][1] - c[1];
        float d = std::sqrt(dx * dx + dy * dy);
        if (d > spread) spread = d;
    }
    // The camera follows Player 1's character (p[0]). Frame everyone in the
    // camera's own axes (1.2.25): across the screen, the middle; along the view,
    // the screen shows much less below the focus (toward the camera) than above
    // it, so keep the nearest player within kBack metres of the focus and the
    // farthest within kFront, preferring the middle.
    const float kBack = 2.5f, kFront = 9.0f;
    float fx = 0.f, fy = 1.f;
    if (game::CameraLook(&fx, &fy)) {
        float l = std::sqrt(fx * fx + fy * fy);
        if (l > 0.01f) { fx /= l; fy /= l; } else { fx = 0.f; fy = 1.f; }
    }
    float rx = fy, ry = -fx;
    float minF = 1e9f, maxF = -1e9f, sumR = 0.f, sumF = 0.f;
    for (int i = 0; i < n; ++i) {
        float ox = p[i][0] - p[0][0], oy = p[i][1] - p[0][1];   // relative to Player 1
        float f = ox * fx + oy * fy, r = ox * rx + oy * ry;
        if (f < minF) minF = f;
        if (f > maxF) maxF = f;
        sumF += f; sumR += r;
    }
    float midF = sumF / n, midR = sumR / n;
    float lo = maxF - kFront, hi = minF + kBack;                  // allowed focus range along the view
    float focF = midF;
    if (lo <= hi) { if (focF < lo) focF = lo; if (focF > hi) focF = hi; }
    else focF = hi;                                                // can't fit both: keep the near one on screen
    float sx = fx * focF + rx * midR, sy = fy * focF + ry * midR;
    float len = std::sqrt(sx * sx + sy * sy);
    if (len > g_s.maxShift && len > 0.f) { sx *= g_s.maxShift / len; sy *= g_s.maxShift / len; }
    g_wantShift[0] = sx; g_wantShift[1] = sy; g_wantShift[2] = 0.f;
    // Zooming out by scaling (position - focus) was wrong: that vector is the
    // sideways shoulder offset, not the camera distance (see engine notes, 1.2.6),
    // so it pushed the view sideways. Slide only until the real distance is known.
    g_wantZoom = 1.f;

    // Combat zoom (1.2.47): pull back while anyone's chest/head is near a screen edge,
    // come back in once everyone is comfortably inside. Out of combat: back to normal.
    static unsigned last = 0;
    unsigned now = GetTickCount();
    float dt = last ? (now - last) / 1000.f : 0.016f;
    last = now;
    if (dt > 0.5f) dt = 0.016f;
    if (!g_s.combatZoom || !combat) { g_wantBack = 0.f; return; }
    if (g_eyeOk) UpdateForward(g_eye);
    float worst = -1.f;
    bool seenAll = true;
    for (int i = 0; i < n; ++i) {
        float chest[3] = { p[i][0], p[i][1], p[i][2] + 1.1f }, head[3] = { p[i][0], p[i][1], p[i][2] + 1.9f };
        float nx, ny, hx, hy; bool on, onh;
        if (!ScreenWallProject(chest, &nx, &ny, &on) || !ScreenWallProject(head, &hx, &hy, &onh)) return;
        if (!on) { seenAll = false; continue; }
        const float m = 0.10f;
        float o = m - nx;
        if (nx - (1.f - m) > o) o = nx - (1.f - m);
        if (ny - (1.f - m) > o) o = ny - (1.f - m);
        if (m - hy > o) o = m - hy;
        if (o > worst) worst = o;
    }
    // 1.2.49: gentler (it pumped in and out), and never through walls or ceilings: the
    // pulled-back eye must be in sight of Player 1's character (game collision ray).
    static unsigned roomSince = 0, nextLos = 0;
    static float losCap = 1e9f;
    if (!seenAll || worst > 0.f) { g_wantBack += 2.f * dt; roomSince = 0; }   // someone at/over an edge: out
    else if (worst < -0.12f) {                                                 // lots of room for a while: back in
        if (!roomSince) roomSince = now ? now : 1;
        if (now - roomSince > 1500) g_wantBack -= 1.f * dt;
    } else roomSince = 0;
    if (g_wantBack < 0.f) g_wantBack = 0.f;
    if (g_wantBack > g_s.combatZoomMax) g_wantBack = g_s.combatZoomMax;
    if (g_wantBack > 0.f && g_eyeOk && g_fwdOk && (int)(now - nextLos) >= 0) {
        nextLos = now + 150;
        float base[3];
        for (int i = 0; i < 3; ++i) base[i] = g_eye[i] + g_fwd[i] * g_back;   // the game's own eye
        script::Vec3 from = { p[0][0], p[0][1], p[0][2] + 1.7f };
        auto clear = [&](float b) {
            script::Vec3 e = { base[0] - g_fwd[0] * (b + 0.6f), base[1] - g_fwd[1] * (b + 0.6f), base[2] - g_fwd[2] * (b + 0.6f) };
            return script::LineOfSight(g_leadId, from, e) != 0;                         // unknown counts as clear
        };
        script::Vec3 up = { from.x, from.y, from.z + 0.5f };
        int sane = g_leadId == 0xFFFFFFFF ? -1 : script::LineOfSight(g_leadId, from, up);
        static int loggedSane = -2;
        if (sane != loggedSane) { loggedSane = sane; Log("Camera: wall check %s (%d)", sane == 1 ? "working" : "not usable here - combat zoom kept to 2 m", sane); }
        if (sane != 1) losCap = 2.f;                       // can't tell: stay close
        else if (clear(g_wantBack)) losCap = 1e9f;
        else {
            float lo = 0.f, hi = g_wantBack;
            for (int it = 0; it < 4; ++it) { float m = (lo + hi) * 0.5f; if (clear(m)) lo = m; else hi = m; }
            losCap = lo;
            static int loggedWall = 0;
            if (loggedWall < 6) { ++loggedWall; Log("Camera: combat zoom held at %.1f m (wall or ceiling behind the camera)", lo); }
        }
    }
    if (g_wantBack > losCap) g_wantBack = losCap;
    static int logged = 0;
    if (logged < 6 && g_wantBack > 0.5f) { ++logged; Log("Camera: combat zoom out %.1f m (forward %.2f %.2f %.2f%s)", g_wantBack, g_fwd[0], g_fwd[1], g_fwd[2], g_fwdOk ? "" : ", not measured"); }
}
