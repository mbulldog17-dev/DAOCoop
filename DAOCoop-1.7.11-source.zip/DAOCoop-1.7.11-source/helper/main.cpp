// DAOCoopStream.exe (1.6.0): encodes the online stream for the game, in its own 64-bit process.
//   DAOCoopStream.exe <shared memory name> <game process id>
// Started and ended by the game (OnlineVideo9.cpp, RemoteStart); ends by itself when the game does.
// Pictures in: NV12 in shared memory (StreamShared.h). Out: H.264 frames, which the game sends on.
#include <windows.h>
#include <shellapi.h>
#include <cstdio>
#include <cstring>
#include <string>
#include "log.h"
#include "online/OnlineVideo.h"
#include "online/StreamShared.h"

static const char* kHelperVersion = "1.6.0";

// The game's drawing-thread watchdog (d3d9hook.cpp) is not here: the shared video code only calls this.
void D3D9Stage(const char*) {}
int D3D9PacedInterval() { return 0; }   // 1.7.6: screen pacing is the game's (the helper only encodes)

int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int)
{
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv || argc < 3) return 2;

    wchar_t logPath[MAX_PATH];
    GetModuleFileNameW(nullptr, logPath, MAX_PATH);
    wchar_t* slash = wcsrchr(logPath, L'\\');
    if (slash) lstrcpyW(slash + 1, L"DAOCoopStream.log");
    LogInit(logPath);
    const DWORD gamePid = wcstoul(argv[2], nullptr, 10);
    Log("DAOCoopStream %s (64-bit) for the game, process %lu", kHelperVersion, gamePid);

    HANDLE game = OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, gamePid);
    // Run on the processor cores the game doesn't use (Dragon Age keeps itself to 2): the stream then
    // takes nothing from the game. Everything when there are no other cores.
    {
        DWORD_PTR gameMask = 0, sysMask = 0, mine = 0, sys2 = 0;
        if (game && GetProcessAffinityMask(game, &gameMask, &sysMask) && GetProcessAffinityMask(GetCurrentProcess(), &mine, &sys2)) {
            const DWORD_PTR others = sysMask & ~gameMask;
            if (others && SetProcessAffinityMask(GetCurrentProcess(), others))
                Log("Running on the cores the game doesn't use (mask 0x%llX; the game: 0x%llX)", (unsigned long long)others, (unsigned long long)gameMask);
            else
                Log("Sharing cores with the game (game mask 0x%llX, all 0x%llX)", (unsigned long long)gameMask, (unsigned long long)sysMask);
        }
    }
    HANDLE map = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, argv[1]);
    if (!map || !game) { Log("No game or shared memory (%lu) - ending", GetLastError()); return 3; }
    auto* h = static_cast<StreamShared::Header*>(MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, 0));
    if (!h || h->magic != StreamShared::kMagic || h->version != StreamShared::kVersion)
    {
        Log("Shared memory is not what this version expects - ending");
        if (h) { std::snprintf(h->status, sizeof(h->status), "DAOCoopStream.exe is another version than the mod"); InterlockedExchange(&h->state, 2); }
        return 4;
    }
    wchar_t ev[160];
    swprintf(ev, 160, L"%ls_in", argv[1]);
    HANDLE inEv = OpenEventW(SYNCHRONIZE | EVENT_MODIFY_STATE, FALSE, ev);
    swprintf(ev, 160, L"%ls_out", argv[1]);
    HANDLE outEv = OpenEventW(SYNCHRONIZE | EVENT_MODIFY_STATE, FALSE, ev);
    if (!inEv || !outEv) { Log("Events missing (%lu) - ending", GetLastError()); InterlockedExchange(&h->state, 2); return 5; }

    OnlineVideo::Settings s;
    s.height = h->height; s.fps = h->fps; s.bitrateKbps = h->bitrateKbps; s.gopSeconds = h->gopSeconds;
    s.profile = h->profile; s.qualityVsSpeed = h->effort; s.hardware = h->hardware != 0;
    uint32_t outSeq = 0;
    auto sink = [&](const uint8_t* data, size_t size, bool key, uint16_t w, uint16_t hh, uint32_t captureMs) {
        if (size > StreamShared::kOutSlotBytes) { Log("A frame of %zu bytes is too big for the shared slot - dropped", size); return; }
        int slot = -1;
        for (int i = 0; i < StreamShared::kOutSlots && slot < 0; ++i) if (h->out[i].state == 0) slot = i;
        if (slot < 0) { static int noted = 0; if (noted++ < 5) Log("The game is not taking frames - one dropped"); return; }
        std::memcpy(StreamShared::OutData(h, slot), data, size);
        StreamShared::OutSlot& o = h->out[slot];
        o.size = static_cast<uint32_t>(size); o.key = key ? 1 : 0; o.w = w; o.h = hh; o.captureMs = captureMs; o.seq = ++outSeq;
        InterlockedExchange(&o.state, 1);
        InterlockedIncrement(&h->encoded);
        SetEvent(outEv);
    };
    if (!OnlineVideo::StartHost(s, sink))
    {
        std::snprintf(h->status, sizeof(h->status), "the encoder did not start");
        InterlockedExchange(&h->state, 2);
        return 6;
    }
    std::snprintf(h->status, sizeof(h->status), "%s", OnlineVideo::HostStatus().c_str());
    InterlockedExchange(&h->heartbeat, static_cast<long>(GetTickCount()));
    InterlockedExchange(&h->state, 1);
    Log("Encoder started: %dp %d fps %d kbps, %s", s.height, s.fps, s.bitrateKbps, s.hardware ? "graphics card encoder allowed" : "processor encoder");

    DWORD lastStatus = 0;
    HANDLE waits[2] = { inEv, game };
    for (;;)
    {
        const DWORD r = WaitForMultipleObjects(2, waits, FALSE, 100);
        if (r == WAIT_OBJECT_0 + 1) { Log("The game ended"); break; }
        if (h->quit) { Log("The game stopped the stream"); break; }
        InterlockedExchange(&h->heartbeat, static_cast<long>(GetTickCount()));
        if (const long kbps = InterlockedExchange(&h->newBitrate, 0)) OnlineVideo::SetBitrate(static_cast<int>(kbps));
        if (InterlockedExchange(&h->forceKey, 0)) OnlineVideo::RequestKeyframe();
        if (GetTickCount() - lastStatus > 500)
        {
            lastStatus = GetTickCount();
            std::snprintf(h->status, sizeof(h->status), "%s", OnlineVideo::HostStatus().c_str());
        }
        // the pictures waiting, oldest first (the encoder keeps only the newest if it falls behind)
        for (;;)
        {
            int slot = -1;
            uint32_t best = 0xFFFFFFFF;
            for (int i = 0; i < StreamShared::kInSlots; ++i)
                if (h->in[i].state == 1 && h->in[i].seq < best) { best = h->in[i].seq; slot = i; }
            if (slot < 0 || InterlockedCompareExchange(&h->in[slot].state, 2, 1) != 1) break;
            const StreamShared::InSlot& in = h->in[slot];
            if (in.w > 0 && in.h > 0 && static_cast<uint64_t>(in.w) * in.h * 4 <= h->inSlotBytes)
                OnlineVideo::SubmitHostBgra(StreamShared::InData(h, slot), in.w, in.h, in.us);   // (copied: the slot is free again at once)
            InterlockedExchange(&h->in[slot].state, 0);
        }
    }
    OnlineVideo::StopHost();
    UnmapViewOfFile(h);
    CloseHandle(map);
    LogShutdown();
    return 0;
}
