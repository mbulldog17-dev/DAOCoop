@echo off
rem Puts the DAOCoop lobby server (the public game list) online on your free Cloudflare account,
rem then writes its address into the mod (dll\src\online\LobbyServer.h). Build the mod afterwards.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Lobby.ps1"
