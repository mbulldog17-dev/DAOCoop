# DAOCoop lobby server

The public game list for DAOCoop's online play: hosts list their game, players browse it and
ask to join, the host accepts or declines, and only then do the two games connect directly.
It never carries game traffic, so it fits easily in Cloudflare's free plan.

## Put it online (about 10 minutes, once)

The easy way: double-click **PUT THE LOBBY SERVER ONLINE.cmd** in this folder. It checks for
Node.js (and opens the download page if it's missing), signs you in to a free Cloudflare
account, sends the server, and writes its address into `dll\src\online\LobbyServer.h`.
Then build the mod.

By hand, if you prefer: you need a free Cloudflare account (https://dash.cloudflare.com/sign-up)
and Node.js (https://nodejs.org, the LTS version).

1. Open a command prompt in this folder (`lobby-server`).
2. `npx wrangler login` - a browser window opens; allow access to your Cloudflare account.
3. `npx wrangler deploy` - it prints the address, something like
   `https://daocoop-lobby.<your-name>.workers.dev`.
4. Open that address in a browser: it should say `DAOCoop lobby server`.
5. Put the address into the mod: open `dll\src\online\LobbyServer.h` in the project and change
   the last line to

   ```
   #define DAOCOOP_LOBBY_SERVER "https://daocoop-lobby.<your-name>.workers.dev"
   ```

   Build ("1 - BUILD AND INSTALL THE MOD"). Every package you build from then on uses your
   server, including updates for people who already have the mod. (A player can override it
   with `LobbyServer=` under `[Online]` in their DAOCoop.ini, or turn the list off with `off`.)

## Costs and limits

Cloudflare's free plan allows 100,000 requests a day for Workers and for Durable Objects. A
hosted game costs a handful of requests (its connection, a few updates, the join requests);
a player browsing refreshes the list every 10 seconds. Idle connections cost nothing. If a
limit is ever reached, the list stops answering until midnight UTC; invite codes keep working.

## Updating

Change `worker.js`, then `npx wrangler deploy` again. Running games reconnect by themselves.

## Testing the logic

`node test/run.mjs` walks through listing, joining, accepting, declining, locking, timeouts
and rate limits with a stand-in for the Workers runtime.
