; DAOCoop - the installer (1.7.8: Inno Setup, a well-known installer, instead of our own self-extractor that ran
; PowerShell - virus scanners took that for a "dropper"). Built by scripts\Make-Install-Package.ps1 with Inno Setup 6:
;   ISCC.exe /DMyVersion=1.7.8 /DPkg="<dist\DAOCoop-1.7.8>" /DOutDir="<dist>" installer\DAOCoop.iss
; It does what Install-DAOCoop.ps1 did: finds the game, keeps another mod's dinput8.dll working (renamed to
; dinput8_chain.dll), adds the new settings to an existing DAOCoop.ini without changing any value, the 4GB patch
; (GOG; never the Steam exe), the firewall rule for online play, and a normal uninstaller (Settings > Apps).

#ifndef MyVersion
  #define MyVersion "0.0.0"
#endif
#ifndef Pkg
  #define Pkg "..\dist\DAOCoop-" + MyVersion
#endif
#ifndef OutDir
  #define OutDir "..\dist"
#endif

[Setup]
AppId={{6A3F1C52-8B4E-4D7A-9C1E-DA0C0060E7A1}
AppName=DAOCoop - 3-Player Co-op for Dragon Age: Origins
AppVersion={#MyVersion}
AppVerName=DAOCoop {#MyVersion}
AppPublisher=DAOCoop
VersionInfoVersion={#MyVersion}
VersionInfoDescription=DAOCoop co-op mod installer
DefaultDirName={code:DefaultGameDir}
DirExistsWarning=no
AppendDefaultDirName=no
UsePreviousAppDir=yes
DisableProgramGroupPage=yes
DisableDirPage=no
Uninstallable=yes
UninstallFilesDir={app}\DAOCoop\Uninstall
UninstallDisplayName=DAOCoop {#MyVersion} (Dragon Age: Origins co-op)
PrivilegesRequired=admin
OutputDir={#OutDir}
OutputBaseFilename=DAOCoop-{#MyVersion}-Setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
LicenseFile={#Pkg}\LICENSES.txt
InfoAfterFile={#Pkg}\README.txt
CloseApplications=no

[Messages]
SelectDirLabel3=Choose the Dragon Age: Origins game folder (the one with bin_ship in it).
SelectDirBrowseLabel=It was looked for in Steam, GOG, the EA app and the usual folders. Click Next if it's right, or Browse.

[Tasks]
Name: "laa"; Description: "Give DAOrigins.exe the 4GB patch (fewer crashes; the original is kept and the uninstaller puts it back)"; Check: CanPatchLaa
Name: "firewall"; Description: "Let online play through Windows Firewall (so friends can join games you host)"

[InstallDelete]
; the PowerShell installer's copy (1.7.1 - 1.7.8 before this installer): replaced by the uninstaller in Settings > Apps
Type: filesandordirs; Name: "{app}\DAOCoop\Setup"

[Dirs]
; the game writes its log and the settings into DAOCoop (Program Files is read-only for programs otherwise)
Name: "{app}\DAOCoop"; Permissions: users-modify
Name: "{app}\DAOCoop\backups"; Permissions: users-modify

[Files]
Source: "{#Pkg}\files\bin_ship\dinput8.dll"; DestDir: "{app}\bin_ship"; Flags: ignoreversion
Source: "{#Pkg}\files\DAOCoop\DAOCoopStream.exe"; DestDir: "{app}\DAOCoop"; Flags: ignoreversion
; the settings: copied only when this PC has none; otherwise the new settings are added in [Code] (values kept)
Source: "{#Pkg}\files\DAOCoop\DAOCoop.ini"; DestDir: "{tmp}"; Flags: deleteafterinstall
Source: "{#Pkg}\files\override\*.dds"; DestDir: "{app}\packages\core\override\DAOCoop"; Flags: ignoreversion
Source: "{#Pkg}\files\override\portraits.gfx"; DestDir: "{app}\packages\core\override\DAOCoop"; Flags: ignoreversion; Check: NoOtherGfx('portraits.gfx')
Source: "{#Pkg}\files\override\startmenu2.gfx"; DestDir: "{app}\packages\core\override\DAOCoop"; Flags: ignoreversion; Check: NoOtherGfx('startmenu2.gfx')
Source: "{#Pkg}\files\override\floatylayer.gfx"; DestDir: "{app}\packages\core\override\DAOCoop"; Flags: ignoreversion; Check: NoOtherGfx('floatylayer.gfx')
Source: "{#Pkg}\README.txt"; DestDir: "{app}\DAOCoop"; DestName: "README.txt"; Flags: ignoreversion
Source: "{#Pkg}\LICENSES.txt"; DestDir: "{app}\DAOCoop"; Flags: ignoreversion

[UninstallDelete]
Type: files; Name: "{app}\DAOCoop\DAOCoopStream.log"
Type: files; Name: "{app}\DAOCoop\install-record.txt"
Type: dirifempty; Name: "{app}\packages\core\override\DAOCoop"

[Code]
const
  ExeRel = 'bin_ship\DAOrigins.exe';

var
  Chained: Boolean;
  LaaDone: Boolean;

{ ---------------- the game folder ---------------- }
function IsGame(const P: String): Boolean;
begin
  Result := (P <> '') and FileExists(AddBackslash(P) + ExeRel);
end;

function TryAdd(var Best: String; const P: String): Boolean;
begin
  Result := False;
  if (Best = '') and IsGame(P) then begin Best := RemoveBackslashUnlessRoot(P); Result := True; end;
end;

{ the value of "key" "value" in a Steam .vdf / .acf text }
function VdfValue(const Text, Key: String; From: Integer; var AtPos: Integer): String;
var i, q1, q2, q3: Integer; s: String;
begin
  Result := ''; AtPos := 0;
  s := Copy(Text, From, Length(Text));
  i := Pos('"' + Key + '"', s);
  if i = 0 then Exit;
  s := Copy(s, i + Length(Key) + 2, Length(s));
  q1 := Pos('"', s); if q1 = 0 then Exit;
  s := Copy(s, q1 + 1, Length(s));
  q2 := Pos('"', s); if q2 = 0 then Exit;
  Result := Copy(s, 1, q2 - 1);
  StringChangeEx(Result, '\\', '\', True);
  q3 := From + i + Length(Key) + 2 + q1 + q2;
  AtPos := q3;
end;

procedure TrySteamLibrary(var Best: String; const Lib: String);
var Ids: TArrayOfString; i, atp: Integer; acf: AnsiString; dir: String;
begin
  SetArrayLength(Ids, 2); Ids[0] := '47810'; Ids[1] := '17450';
  for i := 0 to 1 do
    if LoadStringFromFile(AddBackslash(Lib) + 'steamapps\appmanifest_' + Ids[i] + '.acf', acf) then begin
      dir := VdfValue(String(acf), 'installdir', 1, atp);
      if dir <> '' then TryAdd(Best, AddBackslash(Lib) + 'steamapps\common\' + dir);
    end;
  TryAdd(Best, AddBackslash(Lib) + 'steamapps\common\Dragon Age Ultimate Edition');
end;

function FindGame(): String;
var v, steam, lib, drives, d: String; keys: TArrayOfString; i, atp, from: Integer; vdf: AnsiString;
begin
  Result := '';
  { GOG (Galaxy and the offline installers) }
  if RegGetSubkeyNames(HKLM32, 'SOFTWARE\GOG.com\Games', keys) then
    for i := 0 to GetArrayLength(keys) - 1 do
      if RegQueryStringValue(HKLM32, 'SOFTWARE\GOG.com\Games\' + keys[i], 'gameName', v) and (Pos('dragon age', Lowercase(v)) > 0) then
        if RegQueryStringValue(HKLM32, 'SOFTWARE\GOG.com\Games\' + keys[i], 'path', v) then TryAdd(Result, v);
  { Steam's uninstall records, then every Steam library }
  if RegQueryStringValue(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 47810', 'InstallLocation', v) then TryAdd(Result, v);
  if RegQueryStringValue(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 17450', 'InstallLocation', v) then TryAdd(Result, v);
  steam := '';
  if not RegQueryStringValue(HKCU, 'Software\Valve\Steam', 'SteamPath', steam) then
    RegQueryStringValue(HKLM32, 'SOFTWARE\Valve\Steam', 'InstallPath', steam);
  StringChangeEx(steam, '/', '\', True);
  if (Result = '') and (steam <> '') then begin
    TrySteamLibrary(Result, steam);
    if LoadStringFromFile(AddBackslash(steam) + 'steamapps\libraryfolders.vdf', vdf) then begin
      from := 1;
      repeat
        lib := VdfValue(String(vdf), 'path', from, atp);
        if lib <> '' then begin TrySteamLibrary(Result, lib); from := atp; end;
      until (lib = '') or (Result <> '');
    end;
  end;
  { BioWare's own entry (EA app, Origin, disc) }
  if RegQueryStringValue(HKLM32, 'SOFTWARE\BioWare\Dragon Age', 'Path', v) then TryAdd(Result, v);
  if RegQueryStringValue(HKLM32, 'SOFTWARE\BioWare\Dragon Age', 'Install Dir', v) then TryAdd(Result, v);
  { the usual folders on drives C - H }
  drives := 'CDEFGH';
  for i := 1 to Length(drives) do begin
    d := Copy(drives, i, 1);
    TryAdd(Result, d + ':\Program Files (x86)\GOG Galaxy\Games\Dragon Age Origins');
    TryAdd(Result, d + ':\GOG Games\Dragon Age Origins');
    TryAdd(Result, d + ':\GOG Games\Dragon Age Origins - Ultimate Edition');
    TryAdd(Result, d + ':\Program Files (x86)\Steam\steamapps\common\Dragon Age Ultimate Edition');
    TryAdd(Result, d + ':\SteamLibrary\steamapps\common\Dragon Age Ultimate Edition');
    TryAdd(Result, d + ':\Program Files (x86)\Origin Games\Dragon Age');
    TryAdd(Result, d + ':\Program Files\EA Games\Dragon Age');
  end;
end;

function DefaultGameDir(Param: String): String;
begin
  Result := FindGame();
  if Result = '' then Result := ExpandConstant('{pf32}\Dragon Age Origins');
end;

function GameDir(Param: String): String;
begin
  Result := RemoveBackslashUnlessRoot(WizardDirValue);
end;

{ ---------------- files ---------------- }
function FileHas(const F, Text: String): Boolean;
var s: AnsiString;
begin
  Result := LoadStringFromFile(F, s) and (Pos(AnsiString(Text), s) > 0);
end;

function IsOurDll(const F: String): Boolean;
begin
  Result := FileHas(F, 'loaded into DAOrigins.exe') and FileHas(F, 'DAOCoop');
end;

function Stamp(): String;
begin
  Result := GetDateTimeString('yyyymmdd-hhnnss', #0, #0);
end;

{ a file of that name anywhere below Dir, except in our own folder }
function FoundBelow(const Dir, Name, Skip: String; Depth: Integer): String;
var fr: TFindRec; sub: String;
begin
  Result := '';
  if (Depth > 6) or not DirExists(Dir) then Exit;
  if (CompareText(RemoveBackslash(Dir), RemoveBackslash(Skip)) <> 0) and FileExists(AddBackslash(Dir) + Name) then begin
    Result := AddBackslash(Dir) + Name; Exit;
  end;
  if FindFirst(AddBackslash(Dir) + '*', fr) then
    try
      repeat
        if ((fr.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0) and (fr.Name <> '.') and (fr.Name <> '..') then begin
          sub := FoundBelow(AddBackslash(Dir) + fr.Name, Name, Skip, Depth + 1);
          if sub <> '' then begin Result := sub; Exit; end;
        end;
      until not FindNext(fr);
    finally
      FindClose(fr);
    end;
end;

{ another mod replacing the same menu movie wins; ours is not installed (the game would load only one) }
function NoOtherGfx(Name: String): Boolean;
var ours, other: String;
begin
  ours := GameDir('') + '\packages\core\override\DAOCoop';
  other := FoundBelow(GameDir('') + '\packages\core\override', Name, ours, 0);
  if other = '' then other := FoundBelow(ExpandConstant('{userdocs}\BioWare\Dragon Age\packages\core\override'), Name, ours, 0);
  Result := other = '';
  if not Result then Log('Another mod already replaces ' + Name + ' (' + other + '); ours is not installed.');
end;

{ older DAOCoop game files left in other places (older versions, mod managers, Documents) - never the co-op faces (.mor) }
procedure CleanOld(const Dir, Ours: String; Depth: Integer);
var fr: TFindRec; ext, p: String;
begin
  if (Depth > 6) or not DirExists(Dir) then Exit;
  if FindFirst(AddBackslash(Dir) + '*', fr) then
    try
      repeat
        p := AddBackslash(Dir) + fr.Name;
        if (fr.Name = '.') or (fr.Name = '..') then Continue;
        if (fr.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0 then begin
          if CompareText(RemoveBackslash(p), RemoveBackslash(Ours)) <> 0 then CleanOld(p, Ours, Depth + 1);
        end else begin
          ext := Lowercase(ExtractFileExt(fr.Name));
          if (Pos('daocoop_', Lowercase(fr.Name)) = 1) and (ext <> '.mor') and
             ((ext = '.dds') or (ext = '.gfx') or (ext = '.gda') or (ext = '.xml') or (ext = '.erf')) then
            if DeleteFile(p) then Log('Removed an older DAOCoop file: ' + p);
        end;
      until not FindNext(fr);
    finally
      FindClose(fr);
    end;
end;

{ ---------------- the 4GB patch (large address aware) ---------------- }
function U16(const S: AnsiString; AtPos: Integer): Integer;   { AtPos: 0-based }
begin
  Result := Ord(S[AtPos + 1]) + Ord(S[AtPos + 2]) * 256;
end;
function U32(const S: AnsiString; AtPos: Integer): Integer;
begin
  Result := U16(S, AtPos) + U16(S, AtPos + 2) * 65536;
end;

{ the offset of the PE header's Characteristics (0-based), or -1 }
function LaaOffset(const S: AnsiString): Integer;
var pe: Integer;
begin
  Result := -1;
  if (Length(S) < $40) or (S[1] <> 'M') or (S[2] <> 'Z') then Exit;
  pe := U32(S, $3C);
  if (pe < 0) or (pe + 24 > Length(S)) then Exit;
  if (S[pe + 1] <> 'P') or (S[pe + 2] <> 'E') or (U16(S, pe + 4) <> $14C) then Exit;
  Result := pe + 22;
end;

{ Steam's copy protection wraps its DAOrigins.exe (a ".bind" section); it won't start once changed }
function HasSteamDrm(const S: AnsiString): Boolean;
var o, pe, count, first, i: Integer;
begin
  Result := False;
  o := LaaOffset(S); if o < 0 then Exit;
  pe := o - 22;
  count := U16(S, pe + 6);
  first := pe + 24 + U16(S, pe + 20);
  for i := 0 to count - 1 do
    if (first + 40 * i + 8 <= Length(S)) and (Copy(S, first + 40 * i + 1, 5) = '.bind') then begin Result := True; Exit; end;
end;

function CanPatchLaa(): Boolean;
var s: AnsiString; o: Integer;
begin
  Result := False;
  if not LoadStringFromFile(GameDir('') + '\' + ExeRel, s) then Exit;
  o := LaaOffset(s);
  Result := (o >= 0) and not HasSteamDrm(s) and ((Ord(s[o + 1]) and $20) = 0);
end;

procedure PatchLaa();
var exe, bak: String; s: AnsiString; o: Integer;
begin
  exe := GameDir('') + '\' + ExeRel;
  bak := GameDir('') + '\DAOCoop\backups\DAOrigins.before-4gb-patch.exe';
  if not LoadStringFromFile(exe, s) then Exit;
  o := LaaOffset(s);
  if (o < 0) or HasSteamDrm(s) or ((Ord(s[o + 1]) and $20) <> 0) then Exit;
  if not FileCopy(exe, bak, False) then begin MsgBox('The 4GB patch was skipped: the original could not be saved.', mbError, MB_OK); Exit; end;
  s[o + 1] := Chr(Ord(s[o + 1]) or $20);   { (the flag sits in a byte below 128) }
  if SaveStringToFile(exe, s, False) then begin LaaDone := True; Log('4GB patch applied to ' + exe); end;
end;

{ ---------------- settings: add the new ones, never change a value ---------------- }
function IniKeyOf(const L: String): String;
var t: String; e: Integer;
begin
  Result := ''; t := Trim(L);
  if (t = '') or (t[1] = ';') or (t[1] = '[') then Exit;
  e := Pos('=', t); if e <= 1 then Exit;
  Result := Lowercase(Trim(Copy(t, 1, e - 1)));
end;
function IniSectionOf(const L: String): String;
var t: String;
begin
  Result := ''; t := Trim(L);
  if (Length(t) > 2) and (t[1] = '[') and (t[Length(t)] = ']') then Result := Copy(t, 2, Length(t) - 2);
end;

procedure MergeIni(const Src, Dst: String);
var a, b, have, comments: TStringList; i, j, n, added: Integer; sec, k, s, t: String;
begin
  a := TStringList.Create; b := TStringList.Create; have := TStringList.Create; comments := TStringList.Create;
  try
    b.LoadFromFile(Dst); a.LoadFromFile(Src);
    sec := '';
    for i := 0 to b.Count - 1 do begin
      s := IniSectionOf(b[i]);
      if s <> '' then begin sec := Lowercase(s); have.Add('[' + sec + ']'); end
      else begin k := IniKeyOf(b[i]); if k <> '' then have.Add(sec + '|' + k); end;
    end;
    sec := ''; added := 0;
    for i := 0 to a.Count - 1 do begin
      s := IniSectionOf(a[i]);
      if s <> '' then begin sec := s; comments.Clear; Continue; end;
      t := Trim(a[i]);
      if (t <> '') and (Copy(t, 1, 1) = ';') then begin comments.Add(a[i]); Continue; end;
      k := IniKeyOf(a[i]);
      if k = '' then begin comments.Clear; Continue; end;
      if have.IndexOf(Lowercase(sec) + '|' + k) < 0 then begin
        { under the section's header in the player's file, or a new section at the end }
        n := -1;
        for j := 0 to b.Count - 1 do
          if CompareText(IniSectionOf(b[j]), sec) = 0 then begin n := j; Break; end;
        if n < 0 then begin
          b.Add(''); b.Add('[' + sec + ']'); n := b.Count - 1;
          have.Add('[' + Lowercase(sec) + ']');
        end;
        for j := comments.Count - 1 downto 0 do b.Insert(n + 1, comments[j]);
        b.Insert(n + 1 + comments.Count, a[i]);
        have.Add(Lowercase(sec) + '|' + k);
        Inc(added);
      end;
      comments.Clear;
    end;
    if added > 0 then begin b.SaveToFile(Dst); Log('Settings: ' + IntToStr(added) + ' new setting(s) added to ' + Dst); end;
  finally
    a.Free; b.Free; have.Free; comments.Free;
  end;
end;

{ ---------------- the wizard ---------------- }
function NextButtonClick(CurPageID: Integer): Boolean;
var code: Integer;
begin
  Result := True;
  if CurPageID = wpSelectDir then begin
    if not IsGame(WizardDirValue) then begin
      MsgBox('That folder has no bin_ship\DAOrigins.exe. Choose the Dragon Age: Origins game folder.', mbError, MB_OK);
      Result := False; Exit;
    end;
  end;
  if CurPageID = wpReady then
    if Exec(ExpandConstant('{sys}\cmd.exe'), '/c tasklist /FI "IMAGENAME eq DAOrigins.exe" | find /I "DAOrigins.exe" >nul', '', SW_HIDE, ewWaitUntilTerminated, code) and (code = 0) then begin
      MsgBox('Dragon Age: Origins is running. Close it first, then click Install.', mbError, MB_OK);
      Result := False;
    end;
end;

function VcRuntimeMissing(): Boolean;
begin
  Result := not FileExists(ExpandConstant('{syswow64}\msvcp140.dll')) or not FileExists(ExpandConstant('{syswow64}\vcruntime140.dll'));
end;

procedure CurStepChanged(CurStep: TSetupStep);
var bin, dll, chain, bak, cfg, rec, exe, md5, code: String; rc: Integer;
begin
  bin := GameDir('') + '\bin_ship';
  dll := bin + '\dinput8.dll';
  chain := bin + '\dinput8_chain.dll';
  bak := GameDir('') + '\DAOCoop\backups';
  if CurStep = ssInstall then begin
    ForceDirectories(bak);
    Chained := FileExists(chain);
    { another mod's dinput8.dll (for example the Native Controller Framework): kept as dinput8_chain.dll, DAOCoop
      passes every call on to it, so both mods load }
    if FileExists(dll) then begin
      if IsOurDll(dll) then FileCopy(dll, bak + '\dinput8.before-daocoop-' + Stamp() + '.dll', False)
      else begin
        FileCopy(dll, bak + '\dinput8.other-mod-' + Stamp() + '.dll', False);
        if FileExists(chain) then DeleteFile(chain);
        if RenameFile(dll, chain) then begin Chained := True; Log('The other mod''s dinput8.dll now loads as dinput8_chain.dll'); end;
      end;
    end;
    CleanOld(GameDir('') + '\packages\core\override', GameDir('') + '\packages\core\override\DAOCoop', 0);
    CleanOld(ExpandConstant('{userdocs}\BioWare\Dragon Age\packages\core\override'), GameDir('') + '\packages\core\override\DAOCoop', 0);
  end;
  if CurStep = ssPostInstall then begin
    cfg := GameDir('') + '\DAOCoop\DAOCoop.ini';
    if not FileExists(cfg) then FileCopy(ExpandConstant('{tmp}\DAOCoop.ini'), cfg, False)
    else MergeIni(ExpandConstant('{tmp}\DAOCoop.ini'), cfg);
    if WizardIsTaskSelected('laa') then PatchLaa();
    exe := GameDir('') + '\' + ExeRel;
    if WizardIsTaskSelected('firewall') then begin
      Exec(ExpandConstant('{sys}\netsh.exe'), 'advfirewall firewall delete rule name="DAOCoop online play" program="' + exe + '"', '', SW_HIDE, ewWaitUntilTerminated, rc);
      Exec(ExpandConstant('{sys}\netsh.exe'), 'advfirewall firewall add rule name="DAOCoop online play" dir=in action=allow program="' + exe + '" protocol=UDP enable=yes profile=any', '', SW_HIDE, ewWaitUntilTerminated, rc);
    end;
    { what was done (the uninstaller reads it) }
    md5 := '';
    if LaaDone then md5 := GetMD5OfFile(exe);
    rec := 'Installed=' + GetDateTimeString('yyyy-mm-dd hh:nn', '-', ':') + #13#10 +
           'Version={#MyVersion}' + #13#10 + 'DllName=dinput8.dll' + #13#10 + 'DllMd5=' + GetMD5OfFile(dll) + #13#10;
    if Chained then rec := rec + 'ChainedDll=1' + #13#10 else rec := rec + 'ChainedDll=' + #13#10;
    if LaaDone then rec := rec + 'LaaPatched=1' + #13#10 + 'ExePatchedMd5=' + md5 + #13#10;
    SaveStringToFile(GameDir('') + '\DAOCoop\install-record.txt', rec, False);
    if Chained and VcRuntimeMissing() then
      if MsgBox('The other mod (dinput8_chain.dll, for example the controller framework) needs Microsoft''s Visual C++ ' +
                'Redistributable (x86), which this PC does not have. Without it that mod does not load.' + #13#10#13#10 +
                'Open the download page now?', mbConfirmation, MB_YESNO) = IDYES then
        ShellExec('open', 'https://aka.ms/vs/17/release/vc_redist.x86.exe', '', '', SW_SHOWNORMAL, ewNoWait, rc);
  end;
end;

{ ---------------- uninstalling ---------------- }
function RecValue(const Rec, Key: String): String;
var i, e: Integer; s: String;
begin
  Result := '';
  i := Pos(#10 + Key + '=', #10 + Rec);
  if i = 0 then Exit;
  s := Copy(Rec, i + Length(Key) + 1, Length(Rec));
  e := Pos(#13, s); if e = 0 then e := Pos(#10, s); if e = 0 then e := Length(s) + 1;
  Result := Copy(s, 1, e - 1);
end;

var
  URec: AnsiString;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var game, bin, exe, bak: String; rc: Integer;
begin
  game := ExpandConstant('{app}');
  if CurUninstallStep = usUninstall then
    LoadStringFromFile(game + '\DAOCoop\install-record.txt', URec);
  if CurUninstallStep = usPostUninstall then begin
    bin := game + '\bin_ship';
    exe := game + '\' + ExeRel;
    { the other mod's dinput8.dll gets its name back }
    if FileExists(bin + '\dinput8_chain.dll') and not FileExists(bin + '\dinput8.dll') then
      RenameFile(bin + '\dinput8_chain.dll', bin + '\dinput8.dll');
    { the 4GB patch this installer made }
    bak := game + '\DAOCoop\backups\DAOrigins.before-4gb-patch.exe';
    if (RecValue(String(URec), 'LaaPatched') = '1') and FileExists(bak) and FileExists(exe) and
       (GetMD5OfFile(exe) = RecValue(String(URec), 'ExePatchedMd5')) then
      if MsgBox('Put back the original DAOrigins.exe (without the 4GB patch)? The patch helps the game even without the mod.',
                mbConfirmation, MB_YESNO) = IDYES then FileCopy(bak, exe, False);
    Exec(ExpandConstant('{sys}\netsh.exe'), 'advfirewall firewall delete rule name="DAOCoop online play" program="' + exe + '"', '', SW_HIDE, ewWaitUntilTerminated, rc);
    if DirExists(game + '\DAOCoop') then
      if MsgBox('The DAOCoop folder holds your co-op settings, logs, save backups and the co-op characters'' face backups. Delete it too?',
                mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then DelTree(game + '\DAOCoop', True, True, True);
  end;
end;
