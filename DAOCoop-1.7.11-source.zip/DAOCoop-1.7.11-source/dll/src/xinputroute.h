#pragma once
// Hands the controller UI (Native Controller Framework) to another player.
//
// The framework (bin_ship\dinput8_chain.dll) reads the Xbox UI controller with
// XInputGetState(0) from XINPUT9_1_0.dll. We patch that one import in the
// framework only, so while a route is set:
//   - XInputGetState(0) returns the routed player's pad (plus a few buttons of
//     Player 1's pad that are passed through, e.g. to cycle character tabs);
//   - XInputGetState(routed pad) reports "not connected".
// Our own pad reading (pads.cpp) uses its own import and is not affected.
#include <windows.h>

bool XInputRouteInstall();               // false = framework not found / not patched
void XInputRouteSet(int padIndex);       // -1 = normal (Player 1 on pad 0)
void XInputRouteSetPassThrough(WORD buttons);
void XInputRouteBlank(bool on);
void XInputRouteHold(bool on);       // 1.4.1: the game's menus see an idle controller (join pop-up answered with A)
void XInputRouteHoldMenu(bool on);
void XInputRouteHoldChat(bool on);   // 1.7.8: Player 1's controller is idle while the chat line is open (back once sent)
   // 1.7.2: the same while Player 1 uses the co-op menu
void XInputRoutePressA(unsigned delayMs);   // a short A press on the UI controller (after delayMs)
void XInputRouteP1None(bool on);        // Player 1 on keyboard + mouse: controller 0 belongs to a co-op player
bool XInputRouteP1NoneGet();         // online friend watching: the framework sees no controller
int  XInputRouteGet();
// 1.7.2: Player 1's menu button held 2 s = the co-op menu (a shorter press reaches the game when let go).
// 1.7.6: that button is View (Back) - START is the game's own again (held: the game menu).
void XInputRouteStartFilter(bool on);   // on while in the game world
bool XInputRouteTakeStartHold();       // true once per 2 s hold
bool XInputRouteActive();              // the framework's controller reading is patched
