#pragma once
// 1.7.1: Reed-Solomon erasure code for the video stream's recovery packets (written for DAOCoop).
// Systematic Cauchy code over GF(2^8): k data shards, m recovery shards; any k of the k+m rebuild all data.
// Recovery shard j = sum over i of C[j][i] * data[i], with C[j][i] = 1 / (x_j + y_i), x_j = k + j, y_i = i
// (all distinct elements, k + m <= 256, so every square submatrix of C can be inverted).
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>

namespace RsCode
{
    struct Gf
    {
        uint8_t exp[512];
        uint8_t log[256];
        uint8_t inv[256];
        uint8_t mul[256][256];
        Gf()
        {
            int x = 1;
            for (int i = 0; i < 255; ++i) {
                exp[i] = static_cast<uint8_t>(x);
                log[x] = static_cast<uint8_t>(i);
                x <<= 1;
                if (x & 0x100) x ^= 0x11D;
            }
            for (int i = 255; i < 512; ++i) exp[i] = exp[i - 255];
            log[0] = 0;
            inv[0] = 0;
            for (int a = 1; a < 256; ++a) inv[a] = exp[255 - log[a]];
            for (int a = 0; a < 256; ++a)
                for (int b = 0; b < 256; ++b)
                    mul[a][b] = (a && b) ? exp[log[a] + log[b]] : 0;
        }
    };
    inline const Gf& G() { static const Gf g; return g; }

    inline uint8_t Coef(int k, int j, int i) { return G().inv[static_cast<uint8_t>((k + j) ^ i)]; }

    // dst ^= c * src (n bytes)
    inline void MulAdd(uint8_t* dst, const uint8_t* src, uint8_t c, size_t n)
    {
        if (!c) return;
        if (c == 1) { for (size_t t = 0; t < n; ++t) dst[t] ^= src[t]; return; }
        const uint8_t* row = G().mul[c];
        for (size_t t = 0; t < n; ++t) dst[t] ^= row[src[t]];
    }

    // The m recovery shards of k data shards (each `size` bytes; shorter data counts as zero-padded).
    // data[i]/len[i]: shard i and its real length.
    inline void Encode(int k, int m, const uint8_t* const* data, const size_t* len, size_t size, std::vector<std::vector<uint8_t>>& out)
    {
        out.assign(static_cast<size_t>(m), std::vector<uint8_t>(size, 0));
        for (int j = 0; j < m; ++j)
            for (int i = 0; i < k; ++i)
                MulAdd(out[j].data(), data[i], Coef(k, j, i), len[i] < size ? len[i] : size);
    }

    // Rebuild the missing data shards. shards[i] (i < k): data shard i, `size` bytes (zero-padded), present[i] set
    // when it arrived. rec: the recovery shards that arrived, (j, bytes). False: too few to rebuild.
    inline bool Decode(int k, std::vector<std::vector<uint8_t>*>& shards, const std::vector<uint8_t>& present,
                       const std::vector<std::pair<int, const uint8_t*>>& rec, size_t size, std::vector<int>* rebuilt = nullptr)
    {
        std::vector<int> miss;
        for (int i = 0; i < k; ++i) if (!present[static_cast<size_t>(i)]) miss.push_back(i);
        const int e = static_cast<int>(miss.size());
        if (e == 0) return true;
        if (static_cast<int>(rec.size()) < e) return false;
        const Gf& g = G();
        // A (e x e) = C[j_r][miss_c]; rhs_r = rec_r + sum over present i of C[j_r][i] * d_i
        std::vector<uint8_t> a(static_cast<size_t>(e) * e);
        std::vector<std::vector<uint8_t>> rhs(static_cast<size_t>(e));
        for (int r = 0; r < e; ++r) {
            const int j = rec[static_cast<size_t>(r)].first;
            for (int c = 0; c < e; ++c) a[static_cast<size_t>(r) * e + c] = Coef(k, j, miss[static_cast<size_t>(c)]);
            rhs[static_cast<size_t>(r)].assign(rec[static_cast<size_t>(r)].second, rec[static_cast<size_t>(r)].second + size);
            for (int i = 0; i < k; ++i)
                if (present[static_cast<size_t>(i)]) MulAdd(rhs[static_cast<size_t>(r)].data(), shards[static_cast<size_t>(i)]->data(), Coef(k, j, i), size);
        }
        // invert A (Gauss-Jordan), applying the same row steps to rhs
        for (int col = 0; col < e; ++col) {
            int piv = col;
            while (piv < e && !a[static_cast<size_t>(piv) * e + col]) ++piv;
            if (piv == e) return false;
            if (piv != col) {
                for (int c = 0; c < e; ++c) std::swap(a[static_cast<size_t>(piv) * e + c], a[static_cast<size_t>(col) * e + c]);
                std::swap(rhs[static_cast<size_t>(piv)], rhs[static_cast<size_t>(col)]);
            }
            const uint8_t inv = g.inv[a[static_cast<size_t>(col) * e + col]];
            if (inv != 1) {
                for (int c = 0; c < e; ++c) a[static_cast<size_t>(col) * e + c] = g.mul[inv][a[static_cast<size_t>(col) * e + c]];
                uint8_t* row = rhs[static_cast<size_t>(col)].data();
                const uint8_t* mt = g.mul[inv];
                for (size_t t = 0; t < size; ++t) row[t] = mt[row[t]];
            }
            for (int r = 0; r < e; ++r) {
                if (r == col) continue;
                const uint8_t f = a[static_cast<size_t>(r) * e + col];
                if (!f) continue;
                for (int c = 0; c < e; ++c) a[static_cast<size_t>(r) * e + c] ^= g.mul[f][a[static_cast<size_t>(col) * e + c]];
                MulAdd(rhs[static_cast<size_t>(r)].data(), rhs[static_cast<size_t>(col)].data(), f, size);
            }
        }
        for (int c = 0; c < e; ++c) {
            std::vector<uint8_t>& dst = *shards[static_cast<size_t>(miss[static_cast<size_t>(c)])];
            dst.assign(rhs[static_cast<size_t>(c)].begin(), rhs[static_cast<size_t>(c)].end());
            if (rebuilt) rebuilt->push_back(miss[static_cast<size_t>(c)]);
        }
        return true;
    }
}
