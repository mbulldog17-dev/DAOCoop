#pragma once
// Online play, the picture: the host's frames -> H.264, and on the friend's side H.264 -> the whole
// screen. Media Foundation (built into Windows) does the codec work. DirectX 9 (DAOCoop).
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include "OnlineProtocol.h"

struct IDirect3DDevice9;
struct IDirect3DSurface9;

namespace OnlineVideo
{
    struct Settings
    {
        int height = 720;          // stream height; the width follows the game's aspect
        int fps = 60;
        int bitrateKbps = 8000;
        int gopSeconds = 4;        // a keyframe at least this often (and whenever a friend lost one)
        int profile = 66;          // H.264 profile: 66 baseline, 77 main, 100 high
        int qualityVsSpeed = 33;   // encoder effort 0..100 (lower: faster)
        bool hardware = true;      // the GPU's encoder when Windows has one for 32-bit programs
        int readbackWaitMs = 10;   // (not used with D3D9: the copy is read one frame later)
        std::wstring helperPath;   // 1.6.0: DAOCoopStream.exe (64-bit encoder process); empty = encode in the game
    };
    // One encoded frame (Annex B; SPS/PPS in front of every keyframe). Encoder thread.
    using FrameSink = std::function<void(const uint8_t* data, size_t size, bool key, uint16_t width, uint16_t height, uint32_t captureMs)>;

    // ---- Host ----
    bool StartHost(const Settings& settings, FrameSink sink);
    void StopHost();
    bool HostRunning();
    void RequestKeyframe();
    void SetBitrate(int kbps);
    std::string HostStatus();
    // 1.6.0, the helper process (DAOCoopStream.exe): a picture already in NV12 (w x h, Y then UV, no padding)
    void SubmitHostNv12(const uint8_t* nv12, int w, int h, int64_t us);
    void SubmitHostBgra(const uint8_t* bgra, int w, int h, int64_t us);   // (packed rows, w * 4 bytes)
    void CaptureD3D9(IDirect3DDevice9* dev);      // render thread, the game's Present (before the real one)
    void DeviceLost();                            // render thread, before the device's Reset

    // 1.7.0: each online friend their own player's picture (views.h, mode 3). Channel 0 is the stream above;
    // channel 1 a second one with its own DAOCoopStream.exe. The source gives the surface a channel streams
    // this frame (render thread, not AddRef'd), or null for the back buffer (Player 1's picture).
    using PictureSource = IDirect3DSurface9* (*)(int channel);
    void SetPictureSource(PictureSource src);
    // 1.7.1: render thread: is anyone watching channel c now? (false: its picture isn't taken or encoded)
    using ChannelWanted = bool (*)(int channel);
    void SetChannelWanted(ChannelWanted fn);
    void SetHardwareDecode(bool on);              // 1.7.1: friend: decode on the graphics card when it can
    void SetLowerResolution(bool on);             // 1.7.8: host: may a slow game make the stream smaller (else only 30 -> 24 fps)
    void AfterPresent();                          // 1.7.8: host: right after Present (the frame's copy picked up at once)
    void SetViewerFit(int fit);                   // 1.7.8: friend: 0 black bars, 1 stretch a near shape (default), 2 fill (crop)
    void SetPacingBuffer(int ms);                 // 1.7.5: friend: pictures shown on the host's clock + this margin (0 = as they come)
    bool StartExtra(int channel, const Settings& settings, FrameSink sink);   // needs DAOCoopStream.exe
    void StopExtra(int channel);
    bool ExtraRunning(int channel);
    void RequestKeyframe(int channel);
    void SetBitrate(int channel, int kbps);

    // ---- Friend ----
    bool StartViewer();
    void StopViewer();
    bool ViewerRunning();
    void SubmitFrame(OnlineProtocol::VideoFrame&& frame);   // network thread, frames in order
    bool DrawViewerD3D9(IDirect3DDevice9* dev);   // render thread: the newest picture over the whole back buffer
    void ViewerCursorBack(IDirect3DDevice9* dev); // 1.7.1: render thread: the mouse pointer back after watching
    struct ViewerStats
    {
        bool picture = false;
        uint32_t decoded = 0, shown = 0, failures = 0;
        double decodeMs = 0;            // average
        uint32_t captureMs = 0;         // host clock, of the picture shown last
        uint32_t shownAtMs = 0;         // our clock (OnlineClock), when it was put on screen
        uint16_t width = 0, height = 0;
        std::string decoder;
    };
    ViewerStats GetViewerStats();
    bool TakeKeyframeRequest();
    void Shutdown();
}
