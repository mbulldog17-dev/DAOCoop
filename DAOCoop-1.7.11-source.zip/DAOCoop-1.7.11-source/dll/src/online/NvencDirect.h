#pragma once
// 1.7.8: NVIDIA's video encoder driven directly (NVENC, like Moonlight/Sunshine), for DAOCoopStream.exe only.
// Windows' Media Foundation wrapper around it held each picture back until the next one came (about 50 ms from
// the picture being taken to its output at 30 fps); directly, with the ultra low latency tuning, a 1080p picture
// is encoded in a few ms. The picture goes in as it comes (BGRA, the colour conversion done by the graphics card).
// Any problem (no NVIDIA card, an old driver): Open fails and the stream uses the Media Foundation encoders as before.
#include <cstdint>
#include <functional>
#include <string>

class NvencDirect
{
public:
    // out(data, size, keyframe) is called from Encode, before it returns
    using Out = std::function<void(const uint8_t*, size_t, bool)>;
    ~NvencDirect() { Close(); }
    bool Open(int w, int h, int fps, int kbps, std::string& why);
    bool Encode(const uint8_t* bgra, int w, int h, int64_t us, bool forceKey, const Out& out, double* encodeMs);
    void SetBitrate(int kbps);
    void Close();
    bool IsOpen() const { return enc_ != nullptr; }
    int Width() const { return w_; }
    int Height() const { return h_; }
private:
    bool Configure(bool reconfigure);
    void* lib_ = nullptr;          // nvEncodeAPI64.dll
    void* fn_ = nullptr;           // NV_ENCODE_API_FUNCTION_LIST
    void* enc_ = nullptr;
    void* dev_ = nullptr;          // ID3D11Device
    void* ctx_ = nullptr;          // ID3D11DeviceContext
    void* tex_ = nullptr;          // ID3D11Texture2D (BGRA)
    void* reg_ = nullptr;          // registered resource
    void* bits_ = nullptr;         // bitstream buffer
    void* cfg_ = nullptr;          // NV_ENC_CONFIG
    void* init_ = nullptr;         // NV_ENC_INITIALIZE_PARAMS
    int w_ = 0, h_ = 0, fps_ = 30, kbps_ = 20000;
};
