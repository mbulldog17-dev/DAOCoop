#pragma once
// Online play, the sound: on the host the game's own sound is recorded (WASAPI process loopback:
// DAOrigins.exe only, Windows 10 2104+ / 11; else everything the PC plays), on the friend's side it is
// played while the friend's own game is muted.
#include <cstdint>
#include <functional>
#include <string>

namespace OnlineAudio
{
    constexpr int kRate = 48000;
    constexpr int kChunk = 480;   // 10 ms
    // Host: 10 ms stereo 48 kHz s16 chunks, on the capture thread.
    using ChunkSink = std::function<void(const int16_t* stereo, int frames)>;
    bool StartCapture(ChunkSink sink);
    void StopCapture();
    // Friend.
    bool StartPlayback(int bufferMs);
    void StopPlayback();
    void Push(uint32_t seq, const int16_t* stereo, int frames);   // network thread
    int BufferedMs();
    // The friend's game: put the game's sound back if an earlier online session muted it and never
    // ended (Windows keeps a program's mute). Once per run, from the main menu.
    void RepairMuteOnce();
    // 1.7.2: a sound session of this game that the friend-side muting leaves alone (voice chat).
    void KeepUnmuted(const std::wstring& sessionInstance, bool keep);
    std::string Status();
}
