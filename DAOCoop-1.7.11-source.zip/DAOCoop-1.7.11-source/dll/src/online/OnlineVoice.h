#pragma once
// 1.7.2 voice chat for online games: open mic, 16 kHz mono speech.
// Each PC records its own microphone (Windows' echo cancelling voice capture when it can, so the game's sound
// from the speakers is not sent back) and plays everyone else's voice. The host plays its friends' voices and
// passes each one on to the other friend. Only speech is sent: quiet moments send nothing.
// Mic on / off and the other settings: the co-op menu (hold START 2 s, Voice tab), or the [Voice] MicKey key
// (Pause by default). Everything is remembered in DAOCoop.ini ([Voice]).
#include <cstdint>
#include <functional>
#include <string>

struct IDirect3DDevice9;

namespace OnlineVoice
{
    // The capture thread: 20 ms of speech to send (seq counts what this PC sent; level 0-255).
    using Sink = std::function<void(uint32_t seq, uint8_t level, const int16_t* mono, int samples)>;

    void Start(Sink sink);                  // while online (with [Voice] Enabled=0 it records and plays nothing)
    void Stop();
    bool Running();

    // A voice from the network (network thread). speaker: 1 host, 2/3 Player 2/3, 4+ other.
    void Received(uint8_t speaker, uint32_t seq, uint8_t level, const int16_t* mono, int samples);
    void SetName(uint8_t speaker, const std::string& utf8);
    void ForgetSpeaker(uint8_t speaker);

    // The co-op menu's Voice tab (written to DAOCoop.ini and used at once).
    struct Prefs { bool enabled = true, micOn = true, echoCancel = true, showMicOff = true; int sensitivity = 50, volume = 100; };
    Prefs GetPrefs();
    void SetPrefs(const Prefs& p);
    std::string MicStatus();                // "" when not online

    // The small voice notice (who is talking, mic off). Drawn last in the frame: never in the stream.
    void Draw(IDirect3DDevice9* dev);

    std::string Status();
}
