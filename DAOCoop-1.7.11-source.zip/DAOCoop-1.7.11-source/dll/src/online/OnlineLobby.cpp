#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <winhttp.h>

#include "OnlineLobby.h"
#include "Logger.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>

#ifdef _MSC_VER
#pragma comment(lib, "winhttp.lib")
#endif

#ifndef WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY
#define WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY 4
#endif

namespace
{
    std::wstring Wide(const std::string& s)
    {
        std::wstring w;
        const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n); }
        return w;
    }

    std::string UrlDecode(const std::string& s)
    {
        std::string o;
        for (size_t i = 0; i < s.size(); ++i)
        {
            if (s[i] == '%' && i + 2 < s.size())
            {
                char hex[3] = { s[i + 1], s[i + 2], 0 };
                o += static_cast<char>(strtol(hex, nullptr, 16));
                i += 2;
            }
            else o += s[i] == '+' ? ' ' : s[i];
        }
        return o;
    }

    // "t=request&req=12&name=Wraith" -> value of key
    std::string Field(const std::string& msg, const char* key)
    {
        const size_t klen = strlen(key);
        size_t at = 0;
        while (at <= msg.size())
        {
            size_t end = msg.find('&', at);
            if (end == std::string::npos) end = msg.size();
            if (end - at > klen && msg.compare(at, klen, key) == 0 && msg[at + klen] == '=')
                return UrlDecode(msg.substr(at + klen + 1, end - at - klen - 1));
            at = end + 1;
        }
        return "";
    }

    HINTERNET OpenSession(DWORD receiveTimeoutMs)
    {
        HINTERNET s = WinHttpOpen(L"DAOCoop", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!s) s = WinHttpOpen(L"DAOCoop", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (s) WinHttpSetTimeouts(s, 8000, 8000, 8000, static_cast<int>(receiveTimeoutMs));
        return s;
    }

    struct Url { std::wstring host, path; INTERNET_PORT port = 443; bool secure = true; };
    bool Crack(const std::string& url, Url& out)
    {
        std::wstring w = Wide(url);
        URL_COMPONENTS c{};
        c.dwStructSize = sizeof(c);
        wchar_t host[256]{}, path[2048]{}, extra[2048]{};
        c.lpszHostName = host; c.dwHostNameLength = 255;
        c.lpszUrlPath = path; c.dwUrlPathLength = 2047;
        c.lpszExtraInfo = extra; c.dwExtraInfoLength = 2047;
        if (!WinHttpCrackUrl(w.c_str(), 0, 0, &c)) return false;
        out.host = host;
        out.path = std::wstring(path) + extra;
        out.port = c.nPort;
        out.secure = c.nScheme == INTERNET_SCHEME_HTTPS;
        return !out.host.empty();
    }

    std::string ReadBody(HINTERNET req, size_t cap)
    {
        std::string body;
        DWORD avail = 0;
        while (body.size() < cap && WinHttpQueryDataAvailable(req, &avail) && avail)
        {
            std::string chunk(avail, '\0');
            DWORD got = 0;
            if (!WinHttpReadData(req, &chunk[0], avail, &got) || !got) break;
            body.append(chunk.data(), got);
        }
        return body;
    }

    DWORD StatusOf(HINTERNET req)
    {
        DWORD status = 0, len = sizeof(status);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &len, WINHTTP_NO_HEADER_INDEX);
        return status;
    }

    std::string WinErr(const char* what)
    {
        char t[96];
        std::snprintf(t, sizeof(t), "%s failed (error %lu)", what, GetLastError());
        return t;
    }

    // GET url -> body. Returns the HTTP status (0: no answer; why says what failed).
    DWORD HttpGet(const std::string& url, std::string& body, std::string& why)
    {
        Url u;
        if (!Crack(url, u)) { why = "the lobby server address is not valid"; return 0; }
        HINTERNET s = OpenSession(10000);
        if (!s) { why = WinErr("WinHttpOpen"); return 0; }
        DWORD status = 0;
        HINTERNET c = WinHttpConnect(s, u.host.c_str(), u.port, 0);
        HINTERNET r = c ? WinHttpOpenRequest(c, L"GET", u.path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, u.secure ? WINHTTP_FLAG_SECURE : 0) : nullptr;
        if (r && WinHttpSendRequest(r, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(r, nullptr))
        {
            status = StatusOf(r);
            body = ReadBody(r, 256 * 1024);
        }
        else why = "no answer from the lobby server (" + WinErr("request") + ")";
        if (r) WinHttpCloseHandle(r);
        if (c) WinHttpCloseHandle(c);
        WinHttpCloseHandle(s);
        return status;
    }

    // A WebSocket connection. The receiving thread owns it; Close() from anywhere ends it.
    struct Ws
    {
        HINTERNET session = nullptr, connect = nullptr, ws = nullptr;
        std::mutex sendMutex;
        std::atomic<bool> closed{ false };

        // Returns "" when connected; else the reason (the server's text for a refusal).
        std::string Open(const std::string& url, DWORD* httpStatus)
        {
            Url u;
            if (!Crack(url, u)) return "the lobby server address is not valid";
            session = OpenSession(0);
            if (!session) return WinErr("WinHttpOpen");
            connect = WinHttpConnect(session, u.host.c_str(), u.port, 0);
            if (!connect) return WinErr("WinHttpConnect");
            HINTERNET r = WinHttpOpenRequest(connect, L"GET", u.path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, u.secure ? WINHTTP_FLAG_SECURE : 0);
            if (!r) return WinErr("WinHttpOpenRequest");
            std::string why;
            if (!WinHttpSetOption(r, WINHTTP_OPTION_UPGRADE_TO_WEB_SOCKET, nullptr, 0)) why = WinErr("WebSocket upgrade");
            else if (!WinHttpSendRequest(r, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) || !WinHttpReceiveResponse(r, nullptr))
                why = "no answer from the lobby server (" + WinErr("request") + ")";
            else
            {
                const DWORD st = StatusOf(r);
                if (httpStatus) *httpStatus = st;
                if (st != 101)
                {
                    why = ReadBody(r, 512);
                    if (why.empty() || why.size() > 200) { char t[64]; std::snprintf(t, sizeof(t), "the lobby server said %lu", st); why = t; }
                }
                else
                {
                    ws = WinHttpWebSocketCompleteUpgrade(r, 0);
                    if (!ws) why = WinErr("WebSocket");
                }
            }
            WinHttpCloseHandle(r);
            return why;
        }
        bool Send(const std::string& text)
        {
            std::lock_guard<std::mutex> lock(sendMutex);
            if (closed.load() || !ws) return false;
            return WinHttpWebSocketSend(ws, WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE, const_cast<char*>(text.data()), static_cast<DWORD>(text.size())) == NO_ERROR;
        }
        // Blocks until a whole text message arrives; false when the connection ended.
        bool Receive(std::string& out)
        {
            out.clear();
            char buf[2048];
            for (;;)
            {
                if (closed.load() || !ws) return false;
                DWORD got = 0;
                WINHTTP_WEB_SOCKET_BUFFER_TYPE type{};
                if (WinHttpWebSocketReceive(ws, buf, sizeof(buf), &got, &type) != NO_ERROR) return false;
                if (type == WINHTTP_WEB_SOCKET_CLOSE_BUFFER_TYPE) return false;
                out.append(buf, got);
                if (out.size() > 65536) return false;
                if (type == WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE || type == WINHTTP_WEB_SOCKET_BINARY_MESSAGE_BUFFER_TYPE) return true;
            }
        }
        void Close()
        {
            if (closed.exchange(true)) return;
            std::lock_guard<std::mutex> lock(sendMutex);
            // Shutdown sends the close frame without waiting; the receiving thread then sees the
            // server's close and ends (Close() never blocks the caller).
            if (ws) WinHttpWebSocketShutdown(ws, WINHTTP_WEB_SOCKET_SUCCESS_CLOSE_STATUS, nullptr, 0);
        }
        ~Ws()
        {
            if (ws) WinHttpCloseHandle(ws);
            if (connect) WinHttpCloseHandle(connect);
            if (session) WinHttpCloseHandle(session);
        }
    };

    // ---------------- host ----------------
    struct HostState
    {
        std::mutex m;
        std::shared_ptr<Ws> ws;
        std::string server, version, name, fields;   // fields: the latest update, re-sent after a reconnect
        int maxPlayers = 3, open = 2;
        std::deque<OnlineLobby::Request> requests;
        std::deque<std::string> cancels;
        OnlineLobby::HostStatus status = OnlineLobby::kHostOff;
        std::string why;
        uint32_t gen = 0;
    };
    HostState& H() { static HostState* s = new HostState(); return *s; }

    void HostThread(uint32_t gen)
    {
        int backoff = 2000;
        for (;;)
        {
            std::string url, fields;
            {
                std::lock_guard<std::mutex> lock(H().m);
                if (H().gen != gen) return;
                char q[64];
                std::snprintf(q, sizeof(q), "&max=%d&open=%d", H().maxPlayers, H().open);
                url = H().server + "/v1/host?v=" + OnlineLobby::UrlEncode(H().version) + "&name=" + OnlineLobby::UrlEncode(H().name) + q;
                H().status = OnlineLobby::kHostConnecting;
            }
            auto ws = std::make_shared<Ws>();
            DWORD st = 0;
            std::string why = ws->Open(url, &st);
            {
                std::lock_guard<std::mutex> lock(H().m);
                if (H().gen != gen) { ws->Close(); return; }
                if (!why.empty())
                {
                    H().status = OnlineLobby::kHostFailed;
                    H().why = why;
                }
                else { H().ws = ws; fields = H().fields; }
            }
            if (why.empty())
            {
                Logger::Write(Logger::Level::Info, "Online lobby: connected, game listed");
                if (!fields.empty()) ws->Send("t=update&" + fields);
                backoff = 2000;
                // keep-alive: an app-level ping every 45 s (answered by the server without waking it)
                std::thread([ws] {
                    while (!ws->closed.load())
                    {
                        for (int i = 0; i < 45 && !ws->closed.load(); ++i) Sleep(1000);
                        if (!ws->closed.load()) ws->Send("t=ping");
                    }
                }).detach();
                std::string msg;
                while (ws->Receive(msg))
                {
                    const std::string t = Field(msg, "t");
                    std::lock_guard<std::mutex> lock(H().m);
                    if (H().gen != gen) break;
                    if (t == "hello") { H().status = OnlineLobby::kHostListed; H().why.clear(); }
                    else if (t == "request" && H().requests.size() < 8)
                    {
                        OnlineLobby::Request r;
                        r.req = Field(msg, "req"); r.name = Field(msg, "name"); r.cid = Field(msg, "cid");
                        r.addr = Field(msg, "addr"); r.lan = Field(msg, "lan"); r.country = Field(msg, "country");
                        H().requests.push_back(r);
                    }
                    else if (t == "cancel") H().cancels.push_back(Field(msg, "req"));
                }
                ws->Close();
                std::lock_guard<std::mutex> lock(H().m);
                if (H().ws == ws) H().ws.reset();
                if (H().gen != gen) return;
                H().status = OnlineLobby::kHostConnecting;
                Logger::Write(Logger::Level::Warning, "Online lobby: connection ended - reconnecting");
            }
            else Logger::WriteFormat(Logger::Level::Warning, "Online lobby: could not list the game: %s", why.c_str());
            // wait before trying again (longer each time, up to a minute)
            for (int waited = 0; waited < backoff; waited += 250)
            {
                Sleep(250);
                std::lock_guard<std::mutex> lock(H().m);
                if (H().gen != gen) return;
            }
            backoff = std::min(backoff * 2, 60000);
            if (st == 429) backoff = 60000;
        }
    }

    // ---------------- browser ----------------
    struct BrowseState
    {
        std::mutex m;
        std::string server, version, status;
        std::vector<OnlineLobby::Game> games;
        bool have = false, refresh = false;
        uint32_t gen = 0;
    };
    BrowseState& B() { static BrowseState* s = new BrowseState(); return *s; }

    // A small reader for the list: [{"id":"AB12CD","name":"Valun","players":1,...},...]
    struct Json
    {
        const std::string& s; size_t i = 0;
        explicit Json(const std::string& t) : s(t) {}
        void Skip() { while (i < s.size() && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) ++i; }
        bool Eat(char c) { Skip(); if (i < s.size() && s[i] == c) { ++i; return true; } return false; }
        bool Str(std::string& out)
        {
            out.clear();
            if (!Eat('"')) return false;
            while (i < s.size() && s[i] != '"')
            {
                char c = s[i++];
                if (c == '\\' && i < s.size())
                {
                    char e = s[i++];
                    if (e == 'u' && i + 4 <= s.size())
                    {
                        unsigned cp = static_cast<unsigned>(strtoul(s.substr(i, 4).c_str(), nullptr, 16));
                        i += 4;
                        if (cp < 0x80) out += static_cast<char>(cp);
                        else if (cp < 0x800) { out += static_cast<char>(0xC0 | (cp >> 6)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
                        else { out += static_cast<char>(0xE0 | (cp >> 12)); out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
                    }
                    else out += e == 'n' ? '\n' : e == 't' ? '\t' : e;
                }
                else out += c;
            }
            return Eat('"');
        }
        bool Value(std::string& out)       // string or number (as text)
        {
            Skip();
            if (i < s.size() && s[i] == '"') return Str(out);
            size_t st = i;
            while (i < s.size() && (isalnum(static_cast<unsigned char>(s[i])) || s[i] == '-' || s[i] == '.')) ++i;
            out = s.substr(st, i - st);
            return i > st;
        }
    };
    bool ParseList(const std::string& body, std::vector<OnlineLobby::Game>& out)
    {
        out.clear();
        Json j(body);
        if (!j.Eat('[')) return false;
        if (j.Eat(']')) return true;
        do
        {
            if (!j.Eat('{')) return false;
            OnlineLobby::Game g;
            if (!j.Eat('}'))
            {
                do
                {
                    std::string k, v;
                    if (!j.Str(k) || !j.Eat(':') || !j.Value(v)) return false;
                    if (k == "id") g.id = v; else if (k == "name") g.name = v; else if (k == "area") g.area = v;
                    else if (k == "diff") g.diff = v; else if (k == "country") g.country = v;
                    else if (k == "players") g.players = atoi(v.c_str()); else if (k == "max") g.max = atoi(v.c_str());
                    else if (k == "open") g.open = atoi(v.c_str()); else if (k == "minutes") g.minutes = atoi(v.c_str());
                } while (j.Eat(','));
                if (!j.Eat('}')) return false;
            }
            if (!g.id.empty() && out.size() < 50) out.push_back(g);
        } while (j.Eat(','));
        return j.Eat(']');
    }

    void BrowseThread(uint32_t gen)
    {
        for (;;)
        {
            std::string url;
            {
                std::lock_guard<std::mutex> lock(B().m);
                if (B().gen != gen) return;
                url = B().server + "/v1/list?v=" + OnlineLobby::UrlEncode(B().version);
                B().refresh = false;
            }
            std::string body, why;
            const DWORD st = HttpGet(url, body, why);
            std::vector<OnlineLobby::Game> games;
            const bool ok = st == 200 && ParseList(body, games);
            {
                std::lock_guard<std::mutex> lock(B().m);
                if (B().gen != gen) return;
                if (ok) { B().games = games; B().status.clear(); B().have = true; }
                else
                {
                    char t[64];
                    std::snprintf(t, sizeof(t), "the lobby server said %lu", st);
                    B().status = st ? std::string(t) : why;
                    B().have = true;
                }
            }
            for (;;)   // 1.4.4: asked again only when the player presses Refresh
            {
                Sleep(100);
                std::lock_guard<std::mutex> lock(B().m);
                if (B().gen != gen) return;
                if (B().refresh) break;
            }
        }
    }

    // ---------------- one join request ----------------
    struct JoinState
    {
        std::mutex m;
        std::shared_ptr<Ws> ws;
        OnlineLobby::JoinStatus status = OnlineLobby::kJoinNone;
        std::string token, addr, lan, why;
        uint32_t gen = 0;
    };
    JoinState& J() { static JoinState* s = new JoinState(); return *s; }

    void JoinThread(uint32_t gen, std::string url)
    {
        auto ws = std::make_shared<Ws>();
        DWORD st = 0;
        std::string why = ws->Open(url, &st);
        {
            std::lock_guard<std::mutex> lock(J().m);
            if (J().gen != gen) { ws->Close(); return; }
            if (!why.empty()) { J().status = OnlineLobby::kJoinDeclined; J().why = why; return; }
            J().ws = ws;
        }
        std::string msg;
        bool answered = false;
        while (ws->Receive(msg))
        {
            const std::string t = Field(msg, "t");
            std::lock_guard<std::mutex> lock(J().m);
            if (J().gen != gen) break;
            if (t == "accepted")
            {
                J().status = OnlineLobby::kJoinAccepted;
                J().token = Field(msg, "token"); J().addr = Field(msg, "addr"); J().lan = Field(msg, "lan");
                answered = true;
                break;
            }
            if (t == "declined")
            {
                J().status = OnlineLobby::kJoinDeclined;
                J().why = Field(msg, "why");
                answered = true;
                break;
            }
        }
        ws->Close();
        std::lock_guard<std::mutex> lock(J().m);
        if (J().ws == ws) J().ws.reset();
        if (J().gen == gen && !answered && J().status == OnlineLobby::kJoinWaiting)
        {
            J().status = OnlineLobby::kJoinDeclined;
            J().why = "Lost the connection to the lobby server.";
        }
    }
}

namespace OnlineLobby
{
    std::string UrlEncode(const std::string& s)
    {
        std::string o;
        char t[4];
        for (unsigned char c : s)
        {
            if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += static_cast<char>(c);
            else { std::snprintf(t, sizeof(t), "%%%02X", c); o += t; }
        }
        return o;
    }

    void HostStart(const std::string& server, const std::string& version, const std::string& name, int maxPlayers, int open)
    {
        uint32_t gen;
        {
            std::lock_guard<std::mutex> lock(H().m);
            if (H().ws) H().ws->Close();
            H().ws.reset();
            H().server = server; H().version = version; H().name = name;
            H().maxPlayers = maxPlayers; H().open = open;
            H().fields.clear(); H().requests.clear(); H().cancels.clear();
            H().status = kHostConnecting; H().why.clear();
            gen = ++H().gen;
        }
        std::thread(HostThread, gen).detach();
    }

    void HostUpdate(const std::string& fields)
    {
        std::shared_ptr<Ws> ws;
        std::string all;
        {
            std::lock_guard<std::mutex> lock(H().m);
            // merge: later values replace earlier ones for the same key
            std::string merged;
            auto add = [&](const std::string& part) {
                const size_t eq = part.find('=');
                if (eq == std::string::npos) return;
                const std::string key = part.substr(0, eq + 1);
                std::string rest;
                size_t at = 0;
                while (at <= merged.size() && !merged.empty())
                {
                    size_t end = merged.find('&', at);
                    if (end == std::string::npos) end = merged.size();
                    const std::string p = merged.substr(at, end - at);
                    if (p.compare(0, key.size(), key) != 0) rest += (rest.empty() ? "" : "&") + p;
                    at = end + 1;
                }
                merged = rest + (rest.empty() ? "" : "&") + part;
            };
            merged = H().fields;
            size_t at = 0;
            while (at < fields.size())
            {
                size_t end = fields.find('&', at);
                if (end == std::string::npos) end = fields.size();
                add(fields.substr(at, end - at));
                at = end + 1;
            }
            H().fields = merged;
            if (Field(fields, "open").size()) H().open = atoi(Field(fields, "open").c_str());
            if (Field(fields, "max").size()) H().maxPlayers = atoi(Field(fields, "max").c_str());
            ws = H().ws;
        }
        if (ws) ws->Send("t=update&" + fields);
    }

    void HostAnswer(const std::string& req, bool ok, const std::string& token, const std::string& addr, const std::string& lan, const std::string& why)
    {
        std::shared_ptr<Ws> ws;
        {
            std::lock_guard<std::mutex> lock(H().m);
            ws = H().ws;
        }
        if (!ws) return;
        if (ok) ws->Send("t=answer&req=" + UrlEncode(req) + "&ok=1&token=" + UrlEncode(token) + "&addr=" + UrlEncode(addr) + "&lan=" + UrlEncode(lan));
        else ws->Send("t=answer&req=" + UrlEncode(req) + "&ok=0&why=" + UrlEncode(why));
    }

    bool HostTakeRequest(Request& out)
    {
        std::lock_guard<std::mutex> lock(H().m);
        if (H().requests.empty()) return false;
        out = H().requests.front();
        H().requests.pop_front();
        return true;
    }

    bool HostTakeCancel(std::string& req)
    {
        std::lock_guard<std::mutex> lock(H().m);
        if (H().cancels.empty()) return false;
        req = H().cancels.front();
        H().cancels.pop_front();
        return true;
    }

    HostStatus HostState(std::string* why)
    {
        std::lock_guard<std::mutex> lock(H().m);
        if (why) *why = H().why;
        return H().status;
    }

    void HostStop()
    {
        std::lock_guard<std::mutex> lock(H().m);
        ++H().gen;
        if (H().ws) H().ws->Close();
        H().ws.reset();
        H().status = kHostOff;
        H().requests.clear();
        H().cancels.clear();
    }

    void BrowseStart(const std::string& server, const std::string& version)
    {
        uint32_t gen;
        {
            std::lock_guard<std::mutex> lock(B().m);
            if (B().server == server && B().version == version && B().gen % 2 == 1) return;   // already running
            B().server = server; B().version = version;
            B().games.clear(); B().have = false; B().status.clear();
            B().gen += B().gen % 2 == 1 ? 2 : 1;          // odd = running
            gen = B().gen;
        }
        std::thread(BrowseThread, gen).detach();
    }

    void BrowseStop()
    {
        std::lock_guard<std::mutex> lock(B().m);
        if (B().gen % 2 == 1) ++B().gen;
        B().games.clear(); B().have = false;
    }

    bool BrowseList(std::vector<Game>& out, std::string& status)
    {
        std::lock_guard<std::mutex> lock(B().m);
        out = B().games;
        status = B().status;
        return B().have;
    }

    void BrowseRefreshNow()
    {
        std::lock_guard<std::mutex> lock(B().m);
        B().refresh = true;
    }

    void JoinAsk(const std::string& server, const std::string& version, const std::string& hostId, const std::string& name,
                 const std::string& cid, const std::string& addr, const std::string& lan)
    {
        uint32_t gen;
        {
            std::lock_guard<std::mutex> lock(J().m);
            if (J().ws) J().ws->Close();
            J().ws.reset();
            J().status = kJoinWaiting;
            J().token.clear(); J().addr.clear(); J().lan.clear(); J().why.clear();
            gen = ++J().gen;
        }
        const std::string url = server + "/v1/join?v=" + UrlEncode(version) + "&host=" + UrlEncode(hostId) + "&name=" + UrlEncode(name) +
            "&cid=" + UrlEncode(cid) + "&addr=" + UrlEncode(addr) + "&lan=" + UrlEncode(lan);
        std::thread(JoinThread, gen, url).detach();
    }

    JoinStatus JoinState(std::string& token, std::string& addr, std::string& lan, std::string& why)
    {
        std::lock_guard<std::mutex> lock(J().m);
        token = J().token; addr = J().addr; lan = J().lan; why = J().why;
        return J().status;
    }

    void JoinCancel()
    {
        std::lock_guard<std::mutex> lock(J().m);
        ++J().gen;
        if (J().ws) J().ws->Close();
        J().ws.reset();
        J().status = kJoinNone;
    }
}
