#pragma once
// 1.6.0: the game (32-bit) <-> DAOCoopStream.exe (64-bit) - the stream's encoder in its own process.
//
// Why: hardware video encoders are being dropped for 32-bit programs (NVIDIA's already refuses them on
// newer cards, and in testing its 32-bit encoder froze a whole PC), and inside the game the encoder takes
// processor time from Dragon Age itself. The helper encodes and hands the H.264 back, and the game
// sends it on exactly as before.
//
// The game only copies the picture it already reads back (BGRA) into shared memory; the helper turns it
// into NV12 and encodes it, on processor cores the game doesn't use. So the game itself does no more work
// for the stream than reading the picture back.
// One shared memory block (name given to the helper on its command line):
//   Header | in[kInSlots] BGRA pictures (w * 4 bytes a row) | out[kOutSlots] encoded frames
// and two auto-reset events: <name>_in (a picture is waiting), <name>_out (an encoded frame is waiting).
// Slot states: 0 free, 1 written (waiting for the other side), 2 being read.
#include <cstdint>

namespace StreamShared
{
    constexpr uint32_t kMagic = 0x31534344;     // "DCS1"
    constexpr uint32_t kVersion = 2;
    constexpr int kInSlots = 2;
    constexpr int kOutSlots = 6;
    constexpr uint32_t kOutSlotBytes = 1536u * 1024u;

    struct InSlot
    {
        volatile long state;
        int32_t w, h;
        uint32_t seq;
        int64_t us;                 // when the picture was taken (OnlineClock, the same in both processes)
    };
    struct OutSlot
    {
        volatile long state;
        uint32_t size;
        int32_t key, w, h;
        uint32_t captureMs;
        uint32_t seq;
    };

    struct Header
    {
        uint32_t magic, version;
        uint32_t inSlotBytes;       // bytes per BGRA picture slot
        uint32_t totalBytes;
        // the game -> helper
        int32_t height, fps, bitrateKbps, gopSeconds, profile, effort, hardware;
        volatile long quit;
        volatile long newBitrate;   // 0 = no change
        volatile long forceKey;
        // helper -> the game
        volatile long state;        // 0 starting, 1 running, 2 failed
        volatile long heartbeat;    // GetTickCount, about every 100 ms
        volatile long encoded;
        char status[192];           // HostStatus() of the helper's encoder
        InSlot in[kInSlots];
        OutSlot out[kOutSlots];
    };

    inline uint32_t InSlotBytesFor(int height)
    {
        const uint32_t h = static_cast<uint32_t>(height < 240 ? 240 : height);
        const uint32_t w = (h * 64u / 27u + 15u) & ~15u;     // up to 21:9 screens (wider ones: the in-game encoder)
        return w * h * 4u;
    }
    inline uint32_t TotalBytes(uint32_t inSlotBytes)
    {
        return static_cast<uint32_t>((sizeof(Header) + 4095u) & ~4095u) + inSlotBytes * kInSlots + kOutSlotBytes * kOutSlots;
    }
    inline uint8_t* InData(Header* h, int i)
    {
        return reinterpret_cast<uint8_t*>(h) + ((sizeof(Header) + 4095u) & ~4095u) + static_cast<size_t>(h->inSlotBytes) * i;
    }
    inline uint8_t* OutData(Header* h, int i)
    {
        return InData(h, kInSlots) + static_cast<size_t>(kOutSlotBytes) * i;
    }
}
