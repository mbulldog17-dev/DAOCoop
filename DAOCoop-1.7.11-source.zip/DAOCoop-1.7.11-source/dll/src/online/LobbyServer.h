#pragma once
// The public game list's server, built into the mod so every player uses the same one.
// Put the address of your deployed lobby server here (see lobby-server/README.md), then build:
//   #define DAOCOOP_LOBBY_SERVER "https://daocoop-lobby.daocoop-official.workers.dev"
// Empty = no public list (invite codes and games on the same network still work).
// A player can still use another server, or none, with [Online] LobbyServer in DAOCoop.ini.
#define DAOCOOP_LOBBY_SERVER "https://daocoop-lobby.daocoop-official.workers.dev"
