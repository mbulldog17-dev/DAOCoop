#include "OnlineVideo.h"
#ifdef DAOCOOP_STREAM_HELPER
#include "NvencDirect.h"
#endif
#include "StreamShared.h"
#include "../d3d9hook.h"
// Online play, the picture (DAOCoop, DirectX 9). From the Amalur co-op mod's OnlineVideo.cpp: the
// Media Foundation H.264 encoder / decoder are the same; the GPU side is new (Amalur drew with D3D11):
//   host:   back buffer -> StretchRect to a stream-size render target -> GetRenderTargetData (one
//           frame later, so the GPU is done) -> BGRA -> NV12 on the encoder thread -> H.264;
//   friend: H.264 -> NV12 -> BGRA on the decoder thread -> system-memory surface -> UpdateSurface ->
//           StretchRect over the whole back buffer (black bars keep the shape).
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <objbase.h>
#include <oleauto.h>
#include <d3d9.h>
#include <d3d11.h>
#include <d3d10.h>
#include <mfapi.h>
#include <mferror.h>
#include <mfidl.h>
#include <mftransform.h>
#include <strmif.h>
#include <codecapi.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "Logger.h"
#include "OnlineClock.h"
#include "Paths.h"

#ifdef _MSC_VER
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "d3d11.lib")
#endif

#ifdef __MINGW32__
__CRT_UUID_DECL(ICodecAPI, 0x901db4c7, 0x31ce, 0x41a2, 0x85, 0xdc, 0x8f, 0xa0, 0xbf, 0x41, 0xb8, 0xda)   // (test builds; MSVC has it)
#endif

using Microsoft::WRL::ComPtr;

namespace
{
    bool MediaFoundationThere()
    {
        static const bool there = [] {
            const bool ok = LoadLibraryExW(L"mfplat.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32) != nullptr;
            if (!ok) Logger::Write(Logger::Level::Error, "Online: Windows' Media Foundation (mfplat.dll) is missing - on Windows N editions install the Media Feature Pack; no picture until then");
            return ok;
        }();
        return there;
    }

    int64_t QpcNow() { LARGE_INTEGER t; QueryPerformanceCounter(&t); return t.QuadPart; }
    int64_t QpcFreq() { static const int64_t f = [] { LARGE_INTEGER q; QueryPerformanceFrequency(&q); return q.QuadPart; }(); return f; }
    double QpcMs(int64_t from, int64_t to) { return static_cast<double>(to - from) * 1000.0 / static_cast<double>(QpcFreq()); }

    // ======================================================================================
    // Host: frames -> encoder thread
    // ======================================================================================
    struct RawFrame { std::vector<uint8_t> nv12, bgra; int w = 0, h = 0; int64_t us = 0; bool nv12Ready = false; };

    std::mutex g_hostMutex;              // start / stop
    std::atomic<bool> g_hostOn{ false };
    OnlineVideo::Settings g_settings;
    OnlineVideo::FrameSink g_sink;
    std::thread& g_encThread = *new std::thread();
    std::atomic<bool> g_encRun{ false };
    std::atomic<bool> g_forceKey{ false };
    std::atomic<bool> g_refresh{ false };        // 1.7.1: the encoder took gradual intra refresh
    std::atomic<bool> g_keyAfterOpen{ false };   // 1.7.1: the encoder was just (re)opened: its first keyframe always
    std::atomic<int> g_newBitrate{ 0 };

    // the smoothness governor's state (CaptureD3D9 / GovernorFrame below)
    struct Governor
    {
        int level = 0;                    // 0 = as set; each step lighter
        int64_t windowFrom = 0;
        int frames = 0;
        int64_t goodSince = 0, lastChange = 0;
    };
    Governor& g_gov = *new Governor();
    std::atomic<bool> g_remoteOn{ false };   // 1.6.0: the helper process encodes (RemotePush below)
    bool RemotePushMain(const uint8_t* bits, int pitch, int w, int h, int64_t us);
    std::mutex g_frameMutex;
    std::condition_variable g_frameCv;
    RawFrame g_pending;
    bool g_hasPending = false;
    std::atomic<uint32_t> g_captured{ 0 }, g_replaced{ 0 }, g_skippedBusy{ 0 }, g_encoded{ 0 };

    std::mutex g_statusMutex;
    std::string g_encName = "starting";
    double g_encMs = 0, g_readbackWaitMs = 0;
    double g_encOnlyMs = 0;                  // 1.7.8: of that, inside the GPU encoder itself (in -> out)
    struct InAt { int64_t time = -1; int64_t us = 0; };
    InAt g_inAt[8];                          // (the encoder thread) when each picture went into the encoder
    int g_streamW = 0, g_streamH = 0;
    int g_bitrateNow = 0;

    // D3D9: the readback (BGRA rows, any pitch) -> the encoder thread, which makes NV12 itself.
    void PushFrame(const uint8_t* bits, int pitch, int w, int h, int64_t us)
    {
        if (g_remoteOn.load(std::memory_order_relaxed) && RemotePushMain(bits, pitch, w, h, us)) { g_captured.fetch_add(1, std::memory_order_relaxed); return; }
        {
            std::lock_guard<std::mutex> lock(g_frameMutex);
            if (g_hasPending) g_replaced.fetch_add(1, std::memory_order_relaxed);
            g_pending.bgra.resize(static_cast<size_t>(w) * h * 4);
            for (int y = 0; y < h; ++y) std::memcpy(g_pending.bgra.data() + static_cast<size_t>(y) * w * 4, bits + static_cast<size_t>(y) * pitch, static_cast<size_t>(w) * 4);
            g_pending.w = w;
            g_pending.h = h;
            g_pending.us = us;
            g_hasPending = true;
        }
        g_frameCv.notify_one();
        g_captured.fetch_add(1, std::memory_order_relaxed);
    }

    // BT.601 limited range, the decoders' default for H.264 without colour info.
    // 1.7.8: the colour conversions run on several cores at once (a 1080p picture took 6-12 ms on one core, on
    // both the host's and the friend's side). rows [r0, r1), r0 even.
    template <typename F> void ParallelRows(int h, F rows)
    {
        static const int n = [] { const unsigned c = std::thread::hardware_concurrency(); return c >= 8 ? 4 : c >= 4 ? 3 : 1; }();
        if (n <= 1 || h < 64) { rows(0, h); return; }
        std::thread t[3];
        const int per = ((h / n) + 1) & ~1;
        for (int i = 1; i < n; ++i) { const int a = per * i, b = i + 1 == n ? h : per * (i + 1); if (a < h) t[i - 1] = std::thread([=] { rows(a, b < h ? b : h); }); }
        rows(0, per < h ? per : h);
        for (int i = 0; i < n - 1; ++i) if (t[i].joinable()) t[i].join();
    }
    void BgraToNv12Rows(const uint8_t* bgra, int w, int h, uint8_t* Y, uint8_t* UV, int rStart, int rEnd);
    void BgraToNv12(const uint8_t* bgra, int w, int h, std::vector<uint8_t>& out)
    {
        out.resize(static_cast<size_t>(w) * h * 3 / 2);
        uint8_t* Y = out.data();
        uint8_t* UV = out.data() + static_cast<size_t>(w) * h;
        ParallelRows(h, [&](int a, int b) { BgraToNv12Rows(bgra, w, h, Y, UV, a, b); });
    }
    void BgraToNv12Rows(const uint8_t* bgra, int w, int h, uint8_t* Y, uint8_t* UV, int rStart, int rEnd)
    {
        (void)h;
        for (int y = rStart; y + 1 < rEnd + 1 && y + 1 < h + 1 && y < rEnd; y += 2)
        {
            const uint8_t* r0 = bgra + static_cast<size_t>(y) * w * 4;
            const uint8_t* r1 = r0 + static_cast<size_t>(w) * 4;
            uint8_t* y0 = Y + static_cast<size_t>(y) * w;
            uint8_t* y1 = y0 + w;
            uint8_t* uv = UV + static_cast<size_t>(y / 2) * w;
            for (int x = 0; x < w; x += 2)
            {
                int rs = 0, gs = 0, bs = 0;
                const uint8_t* p[4] = { r0 + x * 4, r0 + x * 4 + 4, r1 + x * 4, r1 + x * 4 + 4 };
                uint8_t* yo[4] = { y0 + x, y0 + x + 1, y1 + x, y1 + x + 1 };
                for (int k = 0; k < 4; ++k)
                {
                    const int b = p[k][0], g = p[k][1], r = p[k][2];
                    *yo[k] = static_cast<uint8_t>(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
                    rs += r; gs += g; bs += b;
                }
                rs >>= 2; gs >>= 2; bs >>= 2;
                uv[x] = static_cast<uint8_t>(((-38 * rs - 74 * gs + 112 * bs + 128) >> 8) + 128);
                uv[x + 1] = static_cast<uint8_t>(((112 * rs - 94 * gs - 18 * bs + 128) >> 8) + 128);
            }
        }
    }

    inline uint8_t Clamp255(int v) { return static_cast<uint8_t>(v < 0 ? 0 : v > 255 ? 255 : v); }
    // NV12 rows (any pitch) -> BGRX.
    void Nv12ToBgraRows(const uint8_t* y, const uint8_t* uv, int pitch, int w, uint8_t* out, int rStart, int rEnd);
    void Nv12ToBgra(const uint8_t* y, const uint8_t* uv, int pitch, int w, int h, uint8_t* out)
    {
        ParallelRows(h, [&](int a, int b) { Nv12ToBgraRows(y, uv, pitch, w, out, a, b); });
    }
    void Nv12ToBgraRows(const uint8_t* y, const uint8_t* uv, int pitch, int w, uint8_t* out, int rStart, int rEnd)
    {
        for (int r = rStart; r < rEnd; ++r)
        {
            const uint8_t* yr = y + static_cast<size_t>(r) * pitch;
            const uint8_t* cr = uv + static_cast<size_t>(r / 2) * pitch;
            uint8_t* o = out + static_cast<size_t>(r) * w * 4;
            for (int x = 0; x < w; ++x)
            {
                const int c = 298 * (yr[x] - 16), d = cr[x & ~1] - 128, e = cr[(x & ~1) + 1] - 128;
                o[x * 4 + 0] = Clamp255((c + 516 * d + 128) >> 8);
                o[x * 4 + 1] = Clamp255((c - 100 * d - 208 * e + 128) >> 8);
                o[x * 4 + 2] = Clamp255((c + 409 * e + 128) >> 8);
                o[x * 4 + 3] = 255;
            }
        }
    }


    // ======================================================================================
    // Media Foundation helpers
    // (MF_LOW_LATENCY is the same GUID as CODECAPI_AVLowLatencyMode, which needs no library; it is
    // used as the attribute key below)
    // ======================================================================================
    void SetUi4(ICodecAPI* api, const GUID& key, UINT32 v)
    {
        if (!api) return;
        VARIANT var;
        VariantInit(&var);
        var.vt = VT_UI4;
        var.ulVal = v;
        api->SetValue(&key, &var);
    }
    void SetBool(ICodecAPI* api, const GUID& key, bool v)
    {
        if (!api) return;
        VARIANT var;
        VariantInit(&var);
        var.vt = VT_BOOL;
        var.boolVal = v ? VARIANT_TRUE : VARIANT_FALSE;
        api->SetValue(&key, &var);
    }
    std::string FriendlyName(IMFActivate* act)
    {
        WCHAR* name = nullptr;
        UINT32 len = 0;
        std::string out = "?";
        if (SUCCEEDED(act->GetAllocatedString(MFT_FRIENDLY_NAME_Attribute, &name, &len)) && name)
        {
            const int n = WideCharToMultiByte(CP_UTF8, 0, name, -1, nullptr, 0, nullptr, nullptr);
            if (n > 1) { out.assign(static_cast<size_t>(n - 1), '\0'); WideCharToMultiByte(CP_UTF8, 0, name, -1, &out[0], n, nullptr, nullptr); }
            CoTaskMemFree(name);
        }
        return out;
    }

    // NAL units of an Annex B stream: does it carry SPS / an IDR slice, and where the first slice starts.
    void ScanNals(const uint8_t* d, size_t n, bool& sps, bool& idr, size_t& firstSlice)
    {
        sps = idr = false;
        firstSlice = n;
        for (size_t i = 0; i + 3 < n; ++i)
        {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1)
            {
                const size_t start = (i > 0 && d[i - 1] == 0) ? i - 1 : i;
                const int type = d[i + 3] & 0x1F;
                if (type == 7) sps = true;
                if (type == 5) idr = true;
                if ((type == 1 || type == 5) && firstSlice == n) firstSlice = start;
                i += 2;
            }
        }
    }

    // ---- The H.264 encoder (encoder thread) ----
    struct Encoder
    {
        ComPtr<IMFTransform> mft;
        ComPtr<ICodecAPI> api;
        ComPtr<IMFMediaEventGenerator> events;
        bool async = false, providesSamples = false, hardware = false;
        DWORD inId = 0, outId = 0, outSize = 0;
        int w = 0, h = 0, needInput = 0;
        std::string name;
        std::vector<uint8_t> header;   // SPS + PPS, put in front of keyframes that lack them
        std::vector<uint8_t> scratch;
        int64_t pendingUs = 0;

        void Close()
        {
            if (mft)
            {
                mft->ProcessMessage(MFT_MESSAGE_NOTIFY_END_OF_STREAM, 0);
                mft->ProcessMessage(MFT_MESSAGE_NOTIFY_END_STREAMING, 0);
                if (async)
                {
                    ComPtr<IMFShutdown> sd;
                    if (SUCCEEDED(mft.As(&sd))) sd->Shutdown();
                }
            }
            events.Reset(); api.Reset(); mft.Reset();
            needInput = 0;
            header.clear();
        }

        void SetProps(const OnlineVideo::Settings& s, int kbps)
        {
            SetBool(api.Get(), CODECAPI_AVLowLatencyMode, true);
            SetUi4(api.Get(), CODECAPI_AVEncCommonRateControlMode, eAVEncCommonRateControlMode_CBR);
            SetUi4(api.Get(), CODECAPI_AVEncCommonMeanBitRate, static_cast<UINT32>(kbps) * 1000u);
            // decoder buffer of about two frames: frame sizes stay even, so nothing waits in a queue
            SetUi4(api.Get(), CODECAPI_AVEncCommonBufferSize, static_cast<UINT32>(kbps) * 1000u / static_cast<UINT32>(std::max(1, s.fps)) * 2u);
            SetUi4(api.Get(), CODECAPI_AVEncMPVGOPSize, static_cast<UINT32>(std::max(1, s.gopSeconds) * std::max(1, s.fps)));
            SetUi4(api.Get(), CODECAPI_AVEncMPVDefaultBPictureCount, 0);
            SetUi4(api.Get(), CODECAPI_AVEncCommonQualityVsSpeed, static_cast<UINT32>(std::clamp(s.qualityVsSpeed, 0, 100)));
            SetUi4(api.Get(), CODECAPI_AVEncNumWorkerThreads, 2u);   // 1.5.5: the CPU encoder leaves cores for the game
            // 1.7.1: gradual intra refresh (as game streamers use): the picture is renewed strip by strip over half a
            // second, again and again, so a frame lost on the way heals by itself - no full keyframe (a burst of
            // packets that is often lost on Wi-Fi itself) needed. Only when the encoder takes it.
            g_refresh.store(false);
#ifdef CODECAPI_AVEncVideoGradualIntraRefresh
            if (api && api->IsSupported(&CODECAPI_AVEncVideoGradualIntraRefresh) == S_OK)
            {
                VARIANT var;
                VariantInit(&var);
                var.vt = VT_UI4;
                var.ulVal = static_cast<UINT32>(std::max(2, s.fps / 2));
                g_refresh.store(SUCCEEDED(api->SetValue(&CODECAPI_AVEncVideoGradualIntraRefresh, &var)));
            }
#endif
            static int said = 0;
            if (said++ < 4) Logger::WriteFormat(Logger::Level::Info, "Online: gradual intra refresh %s", g_refresh.load() ? "on (lost frames heal within half a second, fewer keyframes)" : "not offered by this encoder");
        }

        bool Configure(IMFTransform* t, bool hw, int width, int height, const OnlineVideo::Settings& s)
        {
            mft = t;
            hardware = hw;
            ComPtr<IMFAttributes> attrs;
            UINT32 isAsync = 0;
            if (SUCCEEDED(t->GetAttributes(&attrs)) && attrs)
            {
                attrs->GetUINT32(MF_TRANSFORM_ASYNC, &isAsync);
                if (isAsync) attrs->SetUINT32(MF_TRANSFORM_ASYNC_UNLOCK, TRUE);
                attrs->SetUINT32(CODECAPI_AVLowLatencyMode, TRUE);
            }
            async = isAsync != 0;
            t->QueryInterface(IID_PPV_ARGS(&api));
            const int kbps = g_bitrateNow > 0 ? g_bitrateNow : s.bitrateKbps;
            SetProps(s, kbps);
            DWORD inCount = 0, outCount = 0;
            inId = outId = 0;
            if (SUCCEEDED(t->GetStreamCount(&inCount, &outCount)) && inCount == 1 && outCount == 1)
            {
                DWORD i = 0, o = 0;
                if (SUCCEEDED(t->GetStreamIDs(1, &i, 1, &o))) { inId = i; outId = o; }
            }
            ComPtr<IMFMediaType> out;
            MFCreateMediaType(&out);
            out->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
            out->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
            out->SetUINT32(MF_MT_AVG_BITRATE, static_cast<UINT32>(kbps) * 1000u);
            MFSetAttributeSize(out.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
            MFSetAttributeRatio(out.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
            MFSetAttributeRatio(out.Get(), MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
            out->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
            out->SetUINT32(MF_MT_MPEG2_PROFILE, static_cast<UINT32>(s.profile));
            HRESULT hr = t->SetOutputType(outId, out.Get(), 0);
            if (FAILED(hr)) { Logger::WriteFormat(Logger::Level::Warning, "Online: %s refused the H.264 settings (0x%08lX)", name.c_str(), static_cast<unsigned long>(hr)); return false; }
            ComPtr<IMFMediaType> in;
            MFCreateMediaType(&in);
            in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
            in->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
            MFSetAttributeSize(in.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
            MFSetAttributeRatio(in.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
            MFSetAttributeRatio(in.Get(), MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
            in->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
            hr = t->SetInputType(inId, in.Get(), 0);
            if (FAILED(hr))
            {
                // its own NV12 type, with our size
                bool set = false;
                for (DWORD i = 0; !set; ++i)
                {
                    ComPtr<IMFMediaType> av;
                    if (FAILED(t->GetInputAvailableType(inId, i, &av))) break;
                    GUID sub{};
                    av->GetGUID(MF_MT_SUBTYPE, &sub);
                    if (sub != MFVideoFormat_NV12) continue;
                    MFSetAttributeSize(av.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(width), static_cast<UINT32>(height));
                    MFSetAttributeRatio(av.Get(), MF_MT_FRAME_RATE, static_cast<UINT32>(s.fps), 1);
                    set = SUCCEEDED(t->SetInputType(inId, av.Get(), 0));
                }
                if (!set) { Logger::WriteFormat(Logger::Level::Warning, "Online: %s takes no NV12 %dx%d (0x%08lX)", name.c_str(), width, height, static_cast<unsigned long>(hr)); return false; }
            }
            SetProps(s, kbps);
            MFT_OUTPUT_STREAM_INFO info{};
            t->GetOutputStreamInfo(outId, &info);
            providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
            outSize = std::max<DWORD>(info.cbSize, static_cast<DWORD>(width * height * 3 / 2 + 4096));
            if (async && FAILED(t->QueryInterface(IID_PPV_ARGS(&events)))) return false;
            t->ProcessMessage(MFT_MESSAGE_NOTIFY_BEGIN_STREAMING, 0);
            t->ProcessMessage(MFT_MESSAGE_NOTIFY_START_OF_STREAM, 0);
            w = width; h = height;
            needInput = 0;
            return true;
        }

        bool Open(int width, int height, const OnlineVideo::Settings& s)
        {
            Close();
            MFT_REGISTER_TYPE_INFO inInfo{ MFMediaType_Video, MFVideoFormat_NV12 };
            MFT_REGISTER_TYPE_INFO outInfo{ MFMediaType_Video, MFVideoFormat_H264 };
            for (int pass = s.hardware ? 0 : 1; pass < 2; ++pass)
            {
                const UINT32 flags = pass == 0 ? (MFT_ENUM_FLAG_HARDWARE | MFT_ENUM_FLAG_SORTANDFILTER)
                                               : (MFT_ENUM_FLAG_SYNCMFT | MFT_ENUM_FLAG_LOCALMFT | MFT_ENUM_FLAG_SORTANDFILTER);
                IMFActivate** acts = nullptr;
                UINT32 count = 0;
                if (FAILED(MFTEnumEx(MFT_CATEGORY_VIDEO_ENCODER, flags, &inInfo, &outInfo, &acts, &count))) count = 0;
                if (pass == 0) Logger::WriteFormat(Logger::Level::Info, "Online: %u hardware H.264 encoder(s) for this 32-bit game", count);
                bool ok = false;
                for (UINT32 i = 0; i < count; ++i)
                {
                    if (!ok)
                    {
                        name = FriendlyName(acts[i]);
                        ComPtr<IMFTransform> t;
                        if (SUCCEEDED(acts[i]->ActivateObject(IID_PPV_ARGS(&t))) && Configure(t.Get(), pass == 0, width, height, s)) ok = true;
                        else { Close(); acts[i]->ShutdownObject(); }
                    }
                    acts[i]->Release();
                }
                CoTaskMemFree(acts);
                if (ok)
                {
                    Logger::WriteFormat(Logger::Level::Success, "Online: encoder %s (%s, %s) %dx%d %d fps %d kbps", name.c_str(),
                        pass == 0 ? "hardware" : "software", async ? "async" : "sync", width, height, s.fps, g_bitrateNow > 0 ? g_bitrateNow : s.bitrateKbps);
                    std::lock_guard<std::mutex> lock(g_statusMutex);
                    g_encName = name + (pass == 0 ? " (GPU)" : " (CPU)");
                    return true;
                }
            }
            Logger::Write(Logger::Level::Error, "Online: no H.264 encoder could be set up");
            return false;
        }

        // One encoded sample out of the MFT, to the sink. False: none there.
        bool Drain()
        {
            MFT_OUTPUT_DATA_BUFFER out{};
            out.dwStreamID = outId;
            ComPtr<IMFSample> own;
            if (!providesSamples)
            {
                ComPtr<IMFMediaBuffer> buf;
                if (FAILED(MFCreateSample(&own)) || FAILED(MFCreateMemoryBuffer(outSize, &buf))) return false;
                own->AddBuffer(buf.Get());
                out.pSample = own.Get();
            }
            DWORD status = 0;
            const HRESULT hr = mft->ProcessOutput(0, 1, &out, &status);
            if (out.pEvents) out.pEvents->Release();
            if (hr == MF_E_TRANSFORM_NEED_MORE_INPUT) return false;
            if (hr == MF_E_TRANSFORM_STREAM_CHANGE)
            {
                ComPtr<IMFMediaType> t;
                if (SUCCEEDED(mft->GetOutputAvailableType(outId, 0, &t))) mft->SetOutputType(outId, t.Get(), 0);
                MFT_OUTPUT_STREAM_INFO info{};
                mft->GetOutputStreamInfo(outId, &info);
                providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
                outSize = std::max<DWORD>(info.cbSize, outSize);
                return true;
            }
            if (FAILED(hr) || !out.pSample)
            {
                if (providesSamples && out.pSample) out.pSample->Release();
                return false;
            }
            IMFSample* sample = out.pSample;
            ComPtr<IMFMediaBuffer> buf;
            if (SUCCEEDED(sample->ConvertToContiguousBuffer(&buf)))
            {
                BYTE* data = nullptr;
                DWORD len = 0;
                if (SUCCEEDED(buf->Lock(&data, nullptr, &len)) && data && len)
                {
                    UINT32 clean = 0;
                    sample->GetUINT32(MFSampleExtension_CleanPoint, &clean);
                    bool sps = false, idr = false;
                    size_t firstSlice = 0;
                    ScanNals(data, len, sps, idr, firstSlice);
                    if (sps && firstSlice > 0 && firstSlice <= len) header.assign(data, data + firstSlice);
                    const bool key = idr || clean != 0;
                    if (key && !sps && header.empty())
                    {
                        ComPtr<IMFMediaType> t;
                        UINT32 blob = 0;
                        if (SUCCEEDED(mft->GetOutputCurrentType(outId, &t)) && SUCCEEDED(t->GetBlobSize(MF_MT_MPEG_SEQUENCE_HEADER, &blob)) && blob)
                        {
                            header.resize(blob);
                            t->GetBlob(MF_MT_MPEG_SEQUENCE_HEADER, header.data(), blob, nullptr);
                        }
                    }
                    LONGLONG time = 0;
                    sample->GetSampleTime(&time);
                    const uint32_t captureMs = static_cast<uint32_t>(static_cast<int64_t>(time) / 10000);
                    const uint8_t* bytes = data;
                    size_t size = len;
                    if (key && !sps && !header.empty())
                    {
                        scratch.assign(header.begin(), header.end());
                        scratch.insert(scratch.end(), data, data + len);
                        bytes = scratch.data();
                        size = scratch.size();
                    }
                    if (g_sink) g_sink(bytes, size, key, static_cast<uint16_t>(w), static_cast<uint16_t>(h), captureMs);
                    g_encoded.fetch_add(1, std::memory_order_relaxed);
                    if (async)
                    {
                        // GPU encoder: time from the picture being taken to its output
                        const int64_t nowUs = OnlineClock::NowUs();
                        const double ms = static_cast<double>(nowUs - static_cast<int64_t>(time) / 10) / 1000.0;
                        double only = -1;
                        for (const InAt& a : g_inAt) if (a.time == static_cast<int64_t>(time)) only = (nowUs - a.us) / 1000.0;
                        if (ms >= 0 && ms < 1000)
                        {
                            std::lock_guard<std::mutex> lock(g_statusMutex);
                            g_encMs = g_encMs <= 0 ? ms : g_encMs * 0.95 + ms * 0.05;
                            if (only >= 0 && only < 1000) g_encOnlyMs = g_encOnlyMs <= 0 ? only : g_encOnlyMs * 0.95 + only * 0.05;
                        }
                    }
                    buf->Unlock();
                }
            }
            if (providesSamples) sample->Release();
            return true;
        }

        // Async MFT events waiting now: input requests counted, outputs taken. waitInputMs > 0: wait
        // that long for an input request (right after opening).
        void Pump(double waitInputMs = 0.0)
        {
            const int64_t start = QpcNow();
            for (;;)
            {
                ComPtr<IMFMediaEvent> ev;
                const HRESULT hr = events->GetEvent(MF_EVENT_FLAG_NO_WAIT, &ev);
                if (hr == MF_E_NO_EVENTS_AVAILABLE)
                {
                    if (needInput > 0 || waitInputMs <= 0) return;
                    const double ms = QpcMs(start, QpcNow());
                    if (ms >= waitInputMs) return;
                    if (ms < 1.5) SwitchToThread(); else Sleep(1);
                    continue;
                }
                if (FAILED(hr) || !ev) return;
                MediaEventType type = MEUnknown;
                ev->GetType(&type);
                if (type == METransformNeedInput) ++needInput;
                else if (type == METransformHaveOutput) Drain();
            }
        }

        bool Encode(const RawFrame& f)
        {
            ComPtr<IMFSample> sample;
            ComPtr<IMFMediaBuffer> buf;
            const DWORD size = static_cast<DWORD>(f.nv12.size());
            if (FAILED(MFCreateSample(&sample)) || FAILED(MFCreateMemoryBuffer(size, &buf))) return false;
            BYTE* dst = nullptr;
            if (FAILED(buf->Lock(&dst, nullptr, nullptr))) return false;
            std::memcpy(dst, f.nv12.data(), size);
            buf->Unlock();
            buf->SetCurrentLength(size);
            sample->AddBuffer(buf.Get());
            sample->SetSampleTime(f.us * 10);
            sample->SetSampleDuration(10000000LL / std::max(1, g_settings.fps));
            if (async)
            {
                if (needInput <= 0) Pump(30.0);
                if (needInput <= 0) return false;
                {
                    static int k = 0;
                    g_inAt[k].time = f.us * 10; g_inAt[k].us = OnlineClock::NowUs(); k = (k + 1) % 8;
                }
                if (FAILED(mft->ProcessInput(inId, sample.Get(), 0))) return false;
                --needInput;
                ++inputsWaiting;
                Pump();   // an output that is already there (the loop keeps looking every millisecond)
                return true;
            }
            HRESULT hr = mft->ProcessInput(inId, sample.Get(), 0);
            if (hr == MF_E_NOTACCEPTING) { while (Drain()) {} hr = mft->ProcessInput(inId, sample.Get(), 0); }
            if (FAILED(hr)) return false;
            while (Drain()) {}
            return true;
        }
        int inputsWaiting = 0;   // async: frames given since the last output
    };

    // 1.5.2: what the encoder thread is doing, watched like the drawing thread (a stuck video driver call
    // shows in the log)
    std::atomic<const char*> g_encStage{ nullptr };
    std::atomic<DWORD> g_encStageAt{ 0 };
    void EncStage(const char* s) { g_encStageAt.store(GetTickCount()); g_encStage.store(s); }
    DWORD WINAPI EncWatchdog(LPVOID)
    {
        const char* reported = nullptr; DWORD reportedAt = 0;
        for (;;)
        {
            Sleep(1000);
            const char* st = g_encStage.load();
            const DWORD at = g_encStageAt.load();
            if (st && GetTickCount() - at > 3000 && (st != reported || at != reportedAt))
            {
                reported = st; reportedAt = at;
                Logger::WriteFormat(Logger::Level::Warning, "Online: WATCHDOG - the encoder has been stuck for %lu s in: %s",
                    static_cast<unsigned long>((GetTickCount() - at) / 1000), st);
            }
        }
    }

    void EncoderMain()
    {
        static bool watch = false;
        if (!watch) { watch = true; HANDLE t = CreateThread(nullptr, 0, EncWatchdog, nullptr, 0, nullptr); if (t) CloseHandle(t); }
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool mfOk = MediaFoundationThere() && SUCCEEDED(MFStartup(MF_VERSION, MFSTARTUP_LITE));
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);   // 1.5.5: the game's own threads first (was above normal)
        Encoder enc;
        RawFrame frame;
        int failures = 0;
        DWORD retryAt = 0;
        if (!mfOk)
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_encName = "no Media Foundation in this Windows (Media Feature Pack)";
        }
        while (g_encRun.load())
        {
            const bool polling = enc.mft && enc.async;
            bool have = false;
            {
                std::unique_lock<std::mutex> lock(g_frameMutex);
                // a GPU encoder answers through events: looked at every millisecond
                if (!g_hasPending)
                    g_frameCv.wait_for(lock, std::chrono::milliseconds(polling ? 1 : 50), [] { return g_hasPending || !g_encRun.load(); });
                if (!g_encRun.load()) break;
                // a GPU encoder takes a frame only when it asks for one (until then a newer frame replaces it)
                if (g_hasPending && (!polling || enc.needInput > 0))
                {
                    if (g_pending.nv12Ready) { std::swap(frame.nv12, g_pending.nv12); frame.nv12Ready = true; }   // (the helper)
                    else { std::swap(frame.bgra, g_pending.bgra); frame.nv12Ready = false; }
                    g_pending.nv12Ready = false;
                    frame.w = g_pending.w; frame.h = g_pending.h; frame.us = g_pending.us;
                    g_hasPending = false;
                    have = true;
                }
            }
            if (polling)
            {
                const uint32_t before = g_encoded.load(std::memory_order_relaxed);
                EncStage("encoder: Pump (GPU encoder events)");
                enc.Pump();
                EncStage(nullptr);
                if (g_encoded.load(std::memory_order_relaxed) != before) enc.inputsWaiting = 0;
                // frames go in and nothing comes out (2 s): this encoder does not work here
                if (enc.inputsWaiting > std::max(30, g_settings.fps * 2))
                {
                    Logger::WriteFormat(Logger::Level::Warning, "Online: %s gives no output; trying the next encoder", enc.name.c_str());
                    g_settings.hardware = false;
                    enc.Close();
                    enc.inputsWaiting = 0;
                    continue;
                }
            }
            if (!have || !mfOk) continue;
            if (!frame.nv12Ready) BgraToNv12(frame.bgra.data(), frame.w, frame.h, frame.nv12);
            if (!enc.mft || frame.w != enc.w || frame.h != enc.h)
            {
                if (retryAt && static_cast<int>(GetTickCount() - retryAt) < 0) continue;
                EncStage("encoder: Open");
                const bool opened = enc.Open(frame.w, frame.h, g_settings);
                EncStage(nullptr);
                if (!opened)
                {
                    retryAt = GetTickCount() + 3000;
                    std::lock_guard<std::mutex> lock(g_statusMutex);
                    g_encName = "no H.264 encoder found";
                    continue;
                }
                retryAt = 0;
                enc.inputsWaiting = 0;
                g_forceKey.store(true);
                g_keyAfterOpen.store(true);
            }
            if (const int kbps = g_newBitrate.exchange(0))
            {
                SetUi4(enc.api.Get(), CODECAPI_AVEncCommonMeanBitRate, static_cast<UINT32>(kbps) * 1000u);
                SetUi4(enc.api.Get(), CODECAPI_AVEncCommonBufferSize, static_cast<UINT32>(kbps) * 1000u / static_cast<UINT32>(std::max(1, g_settings.fps)) * 2u);
            }
            if (g_forceKey.exchange(false))
            {
                // 1.7.1: with gradual refresh, a friend's keyframe request after a loss is mostly not needed (the picture
                // heals by itself): at most one keyframe every 2 s then (a just-opened encoder's first always)
                static DWORD lastForced = 0;
                const DWORD nowTick = GetTickCount();
                if (!g_refresh.load() || g_keyAfterOpen.exchange(false) || !lastForced || nowTick - lastForced > 2000)
                {
                    lastForced = nowTick;
                    SetUi4(enc.api.Get(), CODECAPI_AVEncVideoForceKeyFrame, 1);
                }
            }
            const int64_t t0 = QpcNow();
            EncStage("encoder: Encode");
            const bool encodedOk = enc.Encode(frame);
            EncStage(nullptr);
            if (!encodedOk)
            {
                if (++failures == 30)
                {
                    Logger::WriteFormat(Logger::Level::Warning, "Online: %s keeps failing; trying the next encoder", enc.name.c_str());
                    if (enc.hardware) g_settings.hardware = false;   // a broken GPU encoder: the CPU one
                    enc.Close();
                    failures = 0;
                }
                continue;
            }
            failures = 0;
            if (!enc.async)
            {
                const double ms = QpcMs(t0, QpcNow());
                std::lock_guard<std::mutex> lock(g_statusMutex);
                g_encMs = g_encMs <= 0 ? ms : g_encMs * 0.95 + ms * 0.05;
            }
        }
        enc.Close();
        if (mfOk) MFShutdown();
        if (SUCCEEDED(co)) CoUninitialize();
    }

    // ======================================================================================
    // Friend: decoder thread and the picture on screen
    // ======================================================================================
    std::atomic<bool> g_viewOn{ false };
    std::atomic<bool> g_viewReset{ false };    // a new session: the last picture of the old one goes
    std::atomic<bool> g_wantKey{ false };      // the decoder needs a keyframe (the network thread asks the host)
    std::atomic<bool> g_decNeedKey{ false };   // frames were dropped before the decoder: skip to a keyframe
    std::thread& g_decThread = *new std::thread();
    std::mutex g_decMutex;
    std::condition_variable g_decCv;
    std::deque<OnlineProtocol::VideoFrame> g_decQueue;

    // 1.7.1: decoded pictures wait in a short queue and are put on screen one per Present, in order (a
    // picture arriving a little early or late no longer replaces the one before it). The decoder converts
    // into a buffer of its own; the lock is held only to hand buffers over, never while copying.
    struct Pic { std::vector<uint8_t> px; int w = 0, h = 0; uint32_t captureMs = 0, readyMs = 0; };   // readyMs: decoded here (1.7.5)
    std::mutex g_picMutex;
    std::deque<Pic> g_picReady;              // decoded, not shown yet (oldest first)
    std::vector<Pic> g_picFree;              // buffers to reuse
    uint32_t g_picDropped = 0;               // decoded but never shown (the screen fell behind)
    uint32_t g_picCaughtUp = 0;               // 1.7.8: frames skipped to catch up (g_picMutex)
    int g_viewerFit = 1;                     // 1.7.8: [Online] ViewerFit - 0 black bars, 1 stretch a near shape, 2 fill (crop)
    int g_pacingBufferMs = 25;               // 1.7.5: [Online] PacingBufferMs - margin for the pictures shown on the host's clock (0 = as they come)
    Pic TakeFreePic()
    {
        std::lock_guard<std::mutex> lock(g_picMutex);
        if (g_picFree.empty()) return Pic{};
        Pic p = std::move(g_picFree.back());
        g_picFree.pop_back();
        return p;
    }
    void GiveBackPic(Pic&& p)
    {
        std::lock_guard<std::mutex> lock(g_picMutex);
        if (g_picFree.size() < 4) g_picFree.push_back(std::move(p));
    }

    std::mutex g_viewStatsMutex;
    OnlineVideo::ViewerStats g_viewStats;

    std::atomic<bool> g_hwDecode{ true };   // 1.7.1: [Online] HardwareDecoder (friend)

    struct Decoder
    {
        ComPtr<IMFTransform> mft;
        // 1.7.1: decoding on the graphics card (D3D11 video, through Media Foundation's DXGI device manager): a few ms
        // a frame instead of 13-19 ms of the processor. Falls back to the processor decoder when it can't.
        ComPtr<ID3D11Device> d3d;
        ComPtr<IMFDXGIDeviceManager> dxgi;
        UINT dxgiToken = 0;
        bool onGpu = false;
        bool GpuManager()
        {
            if (dxgi) return true;
            const D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1, D3D_FEATURE_LEVEL_10_0, D3D_FEATURE_LEVEL_9_3 };
            if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_VIDEO_SUPPORT | D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                                         levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &d3d, nullptr, nullptr)) || !d3d) return false;
            ComPtr<ID3D10Multithread> mt;
            if (SUCCEEDED(d3d.As(&mt))) mt->SetMultithreadProtected(TRUE);
            if (FAILED(MFCreateDXGIDeviceManager(&dxgiToken, &dxgi)) || FAILED(dxgi->ResetDevice(d3d.Get(), dxgiToken))) { dxgi.Reset(); d3d.Reset(); return false; }
            return true;
        }
        bool providesSamples = false, haveOutput = false;
        DWORD outSize = 0;
        UINT32 frameW = 0, frameH = 0;
        LONG stride = 0;
        int inW = 0, inH = 0;
        std::string name;

        void Close() { mft.Reset(); haveOutput = false; inW = inH = 0; onGpu = false; }

        bool PickOutput()
        {
            for (DWORD i = 0;; ++i)
            {
                ComPtr<IMFMediaType> t;
                if (FAILED(mft->GetOutputAvailableType(0, i, &t))) return false;
                GUID sub{};
                t->GetGUID(MF_MT_SUBTYPE, &sub);
                if (sub != MFVideoFormat_NV12) continue;
                if (FAILED(mft->SetOutputType(0, t.Get(), 0))) return false;
                MFGetAttributeSize(t.Get(), MF_MT_FRAME_SIZE, &frameW, &frameH);
                UINT32 s = 0;
                stride = SUCCEEDED(t->GetUINT32(MF_MT_DEFAULT_STRIDE, &s)) ? static_cast<LONG>(s) : static_cast<LONG>(frameW);
                MFT_OUTPUT_STREAM_INFO info{};
                mft->GetOutputStreamInfo(0, &info);
                providesSamples = (info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES)) != 0;
                outSize = std::max<DWORD>(info.cbSize, frameW * frameH * 3 / 2);
                haveOutput = true;
                return true;
            }
        }

        bool Open(int w, int h)
        {
            Close();
            MFT_REGISTER_TYPE_INFO inInfo{ MFMediaType_Video, MFVideoFormat_H264 };
            IMFActivate** acts = nullptr;
            UINT32 count = 0;
            if (FAILED(MFTEnumEx(MFT_CATEGORY_VIDEO_DECODER, MFT_ENUM_FLAG_SYNCMFT | MFT_ENUM_FLAG_LOCALMFT | MFT_ENUM_FLAG_SORTANDFILTER,
                &inInfo, nullptr, &acts, &count))) count = 0;
            for (UINT32 i = 0; i < count; ++i)
            {
                if (!mft)
                {
                    ComPtr<IMFTransform> t;
                    if (SUCCEEDED(acts[i]->ActivateObject(IID_PPV_ARGS(&t))))
                    {
                        name = FriendlyName(acts[i]);
                        ComPtr<IMFAttributes> attrs;
                        if (SUCCEEDED(t->GetAttributes(&attrs)) && attrs) attrs->SetUINT32(CODECAPI_AVLowLatencyMode, TRUE);
                        onGpu = false;
                        UINT32 aware = 0;
                        if (g_hwDecode.load() && attrs && SUCCEEDED(attrs->GetUINT32(MF_SA_D3D11_AWARE, &aware)) && aware && GpuManager())
                            onGpu = SUCCEEDED(t->ProcessMessage(MFT_MESSAGE_SET_D3D_MANAGER, reinterpret_cast<ULONG_PTR>(dxgi.Get())));
                        ComPtr<ICodecAPI> api;
                        if (SUCCEEDED(t.As(&api))) SetBool(api.Get(), CODECAPI_AVLowLatencyMode, true);
                        ComPtr<IMFMediaType> in;
                        MFCreateMediaType(&in);
                        in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
                        in->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
                        MFSetAttributeSize(in.Get(), MF_MT_FRAME_SIZE, static_cast<UINT32>(w), static_cast<UINT32>(h));
                        in->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
                        if (SUCCEEDED(t->SetInputType(0, in.Get(), 0)))
                        {
                            mft = t;
                            if (!PickOutput()) haveOutput = false;   // comes with the first frame (stream change)
                            mft->ProcessMessage(MFT_MESSAGE_NOTIFY_BEGIN_STREAMING, 0);
                            mft->ProcessMessage(MFT_MESSAGE_NOTIFY_START_OF_STREAM, 0);
                        }
                    }
                }
                acts[i]->Release();
            }
            CoTaskMemFree(acts);
            if (!mft) { Logger::Write(Logger::Level::Error, "Online: no H.264 decoder found"); return false; }
            inW = w; inH = h;
            Logger::WriteFormat(Logger::Level::Success, "Online: decoder %s for %dx%d (%s)", name.c_str(), w, h, onGpu ? "on the graphics card" : "on the processor");
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            g_viewStats.decoder = name;
            return true;
        }

        void Publish(IMFSample* sample, int w, int h, uint32_t captureMs)
        {
            ComPtr<IMFMediaBuffer> buf;
            if (FAILED(sample->GetBufferByIndex(0, &buf))) return;
            ComPtr<IMF2DBuffer> b2;
            BYTE* base = nullptr;
            LONG pitch = 0;
            bool twoD = false;
            DWORD len = 0;
            ComPtr<IMF2DBuffer2> b22;
            DWORD lockedLen = 0;
            if (SUCCEEDED(buf.As(&b22)))
            {
                BYTE* start = nullptr;
                if (SUCCEEDED(b22->Lock2DSize(MF2DBuffer_LockFlags_Read, &base, &pitch, &start, &lockedLen))) { twoD = true; b2 = b22; }
            }
            if (!twoD && SUCCEEDED(buf.As(&b2)) && SUCCEEDED(b2->Lock2D(&base, &pitch))) twoD = true;
            if (!twoD)
            {
                if (FAILED(buf->Lock(&base, nullptr, &len))) return;
                pitch = stride;
            }
            // the chroma plane starts after the buffer's own row count (a graphics card frame has 1088 rows for 1080)
            UINT32 rows = frameH;
            if (twoD && lockedLen && pitch > 0)
            {
                const UINT32 r = static_cast<UINT32>(static_cast<uint64_t>(lockedLen) * 2 / 3 / static_cast<uint64_t>(pitch));
                if (r >= frameH && r <= frameH + 64) rows = r;
            }
            const int cw = std::min<int>(w, static_cast<int>(frameW)) & ~1, ch = std::min<int>(h, static_cast<int>(frameH)) & ~1;
            if (base && pitch > 0 && cw > 0 && ch > 0 && (twoD || len >= static_cast<DWORD>(pitch) * frameH * 3 / 2))
            {
                Pic pic = TakeFreePic();
                pic.px.resize(static_cast<size_t>(cw) * ch * 4);
                Nv12ToBgra(base, base + static_cast<size_t>(pitch) * rows, pitch, cw, ch, pic.px.data());
                pic.w = cw; pic.h = ch; pic.captureMs = captureMs; pic.readyMs = OnlineClock::NowMs();
                std::lock_guard<std::mutex> lock(g_picMutex);
                g_picReady.push_back(std::move(pic));
                while (g_picReady.size() > 4)
                {
                    if (g_picFree.size() < 4) g_picFree.push_back(std::move(g_picReady.front()));
                    g_picReady.pop_front();
                    ++g_picDropped;
                }
            }
            if (twoD) b2->Unlock2D(); else buf->Unlock();
        }

        bool Decode(const OnlineProtocol::VideoFrame& f)
        {
            if (!mft || f.width != inW || f.height != inH)
            {
                if (!f.key) return false;
                if (!Open(f.width, f.height)) return false;
            }
            ComPtr<IMFSample> sample;
            ComPtr<IMFMediaBuffer> buf;
            if (FAILED(MFCreateSample(&sample)) || FAILED(MFCreateMemoryBuffer(static_cast<DWORD>(f.data.size()), &buf))) return false;
            BYTE* dst = nullptr;
            if (FAILED(buf->Lock(&dst, nullptr, nullptr))) return false;
            std::memcpy(dst, f.data.data(), f.data.size());
            buf->Unlock();
            buf->SetCurrentLength(static_cast<DWORD>(f.data.size()));
            sample->AddBuffer(buf.Get());
            sample->SetSampleTime(static_cast<LONGLONG>(f.frame) * 166667);
            if (f.key) sample->SetUINT32(MFSampleExtension_CleanPoint, TRUE);
            HRESULT hr = mft->ProcessInput(0, sample.Get(), 0);
            if (hr == MF_E_NOTACCEPTING) { Output(f); hr = mft->ProcessInput(0, sample.Get(), 0); }
            if (FAILED(hr)) return false;
            Output(f);
            return true;
        }

        void Output(const OnlineProtocol::VideoFrame& f)
        {
            for (int guard = 0; guard < 8; ++guard)
            {
                MFT_OUTPUT_DATA_BUFFER out{};
                ComPtr<IMFSample> own;
                if (!providesSamples)
                {
                    // (before the first stream change the size is not known: room for the frame, 16-aligned)
                    const DWORD need = haveOutput ? outSize : static_cast<DWORD>(((f.width + 15) & ~15) * ((f.height + 15) & ~15) * 3 / 2);
                    ComPtr<IMFMediaBuffer> buf;
                    if (FAILED(MFCreateSample(&own)) || FAILED(MFCreateMemoryBuffer(need, &buf))) return;
                    own->AddBuffer(buf.Get());
                    out.pSample = own.Get();
                }
                DWORD status = 0;
                const HRESULT hr = mft->ProcessOutput(0, 1, &out, &status);
                if (out.pEvents) out.pEvents->Release();
                if (hr == MF_E_TRANSFORM_NEED_MORE_INPUT) return;
                if (hr == MF_E_TRANSFORM_STREAM_CHANGE) { if (!PickOutput()) return; continue; }
                if (FAILED(hr)) { if (providesSamples && out.pSample) out.pSample->Release(); return; }
                if (out.pSample) Publish(out.pSample, f.width, f.height, f.captureMs);
                if (providesSamples && out.pSample) out.pSample->Release();
            }
        }
    };

    void DecoderMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool mfOk = MediaFoundationThere() && SUCCEEDED(MFStartup(MF_VERSION, MFSTARTUP_LITE));
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
        Decoder dec;
        OnlineProtocol::VideoFrame f;
        bool needKey = true;
        while (g_viewOn.load())
        {
            {
                std::unique_lock<std::mutex> lock(g_decMutex);
                g_decCv.wait_for(lock, std::chrono::milliseconds(100), [] { return !g_decQueue.empty() || !g_viewOn.load(); });
                if (!g_viewOn.load()) break;
                if (g_decQueue.empty()) continue;
                f = std::move(g_decQueue.front());
                g_decQueue.pop_front();
            }
            if (!mfOk) continue;
            if (g_decNeedKey.exchange(false)) needKey = true;
            if (needKey && !f.key) { g_wantKey.store(true); continue; }
            const int64_t t0 = QpcNow();
            const bool ok = dec.Decode(f);
            const double ms = QpcMs(t0, QpcNow());
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            if (ok)
            {
                needKey = false;
                ++g_viewStats.decoded;
                g_viewStats.decodeMs = g_viewStats.decodeMs <= 0 ? ms : g_viewStats.decodeMs * 0.95 + ms * 0.05;
            }
            else
            {
                ++g_viewStats.failures;
                if (f.key) { dec.Close(); }
                needKey = true;
                g_wantKey.store(true);
            }
        }
        dec.Close();
        if (mfOk) MFShutdown();
        if (SUCCEEDED(co)) CoUninitialize();
    }


    // ======================================================================================
    // D3D9 (render thread: the game's Present)
    // ======================================================================================
    template <typename T> void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

    // 1.7.1: the 8 MB copy of each 1080p picture into the encoder's shared memory, done by this thread: the
    // drawing thread only locks the read-back surface and hands it over (it used to copy it itself, a few ms
    // of every frame, per stream). The surface stays locked until the copy is done; unlocked a frame later.
    struct Copier
    {
        std::mutex m;
        std::condition_variable cv;
        std::deque<std::function<void()>> q;
        bool started = false;
        std::atomic<int> pending{ 0 };
        // waits (up to ms) until every copy handed over is done - before a stream's shared memory goes away
        void Drain(int ms)
        {
            const DWORD until = GetTickCount() + static_cast<DWORD>(ms);
            while (pending.load() > 0 && static_cast<int>(GetTickCount() - until) < 0) Sleep(1);
        }
        void Post(std::function<void()> job)
        {
            pending.fetch_add(1);
            {
                std::lock_guard<std::mutex> lock(m);
                if (!started) { started = true; std::thread([this] { Loop(); }).detach(); }
                q.push_back(std::move(job));
            }
            cv.notify_one();
        }
        void Loop()
        {
            SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
            for (;;)
            {
                std::function<void()> job;
                {
                    std::unique_lock<std::mutex> lock(m);
                    cv.wait(lock, [this] { return !q.empty(); });
                    job = std::move(q.front());
                    q.pop_front();
                }
                job();
                pending.fetch_sub(1);
            }
        }
    };
    Copier& g_copier = *new Copier();

    struct Capture9
    {
        static constexpr int kRing = 3;         // 1.5.4: 3, and each read back only once the GPU says it is done
        bool locked[kRing] = {};                // 1.7.1: locked for the copy thread
        std::atomic<int> copied[kRing] = {};    // 1.7.1: the copy thread is done with it
        // Unlocks surface i once its copy is done (wait: up to 200 ms for it). False: still locked.
        bool Unlocked(int i, bool wait)
        {
            if (!locked[i]) return true;
            if (wait) { const DWORD until = GetTickCount() + 200; while (!copied[i].load() && static_cast<int>(GetTickCount() - until) < 0) Sleep(0); }
            if (!copied[i].load()) return false;
            if (sys[i]) sys[i]->UnlockRect();
            locked[i] = false;
            return true;
        }
        // Lock surface i and give it to the copy thread (copy: what to do with the bits).
        bool Hand(int i, std::function<void(const uint8_t*, int)> copy)
        {
            D3DLOCKED_RECT lr{};
            const HRESULT hr = sys[i]->LockRect(&lr, nullptr, D3DLOCK_READONLY | D3DLOCK_DONOTWAIT);
            if (hr == D3DERR_WASSTILLDRAWING) return false;
            filled[i] = false;
            if (FAILED(hr)) return true;
            locked[i] = true;
            copied[i].store(0);
            std::atomic<int>* flag = &copied[i];
            const uint8_t* bits = static_cast<const uint8_t*>(lr.pBits);
            const int pitch = lr.Pitch;
            g_copier.Post([copy, bits, pitch, flag] { copy(bits, pitch); flag->store(1); });
            return true;
        }
        IDirect3DSurface9* rt[kRing] = {};      // stream size, D3DPOOL_DEFAULT
        IDirect3DSurface9* sys[kRing] = {};     // stream size, system memory (readback)
        IDirect3DQuery9* done[kRing] = {};      // "the copy into rt[i] has finished" (event query)
        bool filled[kRing] = {};
        int64_t us[kRing] = {};
        int next = 0, w = 0, h = 0;
        int64_t lastQpc = 0;
        double dueMs = 0;              // 1.7.1: when the next picture is due (ms after lastQpc's clock start)
        bool logged = false;
        // 1.7.1: steady pictures at the stream's rate. Each is due a frame interval after the one before
        // (not after the moment it was taken), with a quarter interval of slack: at a host frame rate equal to
        // the stream's, every game frame is taken even when one comes a few ms early (before, any frame under
        // the interval minus 1.5 ms was skipped: about 1 in 5 at 30 fps, the stream ran at ~24).
        bool Due(int fps, int64_t now)
        {
            const double period = 1000.0 / std::max(1, fps);
            static const int64_t base = QpcNow();
            const double t = QpcMs(base, now);
            if (lastQpc && t < dueMs - period * 0.25) return false;
            dueMs = (lastQpc && t - dueMs < period) ? dueMs + period : t + period;
            return true;
        }
        void Reset()
        {
            for (int i = 0; i < kRing; ++i) Unlocked(i, true);   // (the copy thread finishes with it first)
            for (int i = 0; i < kRing; ++i) { SafeRelease(rt[i]); SafeRelease(sys[i]); SafeRelease(done[i]); filled[i] = false; locked[i] = false; }
            w = h = 0; next = 0;
        }
        bool Ensure(IDirect3DDevice9* dev, int ow, int oh)
        {
            if (rt[0] && w == ow && h == oh) return true;
            Reset();
            for (int i = 0; i < kRing; ++i)
                if (FAILED(dev->CreateRenderTarget(ow, oh, D3DFMT_X8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &rt[i], nullptr)) ||
                    FAILED(dev->CreateOffscreenPlainSurface(ow, oh, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &sys[i], nullptr)))
                { Reset(); return false; }
            for (int i = 0; i < kRing; ++i)
                if (FAILED(dev->CreateQuery(D3DQUERYTYPE_EVENT, &done[i]))) done[i] = nullptr;   // no queries: wait as before
            w = ow; h = oh;
            return true;
        }
    };
    Capture9& g_cap = *new Capture9();

    struct View9
    {
        IDirect3DSurface9* sysRing[2] = {};     // picture size, system memory (used in turn)
        IDirect3DSurface9* gpu = nullptr;       // picture size, D3DPOOL_DEFAULT
        int w = 0, h = 0, ring = 0;
        bool have = false;
        void Reset() { SafeRelease(sysRing[0]); SafeRelease(sysRing[1]); SafeRelease(gpu); w = h = 0; ring = 0; have = false; }
    };
    View9& g_view = *new View9();
    struct ViewPerf { int64_t since = 0; uint32_t presents = 0, pictures = 0; double uploadMs = 0; };
    ViewPerf g_viewPerf;
}


// ==========================================================================================
// 1.6.0: the encoder in its own 64-bit process (DAOCoopStream.exe, StreamShared.h). The game keeps
// taking the picture (CaptureD3D9 -> PushFrame -> RemotePush, straight into shared memory); the helper
// converts and encodes it, and a reader thread hands the H.264 to g_sink as the in-game encoder did.
// If the helper can't start or stops answering, the in-game encoder takes over.
// ==========================================================================================
namespace
{
    struct Remote
    {
        HANDLE map = nullptr, inEv = nullptr, outEv = nullptr, proc = nullptr, job = nullptr;
        StreamShared::Header* hdr = nullptr;
        std::thread reader;
        std::atomic<bool> run{ false };
        uint32_t inSeq = 0, outSeq = 0;
    };
    Remote& g_rm = *new Remote();
    void EncoderMain();

    void RemoteClose(Remote& rm)
    {
        if (rm.hdr) { InterlockedExchange(&rm.hdr->quit, 1); }
        if (rm.inEv) SetEvent(rm.inEv);
        if (rm.proc)
        {
            if (WaitForSingleObject(rm.proc, 2000) != WAIT_OBJECT_0) TerminateProcess(rm.proc, 1);
            CloseHandle(rm.proc); rm.proc = nullptr;
        }
        if (rm.job) { CloseHandle(rm.job); rm.job = nullptr; }
        if (rm.hdr) { UnmapViewOfFile(rm.hdr); rm.hdr = nullptr; }
        if (rm.map) { CloseHandle(rm.map); rm.map = nullptr; }
        if (rm.inEv) { CloseHandle(rm.inEv); rm.inEv = nullptr; }
        if (rm.outEv) { CloseHandle(rm.outEv); rm.outEv = nullptr; }
    }

    bool RemoteAlive(Remote& rm)
    {
        if (!rm.hdr || !rm.proc) return false;
        if (WaitForSingleObject(rm.proc, 0) == WAIT_OBJECT_0) return false;
        if (rm.hdr->state == 2) return false;
        return GetTickCount() - static_cast<DWORD>(rm.hdr->heartbeat) < 3000;
    }

    // Starts DAOCoopStream.exe; true once it says it is running.
    bool RemoteStart(Remote& rm, const OnlineVideo::Settings& s)
    {
        if (s.helperPath.empty() || GetFileAttributesW(s.helperPath.c_str()) == INVALID_FILE_ATTRIBUTES)
        {
            Logger::Write(Logger::Level::Info, "Online: no DAOCoopStream.exe next to the mod - encoding inside the game");
            return false;
        }
        wchar_t name[96];
        swprintf(name, 96, L"Local\\DAOCoopStream_%lu_%lu", GetCurrentProcessId(), GetTickCount());
        const uint32_t inBytes = StreamShared::InSlotBytesFor(s.height);
        const uint32_t total = StreamShared::TotalBytes(inBytes);
        rm.map = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, total, name);
        if (!rm.map) { Logger::WriteFormat(Logger::Level::Warning, "Online: stream helper: no shared memory (%lu)", GetLastError()); return false; }
        rm.hdr = static_cast<StreamShared::Header*>(MapViewOfFile(rm.map, FILE_MAP_ALL_ACCESS, 0, 0, total));
        if (!rm.hdr) { Logger::WriteFormat(Logger::Level::Warning, "Online: stream helper: shared memory not mapped (%lu, %u MB)", GetLastError(), total >> 20); RemoteClose(rm); return false; }
        std::memset(rm.hdr, 0, sizeof(StreamShared::Header));
        StreamShared::Header& h = *rm.hdr;
        h.magic = StreamShared::kMagic; h.version = StreamShared::kVersion;
        h.inSlotBytes = inBytes; h.totalBytes = total;
        h.height = s.height; h.fps = s.fps; h.bitrateKbps = s.bitrateKbps; h.gopSeconds = s.gopSeconds;
        h.profile = s.profile; h.effort = s.qualityVsSpeed; h.hardware = s.hardware ? 1 : 0;
        wchar_t ev[128];
        swprintf(ev, 128, L"%ls_in", name);  rm.inEv = CreateEventW(nullptr, FALSE, FALSE, ev);
        swprintf(ev, 128, L"%ls_out", name); rm.outEv = CreateEventW(nullptr, FALSE, FALSE, ev);
        if (!rm.inEv || !rm.outEv) { RemoteClose(rm); return false; }

        // the helper ends with the game, whatever happens to the game (job object)
        rm.job = CreateJobObjectW(nullptr, nullptr);
        if (rm.job)
        {
            JOBOBJECT_EXTENDED_LIMIT_INFORMATION li = {};
            li.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            SetInformationJobObject(rm.job, JobObjectExtendedLimitInformation, &li, sizeof(li));
        }
        std::wstring cmd = L"\"" + s.helperPath + L"\" " + name + L" " + std::to_wstring(GetCurrentProcessId());
        std::vector<wchar_t> buf(cmd.begin(), cmd.end());
        buf.push_back(0);
        STARTUPINFOW si = {};
        si.cb = sizeof(si);
        PROCESS_INFORMATION pi = {};
        std::wstring dir = s.helperPath.substr(0, s.helperPath.find_last_of(L"\\/"));
        if (!CreateProcessW(nullptr, buf.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW | CREATE_SUSPENDED | BELOW_NORMAL_PRIORITY_CLASS,
                            nullptr, dir.c_str(), &si, &pi))
        {
            Logger::WriteFormat(Logger::Level::Warning, "Online: DAOCoopStream.exe did not start (%lu) - encoding inside the game", GetLastError());
            RemoteClose(rm);
            return false;
        }
        if (rm.job) AssignProcessToJobObject(rm.job, pi.hProcess);
        ResumeThread(pi.hThread);
        CloseHandle(pi.hThread);
        rm.proc = pi.hProcess;
        for (int i = 0; i < 100 && h.state == 0; ++i)     // up to 5 s for the encoder to be ready
        {
            if (WaitForSingleObject(rm.proc, 50) == WAIT_OBJECT_0) break;
        }
        if (h.state != 1)
        {
            Logger::WriteFormat(Logger::Level::Warning, "Online: DAOCoopStream.exe did not get ready (%s) - encoding inside the game",
                                h.state == 2 ? h.status : "no answer");
            RemoteClose(rm);
            return false;
        }
        Logger::WriteFormat(Logger::Level::Success, "Online: encoding in DAOCoopStream.exe (64-bit, %u MB shared): %s", total >> 20, h.status);
        return true;
    }

    // Render thread (PushFrame): the read-back picture straight into a free shared slot - the same one
    // copy the in-game encoder needed; NV12 and encoding happen in the helper on other cores.
    bool RemotePush(Remote& rm, const uint8_t* bits, int pitch, int w, int h, int64_t us)
    {
        StreamShared::Header* hp = rm.hdr;
        if (!hp) return false;
        StreamShared::Header& hd = *hp;
        if (static_cast<uint64_t>(w) * h * 4 > hd.inSlotBytes) return false;      // too wide: the in-game path
        int slot = -1;
        for (int i = 0; i < StreamShared::kInSlots && slot < 0; ++i) if (hd.in[i].state == 0) slot = i;
        if (slot < 0)   // both waiting: replace the older one
        {
            uint32_t oldest = 0xFFFFFFFF;
            int pick = -1;
            for (int i = 0; i < StreamShared::kInSlots; ++i)
                if (hd.in[i].state == 1 && hd.in[i].seq < oldest) { oldest = hd.in[i].seq; pick = i; }
            if (pick >= 0 && InterlockedCompareExchange(&hd.in[pick].state, 0, 1) == 1) { slot = pick; g_replaced.fetch_add(1, std::memory_order_relaxed); }
            if (slot < 0) { g_skippedBusy.fetch_add(1, std::memory_order_relaxed); return true; }   // the helper is reading both: skip this one
        }
        uint8_t* dst = StreamShared::InData(&hd, slot);
        for (int y = 0; y < h; ++y) std::memcpy(dst + static_cast<size_t>(y) * w * 4, bits + static_cast<size_t>(y) * pitch, static_cast<size_t>(w) * 4);
        hd.in[slot].w = w; hd.in[slot].h = h; hd.in[slot].us = us; hd.in[slot].seq = ++rm.inSeq;
        InterlockedExchange(&hd.in[slot].state, 1);
        SetEvent(rm.inEv);
        return true;
    }

    bool RemotePushMain(const uint8_t* bits, int pitch, int w, int h, int64_t us) { return RemotePush(g_rm, bits, pitch, w, h, us); }

    // In the game: encoded frames from the helper -> g_sink, in order.
    void RemoteReader()
    {
        DWORD aliveCheck = GetTickCount();
        while (g_rm.run.load())
        {
            WaitForSingleObject(g_rm.outEv, 50);
            if (GetTickCount() - aliveCheck > 500)
            {
                aliveCheck = GetTickCount();
                if (!RemoteAlive(g_rm))
                {
                    Logger::Write(Logger::Level::Warning, "Online: DAOCoopStream.exe stopped - encoding inside the game from now on");
                    g_remoteOn.store(false);
                    if (g_encRun.load() && !g_encThread.joinable()) g_encThread = std::thread(EncoderMain);
                    g_forceKey.store(true);
                    break;
                }
                std::lock_guard<std::mutex> lock(g_statusMutex);
                g_encName = std::string("helper: ") + g_rm.hdr->status;
            }
            StreamShared::Header& h = *g_rm.hdr;
            for (;;)
            {
                int slot = -1;
                uint32_t best = 0xFFFFFFFF;
                for (int i = 0; i < StreamShared::kOutSlots; ++i)
                    if (h.out[i].state == 1 && h.out[i].seq < best) { best = h.out[i].seq; slot = i; }
                if (slot < 0) break;
                const StreamShared::OutSlot& o = h.out[slot];
                if (g_sink && o.size <= StreamShared::kOutSlotBytes)
                    g_sink(StreamShared::OutData(&h, slot), o.size, o.key != 0, static_cast<uint16_t>(o.w), static_cast<uint16_t>(o.h), o.captureMs);
                g_encoded.fetch_add(1, std::memory_order_relaxed);
                InterlockedExchange(&h.out[slot].state, 0);
            }
        }
    }
}

// ==========================================================================================
// 1.7.0: more than one stream - each online friend their own player's picture (views.h, mode 3).
// Channel 0 is the stream above (with the in-game encoder to fall back on); channel 1 has its own
// DAOCoopStream.exe and its own capture surfaces, and its frames go to its own sink. A picture source
// says what each channel streams (null: the back buffer, Player 1's picture).
// ==========================================================================================
namespace
{
    OnlineVideo::PictureSource g_source = nullptr;

    struct Extra
    {
        Remote rm;
        Capture9 cap;
        OnlineVideo::Settings settings;
        OnlineVideo::FrameSink sink;
        std::atomic<bool> on{ false };
        int channel = 1;
        uint32_t taken = 0, sent = 0;
    };
    Extra& g_extra1 = *new Extra();
    Extra* ExtraOf(int ch) { return ch == 1 ? &g_extra1 : nullptr; }

    void ExtraReader(Extra* e)
    {
        DWORD aliveCheck = GetTickCount();
        while (e->rm.run.load())
        {
            WaitForSingleObject(e->rm.outEv, 50);
            if (GetTickCount() - aliveCheck > 500)
            {
                aliveCheck = GetTickCount();
                if (!RemoteAlive(e->rm))
                {
                    Logger::WriteFormat(Logger::Level::Warning, "Online: stream %d's DAOCoopStream.exe stopped - that friend gets the main stream", e->channel);
                    e->on.store(false);
                    break;
                }
            }
            StreamShared::Header& h = *e->rm.hdr;
            for (;;)
            {
                int slot = -1;
                uint32_t best = 0xFFFFFFFF;
                for (int i = 0; i < StreamShared::kOutSlots; ++i)
                    if (h.out[i].state == 1 && h.out[i].seq < best) { best = h.out[i].seq; slot = i; }
                if (slot < 0) break;
                const StreamShared::OutSlot& o = h.out[slot];
                if (e->sink && o.size <= StreamShared::kOutSlotBytes)
                    e->sink(StreamShared::OutData(&h, slot), o.size, o.key != 0, static_cast<uint16_t>(o.w), static_cast<uint16_t>(o.h), o.captureMs);
                ++e->sent;
                InterlockedExchange(&h.out[slot].state, 0);
            }
        }
    }

    // The surface a channel streams this frame (AddRef'd), or null.
    OnlineVideo::ChannelWanted g_wanted = nullptr;
    bool Wanted(int ch) { return !g_wanted || g_wanted(ch); }
    IDirect3DSurface9* SourceSurface(IDirect3DDevice9* dev, int ch)
    {
        IDirect3DSurface9* src = g_source ? g_source(ch) : nullptr;
        if (src) { src->AddRef(); return src; }
        IDirect3DSurface9* bb = nullptr;
        if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb))) return nullptr;
        return bb;
    }
}

namespace OnlineVideo
{
    // ---------------- host ----------------
    bool StartHost(const Settings& settings, FrameSink sink)
    {
        std::lock_guard<std::mutex> lock(g_hostMutex);
        if (g_hostOn.load()) return true;
        g_settings = settings;
        g_settings.fps = std::clamp(g_settings.fps, 15, 144);
        g_settings.height = std::clamp(g_settings.height, 240, 2160) & ~7;
        g_settings.bitrateKbps = std::clamp(g_settings.bitrateKbps, 500, 100000);
        g_sink = std::move(sink);
        {
            std::lock_guard<std::mutex> s(g_statusMutex);
            g_bitrateNow = g_settings.bitrateKbps;
            g_encName = "starting";
            g_encMs = 0;
        }
        g_captured = g_replaced = g_skippedBusy = g_encoded = 0;
        g_gov = Governor();
        g_encRun.store(true);
        if (RemoteStart(g_rm, g_settings))
        {
            g_remoteOn.store(true);
            g_rm.run.store(true);
            g_rm.reader = std::thread(RemoteReader);
        }
        else g_encThread = std::thread(EncoderMain);
        g_hostOn.store(true);
        g_forceKey.store(true);
        return true;
    }

    void StopHost()
    {
        std::lock_guard<std::mutex> lock(g_hostMutex);
        if (!g_hostOn.exchange(false)) return;
        g_encRun.store(false);
        g_rm.run.store(false);
        g_remoteOn.store(false);
        Sleep(50);   // (a picture being copied by the render thread right now)
        g_frameCv.notify_all();
        if (g_rm.outEv) SetEvent(g_rm.outEv);
        if (g_rm.reader.joinable()) g_rm.reader.join();
        g_copier.Drain(1000);   // 1.7.1: a picture still being copied into its shared memory
        if (g_rm.hdr || g_rm.proc) RemoteClose(g_rm);
        g_remoteOn.store(false);
        if (g_encThread.joinable()) g_encThread.join();
        {
            std::lock_guard<std::mutex> f(g_frameMutex);
            g_hasPending = false;
        }
        g_sink = nullptr;
        Logger::WriteFormat(Logger::Level::Info, "Online: stream stopped (frames taken %u, encoded %u, replaced before encoding %u, skipped %u)",
            g_captured.load(), g_encoded.load(), g_replaced.load(), g_skippedBusy.load());
    }

    bool HostRunning() { return g_hostOn.load(); }
    void RequestKeyframe()
    {
        g_forceKey.store(true);
        if (g_remoteOn.load() && g_rm.hdr) InterlockedExchange(&g_rm.hdr->forceKey, 1);
    }
    void SetBitrate(int kbps)
    {
        kbps = std::clamp(kbps, 500, 100000);
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            if (kbps == g_bitrateNow) return;
            g_bitrateNow = kbps;
        }
        g_newBitrate.store(kbps);
        if (g_remoteOn.load() && g_rm.hdr) InterlockedExchange(&g_rm.hdr->newBitrate, kbps);
    }

#ifdef DAOCOOP_STREAM_HELPER
    // 1.7.8: NVIDIA cards: NVENC driven directly (NvencDirect.h) - the picture encoded here as it comes, in a few ms.
    // [Online] DirectEncoder=0 in DAOCoop.ini (next to this exe) turns it off. False: the Media Foundation way.
    bool DirectEncode(const uint8_t* bgra, int w, int h, int64_t us)
    {
        static NvencDirect nv;
        static int allowed = -1;
        static bool failed = false;
        static int fails = 0;
        static DWORD lastKey = 0;
        static bool firstKey = true;
        if (allowed < 0)
        {
            wchar_t path[MAX_PATH] = {};
            GetModuleFileNameW(nullptr, path, MAX_PATH);
            if (wchar_t* sl = wcsrchr(path, L'\\')) lstrcpyW(sl + 1, L"DAOCoop.ini");
            allowed = static_cast<int>(GetPrivateProfileIntW(L"Online", L"DirectEncoder", 1, path));
            if (!allowed) Logger::Write(Logger::Level::Info, "Online: direct NVIDIA encoding off ([Online] DirectEncoder=0)");
        }
        if (!allowed || failed) return false;
        if (!nv.IsOpen() || nv.Width() != w || nv.Height() != h)
        {
            std::string why;
            const int kbps = g_bitrateNow > 0 ? g_bitrateNow : g_settings.bitrateKbps;
            if (!nv.Open(w, h, g_settings.fps, kbps, why))
            {
                failed = true;
                Logger::WriteFormat(Logger::Level::Info, "Online: direct NVIDIA encoding not used (%s) - Media Foundation encoders", why.c_str());
                return false;
            }
            Logger::WriteFormat(Logger::Level::Info, "Online: NVIDIA NVENC driven directly - %dx%d %d fps %d kbps, ultra low latency, gradual refresh", w, h, g_settings.fps, kbps);
            {
                std::lock_guard<std::mutex> lock(g_statusMutex);
                g_encName = "NVIDIA NVENC (direct)";
            }
            firstKey = true;
        }
        if (const int kbps = g_newBitrate.exchange(0)) nv.SetBitrate(kbps);
        bool key = false;
        if (g_forceKey.exchange(false) || firstKey)
        {
            // the picture renews itself strip by strip: a keyframe asked after a loss at most every 2 s
            const DWORD now = GetTickCount();
            if (firstKey || now - lastKey > 2000) { key = true; lastKey = now; firstKey = false; }
        }
        double ms = 0;
        const bool ok = nv.Encode(bgra, w, h, us, key, [&](const uint8_t* d, size_t n, bool k) {
            if (g_sink) g_sink(d, n, k, static_cast<uint16_t>(w), static_cast<uint16_t>(h), static_cast<uint32_t>(us / 1000));
            g_encoded.fetch_add(1, std::memory_order_relaxed);
        }, &ms);
        g_captured.fetch_add(1, std::memory_order_relaxed);
        if (!ok)
        {
            if (++fails >= 30)
            {
                failed = true;
                nv.Close();
                Logger::Write(Logger::Level::Warning, "Online: direct NVIDIA encoding keeps failing - Media Foundation encoders from now on");
                g_forceKey.store(true);
                return false;
            }
            return true;   // (this picture dropped)
        }
        fails = 0;
        const double total = static_cast<double>(OnlineClock::NowUs() - us) / 1000.0;
        std::lock_guard<std::mutex> lock(g_statusMutex);
        if (total >= 0 && total < 1000) g_encMs = g_encMs <= 0 ? total : g_encMs * 0.95 + total * 0.05;
        g_encOnlyMs = g_encOnlyMs <= 0 ? ms : g_encOnlyMs * 0.95 + ms * 0.05;
        return true;
    }
#endif

    void SubmitHostBgra(const uint8_t* bgra, int w, int h, int64_t us)
    {
#ifdef DAOCOOP_STREAM_HELPER
        if (DirectEncode(bgra, w, h, us)) return;
#endif
        // 1.7.8: made NV12 here, on several cores, as it comes (was: copied, then converted on the encoder thread)
        static std::vector<uint8_t> nv12;   // (the helper's one feeding thread)
        BgraToNv12(bgra, w, h, nv12);
        SubmitHostNv12(nv12.data(), w, h, us);
    }

    void SubmitHostNv12(const uint8_t* nv12, int w, int h, int64_t us)
    {
        {
            std::lock_guard<std::mutex> lock(g_frameMutex);
            if (g_hasPending) g_replaced.fetch_add(1, std::memory_order_relaxed);
            g_pending.nv12.assign(nv12, nv12 + static_cast<size_t>(w) * h * 3 / 2);
            g_pending.nv12Ready = true;
            g_pending.w = w; g_pending.h = h; g_pending.us = us;
            g_hasPending = true;
        }
        g_frameCv.notify_one();
        g_captured.fetch_add(1, std::memory_order_relaxed);
    }

    std::string HostStatus()
    {
        std::lock_guard<std::mutex> lock(g_statusMutex);
        char line[256];
        std::snprintf(line, sizeof(line), "%s %dx%d %d kbps, encode %.1f ms (in the encoder %.1f), GPU wait %.1f ms", g_encName.c_str(), g_streamW, g_streamH,
            g_bitrateNow, g_encMs, g_encOnlyMs, g_readbackWaitMs);
        return line;
    }

    // 1.5.5 smoothness governor: the host's own frame rate decides how much the stream may take.
    // Below 45 fps for 5 s: one step lighter (sharpness first, then stream frame rate); above 58 for
    // 20 s: one step back up, never past the settings in DAOCoop.ini. Logged on every change.
    std::atomic<bool> g_govLowerRes{ false };   // 1.7.8: [Online] LowerResolution (off: the picture keeps its size)
    void GovernorStep(int height, int fps, int& outHeight, int& outFps)
    {
        if (!g_govLowerRes.load()) {
            // the size stays as set; a slow game only takes the stream from 30 to 24 frames a second
            outHeight = height;
            outFps = g_gov.level > 0 && fps > 24 ? 24 : fps;
            return;
        }
        static const int kHeights[] = { 1080, 900, 720, 540 };
        int idx = 0;
        while (idx < 3 && kHeights[idx] > height) ++idx;          // the configured size's place in the list
        int lv = g_gov.level, h = height, f = fps;
        while (lv > 0 && idx < 3 && kHeights[idx + 1] >= 540) { h = kHeights[++idx]; --lv; }
        while (lv > 0 && f > 20) { f = f > 24 ? 24 : 20; --lv; }
        outHeight = std::min(height, h);
        outFps = std::min(fps, f);
    }
    void GovernorFrame()
    {
        const int64_t now = QpcNow();
        if (!g_gov.windowFrom) { g_gov.windowFrom = now; g_gov.frames = 0; return; }
        ++g_gov.frames;
        const double ms = QpcMs(g_gov.windowFrom, now);
        if (ms < 5000.0) return;
        const double fps = g_gov.frames * 1000.0 / ms;
        g_gov.windowFrom = now; g_gov.frames = 0;
        const bool settled = !g_gov.lastChange || QpcMs(g_gov.lastChange, now) > 8000.0;
        int h0, f0, h1, f1;
        GovernorStep(g_settings.height, g_settings.fps, h0, f0);
        // 1.7.0: judged against the stream's own frame rate (the game is held at 30 with the joiners' views - under
        // the old fixed 45 fps line the stream always went down to 540p 20 fps); and only after 10 s of it
        const double lowLine = std::min(45.0, g_settings.fps * 0.8), highLine = std::min(58.0, g_settings.fps * 0.95);
        static int lowRuns = 0;
        lowRuns = fps < lowLine ? lowRuns + 1 : 0;
        if (lowRuns >= 2 && settled)
        {
            ++g_gov.level;
            GovernorStep(g_settings.height, g_settings.fps, h1, f1);
            if (h1 == h0 && f1 == f0) { --g_gov.level; return; }   // already the lightest
            g_gov.lastChange = now; g_gov.goodSince = 0;
            Logger::WriteFormat(Logger::Level::Info, "Online: host game at %.0f fps - stream lighter: %dp %d fps (was %dp %d fps)", fps, h1, f1, h0, f0);
        }
        else if (fps > highLine && g_gov.level > 0)
        {
            if (!g_gov.goodSince) g_gov.goodSince = now;
            if (QpcMs(g_gov.goodSince, now) > 20000.0 && settled)
            {
                --g_gov.level;
                GovernorStep(g_settings.height, g_settings.fps, h1, f1);
                g_gov.lastChange = now; g_gov.goodSince = 0;
                Logger::WriteFormat(Logger::Level::Info, "Online: host game at %.0f fps - stream sharper again: %dp %d fps", fps, h1, f1);
            }
        }
        else g_gov.goodSince = 0;
    }

    // The copies queued with a frame, handed to the encoder once the graphics card finished them. 1.7.8: also right
    // after Present (AfterPresent): that frame's copy is done by then, so it no longer waits a whole frame (33 ms)
    void PickUpMain()
    {
        for (int i = 0; i < Capture9::kRing; ++i) g_cap.Unlocked(i, false);   // 1.7.1: copies the copy thread finished
        // the copy made a frame ago: done on the GPU by now
        for (int k = 0; k < Capture9::kRing; ++k)
        {
            const int i = (g_cap.next + k) % Capture9::kRing;
            if (!g_cap.filled[i] || g_cap.locked[i]) continue;
            // not finished on the GPU yet: left for a later frame instead of making the game wait (lag spikes)
            if (g_cap.done[i] && g_cap.done[i]->GetData(nullptr, 0, D3DGETDATA_FLUSH) == S_FALSE) continue;
            // 1.5.5: the copy to system memory was queued with the frame (GetRenderTargetData right after
            // StretchRect, like OBS does); now it is only picked up - no waiting on the graphics card here
            const int64_t t0 = QpcNow();
            D3D9Stage("stream capture: LockRect (copy on the copy thread)");
            const int cw = g_cap.w, chh = g_cap.h;
            const int64_t cus = g_cap.us[i];
            if (!g_cap.Hand(i, [cw, chh, cus](const uint8_t* bits, int pitch) { PushFrame(bits, pitch, cw, chh, cus); })) continue;   // a frame later
            const double ms = QpcMs(t0, QpcNow());
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_readbackWaitMs = g_readbackWaitMs <= 0 ? ms : g_readbackWaitMs * 0.95 + ms * 0.05;
        }
    }
    void PickUpExtra(Extra& e)
    {
        Capture9& c = e.cap;
        for (int i = 0; i < Capture9::kRing; ++i) c.Unlocked(i, false);
        for (int k = 0; k < Capture9::kRing; ++k)
        {
            const int i = (c.next + k) % Capture9::kRing;
            if (!c.filled[i] || c.locked[i]) continue;
            if (c.done[i] && c.done[i]->GetData(nullptr, 0, D3DGETDATA_FLUSH) == S_FALSE) continue;
            Extra* ep = &e;
            const int cw = c.w, chh = c.h;
            const int64_t cus = c.us[i];
            if (!c.Hand(i, [ep, cw, chh, cus](const uint8_t* bits, int pitch) { if (RemotePush(ep->rm, bits, pitch, cw, chh, cus)) ++ep->taken; })) continue;
        }
    }

    void CaptureExtra(IDirect3DDevice9* dev, Extra& e);
    void CaptureMain(IDirect3DDevice9* dev);
    void AfterPresent()
    {
        if (g_hostOn.load()) PickUpMain();
        if (g_extra1.on.load()) PickUpExtra(g_extra1);
    }

    void CaptureD3D9(IDirect3DDevice9* dev)
    {
        if (!dev) return;
        if (g_hostOn.load()) CaptureMain(dev);
        if (g_extra1.on.load()) CaptureExtra(dev, g_extra1);
    }

    void CaptureMain(IDirect3DDevice9* dev)
    {
        GovernorFrame();
        PickUpMain();
        const int64_t now = QpcNow();
        int govH = g_settings.height, govFps = g_settings.fps;
        GovernorStep(g_settings.height, g_settings.fps, govH, govFps);
        if (!Wanted(0)) return;                            // 1.7.1: nobody watches it (the GPU copy and encoding saved)
        if (!g_cap.Due(govFps, now)) return;
        D3D9Stage("stream capture: GetBackBuffer");
        IDirect3DSurface9* bb = SourceSurface(dev, 0);     // 1.7.0: a player's own picture (views) or the back buffer
        if (!bb) return;
        D3DSURFACE_DESC bd{};
        bb->GetDesc(&bd);
        D3D9Stage("stream capture: make surfaces");
        int outH = std::min<int>(govH, static_cast<int>(bd.Height)) & ~7;
        int outW = static_cast<int>(static_cast<double>(outH) * bd.Width / std::max<UINT>(1, bd.Height) + 4) & ~7;
        if (outH < 64 || outW < 64 || !g_cap.Ensure(dev, outW, outH))
        {
            bb->Release();
            if (!g_cap.logged) { g_cap.logged = true; Logger::Write(Logger::Level::Error, "Online: stream surfaces could not be made"); }
            return;
        }
        const int slot = g_cap.next;
        if (!g_cap.Unlocked(slot, true)) { bb->Release(); return; }   // (its last copy still running: this frame skipped)
        g_cap.next = (g_cap.next + 1) % Capture9::kRing;
        D3D9Stage("stream capture: StretchRect");
        g_cap.filled[slot] = false;   // (an older copy still waiting there is dropped)
        const int64_t tq = QpcNow();
        if (SUCCEEDED(dev->StretchRect(bb, nullptr, g_cap.rt[slot], nullptr, D3DTEXF_LINEAR)) &&
            (D3D9Stage("stream capture: GetRenderTargetData (queued)"), SUCCEEDED(dev->GetRenderTargetData(g_cap.rt[slot], g_cap.sys[slot]))))
        {
            if (g_cap.done[slot]) g_cap.done[slot]->Issue(D3DISSUE_END);
            g_cap.filled[slot] = true;
            const double ms = QpcMs(tq, QpcNow());           // how long queuing the copy held the game up
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_readbackWaitMs = g_readbackWaitMs <= 0 ? ms : g_readbackWaitMs * 0.95 + ms * 0.05;
            g_cap.us[slot] = OnlineClock::NowUs();
        }
        bb->Release();
        g_cap.lastQpc = now;
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            g_streamW = outW; g_streamH = outH;
        }
        if (!g_cap.logged)
        {
            g_cap.logged = true;
            Logger::WriteFormat(Logger::Level::Info, "Online: stream picture %dx%d from the game's %ux%u (format %d)", outW, outH, bd.Width, bd.Height, static_cast<int>(bd.Format));
        }
    }

    // 1.7.0: a second stream's picture: the same steps as the main one (copy queued with the frame, picked
    // up a frame or more later when the GPU is done), into its own encoder process.
    void CaptureExtra(IDirect3DDevice9* dev, Extra& e)
    {
        Capture9& c = e.cap;
        PickUpExtra(e);
        const int64_t now = QpcNow();
        int govH = e.settings.height, govFps = e.settings.fps;
        GovernorStep(e.settings.height, e.settings.fps, govH, govFps);     // the host's frame rate decides for every stream
        if (!Wanted(e.channel)) return;                    // 1.7.1: no friend on this stream (Player 3's, with 2 players)
        if (!c.Due(govFps, now)) return;
        IDirect3DSurface9* bb = SourceSurface(dev, e.channel);
        if (!bb) return;
        D3DSURFACE_DESC bd{};
        bb->GetDesc(&bd);
        int outH = std::min<int>(govH, static_cast<int>(bd.Height)) & ~7;
        int outW = static_cast<int>(static_cast<double>(outH) * bd.Width / std::max<UINT>(1, bd.Height) + 4) & ~7;
        if (outH < 64 || outW < 64 || !c.Ensure(dev, outW, outH))
        {
            bb->Release();
            if (!c.logged) { c.logged = true; Logger::WriteFormat(Logger::Level::Error, "Online: stream %d surfaces could not be made", e.channel); }
            return;
        }
        const int slot = c.next;
        if (!c.Unlocked(slot, true)) { bb->Release(); return; }
        c.next = (c.next + 1) % Capture9::kRing;
        c.filled[slot] = false;
        if (SUCCEEDED(dev->StretchRect(bb, nullptr, c.rt[slot], nullptr, D3DTEXF_LINEAR)) &&
            SUCCEEDED(dev->GetRenderTargetData(c.rt[slot], c.sys[slot])))
        {
            if (c.done[slot]) c.done[slot]->Issue(D3DISSUE_END);
            c.filled[slot] = true;
            c.us[slot] = OnlineClock::NowUs();
        }
        bb->Release();
        c.lastQpc = now;
        if (!c.logged)
        {
            c.logged = true;
            Logger::WriteFormat(Logger::Level::Info, "Online: stream %d picture %dx%d from %ux%u", e.channel, outW, outH, bd.Width, bd.Height);
        }
    }

    void SetPictureSource(PictureSource src) { g_source = src; }
    void SetChannelWanted(ChannelWanted fn) { g_wanted = fn; }
    void SetHardwareDecode(bool on) { g_hwDecode.store(on); }
    void SetLowerResolution(bool on) { g_govLowerRes.store(on); }
    void SetViewerFit(int fit) { g_viewerFit = fit < 0 ? 0 : fit > 2 ? 2 : fit; }
    void SetPacingBuffer(int ms) { g_pacingBufferMs = ms < 0 ? 0 : ms > 200 ? 200 : ms; }

    bool StartExtra(int channel, const Settings& settings, FrameSink sink)
    {
        Extra* e = ExtraOf(channel);
        if (!e) return false;
        std::lock_guard<std::mutex> lock(g_hostMutex);
        if (e->on.load()) return true;
        e->channel = channel;
        e->settings = settings;
        e->settings.fps = std::clamp(e->settings.fps, 15, 144);
        e->settings.height = std::clamp(e->settings.height, 240, 2160) & ~7;
        e->settings.bitrateKbps = std::clamp(e->settings.bitrateKbps, 500, 100000);
        e->sink = std::move(sink);
        e->taken = e->sent = 0;
        e->cap.logged = false;
        if (!RemoteStart(e->rm, e->settings))
        {
            Logger::WriteFormat(Logger::Level::Warning, "Online: stream %d needs DAOCoopStream.exe - that friend gets the main stream", channel);
            e->sink = nullptr;
            return false;
        }
        e->rm.run.store(true);
        e->rm.reader = std::thread(ExtraReader, e);
        e->on.store(true);
        InterlockedExchange(&e->rm.hdr->forceKey, 1);
        Logger::WriteFormat(Logger::Level::Success, "Online: stream %d started (its own encoder)", channel);
        return true;
    }

    void StopExtra(int channel)
    {
        Extra* e = ExtraOf(channel);
        if (!e) return;
        std::lock_guard<std::mutex> lock(g_hostMutex);
        const bool was = e->on.exchange(false);
        e->rm.run.store(false);
        Sleep(50);
        if (e->rm.outEv) SetEvent(e->rm.outEv);
        if (e->rm.reader.joinable()) e->rm.reader.join();
        g_copier.Drain(1000);   // 1.7.1: a picture still being copied into its shared memory
        if (e->rm.hdr || e->rm.proc) RemoteClose(e->rm);
        e->sink = nullptr;
        if (was) Logger::WriteFormat(Logger::Level::Info, "Online: stream %d stopped (pictures %u, encoded %u)", channel, e->taken, e->sent);
    }

    bool ExtraRunning(int channel) { Extra* e = ExtraOf(channel); return e && e->on.load(); }

    void RequestKeyframe(int channel)
    {
        if (channel == 0) { RequestKeyframe(); return; }
        Extra* e = ExtraOf(channel);
        if (e && e->on.load() && e->rm.hdr) InterlockedExchange(&e->rm.hdr->forceKey, 1);
    }

    void SetBitrate(int channel, int kbps)
    {
        if (channel == 0) { SetBitrate(kbps); return; }
        Extra* e = ExtraOf(channel);
        if (e && e->on.load() && e->rm.hdr) InterlockedExchange(&e->rm.hdr->newBitrate, std::clamp(kbps, 500, 100000));
    }

    void DeviceLost()
    {
        g_cap.Reset();
        g_view.Reset();
        g_extra1.cap.Reset();
    }

    // ---------------- friend ----------------
    bool StartViewer()
    {
        if (g_viewOn.exchange(true)) return true;
        {
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            g_viewStats = ViewerStats{};
        }
        {
            std::lock_guard<std::mutex> lock(g_picMutex);
            g_picReady.clear();
            g_picFree.clear();
            g_picDropped = 0;
        }
        g_viewReset.store(true);
        g_wantKey.store(false);
        g_decNeedKey.store(false);
        g_decThread = std::thread(DecoderMain);
        return true;
    }

    void StopViewer()
    {
        if (!g_viewOn.exchange(false)) return;
        g_decCv.notify_all();
        if (g_decThread.joinable()) g_decThread.join();
        std::lock_guard<std::mutex> lock(g_decMutex);
        g_decQueue.clear();
    }

    bool ViewerRunning() { return g_viewOn.load(); }

    void SubmitFrame(OnlineProtocol::VideoFrame&& frame)
    {
        if (!g_viewOn.load()) return;
        {
            std::lock_guard<std::mutex> lock(g_decMutex);
            // a keyframe makes everything still waiting unnecessary
            if (frame.key) g_decQueue.clear();
            else if (g_decQueue.size() > 30)
            {
                // far behind: drop what waits and restart from the next keyframe (asked for now)
                g_decQueue.clear();
                g_decNeedKey.store(true);
                g_wantKey.store(true);
            }
            g_decQueue.push_back(std::move(frame));
        }
        g_decCv.notify_one();
    }

    // 1.7.1: the friend plays with a controller and sees only the host's picture: this PC's own mouse
    // pointer (the game's menu cursor, drawn over everything by the graphics card) is hidden while watching
    bool g_cursorHidden = false;
    void ViewerCursorBack(IDirect3DDevice9* dev)
    {
        if (!g_cursorHidden || !dev) return;
        g_cursorHidden = false;
        dev->ShowCursor(TRUE);
    }

    bool DrawViewerD3D9(IDirect3DDevice9* dev)
    {
        if (!g_viewOn.load() || !dev) return false;
        dev->ShowCursor(FALSE);
        g_cursorHidden = true;
        D3D9Stage("friend picture: draw");
        if (g_viewReset.exchange(false)) g_view.Reset();
        uint32_t captureMs = 0;
        Pic pic;
        bool got = false;
        {
            std::lock_guard<std::mutex> lock(g_picMutex);
            if (D3D9PacedInterval() > 0 || g_pacingBufferMs <= 0)
            {
                // the screen paces this PC at the host's 30 a second: one picture per Present, oldest first; more than
                // 2 waiting: the screen is behind, the oldest are skipped (at most about a frame of extra delay)
                while (g_picReady.size() > 2)
                {
                    if (g_picFree.size() < 4) g_picFree.push_back(std::move(g_picReady.front()));
                    g_picReady.pop_front();
                    ++g_picDropped;
                }
                // 1.7.8: a picture still waiting after this one, frame after frame, is a whole frame (33 ms) of delay
                // that never goes away - after 0.4 s of it, one is skipped to catch up (one tiny jump, then on time)
                static uint32_t behindSince = 0;
                const uint32_t nowMs = OnlineClock::NowMs();
                if (g_picReady.size() >= 2)
                {
                    if (!behindSince) behindSince = nowMs ? nowMs : 1;
                    else if (nowMs - behindSince > 400)
                    {
                        if (g_picFree.size() < 4) g_picFree.push_back(std::move(g_picReady.front()));
                        g_picReady.pop_front();
                        ++g_picCaughtUp;
                        behindSince = 0;
                    }
                }
                else behindSince = 0;
                if (!g_picReady.empty()) { pic = std::move(g_picReady.front()); g_picReady.pop_front(); got = true; }
            }
            else
            {
                // 1.7.5: drawn more often than pictures come (60 against the host's 30, by a timer): each picture is
                // shown when it is due by the host's own clock - its capture time + the quickest way here seen + a
                // little margin - not when it happens to arrive, so the pictures change at the host's even 33 ms
                // instead of after 1, 2 or 3 of this PC's frames (Wi-Fi delays vary)
                static int32_t off = 0; static bool haveOff = false; static uint32_t relaxAt = 0;
                const uint32_t now = OnlineClock::NowMs();
                for (const Pic& p : g_picReady)
                {
                    const int32_t o = static_cast<int32_t>(p.readyMs - p.captureMs);
                    if (!haveOff || o < off || o > off + 1000) { off = o; haveOff = true; }   // (+1 s: the host restarted its clock)
                }
                if (static_cast<int32_t>(now - relaxAt) >= 0) { relaxAt = now + 1000; if (haveOff) ++off; }   // (follows a slower way back up)
                int pick = -1;
                for (int i = 0; i < static_cast<int>(g_picReady.size()); ++i)
                {
                    const uint32_t due = g_picReady[static_cast<size_t>(i)].captureMs + static_cast<uint32_t>(off + g_pacingBufferMs);
                    if (static_cast<int32_t>(now - due) >= 0) pick = i;
                }
                if (pick >= 0)
                {
                    for (int i = 0; i < pick; ++i)
                    {
                        if (g_picFree.size() < 4) g_picFree.push_back(std::move(g_picReady.front()));
                        g_picReady.pop_front();
                        ++g_picDropped;
                    }
                    pic = std::move(g_picReady.front()); g_picReady.pop_front(); got = true;
                }
            }
        }
        g_viewPerf.presents++;
        if (got && pic.w > 0 && pic.px.size() >= static_cast<size_t>(pic.w) * pic.h * 4)
        {
            if (g_view.w != pic.w || g_view.h != pic.h || !g_view.gpu)
            {
                g_view.Reset();
                bool ok = SUCCEEDED(dev->CreateOffscreenPlainSurface(pic.w, pic.h, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &g_view.gpu, nullptr));
                for (int i = 0; i < 2 && ok; ++i)
                    ok = SUCCEEDED(dev->CreateOffscreenPlainSurface(pic.w, pic.h, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &g_view.sysRing[i], nullptr));
                if (!ok) { g_view.Reset(); GiveBackPic(std::move(pic)); return false; }
                g_view.w = pic.w; g_view.h = pic.h;
            }
            // two system-memory copies used in turn: locking one never waits for the upload of the other
            IDirect3DSurface9* sys = g_view.sysRing[g_view.ring];
            g_view.ring ^= 1;
            D3DLOCKED_RECT lr{};
            const int64_t t0 = QpcNow();
            if (sys && SUCCEEDED(sys->LockRect(&lr, nullptr, 0)))
            {
                if (lr.Pitch == pic.w * 4) std::memcpy(lr.pBits, pic.px.data(), static_cast<size_t>(pic.w) * pic.h * 4);
                else
                    for (int r = 0; r < pic.h; ++r)
                        std::memcpy(static_cast<uint8_t*>(lr.pBits) + static_cast<size_t>(r) * lr.Pitch, pic.px.data() + static_cast<size_t>(r) * pic.w * 4, static_cast<size_t>(pic.w) * 4);
                sys->UnlockRect();
                if (SUCCEEDED(dev->UpdateSurface(sys, nullptr, g_view.gpu, nullptr))) g_view.have = true;
            }
            g_viewPerf.uploadMs += QpcMs(t0, QpcNow());
            g_viewPerf.pictures++;
            captureMs = pic.captureMs;
            GiveBackPic(std::move(pic));
        }
        {   // 1.7.1: this PC's side of the picture, in its log every 5 s
            const int64_t now = QpcNow();
            if (!g_viewPerf.since) g_viewPerf.since = now;
            const double el = QpcMs(g_viewPerf.since, now);
            if (el >= 5000.0)
            {
                uint32_t dropped = 0, waiting = 0, caught = 0;
                { std::lock_guard<std::mutex> lock(g_picMutex); dropped = g_picDropped; g_picDropped = 0; caught = g_picCaughtUp; g_picCaughtUp = 0; waiting = static_cast<uint32_t>(g_picReady.size()); }
                Logger::WriteFormat(Logger::Level::Info, "Online: viewer - this PC draws %.1f frames/s, host pictures put on screen %.1f/s, skipped %u (screen behind) + %u (caught up), waiting %u, upload %.1f ms",
                    g_viewPerf.presents * 1000.0 / el, g_viewPerf.pictures * 1000.0 / el, dropped, caught, waiting,
                    g_viewPerf.pictures ? g_viewPerf.uploadMs / g_viewPerf.pictures : 0.0);
                g_viewPerf = ViewPerf{};
                g_viewPerf.since = now;
            }
        }
        if (!g_view.have) return false;
        IDirect3DSurface9* bb = nullptr;
        if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) || !bb) return false;
        D3DSURFACE_DESC bd{};
        bb->GetDesc(&bd);
        const float sw = static_cast<float>(bd.Width), sh = static_cast<float>(bd.Height);
        // 1.7.8: the host's screen shape can differ from this one's (a 16:10 host on a 16:9 screen gave black bars):
        // ViewerFit 1 (default) stretches a near shape (up to 15 % apart) over the whole screen, 2 fills it (the edges
        // cut off), 0 keeps the shape with black bars
        const float aspView = static_cast<float>(g_view.w) / g_view.h, aspScreen = sw / sh;
        const float apart = std::max(aspView, aspScreen) / std::min(aspView, aspScreen) - 1.f;
        RECT dst{ 0, 0, static_cast<LONG>(bd.Width), static_cast<LONG>(bd.Height) };
        RECT src{ 0, 0, static_cast<LONG>(g_view.w), static_cast<LONG>(g_view.h) };
        if (g_viewerFit == 2)
        {
            if (aspView > aspScreen) { const LONG w = static_cast<LONG>(g_view.h * aspScreen); src.left = (g_view.w - w) / 2; src.right = src.left + w; }
            else { const LONG h = static_cast<LONG>(g_view.w / aspScreen); src.top = (g_view.h - h) / 2; src.bottom = src.top + h; }
        }
        else if (g_viewerFit == 0 || apart > 0.15f)
        {
            const float scale = std::min(sw / g_view.w, sh / g_view.h);
            const int dw = static_cast<int>(g_view.w * scale), dh = static_cast<int>(g_view.h * scale);
            dst = RECT{ static_cast<LONG>((bd.Width - dw) / 2), static_cast<LONG>((bd.Height - dh) / 2), 0, 0 };
            dst.right = dst.left + dw; dst.bottom = dst.top + dh;
        }
        IDirect3DSurface9* oldRt = nullptr;
        dev->GetRenderTarget(0, &oldRt);
        dev->SetRenderTarget(0, bb);
        dev->Clear(0, nullptr, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);
        if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
        dev->StretchRect(g_view.gpu, &src, bb, &dst, D3DTEXF_LINEAR);
        bb->Release();
        if (captureMs)
        {
            std::lock_guard<std::mutex> lock(g_viewStatsMutex);
            ++g_viewStats.shown;
            g_viewStats.captureMs = captureMs;
            g_viewStats.shownAtMs = OnlineClock::NowMs();
            g_viewStats.width = static_cast<uint16_t>(g_view.w);
            g_viewStats.height = static_cast<uint16_t>(g_view.h);
            g_viewStats.picture = true;
        }
        return true;
    }

    bool TakeKeyframeRequest() { return g_wantKey.exchange(false); }

    ViewerStats GetViewerStats()
    {
        std::lock_guard<std::mutex> lock(g_viewStatsMutex);
        return g_viewStats;
    }

    void Shutdown()
    {
        StopHost();
        StopViewer();
        g_cap.Reset();
        g_view.Reset();
    }
}
