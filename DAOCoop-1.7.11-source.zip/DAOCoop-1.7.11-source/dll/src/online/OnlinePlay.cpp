#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#include <Xinput.h>
#include <objbase.h>
#include <oleauto.h>
#include <mmsystem.h>

#include "OnlinePlay.h"
#include "OnlineAudio.h"
#include "OnlineVoice.h"
#include "OnlineChat.h"
#include "OnlineClock.h"
#include "OnlineProtocol.h"
#include "OnlineVideo.h"
#include "OnlineLobby.h"
#include "LobbyServer.h"
#include "Logger.h"
#include "Paths.h"
#include "../vpad.h"
#include "../xinputroute.h"
#include "../popup.h"
#include "../pads.h"
#include "../d3d9hook.h"
#include "../game.h"
#include "../views.h"
#include "../modmenu.h"

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

#ifdef _MSC_VER
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#endif

#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif

static std::string g_iniA;
std::string Paths::GetConfigPath() { return g_iniA; }

namespace
{
    namespace P = OnlineProtocol;
    uint32_t Now() { return OnlineClock::NowMs(); }
    constexpr int kMaxFriends = 2;   // Player 2 and Player 3

    // ---------------- settings: [Online] in DAOCoop.ini ----------------
    struct Options
    {
        int port = P::kDefaultPort;
        int height = 1080, fps = 30, bitrate = 20000, minBitrate = 2000;   // 1.7.8: 1080p 20 Mbps (was 900p 12 Mbps)
        bool lowerRes = false;      // 1.7.8: a slow host game no longer makes the picture smaller
        bool hardware = true;
        bool helper = true;         // 1.6.0: encode in DAOCoopStream.exe (64-bit)
        int keyframeSeconds = 4, profile = 66, effort = 33, fec = 20;   // fec: 1.7.1 recovery packets, % of the data (Reed-Solomon)
        int audioMs = 30;
        int burst = 8;              // 1.7.1: video packets sent back to back before a 1 ms pause (0: all at once)
        bool conceal = true;        // 1.7.1: friend: a lost frame skipped (a brief smudge), not a still picture until a keyframe
        bool hwDecode = true;       // 1.7.1: friend: decode on the graphics card
        int viewerFit = 1;          // 1.7.8: friend: the host's picture on a screen of another shape
        int pacingMs = 25;          // 1.7.5: friend: pictures shown on the host's clock + this margin
        bool upnp = true, stun = true;
        std::string name;
        std::string lobby;          // the lobby server (lobby-server/), "" = no public list
        bool publicList = true;     // host: list the game there
    };

    Options LoadOptions()
    {
        const std::string ini = Paths::GetConfigPath();
        auto get = [&](const char* key, int def) {
            const int none = -987654;
            const int v = static_cast<int>(GetPrivateProfileIntA("Online", key, none, ini.c_str()));
            if (v == none) { WritePrivateProfileStringA("Online", key, std::to_string(def).c_str(), ini.c_str()); return def; }
            return v;
        };
        Options o;
        o.port = std::clamp(get("Port", o.port), 1024, 65535);
        // 1.7.8: the old defaults (900p, 12 Mbps) move up to 1080p 20 Mbps once; values changed by hand stay
        if (GetPrivateProfileIntA("Online", "StreamDefaults", 1, ini.c_str()) < 2)
        {
            if (GetPrivateProfileIntA("Online", "StreamHeight", 900, ini.c_str()) == 900) WritePrivateProfileStringA("Online", "StreamHeight", "1080", ini.c_str());
            if (GetPrivateProfileIntA("Online", "BitrateKbps", 12000, ini.c_str()) == 12000) WritePrivateProfileStringA("Online", "BitrateKbps", "20000", ini.c_str());
            WritePrivateProfileStringA("Online", "StreamDefaults", "2", ini.c_str());
        }
        o.height = get("StreamHeight", o.height);
        o.fps = get("StreamFPS", o.fps);
        o.bitrate = get("BitrateKbps", o.bitrate);
        o.lowerRes = get("LowerResolution", 0) != 0;
        o.minBitrate = get("MinBitrateKbps", o.minBitrate);
        o.hardware = get("HardwareEncoder", 0) != 0;   // 1.5.4: off by default - the NVIDIA one froze a host PC
        o.helper = get("EncoderHelper", 1) != 0;
        o.keyframeSeconds = get("KeyframeSeconds", o.keyframeSeconds);
        o.profile = get("H264Profile", o.profile);
        o.effort = get("EncoderEffort", o.effort);
        o.fec = std::clamp(get("ParityPercent", o.fec), 0, 100);
        o.audioMs = get("AudioBufferMs", o.audioMs);
        o.burst = std::clamp(get("PacketBurst", o.burst), 0, 1000);
        o.conceal = get("ConcealLoss", 1) != 0;
        o.hwDecode = get("HardwareDecoder", 1) != 0;
        o.pacingMs = get("PacingBufferMs", 25);
        o.viewerFit = get("ViewerFit", 1);
        o.upnp = get("UPnP", 1) != 0;
        o.stun = get("FindPublicAddress", 1) != 0;
        char name[64]{};
        GetPrivateProfileStringA("Online", "Name", "", name, sizeof(name), ini.c_str());
        o.name = name;
        char lobby[256]{};
        GetPrivateProfileStringA("Online", "LobbyServer", "", lobby, sizeof(lobby), ini.c_str());
        o.lobby = lobby;
        if (o.lobby.empty()) o.lobby = DAOCOOP_LOBBY_SERVER;          // the mod's own server
        if (_stricmp(o.lobby.c_str(), "off") == 0) o.lobby.clear();
        while (!o.lobby.empty() && (o.lobby.back() == '/' || o.lobby.back() == ' ')) o.lobby.pop_back();
        o.publicList = get("PublicList", 1) != 0;
        if (o.name.empty())
        {
            char user[64]{};
            DWORD n = sizeof(user);
            if (GetUserNameA(user, &n) && user[0]) o.name = user;
        }
        return o;
    }

    // ---------------- state ----------------
    enum class Role { Off, Host, Join };
    enum class Stage { None, Window, Asking, Connecting, Watching };

    struct Peer
    {
        bool on = false;
        sockaddr_in addr{};
        uint32_t clientId = 0, heardMs = 0, rtt = 0, inputSeq = 0, lastInputAt = 0, connectedAt = 0, lastStatsLog = 0;
        bool haveSeq = false, rested = true, haveStats = false;
        std::string name;
        int slot = -1;                 // host: controller slot 4/5 this friend plays with
        P::StatsMsg stats{}, prevStats{};
        int bitrate = 0, calm = 0, lossy = 0; uint32_t maxGap = 0;     // host: what this friend's link takes
    };
    struct LanGame { sockaddr_in addr{}; std::string name; uint32_t token = 0; bool full = false; uint32_t seenMs = 0; };

    std::mutex g_lifeMutex;             // start / stop
    std::mutex g_mutex;                 // everything below, unless noted
    Options g_opt;
    std::atomic<int> g_burst{ 8 };   // 1.7.1: [Online] PacketBurst (the stream's pacing)
    std::atomic<int> g_role{ static_cast<int>(Role::Off) };
    Stage g_stage = Stage::None;
    SOCKET g_sock = INVALID_SOCKET;
    uint16_t g_boundPort = 0;
    // (never destroyed: the game can close while online, and a joinable std::thread at exit ends the process)
    std::thread& g_net = *new std::thread();
    std::thread& g_setup = *new std::thread();
    std::atomic<bool> g_netRun{ false };
    bool g_timerRes = false;
    std::deque<std::wstring> g_messages;

    // host
    uint32_t g_token = 0, g_session = 0;
    std::string g_code, g_codeNote, g_codeWarn;
    bool g_setupDone = false;
    std::atomic<uint32_t> g_stunIp{ 0 };
    std::atomic<uint16_t> g_stunPort{ 0 };
    uint8_t g_stunTx[12]{};
    bool g_upnpMapped = false;
    uint16_t g_upnpPort = 0;
    Peer g_peers[kMaxFriends];
    std::atomic<bool> g_streaming{ false };
    std::mutex g_streamMutex;           // the friends' addresses for the encoder / sound threads
    sockaddr_in g_streamAddr[kMaxFriends]{};
    bool g_streamOn[kMaxFriends]{};
    P::VideoHistory g_history(150);
    std::atomic<uint32_t> g_nextFrame{ 1 }, g_audioSeq{ 0 };
    // 1.7.0: each friend their own player's picture (views.h mode 3): channel c goes to friend c only.
    // Channel 1 has its own history and frame numbers; channel 0 uses the ones above.
    std::atomic<bool> g_perPlayer{ false };
    int g_streamSlot[kMaxFriends] = { -1, -1 };   // (g_streamMutex) the friends' controller slots, for the picture source
    P::VideoHistory g_history1(150);
    std::atomic<uint32_t> g_nextFrame1{ 1 };
    std::atomic<int> g_fec{ 20 };
    std::atomic<uint32_t> g_hostGen{ 0 };
    P::AdpcmState g_adpcm[2];           // sound thread only
    std::atomic<uint64_t> g_bytesOut{ 0 };
    std::atomic<uint32_t> g_sendFails{ 0 };          // 1.7.1: packets the network refused to take (send buffer full)
    uint32_t g_lastVideoMs = 0, g_maxGapMs = 0;      // 1.7.1: friend: the longest wait between the host's picture packets
    double g_kbpsOut = 0;
    int g_bitrateNow = 0;
    uint32_t g_lastKeyReq = 0;

    // host: the public list (1.4.0)
    std::string g_pubAddr, g_lanAddr;   // where friends reach this game ("a.b.c.d:port")
    bool g_locked = false;              // off the public list (invite codes still work)
    int g_lockPref = -1;                // 1.4.1: the lobby's lock button (remembered in DAOCoop.ini, [Online] Locked)
    bool g_listed = false;              // OnlineLobby host session started
    int g_infoPlayers = 1, g_infoMax = 3, g_infoOpen = 2;
    std::string g_infoArea;
    uint32_t g_infoSentAt = 0;
    std::string g_infoSent;
    struct Pending { OnlineLobby::Request r; uint32_t at = 0, remindAt = 0; };
    std::deque<Pending> g_pending;      // join requests waiting for the host's answer
    struct Accepted { uint32_t token = 0, until = 0; std::string name; };
    std::vector<Accepted> g_accepted;   // one-time passes for accepted requests
    struct Punch { sockaddr_in a{}, b{}; bool haveA = false, haveB = false; uint32_t until = 0; };
    std::vector<Punch> g_punch;         // host -> accepted player: open the way through the routers
    WORD g_hostPrevPad = 0;
    bool g_hostPrevKeys[5]{};
    bool g_popShown = false;            // 1.4.1 join pop-up
    int g_popSel = 0, g_popStick = 0;   // 0 Yes, 1 No
    uint32_t g_popAt = 0;

    // friend
    Peer g_host;
    sockaddr_in g_altAddr{};            // the host's other address (its home network), tried too
    bool g_haveAlt = false;
    int g_sel = 0;                      // the chosen game in the list
    std::string g_askName;              // the host we asked
    WORD g_browsePrev = 0;
    bool g_browseKeysPrev[4]{};
    P::VideoReceiver g_rx;              // network thread only
    uint32_t g_helloAt = 0, g_connectStart = 0, g_discoverAt = 0, g_clipAt = 0;
    uint32_t g_joinToken = 0, g_clientId = 0;
    std::string g_error, g_lastClip;
    std::string g_ownCode;
    // 1.4.6 the co-op lobby for friends: host -> what it sends; friend -> what it got
    std::string g_lobbyOut;             // host: UTF-8 lines, "" = not in the lobby
    std::string g_lobbyIn;              // friend
    uint8_t g_lobbySlot = 0, g_lobbyReady = 0;
    uint32_t g_lobbyInAt = 0, g_watchSince = 0, g_videoPackets = 0;              // the last invite code this game made (not joined from the clipboard)
    std::vector<LanGame> g_lan;
    int32_t g_clockOffset = 0;          // host clock - our clock
    uint32_t g_bestRtt = UINT32_MAX, g_offsetAt = 0, g_latencyMs = 0;
    bool g_haveOffset = false;
    int g_padUser = -1;
    uint32_t g_padScanAt = 0, g_inputSeq = 0, g_leaveHold = 0, g_escHold = 0, g_lastInputSent = 0;
    WORD g_prevButtons = 0;
    XINPUT_GAMEPAD g_lastSent{};
    uint32_t g_startAt = 0, g_startTapUntil = 0;   // 1.7.2: the co-op menu's button held (1.7.7: View)
    bool g_startFired = false;
    uint32_t g_chatStartUntil = 0;                   // 1.7.8: a START tap passed on to the host until then
    bool g_chatWasTyping = false;
    std::atomic<uint32_t> g_stepAwayUntil{ 0 };     // 1.7.7: "Step away" from the co-op menu: View held on the host till then
    // 1.7.2 voice chat: where this friend's voice goes (the voice thread reads it)
    std::mutex g_voiceMutex;
    sockaddr_in g_voiceHost{};
    uint32_t g_voiceSession = 0;

    Role RoleNow() { return static_cast<Role>(g_role.load()); }
    std::wstring Wide(const std::string& s)
    {
        std::wstring w;
        const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n); }
        return w;
    }
    // g_mutex held.
    void Message(const std::string& text)
    {
        Logger::WriteFormat(Logger::Level::Info, "Online: %s", text.c_str());
        if (g_messages.size() < 16) g_messages.push_back(Wide(text));
    }

    std::string AddrText(const sockaddr_in& a)
    {
        char ip[INET_ADDRSTRLEN]{};
        inet_ntop(AF_INET, &a.sin_addr, ip, sizeof(ip));
        return std::string(ip) + ":" + std::to_string(ntohs(a.sin_port));
    }
    std::string IpText(uint32_t ip)
    {
        char t[32];
        std::snprintf(t, sizeof(t), "%u.%u.%u.%u", ip >> 24, (ip >> 16) & 255, (ip >> 8) & 255, ip & 255);
        return t;
    }
    bool SameAddr(const sockaddr_in& a, const sockaddr_in& b)
    {
        return a.sin_addr.s_addr == b.sin_addr.s_addr && a.sin_port == b.sin_port;
    }
    uint32_t Random32()
    {
        static std::mt19937 rng([] { std::random_device rd; return rd() ^ static_cast<uint32_t>(OnlineClock::NowUs()); }());
        uint32_t v = 0;
        while (!v) v = rng();
        return v;
    }
    bool PrivateIp(uint32_t ip)
    {
        return (ip >> 24) == 10 || (ip >> 20) == 0xAC1 || (ip >> 16) == 0xC0A8 || (ip >> 22) == (100u << 2 | 1u) || (ip >> 24) == 127 || (ip >> 16) == 0xA9FE;
    }
    bool CarrierNat(uint32_t ip) { return (ip & 0xFFC00000u) == 0x64400000u; }   // 100.64.0.0/10

    // The public list only matches games that speak the same stream protocol.
    std::string LobbyVersion() { return "p" + std::to_string(static_cast<int>(P::kVersion)); }
    bool ParseAddr(const std::string& t, sockaddr_in& out)
    {
        unsigned a, b, c, d, port;
        if (std::sscanf(t.c_str(), "%u.%u.%u.%u:%u", &a, &b, &c, &d, &port) != 5 || a > 255 || b > 255 || c > 255 || d > 255 || !port || port > 65535) return false;
        out = sockaddr_in{};
        out.sin_family = AF_INET;
        out.sin_addr.s_addr = htonl((a << 24) | (b << 16) | (c << 8) | d);
        out.sin_port = htons(static_cast<u_short>(port));
        return true;
    }

    void Send(const sockaddr_in& to, const void* data, size_t n)
    {
        if (g_sock == INVALID_SOCKET) return;
        const int r = sendto(g_sock, static_cast<const char*>(data), static_cast<int>(n), 0, reinterpret_cast<const sockaddr*>(&to), sizeof(to));
        if (r > 0) g_bytesOut.fetch_add(static_cast<uint64_t>(r), std::memory_order_relaxed);
        else g_sendFails.fetch_add(1, std::memory_order_relaxed);
    }
    template <typename T> void SendMsg(const sockaddr_in& to, T& m, uint8_t type, uint32_t session)
    {
        P::Fill(m, type, session);
        Send(to, &m, sizeof(m));
    }
    void SendRefuse(const sockaddr_in& to, uint32_t session, const std::string& why)
    {
        P::RefuseMsg m{};
        P::CopyName(m.reason, sizeof(m.reason), why);
        SendMsg(to, m, P::kRefuse, session);
    }
    void SendBye(const sockaddr_in& to, uint32_t session, const char* why)
    {
        P::ByeMsg m{};
        P::CopyName(m.reason, sizeof(m.reason), why);
        for (int i = 0; i < 3; ++i) SendMsg(to, m, P::kBye, session);
    }

    // ---------------- the friend's own controller (read straight from XInput, never routed) ----------------
    bool ReadOwnPad(XINPUT_GAMEPAD& pad)
    {
        const uint32_t now = Now();
        XINPUT_STATE st{};
        if (g_padUser >= 0 && XInputGetState(static_cast<DWORD>(g_padUser), &st) == ERROR_SUCCESS) { pad = st.Gamepad; return true; }
        if (g_padUser >= 0 || static_cast<int32_t>(now - g_padScanAt) >= 0)
        {
            g_padScanAt = now + 500;
            for (DWORD u = 0; u < 4; ++u)
                if (XInputGetState(u, &st) == ERROR_SUCCESS) { g_padUser = static_cast<int>(u); pad = st.Gamepad; return true; }
            g_padUser = -1;
        }
        pad = XINPUT_GAMEPAD{};
        return false;
    }

    bool OurWindowInFront()
    {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        return pid == GetCurrentProcessId();
    }

    // The game's main window (the clipboard needs an owner window).
    struct FindWindowCtx { HWND w; DWORD pid; };
    BOOL CALLBACK FindGameWindow(HWND w, LPARAM lp)
    {
        auto* f = reinterpret_cast<FindWindowCtx*>(lp);
        DWORD pid = 0;
        GetWindowThreadProcessId(w, &pid);
        if (pid == f->pid && IsWindowVisible(w) && !GetWindow(w, GW_OWNER)) { f->w = w; return FALSE; }
        return TRUE;
    }
    HWND GameWindow()
    {
        FindWindowCtx f{ nullptr, GetCurrentProcessId() };
        EnumWindows(FindGameWindow, reinterpret_cast<LPARAM>(&f));
        return f.w;
    }

    void CopyToClipboard(const std::string& text)
    {
        if (!OpenClipboard(GameWindow())) return;
        EmptyClipboard();
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
        if (h)
        {
            if (void* p = GlobalLock(h)) { std::memcpy(p, text.c_str(), text.size() + 1); GlobalUnlock(h); }
            if (!SetClipboardData(CF_TEXT, h)) GlobalFree(h);
        }
        CloseClipboard();
    }
    std::string ClipboardText()
    {
        std::string out;
        if (!OpenClipboard(nullptr)) return out;
        if (HANDLE h = GetClipboardData(CF_UNICODETEXT))
        {
            if (const wchar_t* w = static_cast<const wchar_t*>(GlobalLock(h)))
            {
                const int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
                if (n > 1 && n < 4096) { out.assign(static_cast<size_t>(n - 1), '\0'); WideCharToMultiByte(CP_UTF8, 0, w, -1, &out[0], n, nullptr, nullptr); }
                GlobalUnlock(h);
            }
        }
        CloseClipboard();
        return out;
    }

    // ---------------- the router: UPnP (Windows' own NAT traversal COM object, late bound) ----------------
    HRESULT DispCall(IDispatch* d, const wchar_t* name, WORD flags, VARIANT* args, UINT argc, VARIANT* result)
    {
        if (result) VariantInit(result);   // (callers clear it whatever happens)
        DISPID id = 0;
        LPOLESTR n = const_cast<LPOLESTR>(name);
        HRESULT hr = d->GetIDsOfNames(IID_NULL, &n, 1, LOCALE_USER_DEFAULT, &id);
        if (FAILED(hr)) return hr;
        DISPPARAMS dp{ args, nullptr, argc, 0 };
        EXCEPINFO ei{};
        UINT argErr = 0;
        hr = d->Invoke(id, IID_NULL, LOCALE_USER_DEFAULT, flags, &dp, result, &ei, &argErr);
        if (ei.bstrSource) SysFreeString(ei.bstrSource);
        if (ei.bstrDescription) SysFreeString(ei.bstrDescription);
        if (ei.bstrHelpFile) SysFreeString(ei.bstrHelpFile);
        return hr;
    }

    IDispatch* UpnpCollection(std::string& why)
    {
        CLSID clsid{};
        if (FAILED(CLSIDFromProgID(L"HNetCfg.NATUPnP", &clsid))) { why = "UPnP is not part of this Windows"; return nullptr; }
        IDispatch* nat = nullptr;
        if (FAILED(CoCreateInstance(clsid, nullptr, CLSCTX_INPROC_SERVER, IID_IDispatch, reinterpret_cast<void**>(&nat))) || !nat)
        {
            why = "UPnP could not start";
            return nullptr;
        }
        IDispatch* coll = nullptr;
        // the first ask searches the network for the router; it can come back empty while that runs
        for (int tries = 0; tries < 4 && !coll; ++tries)
        {
            VARIANT v;
            if (SUCCEEDED(DispCall(nat, L"StaticPortMappingCollection", DISPATCH_PROPERTYGET, nullptr, 0, &v)) && v.vt == VT_DISPATCH && v.pdispVal)
                coll = v.pdispVal;
            else
            {
                VariantClear(&v);
                Sleep(1200);
            }
        }
        nat->Release();
        if (!coll) why = "the router did not answer UPnP (it may be switched off in the router)";
        return coll;
    }

    bool UpnpMap(uint16_t port, uint32_t lanIp, uint32_t& externalIp, std::string& why)
    {
        IDispatch* coll = UpnpCollection(why);
        if (!coll) return false;
        // an old mapping of this port (from a game that closed without removing it) goes first
        {
            VARIANT args[2];
            args[1].vt = VT_I4; args[1].lVal = port;
            args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"UDP");
            VARIANT r;
            DispCall(coll, L"Remove", DISPATCH_METHOD, args, 2, &r);
            VariantClear(&r);
            SysFreeString(args[0].bstrVal);
        }
        const std::string lan = IpText(lanIp);
        const std::wstring wlan(lan.begin(), lan.end());
        VARIANT args[6];
        args[5].vt = VT_I4; args[5].lVal = port;                                    // external port
        args[4].vt = VT_BSTR; args[4].bstrVal = SysAllocString(L"UDP");
        args[3].vt = VT_I4; args[3].lVal = port;                                    // internal port
        args[2].vt = VT_BSTR; args[2].bstrVal = SysAllocString(wlan.c_str());       // this PC
        args[1].vt = VT_BOOL; args[1].boolVal = VARIANT_TRUE;
        args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"Dragon Age Origins co-op");
        VARIANT mapping;
        const HRESULT hr = DispCall(coll, L"Add", DISPATCH_METHOD, args, 6, &mapping);
        SysFreeString(args[4].bstrVal); SysFreeString(args[2].bstrVal); SysFreeString(args[0].bstrVal);
        bool ok = SUCCEEDED(hr) && mapping.vt == VT_DISPATCH && mapping.pdispVal;
        if (ok)
        {
            VARIANT ext;
            if (SUCCEEDED(DispCall(mapping.pdispVal, L"ExternalIPAddress", DISPATCH_PROPERTYGET, nullptr, 0, &ext)) && ext.vt == VT_BSTR && ext.bstrVal)
            {
                char ip[64]{};
                WideCharToMultiByte(CP_UTF8, 0, ext.bstrVal, -1, ip, sizeof(ip) - 1, nullptr, nullptr);
                in_addr a{};
                if (inet_pton(AF_INET, ip, &a) == 1) externalIp = ntohl(a.s_addr);
            }
            VariantClear(&ext);
        }
        else
        {
            char t[96];
            std::snprintf(t, sizeof(t), "the router refused to open the port (0x%08lX)", static_cast<unsigned long>(hr));
            why = t;
        }
        VariantClear(&mapping);
        coll->Release();
        return ok;
    }

    std::mutex g_upnpMutex;                       // one UPnP job at a time
    std::atomic<uint32_t> g_upnpMappedGen{ 0 };   // the hosting session whose mapping is on the router (0: none)

    // COM is initialized by the caller.
    void UpnpRemoveNow(uint16_t port)
    {
        std::string why;
        if (IDispatch* coll = UpnpCollection(why))
        {
            VARIANT args[2];
            args[1].vt = VT_I4; args[1].lVal = port;
            args[0].vt = VT_BSTR; args[0].bstrVal = SysAllocString(L"UDP");
            VARIANT r;
            DispCall(coll, L"Remove", DISPATCH_METHOD, args, 2, &r);
            VariantClear(&r);
            SysFreeString(args[0].bstrVal);
            coll->Release();
        }
    }

    // The mapping of hosting session `gen`, removed in the background (not if a newer session made its own).
    void UpnpUnmap(uint16_t port, uint32_t gen)
    {
        std::thread([port, gen] {
            std::lock_guard<std::mutex> up(g_upnpMutex);
            if (g_upnpMappedGen.load() != gen) return;
            if (FAILED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED))) return;
            UpnpRemoveNow(port);
            g_upnpMappedGen.store(0);
            CoUninitialize();
        }).detach();
    }

    // ---------------- this PC's address on its network, and on the internet (STUN) ----------------
    uint32_t LocalIp()
    {
        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (s == INVALID_SOCKET) return 0;
        sockaddr_in to{};
        to.sin_family = AF_INET;
        to.sin_port = htons(53);
        inet_pton(AF_INET, "8.8.8.8", &to.sin_addr);   // no packet is sent: this only picks the route
        uint32_t ip = 0;
        if (connect(s, reinterpret_cast<sockaddr*>(&to), sizeof(to)) == 0)
        {
            sockaddr_in me{};
            int len = sizeof(me);
            if (getsockname(s, reinterpret_cast<sockaddr*>(&me), &len) == 0) ip = ntohl(me.sin_addr.s_addr);
        }
        closesocket(s);
        return ip;
    }

    void StunAsk()
    {
        const char* servers[][2] = { { "stun.l.google.com", "19302" }, { "stun.cloudflare.com", "3478" }, { "stun1.l.google.com", "19302" } };
        uint8_t req[20]{};
        req[0] = 0x00; req[1] = 0x01;                 // binding request, no attributes
        req[4] = 0x21; req[5] = 0x12; req[6] = 0xA4; req[7] = 0x42;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            for (int i = 0; i < 12; ++i) g_stunTx[i] = static_cast<uint8_t>(Random32());
            std::memcpy(req + 8, g_stunTx, 12);
        }
        for (auto& s : servers)
        {
            addrinfo hints{};
            hints.ai_family = AF_INET;
            hints.ai_socktype = SOCK_DGRAM;
            addrinfo* res = nullptr;
            if (getaddrinfo(s[0], s[1], &hints, &res) != 0 || !res) continue;
            sockaddr_in to{};
            std::memcpy(&to, res->ai_addr, std::min<size_t>(sizeof(to), res->ai_addrlen));
            freeaddrinfo(res);
            Send(to, req, sizeof(req));
        }
    }

    bool IsStun(const uint8_t* d, int n)
    {
        return n >= 20 && d[4] == 0x21 && d[5] == 0x12 && d[6] == 0xA4 && d[7] == 0x42 && (d[0] & 0xC0) == 0;
    }

    void HandleStun(const uint8_t* d, int n)
    {
        if (d[0] != 0x01 || d[1] != 0x01) return;   // binding success
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (std::memcmp(d + 8, g_stunTx, 12) != 0) return;
        }
        const int len = (d[2] << 8) | d[3];
        int at = 20;
        while (at + 4 <= n && at + 4 <= 20 + len)
        {
            const int type = (d[at] << 8) | d[at + 1], alen = (d[at + 2] << 8) | d[at + 3];
            const uint8_t* v = d + at + 4;
            if (at + 4 + alen > n) break;
            if ((type == 0x0020 || type == 0x0001) && alen >= 8 && v[1] == 0x01)
            {
                uint16_t port = static_cast<uint16_t>((v[2] << 8) | v[3]);
                uint32_t ip = (uint32_t(v[4]) << 24) | (uint32_t(v[5]) << 16) | (uint32_t(v[6]) << 8) | v[7];
                if (type == 0x0020) { port ^= 0x2112; ip ^= 0x2112A442u; }
                if (!g_stunIp.load()) { g_stunPort.store(port); g_stunIp.store(ip); }
                return;
            }
            at += 4 + ((alen + 3) & ~3);
        }
    }
    // ---------------- host: the stream (one encoder, sent to every friend) ----------------
    void SendEncoded(int ch, const uint8_t* data, size_t size, bool key, uint16_t w, uint16_t h, uint32_t captureMs)
    {
        if (!g_streaming.load(std::memory_order_relaxed)) return;
        bool per = g_perPlayer.load(std::memory_order_relaxed);
        if (per && !OnlineVideo::ExtraRunning(1))
        {
            g_perPlayer.store(false);       // the second stream is gone: everyone gets Player 1's picture again
            per = false;
            Logger::Write(Logger::Level::Warning, "Online: per-player streams off - both friends get the host's picture");
        }
        if (!per && ch != 0) return;
        sockaddr_in to[kMaxFriends]{};
        bool on[kMaxFriends]{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_streamMutex);
            for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
            session = g_session;
        }
        std::vector<std::vector<uint8_t>> packets;
        const uint32_t frame = (ch == 1 ? g_nextFrame1 : g_nextFrame).fetch_add(1);
        P::BuildVideoPackets(session, frame, data, size, key, w, h, captureMs, g_fec.load(), packets);
        // 1.7.1: paced - a whole 1080p frame (60-90 packets) sent at once overflowed the home network now and then
        // (about half the frames needed a packet sent again, and each of those came late: the friend's picture
        // stuttered). Now a few packets, then 1 ms, so a frame goes out over ~10 ms of the 33 between frames.
        const int burst = g_burst.load(std::memory_order_relaxed);
        for (size_t k = 0; k < packets.size(); ++k)
        {
            for (int i = 0; i < kMaxFriends; ++i)
                if (on[i] && (!per || i == ch)) Send(to[i], packets[k].data(), packets[k].size());
            if (burst > 0 && (k + 1) % static_cast<size_t>(burst) == 0 && k + 1 < packets.size()) Sleep(1);
        }
        (ch == 1 ? g_history1 : g_history).Store(frame, packets);
    }
    void OnEncoded(const uint8_t* data, size_t size, bool key, uint16_t w, uint16_t h, uint32_t captureMs) { SendEncoded(0, data, size, key, w, h, captureMs); }
    void OnEncoded1(const uint8_t* data, size_t size, bool key, uint16_t w, uint16_t h, uint32_t captureMs) { SendEncoded(1, data, size, key, w, h, captureMs); }
    // the stream a friend gets
    int ChannelOf(int friendIndex) { return g_perPlayer.load() && friendIndex == 1 ? 1 : 0; }

    // Render thread: what channel c streams - friend c's own player's picture (per-player streams), or
    // null for the back buffer (Player 1's picture: conversations, cutscenes, a friend not playing yet ...).
    IDirect3DSurface9* StreamSource(int ch)
    {
        if (ch < 0 || ch >= kMaxFriends) return nullptr;
        int slot = -1;
        if (!g_perPlayer.load(std::memory_order_relaxed))
        {
            // 1.7.8: one encoder only (no DAOCoopStream.exe): the one stream still carries the friend's own view when
            // just one friend is in (with two, both get the host's picture)
            if (ch != 0) return nullptr;
            std::lock_guard<std::mutex> lock(g_streamMutex);
            int on = 0;
            for (int i = 0; i < kMaxFriends; ++i) if (g_streamOn[i]) { ++on; slot = g_streamSlot[i]; }
            if (on != 1) return nullptr;
        }
        else { std::lock_guard<std::mutex> lock(g_streamMutex); slot = g_streamSlot[ch]; }
        if (slot < 0) return nullptr;
        int player = PadsIndex(PLAYER_2) == slot ? 2 : PadsIndex(PLAYER_3) == slot ? 3 : 0;
        return player ? ViewsPicture(player) : nullptr;
    }

    // 1.7.1: a stream nobody gets is not taken: with 2 players the second per-player stream used to copy and encode
    // Player 1's picture every frame for no one (several ms of the host's frame)
    bool ChannelWanted(int ch)
    {
        const bool per = g_perPlayer.load(std::memory_order_relaxed);
        std::lock_guard<std::mutex> lock(g_streamMutex);
        if (!per) { if (ch != 0) return false; for (int i = 0; i < kMaxFriends; ++i) if (g_streamOn[i]) return true; return false; }
        return ch >= 0 && ch < kMaxFriends && g_streamOn[ch];
    }

    void OnSound(const int16_t* stereo, int frames)
    {
        if (!g_streaming.load(std::memory_order_relaxed)) { g_adpcm[0] = g_adpcm[1] = P::AdpcmState{}; return; }
        sockaddr_in to[kMaxFriends]{};
        bool on[kMaxFriends]{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_streamMutex);
            for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
            session = g_session;
        }
        const auto pkt = P::BuildAudioPacket(session, g_audioSeq.fetch_add(1), stereo, frames, g_adpcm);
        for (int i = 0; i < kMaxFriends; ++i) if (on[i]) Send(to[i], pkt.data(), pkt.size());
    }

    // 1.7.2 voice chat. Who talks: 1 the host, 2/3 the friend playing Player 2/3, 4+ a friend without a player.
    uint8_t SpeakerOf(int pi)   // g_mutex held
    {
        const int slot = g_peers[pi].slot;
        if (slot >= 0 && PadsIndex(PLAYER_2) == slot) return 2;
        if (slot >= 0 && PadsIndex(PLAYER_3) == slot) return 3;
        return static_cast<uint8_t>(4 + pi);
    }
    void OnHostVoice(uint32_t seq, uint8_t level, const int16_t* mono, int samples)
    {
        sockaddr_in to[kMaxFriends]{};
        bool on[kMaxFriends]{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_streamMutex);
            for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
            session = g_session;
        }
        const auto pkt = P::BuildVoicePacket(session, seq, 1, level, mono, samples);
        for (int i = 0; i < kMaxFriends; ++i) if (on[i]) Send(to[i], pkt.data(), pkt.size());
    }
    // a friend's own voice to the host
    void OnJoinVoice(uint32_t seq, uint8_t level, const int16_t* mono, int samples)
    {
        sockaddr_in to{};
        uint32_t session = 0;
        {
            std::lock_guard<std::mutex> lock(g_voiceMutex);
            to = g_voiceHost; session = g_voiceSession;
        }
        if (!to.sin_port) return;
        const auto pkt = P::BuildVoicePacket(session, seq, 0, level, mono, samples);
        Send(to, pkt.data(), pkt.size());
    }

    // 1.7.8: the game's name on the list, made from the host's name: "Ali's Server" ("James' Server")
    std::string ServerName(const std::string& host)
    {
        std::string n = host.empty() ? std::string("Host") : host;
        if (n.size() > 22) n.resize(22);
        while (!n.empty() && n.back() == ' ') n.pop_back();
        const char last = n.empty() ? 0 : n.back();
        return n + (last == 's' || last == 'S' ? "' Server" : "'s Server");
    }
    // 1.7.8 text chat. Each message goes 3 times (UDP may drop one); the copies are told apart by (sender, id).
    std::atomic<uint32_t> g_chatId{ 0 };
    std::mutex g_chatMutex;
    std::deque<uint64_t> g_chatSeen;   // (g_chatMutex)
    bool ChatFirstTime(uint64_t key)
    {
        std::lock_guard<std::mutex> lock(g_chatMutex);
        if (std::find(g_chatSeen.begin(), g_chatSeen.end(), key) != g_chatSeen.end()) return false;
        g_chatSeen.push_back(key);
        while (g_chatSeen.size() > 64) g_chatSeen.pop_front();
        return true;
    }
    std::vector<uint8_t> ChatPacket(uint32_t session, uint32_t id, uint8_t from, const std::string& name, const std::string& text)
    {
        P::ChatMsg m{};
        P::Fill(m, P::kChat, session);
        m.id = id; m.from = from;
        P::CopyName(m.name, sizeof(m.name), name);
        P::CopyName(m.text, sizeof(m.text), text);
        const auto* b = reinterpret_cast<const uint8_t*>(&m);
        return std::vector<uint8_t>(b, b + sizeof(m));
    }
    // OnlineChat's sender: something this PC wrote (localPlayer 0) or a co-op player on the host's PC picked (2 / 3)
    void OnChatSend(uint8_t localPlayer, const std::string& name, const std::string& text)
    {
        if (text.empty()) return;
        if (!g_chatId.load()) g_chatId.store((GetTickCount() * 2654435761u) | 1u);
        const uint32_t id = g_chatId.fetch_add(1);
        const Role r = RoleNow();
        if (r == Role::Host && (localPlayer == 0xFE || localPlayer == 0xFD)) {   // a notice / menu status: shown here already, to the friends as it is
            sockaddr_in to[kMaxFriends]{};
            bool on[kMaxFriends]{};
            uint32_t session = 0;
            {
                std::lock_guard<std::mutex> lock(g_streamMutex);
                for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
                session = g_session;
            }
            const auto pkt = ChatPacket(session, id, localPlayer, "", text);
            for (int k = 0; k < 2; ++k)
                for (int i = 0; i < kMaxFriends; ++i) if (on[i]) Send(to[i], pkt.data(), pkt.size());
            return;
        }
        if (r == Role::Host) {
            std::string who = name;
            if (who.empty()) { std::lock_guard<std::mutex> lock(g_mutex); who = g_opt.name.empty() ? "Host" : g_opt.name; }
            const uint8_t from = localPlayer >= 2 && localPlayer <= 3 ? localPlayer : 1;
            sockaddr_in to[kMaxFriends]{};
            bool on[kMaxFriends]{};
            uint32_t session = 0;
            {
                std::lock_guard<std::mutex> lock(g_streamMutex);
                for (int i = 0; i < kMaxFriends; ++i) { to[i] = g_streamAddr[i]; on[i] = g_streamOn[i]; }
                session = g_session;
            }
            const auto pkt = ChatPacket(session, id, from, who, text);
            for (int k = 0; k < 3; ++k)
                for (int i = 0; i < kMaxFriends; ++i) if (on[i]) Send(to[i], pkt.data(), pkt.size());
            OnlineChat::Add(from, who, text);
        } else if (r == Role::Join) {
            std::string who;
            { std::lock_guard<std::mutex> lock(g_mutex); who = g_opt.name.empty() ? "Friend" : g_opt.name; }
            sockaddr_in to{};
            uint32_t session = 0;
            {
                std::lock_guard<std::mutex> lock(g_voiceMutex);
                to = g_voiceHost; session = g_voiceSession;
            }
            if (!to.sin_port) return;
            const auto pkt = ChatPacket(session, id, 0, who, text);
            for (int k = 0; k < 3; ++k) Send(to, pkt.data(), pkt.size());
            OnlineChat::Add(0, who, text);
        }
    }

    // g_mutex held: the stream's list of friends follows g_peers.
    void SyncStreamTargets()
    {
        std::lock_guard<std::mutex> lock(g_streamMutex);
        for (int i = 0; i < kMaxFriends; ++i) { g_streamOn[i] = g_peers[i].on; g_streamAddr[i] = g_peers[i].addr; g_streamSlot[i] = g_peers[i].on ? g_peers[i].slot : -1; }
    }

    void StartStream(const Options& o)
    {
        g_burst.store(o.burst);
        if (g_streaming.exchange(true)) { OnlineVideo::RequestKeyframe(); return; }
        g_history.Clear();
        g_history1.Clear();
        OnlineVideo::Settings vs;
        vs.height = o.height; vs.fps = o.fps; vs.bitrateKbps = o.bitrate; vs.gopSeconds = o.keyframeSeconds;
        vs.profile = o.profile; vs.qualityVsSpeed = o.effort; vs.hardware = o.hardware;
        if (o.helper)
        {
            const std::string ini = Paths::GetConfigPath();          // <game>\DAOCoop\DAOCoop.ini
            const size_t cut = ini.find_last_of("\\/");
            if (cut != std::string::npos)
            {
                const std::string exe = ini.substr(0, cut + 1) + "DAOCoopStream.exe";
                const int n = MultiByteToWideChar(CP_ACP, 0, exe.c_str(), -1, nullptr, 0);
                if (n > 1) { vs.helperPath.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_ACP, 0, exe.c_str(), -1, &vs.helperPath[0], n); }
            }
        }
        g_bitrateNow = o.bitrate;
        OnlineVideo::SetPictureSource(&StreamSource);
        OnlineVideo::SetChannelWanted(&ChannelWanted);
        OnlineVideo::SetLowerResolution(o.lowerRes);
        OnlineVideo::StartHost(vs, OnEncoded);
        OnlineVideo::RequestKeyframe();
        // 1.7.0: views mode 3 - a second encoder, so each friend gets their own player's picture
        g_perPlayer.store(false);
        if (ViewsOnline())
        {
            if (OnlineVideo::StartExtra(1, vs, OnEncoded1)) { g_perPlayer.store(true); Logger::Write(Logger::Level::Info, "Online: per-player streams - each friend sees their own character's view"); }
            else Logger::Write(Logger::Level::Warning, "Online: per-player streams not possible (DAOCoopStream.exe needed) - both friends get the host's picture");
        }
        OnlineAudio::StartCapture(OnSound);
        OnlineVoice::Start(OnHostVoice);
    }
    void StopStream()
    {
        if (!g_streaming.exchange(false)) return;
        g_perPlayer.store(false);
        OnlineVideo::StopExtra(1);
        OnlineVideo::StopHost();
        OnlineAudio::StopCapture();
        OnlineVoice::Stop();
    }

    // The stream's bitrate: what the weakest friend's link takes. g_mutex held.
    void ApplyBitrate()
    {
        if (g_perPlayer.load())             // 1.7.0: each stream follows its own friend's link
        {
            for (int i = 0; i < kMaxFriends; ++i)
                if (g_peers[i].on && g_peers[i].bitrate > 0) OnlineVideo::SetBitrate(ChannelOf(i), g_peers[i].bitrate);
            return;
        }
        int kbps = 0;
        for (const Peer& p : g_peers) if (p.on && p.bitrate > 0) kbps = kbps ? std::min(kbps, p.bitrate) : p.bitrate;
        if (kbps > 0 && kbps != g_bitrateNow) { g_bitrateNow = kbps; OnlineVideo::SetBitrate(kbps); }
    }

    void HostSetup(uint16_t port, uint32_t gen)
    {
        const uint32_t lan = LocalIp();
        Options o;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            o = g_opt;
        }
        if (o.stun) StunAsk();
        uint32_t upnpIp = 0;
        std::string upnpWhy = "UPnP off ([Online] UPnP=0)";
        bool mapped = false;
        if (o.upnp && lan)
        {
            std::lock_guard<std::mutex> up(g_upnpMutex);
            if (gen == g_hostGen.load() && SUCCEEDED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED)))
            {
                mapped = UpnpMap(port, lan, upnpIp, upnpWhy);
                if (mapped) g_upnpMappedGen.store(gen);
                if (mapped && gen != g_hostGen.load())
                {
                    UpnpRemoveNow(port);
                    g_upnpMappedGen.store(0);
                    mapped = false;
                }
                CoUninitialize();
            }
        }
        if (gen != g_hostGen.load()) return;
        for (int i = 0; i < 30 && o.stun && !g_stunIp.load(); ++i)
        {
            if (i == 10) StunAsk();
            Sleep(100);
        }
        if (gen != g_hostGen.load()) return;
        const uint32_t stunIp = g_stunIp.load();
        const uint16_t stunPort = g_stunPort.load();
        uint32_t ip = stunIp ? stunIp : (upnpIp && !PrivateIp(upnpIp) ? upnpIp : lan);
        uint16_t codePort = port;
        if (!mapped && stunIp && stunPort) codePort = stunPort;
        std::string note, warn;
        if (mapped) note = "Router: port " + std::to_string(port) + " opened by itself (UPnP).";
        else note = "Router: " + upnpWhy + ". If friends cannot connect, forward UDP port " + std::to_string(port) + " to this PC (" + IpText(lan) + ").";
        if (upnpIp && stunIp && upnpIp != stunIp)
            warn = CarrierNat(upnpIp) || PrivateIp(upnpIp)
                ? "Your router sits behind another one (or your internet provider's): friends outside may not reach you."
                : "The router reports a different internet address than the internet sees.";
        if (!stunIp && !upnpIp) warn = "Could not find this PC's internet address: the code only works on this network.";
        if (stunIp && !mapped && stunPort != port) warn = "Your router changes the game's port: friends outside may not reach you unless the port is forwarded.";
        const std::string code = P::MakeJoinCode(ip, codePort, g_token);
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (RoleNow() != Role::Host || gen != g_hostGen.load()) return;
            g_code = code;
            g_ownCode = code;
            g_codeNote = note;
            g_codeWarn = warn;
            g_setupDone = true;
            g_upnpMapped = mapped;
            g_upnpPort = port;
        }
        bool list = false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_pubAddr = IpText(ip) + ":" + std::to_string(codePort);
            g_lanAddr = lan ? IpText(lan) + ":" + std::to_string(port) : std::string();
            list = !o.lobby.empty() && o.publicList;
            if (list)
            {
                int used = 0;
                for (const Peer& p : g_peers) used += p.on ? 1 : 0;
                g_listed = true;
                g_infoSent.clear();
                OnlineLobby::HostStart(o.lobby, LobbyVersion(), ServerName(o.name), g_infoMax, std::max(0, std::min(g_infoOpen, kMaxFriends - used)));
            }
        }
        if (list) Logger::WriteFormat(Logger::Level::Info, "Online: listing the game on %s", o.lobby.c_str());
        CopyToClipboard(code);
        Logger::WriteFormat(Logger::Level::Success, "Online: hosting on port %u, invite code %s (address %s:%u; LAN %s; UPnP %s; internet address seen %s:%u)",
            port, code.c_str(), IpText(ip).c_str(), codePort, IpText(lan).c_str(), mapped ? ("mapped, router says " + IpText(upnpIp)).c_str() : upnpWhy.c_str(),
            stunIp ? IpText(stunIp).c_str() : "none", stunPort);
        if (!warn.empty()) Logger::WriteFormat(Logger::Level::Warning, "Online: %s", warn.c_str());
    }

    int PeerAt(const sockaddr_in& from)
    {
        for (int i = 0; i < kMaxFriends; ++i) if (g_peers[i].on && SameAddr(g_peers[i].addr, from)) return i;
        return -1;
    }

    // g_mutex held.
    void DropPeer(int i, const std::string& why)
    {
        Peer& p = g_peers[i];
        if (!p.on) return;
        Message(p.name + " " + why);
        OnlineVoice::ForgetSpeaker(SpeakerOf(i));
        VPadSetRemote(p.slot, nullptr);
        p = Peer{};
        SyncStreamTargets();
    }

    void HostHandle(const P::Header* h, const uint8_t* d, int n, const sockaddr_in& from, uint32_t now)
    {
        bool startStream = false, stopStream = false;
        Options o;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            o = g_opt;
            int pi = PeerAt(from);
            const bool known = pi >= 0 && h->session == g_session;
            if (known) g_peers[pi].heardMs = now;
            switch (h->type)
            {
            case P::kDiscover:
            {
                const auto* m = P::As<P::DiscoverMsg>(d, n);
                if (!m) break;
                int used = 0;
                for (const Peer& p : g_peers) used += p.on ? 1 : 0;
                P::OfferMsg r{};
                r.nonce = m->nonce;
                r.token = g_token;
                r.port = g_boundPort;
                r.slotTaken = used >= kMaxFriends ? 1 : 0;
                r.busy = r.slotTaken;
                P::CopyName(r.name, sizeof(r.name), o.name.empty() ? "Host" : o.name);
                SendMsg(from, r, P::kOffer, 0);
                break;
            }
            case P::kHello:
            {
                const auto* m = P::As<P::HelloMsg>(d, n);
                if (!m) break;
                bool pass = m->token == g_token;
                if (!pass && pi < 0)
                    for (auto it = g_accepted.begin(); it != g_accepted.end(); ++it)
                        if (it->token == m->token && static_cast<int32_t>(it->until - now) > 0) { pass = true; g_accepted.erase(it); break; }
                if (!pass && pi >= 0 && g_peers[pi].clientId == m->clientId) pass = true;   // already in: repeats of the first Hello
                if (!pass) { SendRefuse(from, 0, "That invite code is not for this game (an old code?). Ask for the new one."); break; }
                // the same friend from another address (their router moved, or the near address at home)
                if (pi < 0 && m->clientId)
                    for (int i = 0; i < kMaxFriends; ++i)
                        if (g_peers[i].on && g_peers[i].clientId == m->clientId)
                        {
                            Logger::WriteFormat(Logger::Level::Info, "Online: %s now comes from %s", g_peers[i].name.c_str(), AddrText(from).c_str());
                            g_peers[i].addr = from;
                            pi = i;
                            SyncStreamTargets();
                        }
                if (pi < 0)
                {
                    for (int i = 0; i < kMaxFriends && pi < 0; ++i) if (!g_peers[i].on) pi = i;
                    if (pi < 0) { SendRefuse(from, 0, "This game already has two friends connected."); break; }
                    Peer& p = g_peers[pi];
                    p = Peer{};
                    p.on = true;
                    p.addr = from;
                    p.clientId = m->clientId;
                    p.name = P::ReadName(m->name, sizeof(m->name));
                    if (p.name.empty()) p.name = pi == 0 ? "Friend 1" : "Friend 2";
                    p.slot = kVPadFirst + pi;
                    p.bitrate = o.bitrate;
                    p.connectedAt = now;
                    XINPUT_GAMEPAD rest{};
                    VPadSetRemote(p.slot, &rest);   // "plugged in": the lobby can give it to Player 2/3
                    SyncStreamTargets();
                    startStream = true;
                    Message(p.name + " joined online (" + AddrText(from) + ") - press START on their controller to play");
                }
                g_peers[pi].heardMs = now;
                P::WelcomeMsg w{};
                w.width = 0;
                w.height = static_cast<uint16_t>(o.height);
                w.fps = static_cast<uint8_t>(std::clamp(o.fps, 1, 255));
                w.slotTaken = 0;
                w.hostMs = now;
                P::CopyName(w.name, sizeof(w.name), o.name.empty() ? "Host" : o.name);
                SendMsg(from, w, P::kWelcome, g_session);
                if (startStream) { OnlineVideo::RequestKeyframe(); OnlineVideo::RequestKeyframe(1); }
                break;
            }
            case P::kInput:
            {
                const auto* m = P::As<P::InputMsg>(d, n);
                if (!m || !known) break;
                Peer& p = g_peers[pi];
                if (p.haveSeq && static_cast<int32_t>(m->seq - p.inputSeq) <= 0) break;
                p.inputSeq = m->seq;
                p.haveSeq = true;
                p.lastInputAt = now;
                p.rested = false;
                XINPUT_GAMEPAD pad{};
                pad.wButtons = m->buttons;
                pad.bLeftTrigger = m->lt; pad.bRightTrigger = m->rt;
                pad.sThumbLX = m->lx; pad.sThumbLY = m->ly; pad.sThumbRX = m->rx; pad.sThumbRY = m->ry;
                {
                    // 1.7.8: START from a friend, in the log (it's how they join as a player)
                    static WORD lastButtons[kMaxFriends] = {};
                    if ((m->buttons & XINPUT_GAMEPAD_START) && !(lastButtons[pi] & XINPUT_GAMEPAD_START))
                        Logger::WriteFormat(Logger::Level::Info, "Online: %s pressed START (controller slot %d)", p.name.c_str(), p.slot);
                    lastButtons[pi] = m->buttons;
                }
                VPadSetRemote(p.slot, &pad);
                break;
            }
            case P::kVoice:
            {
                if (!known) break;
                P::VoiceHeader vh{};
                std::vector<int16_t> mono;
                if (!P::ReadVoicePacket(d, static_cast<size_t>(n), vh, mono)) break;
                const uint8_t who = SpeakerOf(pi);
                OnlineVoice::SetName(who, g_peers[pi].name);
                OnlineVoice::Received(who, vh.seq, vh.level, mono.data(), static_cast<int>(mono.size()));
                // passed on to the other friend, marked with who talks
                std::vector<uint8_t> fwd(d, d + n);
                fwd[offsetof(P::VoiceHeader, speaker)] = who;
                for (int j = 0; j < kMaxFriends; ++j)
                    if (j != pi && g_peers[j].on) Send(g_peers[j].addr, fwd.data(), fwd.size());
                break;
            }
            case P::kChat:
            {
                if (!known) break;
                const auto* m = P::As<P::ChatMsg>(d, n);
                if (!m || !ChatFirstTime((uint64_t(pi + 1) << 32) | m->id)) break;
                const uint8_t who = SpeakerOf(pi);
                const std::string text = P::ReadName(m->text, sizeof(m->text));
                if (text.empty()) break;
                OnlineChat::Add(who, g_peers[pi].name, text);
                // passed on to the other friend, marked with who wrote it
                const auto fwd = ChatPacket(g_session, m->id, who, g_peers[pi].name, text);
                for (int k = 0; k < 3; ++k)
                    for (int j = 0; j < kMaxFriends; ++j)
                        if (j != pi && g_peers[j].on) Send(g_peers[j].addr, fwd.data(), fwd.size());
                break;
            }
            case P::kNack:
            {
                if (!known) break;
                uint32_t frame = 0;
                std::vector<uint16_t> idx;
                std::vector<std::vector<uint8_t>> again;
                if (P::ReadNack(d, static_cast<size_t>(n), frame, idx) && (ChannelOf(pi) == 1 ? g_history1 : g_history).Get(frame, idx, again))
                    for (const auto& p : again) Send(from, p.data(), p.size());
                break;
            }
            case P::kKeyRequest:
                if (known && now - g_lastKeyReq > 100) { g_lastKeyReq = now; OnlineVideo::RequestKeyframe(ChannelOf(pi)); }
                break;
            case P::kPing:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                P::PingMsg r{};
                r.sentMs = now; r.echoMs = m->sentMs; r.rttMs = g_peers[pi].rtt;
                SendMsg(from, r, P::kPong, g_session);
                break;
            }
            case P::kPong:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                const uint32_t rtt = now - m->echoMs;
                Peer& p = g_peers[pi];
                if (rtt < 10000) p.rtt = p.rtt ? (p.rtt * 3 + rtt) / 4 : rtt;
                break;
            }
            case P::kStats:
            {
                const auto* m = P::As<P::StatsMsg>(d, n);
                if (!m || !known) break;
                Peer& p = g_peers[pi];
                p.prevStats = p.haveStats ? p.stats : *m;
                p.stats = *m;
                p.haveStats = true;
                if (m->reserved > p.maxGap) p.maxGap = m->reserved;      // (the longest over the 10 s of a log line)
                // this friend's share of the stream follows what arrives: lower on loss, back up when calm
                const uint32_t got = m->packets - p.prevStats.packets, asked = m->resendAsked - p.prevStats.resendAsked;
                const uint32_t keys = m->keyAsks - p.prevStats.keyAsks;
                const double loss = got ? static_cast<double>(asked) / got : 0.0;
                if (p.bitrate <= 0) p.bitrate = o.bitrate;
                // 1.7.1: lowered only when a link really struggles - 2 lossy seconds in a row (a single burst of
                // resends on a fast home network is no reason), more allowed on a short ping (resends come back at once)
                // 1.7.1: judged only while the picture really flows (300+ packets a second): in the lobby, a loading screen
                // or a paused host the friend asks for keyframes again and again, and that alone used to push the
                // stream down to its lowest bitrate before the game had even started (a blocky first minute). And it
                // climbs back faster: +15 % every 3 calm seconds (calm: under 2 % asked again - the recovery packets
                // rebuild the rest - and no frame lost).
                const uint32_t lostFrames = m->framesLost - p.prevStats.framesLost;
                (void)keys;
                if (got < 300) { p.lossy = 0; p.calm = 0; }
                else
                {
                    const double lossLine = p.rtt && p.rtt < 15 ? 0.06 : 0.03;
                    p.lossy = (loss > lossLine || lostFrames > 2) ? p.lossy + 1 : 0;
                    if (p.lossy >= 2) { p.bitrate = std::max(o.minBitrate, p.bitrate * 4 / 5); p.calm = 0; p.lossy = 0; }
                    else if (loss < 0.02 && lostFrames == 0 && ++p.calm >= 3 && p.bitrate < o.bitrate) { p.bitrate = std::min(o.bitrate, p.bitrate * 23 / 20 + 100); p.calm = 0; }
                }
                ApplyBitrate();
                if (now - p.lastStatsLog > 10000)
                {
                    p.lastStatsLog = now;
                    Logger::WriteFormat(Logger::Level::Info,
                        "Online: %s: ping %u ms, picture %u ms after it was drawn here, %u/%u packets resent/rebuilt of %u (%u came twice), longest gap %u ms, keyframes asked %u, frames shown %u lost %u, decode %.1f ms, sound buffer %u ms; sending %.0f kbps (target %d, %u refused by the network); %s",
                        p.name.c_str(), p.rtt, m->latencyMs, m->resendAsked, m->recovered, m->packets, m->duplicates, p.maxGap, m->keyAsks, m->framesShown, m->framesLost,
                        m->decodeUs100 / 10.0, m->audioMs, g_kbpsOut, g_bitrateNow, g_sendFails.load(), OnlineVideo::HostStatus().c_str());
                    p.maxGap = 0;
                }
                break;
            }
            case P::kBye:
                if (known)
                {
                    const auto* m = P::As<P::ByeMsg>(d, n);
                    DropPeer(pi, "left" + (m ? std::string(" (") + P::ReadName(m->reason, sizeof(m->reason)) + ")" : std::string()));
                    bool any = false;
                    for (const Peer& p : g_peers) any = any || p.on;
                    stopStream = !any;
                }
                break;
            default:
                break;
            }
        }
        if (stopStream) StopStream();
        if (startStream) StartStream(o);
    }

    // ---------------- host: the public list, join requests, lock (1.4.0) ----------------

    void SendInfo(uint32_t now, bool force)   // g_mutex held
    {
        if (!g_listed) return;
        int used = 0;
        for (const Peer& p : g_peers) used += p.on ? 1 : 0;
        const int open = std::max(0, std::min(g_infoOpen, kMaxFriends - used));
        char t[96];
        // everyone in the game: the host, its co-op players and friends already connected (watching or playing)
        const int players = std::clamp(std::max(g_infoPlayers, 1 + used), 1, g_infoMax);
        std::snprintf(t, sizeof(t), "players=%d&max=%d&open=%d&locked=%d&area=", players, g_infoMax, open, g_locked ? 1 : 0);
        const std::string fields = t + OnlineLobby::UrlEncode(g_infoArea);
        if (!force && fields == g_infoSent) return;
        if (!force && now - g_infoSentAt < 2000) return;   // not more than every 2 s
        g_infoSent = fields;
        g_infoSentAt = now;
        OnlineLobby::HostUpdate(fields);
    }

    void Answer(Pending& q, bool ok, uint32_t now, const char* why)   // g_mutex held
    {
        if (ok)
        {
            Accepted a;
            a.token = Random32();
            a.until = now + 60000;
            a.name = q.r.name;
            g_accepted.push_back(a);
            if (g_accepted.size() > 8) g_accepted.erase(g_accepted.begin());
            Punch pu;
            pu.haveA = ParseAddr(q.r.addr, pu.a);
            pu.haveB = ParseAddr(q.r.lan, pu.b);
            pu.until = now + 5000;
            if (pu.haveA || pu.haveB) g_punch.push_back(pu);
            OnlineLobby::HostAnswer(q.r.req, true, std::to_string(a.token), g_pubAddr, g_lanAddr, "");
            Message("Let " + q.r.name + " in - connecting...");
        }
        else
        {
            OnlineLobby::HostAnswer(q.r.req, false, "", "", "", why);
            Message("Turned " + q.r.name + " away");
        }
    }

    void HostLobbyTick(uint32_t now)   // g_mutex held
    {
        if (!g_listed) return;
        // new requests / requests the player gave up on
        OnlineLobby::Request r;
        while (OnlineLobby::HostTakeRequest(r))
        {
            int used = 0;
            for (const Peer& p : g_peers) used += p.on ? 1 : 0;
            if (g_locked) { OnlineLobby::HostAnswer(r.req, false, "", "", "", "That game is locked."); continue; }
            if (used >= kMaxFriends || g_pending.size() >= 3) { OnlineLobby::HostAnswer(r.req, false, "", "", "", "That game is full."); continue; }
            Pending q;
            q.r = r;
            q.at = now;
            q.remindAt = now;            // shown at once
            g_pending.push_back(q);
            Logger::WriteFormat(Logger::Level::Info, "Online: %s asks to join (from %s, %s)", r.name.c_str(), r.addr.empty() ? "?" : r.addr.c_str(), r.country.c_str());
        }
        std::string gone;
        while (OnlineLobby::HostTakeCancel(gone))
            for (auto it = g_pending.begin(); it != g_pending.end(); ++it)
                if (it->r.req == gone) { Message(it->r.name + " stopped asking"); g_pending.erase(it); break; }

        // the host answers in a pop-up (1.4.1): Yes / No, picked with the D-pad, stick or arrow keys and
        // confirmed with A or Enter, or clicked. While it is up the game's menus don't see controller 1.
        // (The lock is a button in the host's lobby, SetLocked.)
        while (!g_pending.empty() && now - g_pending.front().at > 35000) { Answer(g_pending.front(), false, now, "The host did not answer."); g_pending.pop_front(); g_popSel = 0; }
        const bool show = !g_pending.empty();
        XINPUT_STATE st{};
        const int p1pad = XInputRouteP1NoneGet() ? -1 : PadsP1Index();
        // 1.7.1: the controller and keys only read while the pop-up is up (this runs ~1000 times a second on the
        // network thread, with g_mutex held: reading an empty controller slot that often is slow); what is held
        // when it appears is not taken as a press
        static bool shownBefore = false;
        const bool fresh = show && !shownBefore;
        shownBefore = show;
        const WORD pad = (show && p1pad >= 0 && p1pad < 4 && XInputGetState(static_cast<DWORD>(p1pad), &st) == ERROR_SUCCESS) ? st.Gamepad.wButtons : 0;
        const SHORT lx = (show && p1pad >= 0) ? st.Gamepad.sThumbLX : 0;
        const int stick = lx < -16000 ? -1 : lx > 16000 ? 1 : 0;
        if (fresh) { g_hostPrevPad = pad; g_popStick = stick; }
        const WORD pressed = static_cast<WORD>(pad & ~g_hostPrevPad);
        g_hostPrevPad = pad;
        const bool front = show && OurWindowInFront();
        const bool keys[5] = { front && (GetAsyncKeyState(VK_LEFT) & 0x8000) != 0, front && (GetAsyncKeyState(VK_RIGHT) & 0x8000) != 0,
                               front && ((GetAsyncKeyState(VK_RETURN) & 0x8000) != 0 || (GetAsyncKeyState(VK_SPACE) & 0x8000) != 0),
                               front && (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0, false };
        if (fresh) for (int i = 0; i < 5; ++i) g_hostPrevKeys[i] = keys[i];
        bool hit[5];
        for (int i = 0; i < 5; ++i) { hit[i] = keys[i] && !g_hostPrevKeys[i]; g_hostPrevKeys[i] = keys[i]; }
        const bool stickHit = stick != 0 && stick != g_popStick;
        g_popStick = stick;
        if (show)
        {
            if (!g_popShown) { g_popShown = true; g_popAt = now; g_popSel = 0; }
            const bool ready = now - g_popAt > 400;   // a button already on its way down doesn't answer
            if (ready)
            {
                if ((pressed & (XINPUT_GAMEPAD_DPAD_LEFT | XINPUT_GAMEPAD_DPAD_RIGHT)) || hit[0] || hit[1] || stickHit)
                {
                    if (hit[0] || (pressed & XINPUT_GAMEPAD_DPAD_LEFT) || stick < 0) g_popSel = 0;
                    else g_popSel = 1;
                }
                int answer = -1;
                if ((pressed & XINPUT_GAMEPAD_A) || hit[2]) answer = g_popSel;
                else if (pressed & XINPUT_GAMEPAD_B) answer = 1;
                else if (hit[3])
                {
                    POINT c;
                    HWND w = reinterpret_cast<HWND>(D3D9GameWindow());
                    int bw = 0, bh = 0;
                    RECT cr;
                    if (w && GetCursorPos(&c) && ScreenToClient(w, &c) && GetClientRect(w, &cr) && D3D9BackBufferSize(&bw, &bh) && cr.right > 0 && cr.bottom > 0)
                        answer = PopupHit(c.x * bw / cr.right, c.y * bh / cr.bottom);
                }
                if (answer >= 0)
                {
                    Pending q = g_pending.front();
                    g_pending.pop_front();
                    Answer(q, answer == 0, now, "The host said no.");
                    g_popAt = now;   // the next request (if any) waits a moment too
                    g_popSel = 0;
                }
            }
        }
        else g_popShown = false;
        if (!g_pending.empty())
        {
            const Pending& q = g_pending.front();
            const int left = static_cast<int>((35000 - std::min<uint32_t>(35000, now - q.at)) / 1000);
            std::wstring sub = L"Let them in?  (no answer in " + std::to_wstring(left) + L" s means no)";
            if (g_pending.size() > 1) sub += L"  +" + std::to_wstring(g_pending.size() - 1) + L" more waiting";
            PopupSet(true, Wide(q.r.name) + L" wants to join your game", sub, g_popSel);
        }
        else PopupSet(false, L"", L"", 0);
        // the game's menus get controller 1 back once A / B are let go
        bool hold = !g_pending.empty();
        if (!hold && g_popAt && (pad & (XINPUT_GAMEPAD_A | XINPUT_GAMEPAD_B)) != 0 && now - g_popAt < 3000) hold = true;
        XInputRouteHold(hold);
        // open the way to accepted players (both routers learn about the other side)
        static uint32_t lastPunch = 0;
        if (!g_punch.empty() && now - lastPunch >= 100)
        {
            lastPunch = now;
            for (const Punch& pu : g_punch)
            {
                P::EmptyMsg m{};
                if (pu.haveA) SendMsg(pu.a, m, P::kPunch, 0);
                if (pu.haveB) SendMsg(pu.b, m, P::kPunch, 0);
            }
            g_punch.erase(std::remove_if(g_punch.begin(), g_punch.end(), [&](const Punch& pu) { return static_cast<int32_t>(now - pu.until) > 0; }), g_punch.end());
        }
        g_accepted.erase(std::remove_if(g_accepted.begin(), g_accepted.end(), [&](const Accepted& a) { return static_cast<int32_t>(now - a.until) > 0; }), g_accepted.end());
        SendInfo(now, false);
    }

    void HostTick(uint32_t now)
    {
        bool stopStream = false;
        static uint32_t lastPing = 0, lastBw = 0;
        std::lock_guard<std::mutex> lock(g_mutex);
        HostLobbyTick(now);
        {   // the co-op lobby for each friend, twice a second while the host is in it
            static uint32_t lastLobby = 0;
            if (!g_lobbyOut.empty() && now - lastLobby >= 400)
            {
                lastLobby = now;
                for (int i = 0; i < kMaxFriends; ++i)
                {
                    const Peer& p = g_peers[i];
                    if (!p.on) continue;
                    P::LobbyTextMsg m{};
                    m.slot = static_cast<uint8_t>(PadsIndex(PLAYER_2) == p.slot ? 2 : PadsIndex(PLAYER_3) == p.slot ? 3 : 0);
                    std::snprintf(m.text, sizeof(m.text), "%s", g_lobbyOut.c_str());
                    SendMsg(p.addr, m, P::kLobbyText, g_session);
                }
            }
        }
        bool any = false;
        for (int i = 0; i < kMaxFriends; ++i)
        {
            Peer& p = g_peers[i];
            if (!p.on) continue;
            if (now - p.heardMs > 6000) { DropPeer(i, "lost the connection"); stopStream = true; continue; }
            any = true;
            // nothing from the friend's controller for a moment (the connection hiccups): let go of everything
            if (now - p.lastInputAt > 150 && !p.rested)
            {
                p.rested = true;
                XINPUT_GAMEPAD rest{};
                VPadSetRemote(p.slot, &rest);
            }
            if (now - lastPing >= 500)
            {
                P::PingMsg m{};
                m.sentMs = now; m.rttMs = p.rtt;
                SendMsg(p.addr, m, P::kPing, g_session);
            }
        }
        if (now - lastPing >= 500) lastPing = now;
        if (now - lastBw >= 1000)
        {
            const double secs = (now - lastBw) / 1000.0;
            lastBw = now;
            g_kbpsOut = g_bytesOut.exchange(0) * 8.0 / 1000.0 / std::max(0.001, secs);
        }
        if (stopStream && !any)
        {
            g_mutex.unlock();
            StopStream();
            g_mutex.lock();
        }
    }

    // ---------------- friend ----------------
    void ConnectTo(const sockaddr_in& at, uint32_t token);   // g_mutex held

    void JoinHandle(const P::Header* h, const uint8_t* d, int n, const sockaddr_in& from, uint32_t now)
    {
        bool startView = false, stopAll = false;
        int bufferMs = 30;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            bufferMs = g_opt.audioMs;
            // public list: the host may answer on its other (home network) address
            if (g_stage == Stage::Connecting && g_haveAlt && SameAddr(from, g_altAddr) && !SameAddr(from, g_host.addr))
            {
                Logger::WriteFormat(Logger::Level::Info, "Online: the host answered on %s: using that", AddrText(from).c_str());
                g_host.addr = from;
                g_haveAlt = false;
            }
            const bool fromHost = (g_stage == Stage::Connecting || g_stage == Stage::Watching) && SameAddr(from, g_host.addr);
            const bool known = fromHost && g_host.on && h->session == g_session;
            if (known) g_host.heardMs = now;
            switch (h->type)
            {
            case P::kOffer:
            {
                const auto* m = P::As<P::OfferMsg>(d, n);
                if (!m) break;
                sockaddr_in at = from;
                at.sin_port = htons(m->port);
                // joining with a code, and the same game answers on this network: use the near address
                if (g_stage == Stage::Connecting && !g_host.on && m->token == g_joinToken && !SameAddr(at, g_host.addr))
                {
                    Logger::WriteFormat(Logger::Level::Info, "Online: the host is on this network (%s): joining there", AddrText(at).c_str());
                    g_host.addr = at;
                    g_helloAt = 0;
                }
                bool found = false;
                for (auto& g : g_lan)
                    if (SameAddr(g.addr, at)) { g.name = P::ReadName(m->name, sizeof(m->name)); g.token = m->token; g.full = m->busy != 0; g.seenMs = now; found = true; }
                if (!found && g_lan.size() < 8)
                {
                    LanGame g;
                    g.addr = at; g.name = P::ReadName(m->name, sizeof(m->name)); g.token = m->token; g.full = m->busy != 0; g.seenMs = now;
                    g_lan.push_back(g);
                }
                break;
            }
            case P::kWelcome:
            {
                const auto* m = P::As<P::WelcomeMsg>(d, n);
                if (!m || !fromHost || g_stage != Stage::Connecting) break;
                g_session = h->session;
                g_host.on = true;
                g_host.name = P::ReadName(m->name, sizeof(m->name));
                if (g_host.name.empty()) g_host.name = "the host";
                g_host.heardMs = now;
                g_stage = Stage::Watching;
                g_watchSince = 0; g_lobbyInAt = 0; g_lobbyIn.clear(); g_lobbySlot = 0; g_videoPackets = 0;
                g_rx.Reset();
                g_rx.SetConceal(g_opt.conceal);
                OnlineVideo::SetHardwareDecode(g_opt.hwDecode);
                OnlineVideo::SetPacingBuffer(g_opt.pacingMs);
                OnlineVideo::SetViewerFit(g_opt.viewerFit);
                g_haveOffset = false;
                g_bestRtt = UINT32_MAX;
                g_error.clear();
                g_prevButtons = 0xFFFF;
                {
                    std::lock_guard<std::mutex> vlock(g_voiceMutex);
                    g_voiceHost = g_host.addr; g_voiceSession = g_session;
                }
                OnlineVoice::SetName(1, g_host.name);
                startView = true;
                Message("Connected to " + g_host.name + "'s game");
                break;
            }
            case P::kRefuse:
            {
                const auto* m = P::As<P::RefuseMsg>(d, n);
                if (!m || !fromHost) break;
                const std::string why = P::ReadName(m->reason, sizeof(m->reason));
                if (g_stage == Stage::Connecting) { g_error = why; g_stage = Stage::Window; g_host = Peer{}; }
                Logger::WriteFormat(Logger::Level::Warning, "Online: the host said no: %s", why.c_str());
                break;
            }
            case P::kLobbyText:
                if (known)
                {
                    const auto* m = P::As<P::LobbyTextMsg>(d, n);
                    if (!m) break;
                    g_lobbyIn = P::ReadName(m->text, sizeof(m->text));
                    g_lobbySlot = m->slot;
                    g_lobbyInAt = now;
                }
                break;
            case P::kVideo:
                if (known)
                {
                    ++g_videoPackets;
                    if (g_lastVideoMs && now - g_lastVideoMs > g_maxGapMs && now - g_lastVideoMs < 60000) g_maxGapMs = now - g_lastVideoMs;
                    g_lastVideoMs = now;
                    g_rx.Add(d, static_cast<size_t>(n), now);
                    P::VideoFrame f;
                    while (g_rx.Next(f)) OnlineVideo::SubmitFrame(std::move(f));
                }
                break;
            case P::kAudio:
                if (known)
                {
                    uint32_t seq = 0;
                    std::vector<int16_t> pcm;
                    if (P::ReadAudioPacket(d, static_cast<size_t>(n), seq, pcm)) OnlineAudio::Push(seq, pcm.data(), static_cast<int>(pcm.size() / 2));
                }
                break;
            case P::kChat:
                if (known)
                {
                    const auto* m = P::As<P::ChatMsg>(d, n);
                    if (m && m->from != 0 && ChatFirstTime((uint64_t(m->from) << 32) | m->id)) {
                        const std::string text = P::ReadName(m->text, sizeof(m->text));
                        if (text.empty()) {}
                        else if (m->from == 0xFD) {   // who is in a menu ("" / " " = nobody)
                            std::wstring w; const int n = MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, nullptr, 0);
                            if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, &w[0], n); }
                            OnlineChat::SetStatus(w);
                        }
                        else if (m->from == 0xFE) {
                            std::wstring w; const int n = MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, nullptr, 0);
                            if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, &w[0], n); }
                            OnlineChat::Notice(w.c_str(), 0);
                        }
                        else OnlineChat::Add(m->from, P::ReadName(m->name, sizeof(m->name)), text);
                    }
                }
                break;
            case P::kVoice:
                if (known)
                {
                    P::VoiceHeader vh{};
                    std::vector<int16_t> mono;
                    if (P::ReadVoicePacket(d, static_cast<size_t>(n), vh, mono))
                        OnlineVoice::Received(vh.speaker, vh.seq, vh.level, mono.data(), static_cast<int>(mono.size()));
                }
                break;
            case P::kPing:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                P::PingMsg r{};
                r.sentMs = now; r.echoMs = m->sentMs; r.rttMs = g_host.rtt;
                SendMsg(from, r, P::kPong, g_session);
                break;
            }
            case P::kPong:
            {
                const auto* m = P::As<P::PingMsg>(d, n);
                if (!m || !known) break;
                const uint32_t rtt = now - m->echoMs;
                if (rtt >= 10000) break;
                g_host.rtt = g_host.rtt ? (g_host.rtt * 3 + rtt) / 4 : rtt;
                if (!g_haveOffset || rtt <= g_bestRtt + 2 || now - g_offsetAt > 20000)
                {
                    const int32_t offset = static_cast<int32_t>(m->sentMs - (m->echoMs + rtt / 2));
                    g_clockOffset = g_haveOffset && now - g_offsetAt < 20000 ? (g_clockOffset * 3 + offset) / 4 : offset;
                    g_bestRtt = std::min(g_bestRtt, rtt);
                    g_offsetAt = now;
                    g_haveOffset = true;
                }
                break;
            }
            case P::kBye:
                if (known)
                {
                    const auto* m = P::As<P::ByeMsg>(d, n);
                    g_error = g_host.name + " closed the game" + (m ? " (" + P::ReadName(m->reason, sizeof(m->reason)) + ")" : std::string());
                    stopAll = true;
                }
                break;
            default:
                break;
            }
        }
        if (startView)
        {
            OnlineVideo::StartViewer();
            OnlineAudio::StartPlayback(bufferMs);
            OnlineVoice::Start(OnJoinVoice);
            XInputRouteBlank(true);
        }
        if (stopAll)
        {
            OnlineVideo::StopViewer();
            OnlineAudio::StopPlayback();
            OnlineVoice::Stop();
            XInputRouteBlank(false);
            std::lock_guard<std::mutex> lock(g_mutex);
            g_stage = Stage::Window;
            Message(g_error);
            PopupNotice(Wide(g_error), L"Back to the main menu", 8000);   // 1.7.0: the friend sees why
            g_host = Peer{};
        }
    }

    void StepAwayFromMenu()
    {
        uint32_t until = Now() + 2400; if (!until) until = 1;
        g_stepAwayUntil.store(until);
        Logger::Write(Logger::Level::Info, "Online: stepping away (co-op menu) - the host gets View held");
    }

    void SendInput(const XINPUT_GAMEPAD& pad)
    {
        P::InputMsg m{};
        m.seq = ++g_inputSeq;
        m.buttons = pad.wButtons;
        m.lt = pad.bLeftTrigger; m.rt = pad.bRightTrigger;
        m.lx = pad.sThumbLX; m.ly = pad.sThumbLY; m.rx = pad.sThumbRX; m.ry = pad.sThumbRY;
        SendMsg(g_host.addr, m, P::kInput, g_session);
    }

    void LeaveHost(const char* why)   // g_mutex NOT held
    {
        OnlineVideo::StopViewer();
        OnlineAudio::StopPlayback();
            OnlineVoice::Stop();
        XInputRouteBlank(false);
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_host.on) SendBye(g_host.addr, g_session, why);
        g_host = Peer{};
        g_stage = Stage::Window;
        g_lastClip.clear();   // the same code may be used again
        Message("You left the game.");
    }

    void JoinTick(uint32_t now)
    {
        static uint32_t lastPing = 0, lastStats = 0, lastInput = 0;
        bool lost = false, leave = false;
        std::vector<std::pair<uint32_t, std::vector<uint16_t>>> nacks;
        bool wantKey = false;
        std::string clip;
        bool checkClip = false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            checkClip = false;   // 1.4.4: no joining from the clipboard by itself - Join a Friend > Paste does it
            if (checkClip) g_clipAt = now;
        }
        if (checkClip) clip = ClipboardText();   // (outside the lock: the clipboard can be slow)
        std::lock_guard<std::mutex> lock(g_mutex);
        // (1.4.3: the public list is driven by the menu - Join Game > Browse Games, AskToJoin below)
        // waiting for the host's answer
        if (g_stage == Stage::Asking)
        {
            std::string token, addr, lan, why;
            const OnlineLobby::JoinStatus js = OnlineLobby::JoinState(token, addr, lan, why);
            if (js == OnlineLobby::kJoinAccepted)
            {
                sockaddr_in at{}, alt{};
                const bool haveAt = ParseAddr(addr, at), haveAlt = ParseAddr(lan, alt);
                if (haveAt || haveAlt)
                {
                    ConnectTo(haveAt ? at : alt, static_cast<uint32_t>(strtoul(token.c_str(), nullptr, 10)));
                    if (haveAt && haveAlt && !SameAddr(at, alt)) { g_altAddr = alt; g_haveAlt = true; }
                    Message(g_askName + " let you in - connecting...");
                }
                else { g_stage = Stage::Window; g_error = "The host's address was missing - try again."; }
                OnlineLobby::JoinCancel();
            }
            else if (js == OnlineLobby::kJoinDeclined || js == OnlineLobby::kJoinNone)
            {
                g_stage = Stage::Window;
                g_error = why.empty() ? "The host said no." : why;
                Logger::WriteFormat(Logger::Level::Info, "Online: not let in: %s", g_error.c_str());
                OnlineLobby::JoinCancel();
                OnlineLobby::BrowseRefreshNow();
            }
        }
        // the join window: a code on the clipboard connects by itself; a game on this network: X
        if (g_stage == Stage::Window)
        {
            if (checkClip && !clip.empty() && clip.size() < 64 && clip != g_lastClip)
            {
                uint32_t ip = 0, token = 0;
                uint16_t port = 0;
                if (P::ParseJoinCode(clip, ip, port, token))
                {
                    g_lastClip = clip;
                    sockaddr_in at{};
                    at.sin_family = AF_INET;
                    at.sin_addr.s_addr = htonl(ip);
                    at.sin_port = htons(port);
                    ConnectTo(at, token);
                }
            }
        }
        if ((g_stage == Stage::Window || g_stage == Stage::Connecting) && now - g_discoverAt >= 1000)
        {
            g_discoverAt = now;
            sockaddr_in bc{};
            bc.sin_family = AF_INET;
            bc.sin_port = htons(static_cast<u_short>(g_opt.port));
            bc.sin_addr.s_addr = htonl(INADDR_BROADCAST);
            P::DiscoverMsg m{};
            m.nonce = Random32();
            SendMsg(bc, m, P::kDiscover, 0);
            g_lan.erase(std::remove_if(g_lan.begin(), g_lan.end(), [&](const LanGame& g) { return now - g.seenMs > 3500; }), g_lan.end());
        }
        if (g_stage == Stage::Connecting)
        {
            if (now - g_helloAt >= 300 || !g_helloAt)
            {
                g_helloAt = now;
                P::HelloMsg m{};
                m.token = g_joinToken;
                m.clientId = g_clientId;
                P::CopyName(m.name, sizeof(m.name), g_opt.name.empty() ? "Your friend" : g_opt.name);
                SendMsg(g_host.addr, m, P::kHello, 0);
                if (g_haveAlt) SendMsg(g_altAddr, m, P::kHello, 0);
            }
            if (now - g_connectStart > 12000)
            {
                Logger::WriteFormat(Logger::Level::Warning, "Online: No answer from %s. The host's router must let the game in "
                    "(UPnP on, or UDP port %u forwarded to the host's PC), and Windows Firewall must allow the game there.",
                    AddrText(g_host.addr).c_str(), static_cast<unsigned>(ntohs(g_host.addr.sin_port)));
                g_error = "No answer from that game - its host's router or firewall may be blocking it";
                g_stage = Stage::Window;
                g_host = Peer{};
            }
        }
        if (g_stage == Stage::Watching)
        {
            if (now - g_host.heardMs > 6000) { g_error = "Lost the connection to " + g_host.name + "."; lost = true; }
            if (now - lastPing >= 500)
            {
                lastPing = now;
                P::PingMsg p{};
                p.sentMs = now; p.rttMs = g_host.rtt;
                SendMsg(g_host.addr, p, P::kPing, g_session);
            }
            g_rx.Poll(now, g_host.rtt ? g_host.rtt : 50, nacks, wantKey);
            for (const auto& nk : nacks)
                for (size_t from = 0; from == 0 || from < nk.second.size(); from += P::kNackMax)
                {
                    const auto pkt = P::BuildNack(g_session, nk.first, nk.second, from);
                    Send(g_host.addr, pkt.data(), pkt.size());
                }
            static uint32_t lastDecoderAsk = 0;
            if (OnlineVideo::TakeKeyframeRequest() && now - lastDecoderAsk >= std::max<uint32_t>(100, g_host.rtt + 20))
            {
                lastDecoderAsk = now;
                wantKey = true;
            }
            if (wantKey)
            {
                P::KeyRequestMsg k{};
                SendMsg(g_host.addr, k, P::kKeyRequest, g_session);
            }
            if (now - lastStats >= 1000)
            {
                lastStats = now;
                const auto vs = OnlineVideo::GetViewerStats();
                if (g_haveOffset && vs.captureMs && vs.shownAtMs)
                {
                    const int32_t lat = static_cast<int32_t>(vs.shownAtMs - (vs.captureMs - static_cast<uint32_t>(g_clockOffset)));
                    g_latencyMs = static_cast<uint32_t>(std::clamp(lat, 0, 9999));
                }
                P::StatsMsg s{};
                s.packets = g_rx.stats.packets; s.recovered = g_rx.stats.recovered; s.resendAsked = g_rx.stats.resendAsked;
                s.duplicates = g_rx.stats.duplicates; s.framesShown = vs.shown; s.framesLost = g_rx.stats.framesLost; s.keyAsks = g_rx.stats.keyAsks;
                s.decodeUs100 = static_cast<uint16_t>(std::clamp(vs.decodeMs * 10.0, 0.0, 65535.0));
                s.latencyMs = static_cast<uint16_t>(g_latencyMs);
                s.audioMs = static_cast<uint16_t>(std::clamp(OnlineAudio::BufferedMs(), 0, 65535));
                s.reserved = static_cast<uint16_t>(std::min<uint32_t>(g_maxGapMs, 65535));   // 1.7.1: the longest gap in the picture packets this second
                g_maxGapMs = 0;
                SendMsg(g_host.addr, s, P::kStats, g_session);
                static uint32_t lastPicLog = 0;   // 1.4.7: what arrives of the host's picture, in the log
                if (now - lastPicLog >= 5000)
                {
                    lastPicLog = now;
                    Logger::WriteFormat(Logger::Level::Info, "Online: picture from the host - packets %u (recovered %u, asked again %u), frames lost %u, "
                        "keyframes asked %u, decoded %u, decode failures %u, shown %u, %ux%u",
                        g_rx.stats.packets, g_rx.stats.recovered, g_rx.stats.resendAsked, g_rx.stats.framesLost, g_rx.stats.keyAsks,
                        vs.decoded, vs.failures, vs.shown, static_cast<unsigned>(vs.width), static_cast<unsigned>(vs.height));
                }
            }
            // the controller goes to the host (changes at once, the same state again every 50 ms);
            // leave: Back + Start held 2 s, or Esc held 1.5 s
            if (now - lastInput >= 4)
            {
                lastInput = now;
                XINPUT_GAMEPAD pad{};
                ReadOwnPad(pad);
                if (g_prevButtons == 0xFFFF) g_prevButtons = pad.wButtons;   // what is held when the picture comes is not a press
                constexpr WORD kLeave = XINPUT_GAMEPAD_BACK | XINPUT_GAMEPAD_START;
                if ((pad.wButtons & kLeave) == kLeave)
                {
                    if (!g_leaveHold) g_leaveHold = now;
                    else if (now - g_leaveHold > 2000) leave = true;
                    pad.wButtons = static_cast<WORD>(pad.wButtons & ~kLeave);
                }
                else g_leaveHold = 0;
                const bool esc = OurWindowInFront() && !OnlineChat::Typing() && (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0;
                if (esc) { if (!g_escHold) g_escHold = now; else if (now - g_escHold > 1500) leave = true; }
                else g_escHold = 0;
                // 1.7.8: START held 1 s (without View) opens the chat line on this PC. A tap still reaches the host when
                // it is let go - that's how a friend joins as a player ("press START to play").
                {
                    static uint32_t heldAt = 0;
                    static bool fired = false, startWas = true;
                    const bool startDown = (pad.wButtons & XINPUT_GAMEPAD_START) != 0;
                    const bool start = startDown && !(pad.wButtons & XINPUT_GAMEPAD_BACK);
                    if (start && !startWas && !OnlineChat::Typing()) { heldAt = now ? now : 1; fired = false; }
                    if (heldAt) {
                        if (!startDown || (pad.wButtons & XINPUT_GAMEPAD_BACK)) {
                            if (!startDown && !fired) {   // a tap: START to the host (a quarter second, so the host's game sees it)
                                g_chatStartUntil = (now + 250) ? now + 250 : 1;
                                Logger::Write(Logger::Level::Info, "Online: START tapped - sent to the host");
                            }
                            heldAt = 0;
                        } else {
                            if (!fired && now - heldAt >= 1000 && !ModMenuOpen()) { fired = true; OnlineChat::Open(); }
                            pad.wButtons = static_cast<WORD>(pad.wButtons & ~XINPUT_GAMEPAD_START);   // held back meanwhile
                        }
                    }
                    startWas = start;
                    static bool bWas = true;
                    const bool b = (pad.wButtons & XINPUT_GAMEPAD_B) != 0;
                    if (b && !bWas && OnlineChat::Typing()) OnlineChat::Close();   // B: closed without sending
                    bWas = b;
                }
                // buttons held since the picture came reach the host only once let go
                g_prevButtons = static_cast<WORD>(g_prevButtons & pad.wButtons);
                pad.wButtons = static_cast<WORD>(pad.wButtons & ~g_prevButtons);
                // 1.7.2: the co-op menu opens here, on this PC (its own mic). 1.7.7: View held 2 s (START is the
                // game's own again); a shorter View press reaches the host when it is let go (their inventory).
                // While the menu is up the host gets an idle controller.
                const uint32_t stepAway = g_stepAwayUntil.load();
                if (stepAway && static_cast<int32_t>(now - stepAway) < 0)
                {
                    // "Step away" picked in the co-op menu: View held 2.3 s on the host, as it always meant there
                    pad = XINPUT_GAMEPAD{};
                    pad.wButtons = XINPUT_GAMEPAD_BACK;
                    g_startAt = 0; g_startTapUntil = 0;
                    g_prevButtons = 0xFFFF;
                }
                else if (OnlineChat::Typing() || g_chatWasTyping)
                {
                    // 1.7.8: the chat line is open: an idle controller
                    pad = XINPUT_GAMEPAD{};
                    g_startAt = 0; g_startTapUntil = 0;
                    g_prevButtons = 0xFFFF;              // sent: the controller is back, what is held then is not a press
                    g_chatWasTyping = OnlineChat::Typing();
                }
                else if (ModMenuOpen())
                {
                    if (stepAway) g_stepAwayUntil.store(0);
                    pad = XINPUT_GAMEPAD{};
                    g_startAt = 0; g_startTapUntil = 0;
                    g_prevButtons = 0xFFFF;              // what is held when it closes is not a press
                }
                else
                {
                    if (stepAway) g_stepAwayUntil.store(0);
                    const bool viewNow = (pad.wButtons & XINPUT_GAMEPAD_BACK) != 0;
                    if (viewNow && !g_startAt && !(pad.wButtons & XINPUT_GAMEPAD_START)) { g_startAt = now ? now : 1; g_startFired = false; }
                    if (g_startAt)
                    {
                        if (viewNow)
                        {
                            if (!g_startFired && now - g_startAt >= 2000) { g_startFired = true; ModMenuShow(0, g_padUser); }
                            if (!(pad.wButtons & XINPUT_GAMEPAD_START)) pad.wButtons = static_cast<WORD>(pad.wButtons & ~XINPUT_GAMEPAD_BACK);   // (View + START: leaving)
                        }
                        else
                        {
                            if (!g_startFired) g_startTapUntil = (now + 120) ? now + 120 : 1;
                            g_startAt = 0;
                        }
                    }
                    if (g_startTapUntil && static_cast<int32_t>(now - g_startTapUntil) < 0) pad.wButtons |= XINPUT_GAMEPAD_BACK;
                    else g_startTapUntil = 0;
                }
                if (g_chatStartUntil) {   // 1.7.8: a START tap (let go before the chat line opened) goes to the host
                    if (static_cast<int32_t>(now - g_chatStartUntil) < 0 && !OnlineChat::Typing() && !ModMenuOpen()) pad.wButtons |= XINPUT_GAMEPAD_START;
                    else g_chatStartUntil = 0;
                }
                if (std::memcmp(&pad, &g_lastSent, sizeof(pad)) != 0 || now - g_lastInputSent >= 50)
                {
                    g_lastSent = pad;
                    g_lastInputSent = now;
                    SendInput(pad);
                }
            }
        }
        if (lost)
        {
            g_stage = Stage::Window;
            Message(g_error);
            PopupNotice(Wide(g_error), L"Back to the main menu", 8000);
            g_host = Peer{};
            g_mutex.unlock();
            OnlineVideo::StopViewer();
            OnlineAudio::StopPlayback();
            OnlineVoice::Stop();
            XInputRouteBlank(false);
            g_mutex.lock();
        }
        if (leave)
        {
            g_mutex.unlock();
            LeaveHost("left");
            g_mutex.lock();
        }
    }

    // g_mutex held.
    void ConnectTo(const sockaddr_in& at, uint32_t token)
    {
        g_host = Peer{};
        g_host.addr = at;
        g_haveAlt = false;
        g_joinToken = token;
        g_clientId = g_clientId ? g_clientId : Random32();
        g_stage = Stage::Connecting;
        g_connectStart = Now();
        g_helloAt = 0;
        g_error.clear();
        Logger::WriteFormat(Logger::Level::Info, "Online: joining %s", AddrText(at).c_str());
    }

    // ---------------- network thread ----------------
    void NetMain()
    {
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
        std::vector<uint8_t> buf(65536);
        while (g_netRun.load())
        {
            fd_set rs;
            FD_ZERO(&rs);
            FD_SET(g_sock, &rs);
            timeval tv{ 0, 1000 };
            select(0, &rs, nullptr, nullptr, &tv);
            for (int i = 0; i < 4096; ++i)
            {
                sockaddr_in from{};
                int fl = sizeof(from);
                const int n = recvfrom(g_sock, reinterpret_cast<char*>(buf.data()), static_cast<int>(buf.size()), 0, reinterpret_cast<sockaddr*>(&from), &fl);
                if (n <= 0) break;
                if (IsStun(buf.data(), n)) { HandleStun(buf.data(), n); continue; }
                const P::Header* h = P::Check(buf.data(), static_cast<size_t>(n));
                if (!h) continue;
                const uint32_t now = Now();
                if (RoleNow() == Role::Host) HostHandle(h, buf.data(), n, from, now);
                else if (RoleNow() == Role::Join) JoinHandle(h, buf.data(), n, from, now);
            }
            const uint32_t now = Now();
            if (RoleNow() == Role::Host) HostTick(now);
            else if (RoleNow() == Role::Join) JoinTick(now);
        }
    }

    bool OpenSocket(uint16_t port, bool host, std::string& why)
    {
        WSADATA wsa{};
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { why = "network start failed"; return false; }
        SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (s == INVALID_SOCKET) { why = "no network socket"; WSACleanup(); return false; }
        BOOL no = FALSE;
        DWORD ret = 0;
        WSAIoctl(s, SIO_UDP_CONNRESET, &no, sizeof(no), nullptr, 0, &ret, nullptr, nullptr);
        int big = 4 * 1024 * 1024;
        setsockopt(s, SOL_SOCKET, SO_RCVBUF, reinterpret_cast<const char*>(&big), sizeof(big));
        setsockopt(s, SOL_SOCKET, SO_SNDBUF, reinterpret_cast<const char*>(&big), sizeof(big));
        BOOL yes = TRUE;
        setsockopt(s, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<const char*>(&yes), sizeof(yes));
        u_long nb = 1;
        ioctlsocket(s, FIONBIO, &nb);
        bool bound = false;
        for (int i = 0; i < (host ? 10 : 1) && !bound; ++i)
        {
            sockaddr_in me{};
            me.sin_family = AF_INET;
            me.sin_addr.s_addr = htonl(INADDR_ANY);
            me.sin_port = htons(host ? static_cast<u_short>(port + i) : 0);
            if (bind(s, reinterpret_cast<sockaddr*>(&me), sizeof(me)) == 0)
            {
                sockaddr_in got{};
                int len = sizeof(got);
                getsockname(s, reinterpret_cast<sockaddr*>(&got), &len);
                g_boundPort = ntohs(got.sin_port);
                bound = true;
            }
        }
        if (!bound) { why = "port " + std::to_string(port) + " is in use"; closesocket(s); WSACleanup(); return false; }
        g_sock = s;
        return true;
    }

    void StopAll()
    {
        std::lock_guard<std::mutex> life(g_lifeMutex);
        const Role role = RoleNow();
        if (role == Role::Off) return;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (role == Role::Host)
                for (int i = 0; i < kMaxFriends; ++i)
                    if (g_peers[i].on) { SendBye(g_peers[i].addr, g_session, "the host stopped"); VPadSetRemote(g_peers[i].slot, nullptr); }
            if (role == Role::Join && g_host.on) SendBye(g_host.addr, g_session, "left");
        }
        OnlineLobby::HostStop();
        OnlineLobby::BrowseStop();
        OnlineLobby::JoinCancel();
        g_netRun.store(false);
        const uint32_t stoppedGen = g_hostGen.fetch_add(1);
        if (g_net.joinable()) g_net.join();
        if (g_setup.joinable()) g_setup.detach();
        if (role == Role::Host) StopStream();
        OnlineVideo::StopViewer();
        OnlineAudio::StopPlayback();
            OnlineVoice::Stop();
        XInputRouteBlank(false);
        bool unmap = false;
        uint16_t port = 0;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (g_sock != INVALID_SOCKET) { closesocket(g_sock); g_sock = INVALID_SOCKET; WSACleanup(); }
            unmap = g_upnpMapped;
            port = g_upnpPort;
            g_upnpMapped = false;
            for (Peer& p : g_peers) p = Peer{};
            SyncStreamTargets();
            g_host = Peer{};
            g_stage = Stage::None;
            g_code.clear();
            g_setupDone = false;
            g_lan.clear();
            g_listed = false;
            g_locked = false;
            g_pending.clear();
            g_accepted.clear();
            g_punch.clear();
            g_infoSent.clear();
            g_role.store(static_cast<int>(Role::Off));
            if (g_timerRes) { timeEndPeriod(1); g_timerRes = false; }
        }
        if (unmap) UpnpUnmap(port, stoppedGen);
        Logger::Write(Logger::Level::Info, "Online: stopped");
    }
}

namespace OnlinePlay
{
    void Init(const wchar_t* iniPath)
    {
        // 1.7.8: the stream's copy of a frame is picked up right after it was shown, not a frame later
        D3D9SetPostPresent([] { if (RoleNow() == Role::Host && g_streaming.load(std::memory_order_relaxed)) OnlineVideo::AfterPresent(); });
        char a[MAX_PATH * 2]{};
        WideCharToMultiByte(CP_ACP, 0, iniPath, -1, a, sizeof(a) - 1, nullptr, nullptr);
        g_iniA = a;
    }

    void AfterStartup() { OnlineAudio::RepairMuteOnce(); }   // not in DllMain (COM / audio)

    void OnPresent(IDirect3DDevice9* dev)
    {
        const Role r = RoleNow();
        if (r == Role::Host && g_streaming.load(std::memory_order_relaxed))
        {
            // 1.4.9: not the start menu - friends see the co-op lobby as text there (kLobbyText); the picture
            // starts with the game (intro, Player 1's creator, cutscenes and play).
            if (!(D3D9InSwapChainPresent() && game::CurrentMode() == game::MODE_PREGAME)) OnlineVideo::CaptureD3D9(dev);
        }
        else if (r == Role::Join && OnlineVideo::ViewerRunning()) OnlineVideo::DrawViewerD3D9(dev);
        else OnlineVideo::ViewerCursorBack(dev);
        OnlineVoice::Draw(dev);   // 1.7.2: after the picture was taken - each PC shows its own
        {
            // 1.7.8 text chat: a host with friends in, or a friend watching
            static bool senderSet = false;
            if (!senderSet) { OnlineChat::SetSender(&OnChatSend); senderSet = true; }
            bool online = false;
            if (r == Role::Host) {
                std::lock_guard<std::mutex> lock(g_streamMutex);
                for (int i = 0; i < kMaxFriends; ++i) online = online || g_streamOn[i];
            } else if (r == Role::Join) online = OnlineVideo::ViewerRunning();
            OnlineChat::SetOnline(online, r == Role::Host);
            OnlineChat::Draw(dev);
        }
        ModMenuDraw(dev);         // 1.7.2: the co-op menu (on this PC only)
    }

    void OnReset(IDirect3DDevice9*) { OnlineVideo::DeviceLost(); }

    std::string StartHosting()
    {
        if (RoleNow() == Role::Join) StopAll();
        std::lock_guard<std::mutex> life(g_lifeMutex);
        if (RoleNow() == Role::Host)
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            return g_code.empty() ? "Hosting: getting your invite code" : "Hosting - invite code " + g_code;
        }
        const Options o = LoadOptions();
        std::string why;
        if (!OpenSocket(static_cast<uint16_t>(o.port), true, why)) return "Cannot host: " + why;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_opt = o;
            g_fec.store(o.fec);
            g_token = Random32() & 0xFFFFFF;
            if (!g_token) g_token = 0x5A17;
            g_session = Random32();
            g_code.clear();
            g_codeNote = "Finding your internet address and opening the router...";
            g_codeWarn.clear();
            g_setupDone = false;
            for (Peer& p : g_peers) p = Peer{};
            SyncStreamTargets();
            g_stunIp.store(0);
            g_stunPort.store(0);
            g_listed = false;
            if (g_lockPref < 0) g_lockPref = GetPrivateProfileIntA("Online", "Locked", 0, Paths::GetConfigPath().c_str()) != 0 ? 1 : 0;
            g_locked = g_lockPref == 1;
            g_pending.clear();
            g_accepted.clear();
            g_punch.clear();
            g_role.store(static_cast<int>(Role::Host));
            if (!g_timerRes) g_timerRes = timeBeginPeriod(1) == TIMERR_NOERROR;
        }
        g_netRun.store(true);
        g_net = std::thread(NetMain);
        const uint16_t port = g_boundPort;
        const uint32_t gen = g_hostGen.fetch_add(1) + 1;
        if (g_setup.joinable()) g_setup.detach();
        g_setup = std::thread([port, gen] { HostSetup(port, gen); });
        Logger::WriteFormat(Logger::Level::Info, "Online: hosting started on UDP port %u (stream %dp %d fps %d kbps, %d %% recovery packets)",
            port, o.height, o.fps, o.bitrate, o.fec);
        return "Hosting";
    }

    std::string OpenJoin()
    {
        if (RoleNow() == Role::Host) StopAll();
        std::lock_guard<std::mutex> life(g_lifeMutex);
        if (RoleNow() == Role::Join)
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (g_stage == Stage::None) g_stage = Stage::Window;
            return "Join";
        }
        const Options o = LoadOptions();
        std::string why;
        if (!OpenSocket(0, false, why)) return "Cannot join: " + why;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_opt = o;
            g_stage = Stage::Window;
            g_host = Peer{};
            g_lan.clear();
            g_error.clear();
            g_lastClip = ClipboardText();   // a code already on the clipboard counts: it may be a fresh one
            if (g_lastClip.size() > 64) g_lastClip.clear();
            {
                uint32_t ip = 0, token = 0; uint16_t port = 0;
                if (g_lastClip != g_ownCode && P::ParseJoinCode(g_lastClip, ip, port, token)) g_lastClip.clear();   // (our own code: not a friend's)
            }
            g_discoverAt = 0;
            g_prevButtons = 0xFFFF;
            g_role.store(static_cast<int>(Role::Join));
            if (!g_timerRes) g_timerRes = timeBeginPeriod(1) == TIMERR_NOERROR;
        }
        g_netRun.store(true);
        g_net = std::thread(NetMain);
        if (o.stun) { g_stunIp.store(0); g_stunPort.store(0); StunAsk(); }   // our internet address, for the public list's join requests
        if (!o.lobby.empty()) OnlineLobby::BrowseStart(o.lobby, LobbyVersion());
        Logger::WriteFormat(Logger::Level::Info, "Online: join window open (watching the clipboard for an invite code%s)",
                            o.lobby.empty() ? "; no lobby server set" : ", public list on");
        return "Join";
    }

    void Stop() { StopAll(); }
    // 1.7.0: the host went back to the main menu (left the session): every friend is told and let go.
    void HostLeftGame()
    {
        bool any = false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (RoleNow() != Role::Host) return;
            for (int i = 0; i < kMaxFriends; ++i)
                if (g_peers[i].on) { SendBye(g_peers[i].addr, g_session, "left the game"); any = true; DropPeer(i, "was told the host left the game"); }
        }
        if (any) { StopStream(); Logger::Write(Logger::Level::Info, "Online: the host left the game - the friends were told"); }
    }
    // 1.7.0: the game is closing: a last goodbye to every friend (best effort - other threads may be gone).
    void NotifyExit()
    {
        if (!g_mutex.try_lock()) return;
        const Role r = RoleNow();
        if (r == Role::Host)
            for (int i = 0; i < kMaxFriends; ++i) if (g_peers[i].on) SendBye(g_peers[i].addr, g_session, "closed the game");
        if (r == Role::Join && g_host.on) SendBye(g_host.addr, g_session, "left");
        g_mutex.unlock();
    }

    int FriendsPlaying()
    {
        if (!Hosting()) return 0;
        std::lock_guard<std::mutex> lock(g_streamMutex);
        int n = 0;
        for (int k = 0; k < kMaxFriends; ++k) if (g_streamOn[k]) ++n;
        return n;
    }

    bool Hosting() { return RoleNow() == Role::Host; }
    bool Joining() { return RoleNow() == Role::Join; }
    // 1.7.1: asked every frame by the game's own thread (views' frame cap): it never waits for the network
    // thread's lock - if that is busy, the last answer is used
    void StepAway() { StepAwayFromMenu(); }   // 1.7.7: the co-op menu's "Step away" on a friend's PC

    bool Watching()
    {
        static std::atomic<bool> last{ false };
        if (RoleNow() != Role::Join) { last.store(false); return false; }
        std::unique_lock<std::mutex> lock(g_mutex, std::try_to_lock);
        if (lock.owns_lock()) last.store(g_stage == Stage::Watching);
        return last.load();
    }

    void LobbyLines(std::vector<std::pair<wchar_t, std::wstring>>& out)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        const Role r = RoleNow();
        if (r == Role::Host)
        {
            if (g_code.empty()) out.push_back({ L'W', L"Getting your invite code..." });
            else out.push_back({ L'W', L"Invite code: " + Wide(g_code) + L"  (copied - send it to your friends)" });
            if (!g_pending.empty())
                out.push_back({ L'R', Wide(g_pending.front().r.name) + L" wants to join - answer in the pop-up" });
            else if (g_listed)
            {
                std::string why;
                const OnlineLobby::HostStatus hs = OnlineLobby::HostState(&why);
                if (g_locked) out.push_back({ L'X', L"Locked: not on the public list - only friends with the invite code can join" });
                else if (hs == OnlineLobby::kHostListed) out.push_back({ L'X', L"On the public list - players ask to join, you say yes or no" });
                else if (hs == OnlineLobby::kHostFailed) out.push_back({ L'X', L"Public list unavailable (" + Wide(why) + L") - invite codes still work" });
                else out.push_back({ L'X', L"Listing the game..." });
            }
            else if (!g_codeWarn.empty()) out.push_back({ L'X', Wide(g_codeWarn) });
            else if (!g_codeNote.empty()) out.push_back({ L'X', Wide(g_codeNote) });
            else if (g_opt.lobby.empty()) out.push_back({ L'X', L"Public list: no lobby server in this build - friends join with the invite code" });
            return;
        }
        if (r != Role::Join) return;
        switch (g_stage)
        {
        case Stage::Window:
            if (!g_opt.lobby.empty())
            {
                out.push_back({ L'H', L"Join a game" });
                std::vector<OnlineLobby::Game> games;
                std::string status;
                const bool have = OnlineLobby::BrowseList(games, status);
                if (!have) out.push_back({ L'X', L"Getting the list of games..." });
                else if (!status.empty()) out.push_back({ L'X', L"Game list unavailable (" + Wide(status) + L") - invite codes still work" });
                else if (games.empty()) out.push_back({ L'X', L"No open games right now - the list refreshes by itself" });
                else
                {
                    const int sel = std::min(g_sel, static_cast<int>(games.size()) - 1);
                    const int first = std::max(0, std::min(sel - 1, static_cast<int>(games.size()) - 3));
                    for (int i = first; i < static_cast<int>(games.size()) && i < first + 3; ++i)
                    {
                        const OnlineLobby::Game& g = games[static_cast<size_t>(i)];
                        wchar_t line[200];
                        swprintf(line, 200, L"%ls%ls - %d/%d players%ls - %ls%ls%ls", i == sel ? L"> " : L"   ", Wide(g.name).c_str(),
                                 g.players, g.max, g.open <= 0 || g.players >= g.max ? L" (full)" : L"",
                                 g.area.empty() ? L"in the menus" : Wide(g.area).c_str(),
                                 g.country.empty() ? L"" : L" - ", Wide(g.country).c_str());
                        out.push_back({ i == sel ? L'R' : L'W', line });
                    }
                }
                out.push_back({ L'X', L"D-pad / arrows: choose, A / Enter: ask to join, Y / Q: quick join - or copy an invite code (Ctrl+C)" });
                for (const LanGame& g : g_lan)
                {
                    if (!g.full) { out.push_back({ L'W', L"On this network: " + Wide(g.name) + L"'s game - press X to join" }); break; }
                }
                if (!g_error.empty()) out.push_back({ L'X', Wide(g_error) });
                break;
            }
            out.push_back({ L'H', L"Join a friend's game" });
            out.push_back({ L'X', L"Game list: no lobby server in this build (lobby-server\\README.md) - invite codes only" });
            out.push_back({ L'W', L"Copy your friend's invite code (select it, Ctrl+C) - this connects by itself" });
            for (const LanGame& g : g_lan)
            {
                out.push_back({ g.full ? L'X' : L'W', (g.full ? L"On this network: " + Wide(g.name) + L"'s game (full)"
                                                              : L"On this network: " + Wide(g.name) + L"'s game - press X on your controller to join") });
                break;
            }
            if (!g_error.empty()) out.push_back({ L'X', Wide(g_error) });
            out.push_back({ L'X', L"In the game: your controller plays; hold Back + Start (or Esc) to leave" });
            break;
        case Stage::Asking:
            out.push_back({ L'H', L"Join a game" });
            out.push_back({ L'W', L"Asking " + Wide(g_askName) + L" to let you in..." });
            out.push_back({ L'X', L"The host decides (up to 40 seconds) - X: stop asking" });
            break;
        case Stage::Connecting:
            out.push_back({ L'H', L"Join a friend's game" });
            out.push_back({ L'W', L"Connecting to " + Wide(AddrText(g_host.addr)) + L"..." });
            break;
        case Stage::Watching:
        {
            const uint32_t now = Now();
            if (g_watchSince == 0) g_watchSince = now;
            if (g_lobbyInAt && now - g_lobbyInAt < 3000)
            {
                // the host is in the co-op lobby: show it here (this controller already plays in it)
                out.push_back({ L'H', Wide(g_host.name) + L"'s co-op lobby" });
                if (g_lobbySlot) out.push_back({ L'R', L"You are Player " + std::to_wstring(g_lobbySlot) + L" - press A on your controller when ready (B: not ready)" });
                else out.push_back({ L'W', L"Press START on your controller to take a player slot" });
                std::wstring w = Wide(g_lobbyIn);
                size_t at = 0;
                while (at <= w.size() && out.size() < 7)
                {
                    size_t bar = w.find(L'|', at);
                    if (bar == std::wstring::npos) bar = w.size();
                    if (bar > at + 1) out.push_back({ w[at], w.substr(at + 1, bar - at - 1) });
                    at = bar + 1;
                }
                break;
            }
            out.push_back({ L'H', L"Connected to " + Wide(g_host.name) });
            if (g_lobbyInAt) out.push_back({ L'R', L"The game is starting - loading the host's picture..." });
            else out.push_back({ L'R', L"Waiting for the host..." });
            if (now - g_watchSince > 15000 && g_videoPackets == 0)
                out.push_back({ L'X', L"No picture from the host yet - the host's DAOCoop.log says why (send it with yours)" });
            out.push_back({ L'X', L"Leave: hold Back + Start on your controller, or Esc" });
            break;
        }
        default:
            break;
        }
    }

    // ---------------- the join menus (1.4.3: Join Game > Browse Games / Enter Invite Code) ----------------
    std::string Clean(const std::string& s)   // no separators in menu text
    {
        std::string o;
        for (char c : s) o += (c == '|' || c == '~' || c == '\n' || c == '\r') ? ' ' : c;
        return o;
    }

    std::wstring GamesList()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (RoleNow() != Role::Join) return L"off";
        std::wstring out;
        std::vector<OnlineLobby::Game> games;
        std::string status;
        bool have = false;
        if (g_opt.lobby.empty()) out = L"The game list is not switched on in this build (no lobby server) - Join a Friend still works";
        else
        {
            have = OnlineLobby::BrowseList(games, status);
            if (!have) out = L"Getting the list of games...";
            else if (!status.empty()) out = L"Game list unavailable (" + Wide(status) + L") - invite codes still work";
            else out = L"";
        }
        if (!g_error.empty() && !g_opt.lobby.empty()) out = Wide(Clean(g_error)) + (out.empty() ? L"" : L" - " + out);
        else if (!g_error.empty() && out.empty()) out = Wide(Clean(g_error));
        int n = 0;
        for (size_t i = 0; i < g_lan.size() && n < 6; ++i)
        {
            const LanGame& g = g_lan[i];
            out += L"|lan" + std::to_wstring(i) + L"~" + Wide(Clean(g.name)) + (g.full ? L" - full (this network)" : L" - on this network");
            ++n;
        }
        for (const OnlineLobby::Game& g : games)
        {
            if (n >= 6) break;
            wchar_t line[200];
            swprintf(line, 200, L"%ls - %d/%d players%ls - %ls", Wide(Clean(g.name)).c_str(), g.players, g.max,
                     g.open <= 0 || g.players >= g.max ? L" (full)" : L"",
                     g.area.empty() ? L"in the menus" : Wide(Clean(g.area)).c_str());
            out += L"|" + Wide(Clean(g.id)) + L"~" + line;
            ++n;
        }
        if (n == 0 && out.empty()) out = L"No open games right now - the list refreshes by itself";
        return out;
    }

    void BrowseRefresh() { OnlineLobby::BrowseRefreshNow(); }

    bool AskToJoin(const std::string& id)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (RoleNow() != Role::Join || g_stage != Stage::Window) return false;
        g_error.clear();
        if (id.rfind("lan", 0) == 0)
        {
            const size_t i = static_cast<size_t>(atoi(id.c_str() + 3));
            if (i >= g_lan.size() || g_lan[i].full) { g_error = "That game is full or gone."; return false; }
            ConnectTo(g_lan[i].addr, g_lan[i].token);
            return true;
        }
        std::vector<OnlineLobby::Game> games;
        std::string status;
        OnlineLobby::BrowseList(games, status);
        for (const OnlineLobby::Game& g : games)
        {
            if (g.id != id) continue;
            const uint32_t now = Now();
            const uint32_t sip = g_stunIp.load();
            const std::string mine = sip ? IpText(sip) + ":" + std::to_string(g_stunPort.load()) : std::string();
            const uint32_t lan = LocalIp();
            const std::string mineLan = lan ? IpText(lan) + ":" + std::to_string(g_boundPort) : std::string();
            g_clientId = g_clientId ? g_clientId : Random32();
            OnlineLobby::JoinAsk(g_opt.lobby, LobbyVersion(), g.id, g_opt.name.empty() ? "Player" : g_opt.name,
                                 std::to_string(g_clientId), mine, mineLan);
            g_askName = g.name;
            g_stage = Stage::Asking;
            g_connectStart = now;
            Logger::WriteFormat(Logger::Level::Info, "Online: asking %s (%s) to let us in (we are %s / %s)", g.name.c_str(), g.id.c_str(),
                                mine.empty() ? "?" : mine.c_str(), mineLan.c_str());
            return true;
        }
        g_error = "That game is not on the list any more.";
        OnlineLobby::BrowseRefreshNow();
        return false;
    }

    bool JoinWithCode(const std::string& text)
    {
        std::string code;
        for (char c : text) if (c != ' ' && c != '\t' && c != '\r' && c != '\n') code += c;
        std::lock_guard<std::mutex> lock(g_mutex);
        if (RoleNow() != Role::Join || g_stage != Stage::Window) return false;
        uint32_t ip = 0, token = 0;
        uint16_t port = 0;
        if (code == g_ownCode && !g_ownCode.empty()) { g_error = "That is your own invite code - it is for your friends."; return false; }
        if (!P::ParseJoinCode(code, ip, port, token)) { g_error = "That invite code is not right - check it and try again."; return false; }
        g_error.clear();
        g_lastClip = code;
        sockaddr_in at{};
        at.sin_family = AF_INET;
        at.sin_addr.s_addr = htonl(ip);
        at.sin_port = htons(port);
        ConnectTo(at, token);
        return true;
    }

    std::wstring ClipboardCode()
    {
        std::string c = ClipboardText();
        std::string code;
        for (char ch : c) if (ch != ' ' && ch != '\t' && ch != '\r' && ch != '\n') code += ch;
        uint32_t ip = 0, token = 0;
        uint16_t port = 0;
        if (code.size() > 64 || !P::ParseJoinCode(code, ip, port, token)) return L"";
        return Wide(code);
    }

    int JoinStage()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (RoleNow() != Role::Join) return -1;
        switch (g_stage)
        {
        case Stage::Window: return 0;
        case Stage::Asking: return 1;
        case Stage::Connecting: return 2;
        case Stage::Watching: return 3;
        default: return -1;
        }
    }

    void JoinBack()
    {
        bool leave = false;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (RoleNow() != Role::Join) return;
            if (g_stage == Stage::Asking) { OnlineLobby::JoinCancel(); g_stage = Stage::Window; g_error.clear(); }
            else if (g_stage == Stage::Connecting || g_stage == Stage::Watching) leave = true;
            else g_error.clear();
        }
        if (leave) { LeaveHost("left"); std::lock_guard<std::mutex> lock(g_mutex); g_error.clear(); }
    }

    void SetLobbyText(const std::wstring& lines)
    {
        std::string u;
        const int n = WideCharToMultiByte(CP_UTF8, 0, lines.c_str(), -1, nullptr, 0, nullptr, nullptr);
        if (n > 1) { u.resize(static_cast<size_t>(n - 1)); WideCharToMultiByte(CP_UTF8, 0, lines.c_str(), -1, &u[0], n, nullptr, nullptr); }
        std::lock_guard<std::mutex> lock(g_mutex);
        g_lobbyOut = u.substr(0, 750);
    }

    int LockState()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (RoleNow() != Role::Host) return -1;   // (1.4.2: shown even without a lobby server, so the host always has it)
        return g_locked ? 1 : 0;
    }

    void SetLocked(bool on)
    {
        WritePrivateProfileStringA("Online", "Locked", on ? "1" : "0", Paths::GetConfigPath().c_str());
        std::lock_guard<std::mutex> lock(g_mutex);
        g_lockPref = on ? 1 : 0;
        if (g_locked == on) return;
        g_locked = on;
        Logger::WriteFormat(Logger::Level::Info, "Online: game %s", on ? "locked (off the public list, invite codes still work)" : "unlocked (on the public list)");
        if (RoleNow() != Role::Host || !g_listed) return;
        const uint32_t now = Now();
        if (on)
            while (!g_pending.empty()) { Answer(g_pending.front(), false, now, "That game is locked."); g_pending.pop_front(); }
        SendInfo(now, true);
    }

    void SetHostInfo(int players, int maxPlayers, int open, const std::wstring& area)
    {
        std::string a;
        const int n = WideCharToMultiByte(CP_UTF8, 0, area.c_str(), -1, nullptr, 0, nullptr, nullptr);
        if (n > 1) { a.resize(static_cast<size_t>(n - 1)); WideCharToMultiByte(CP_UTF8, 0, area.c_str(), -1, &a[0], n, nullptr, nullptr); }
        std::lock_guard<std::mutex> lock(g_mutex);
        g_infoPlayers = std::clamp(players, 1, 3);
        g_infoMax = std::clamp(maxPlayers, 2, 3);
        g_infoOpen = std::clamp(open, 0, 2);
        g_infoArea = a.substr(0, 48);
    }

    std::wstring FriendName(int slot)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        for (const Peer& p : g_peers) if (p.on && p.slot == slot) return Wide(p.name);
        return L"";
    }

    bool TakeMessage(std::wstring& out)
    {
        std::unique_lock<std::mutex> lock(g_mutex, std::try_to_lock);   // 1.7.1: game thread, every tick: never waits
        if (!lock.owns_lock()) return false;
        if (g_messages.empty()) return false;
        out = g_messages.front();
        g_messages.pop_front();
        return true;
    }

    void Shutdown() { StopAll(); }
}
