// 1.7.0 testing: a virtual controller driven from DAOCoop.ini, so the mod can be tested with no one at the PC.
// It is the online-friend controller slot 4 (vpad.h), which the co-op lobby gives to Player 2 like a real one;
// after P3 in the commands, slot 5 (the second online friend, Player 3).
//   [TestPad] Enabled = 1
//   [TestPad] Cmd = <n>: <commands>     a new <n> runs the commands once, in order:
//     A B X Y START BACK LB RB LS RS UP DOWN LEFT RIGHT   tap a button (0.15 s down, 0.25 s up)
//     L:x,y,s   left stick at x,y (-1..1) for s seconds       R:x,y,s   right stick
//     LT:s RT:s   hold a trigger s seconds                     W:s   wait s seconds
//     HOLD:BUTTON,s   hold a button s seconds
//     SCAN   log the usable objects around the player     USE:<hex id>   the player uses that object
//     P2 / P3   the commands after it drive Player 2 (slot 4, the default) or Player 3 (slot 5)
#include "testpad.h"
#include "vpad.h"
#include "log.h"
#include "interact.h"
#include "equiplock.h"
#include <windows.h>
#include <string>
#include <vector>
#include <cstdlib>
#include <cwchar>

namespace
{
    wchar_t g_ini[MAX_PATH] = L"";
    XINPUT_GAMEPAD g_pad = {};
    int g_slot = kVPadFirst;          // P2 / P3 in the commands: slot 4 (first online friend) or 5 (second)
    volatile long g_player = 2;       // whose character SCAN / USE are about
    volatile long g_scan = 0;
    volatile long g_use = 0;          // USE:<hex id>, done on the main thread

    WORD Button(const std::wstring& n)
    {
        struct { const wchar_t* n; WORD b; } t[] = {
            { L"A", XINPUT_GAMEPAD_A }, { L"B", XINPUT_GAMEPAD_B }, { L"X", XINPUT_GAMEPAD_X }, { L"Y", XINPUT_GAMEPAD_Y },
            { L"START", XINPUT_GAMEPAD_START }, { L"BACK", XINPUT_GAMEPAD_BACK },
            { L"LB", XINPUT_GAMEPAD_LEFT_SHOULDER }, { L"RB", XINPUT_GAMEPAD_RIGHT_SHOULDER },
            { L"LS", XINPUT_GAMEPAD_LEFT_THUMB }, { L"RS", XINPUT_GAMEPAD_RIGHT_THUMB },
            { L"UP", XINPUT_GAMEPAD_DPAD_UP }, { L"DOWN", XINPUT_GAMEPAD_DPAD_DOWN },
            { L"LEFT", XINPUT_GAMEPAD_DPAD_LEFT }, { L"RIGHT", XINPUT_GAMEPAD_DPAD_RIGHT } };
        for (auto& e : t) if (_wcsicmp(e.n, n.c_str()) == 0) return e.b;
        return 0;
    }
    SHORT Axis(double v) { if (v > 1) v = 1; if (v < -1) v = -1; return (SHORT)(v * 32767); }
    void Push() { VPadSetRemote(g_slot, &g_pad); }
    void Hold(DWORD ms) { DWORD end = GetTickCount() + ms; while ((int)(end - GetTickCount()) > 0) { Push(); Sleep(15); } }

    void Run(const std::wstring& cmds)
    {
        Log("Test pad: %ls", cmds.c_str());
        size_t i = 0;
        while (i < cmds.size()) {
            while (i < cmds.size() && cmds[i] == L' ') ++i;
            size_t j = cmds.find(L' ', i);
            std::wstring tok = cmds.substr(i, j == std::wstring::npos ? std::wstring::npos : j - i);
            i = j == std::wstring::npos ? cmds.size() : j + 1;
            if (tok.empty()) continue;
            size_t c = tok.find(L':');
            std::wstring head = c == std::wstring::npos ? tok : tok.substr(0, c);
            std::vector<double> a;
            std::wstring rest = c == std::wstring::npos ? L"" : tok.substr(c + 1);
            if (_wcsicmp(head.c_str(), L"HOLD") == 0) {
                size_t k = rest.find(L',');
                WORD b = Button(rest.substr(0, k));
                double s = k == std::wstring::npos ? 1.0 : wcstod(rest.c_str() + k + 1, nullptr);
                g_pad.wButtons |= b; Hold((DWORD)(s * 1000)); g_pad.wButtons &= ~b; Hold(250);
                continue;
            }
            for (const wchar_t* p = rest.c_str(); *p; ) { wchar_t* e; double v = wcstod(p, &e); if (e == p) break; a.push_back(v); p = (*e == L',') ? e + 1 : e; }
            if (c == std::wstring::npos && (_wcsicmp(head.c_str(), L"P2") == 0 || _wcsicmp(head.c_str(), L"P3") == 0)) {
                XINPUT_GAMEPAD rest = {};
                VPadSetRemote(g_slot, &rest);
                g_pad = rest;
                const bool three = _wcsicmp(head.c_str(), L"P3") == 0;
                g_slot = kVPadFirst + (three ? 1 : 0);
                InterlockedExchange(&g_player, three ? 3 : 2);
                Push();
                continue;
            }
            if (_wcsicmp(head.c_str(), L"USE") == 0) {
                InterlockedExchange(&g_use, (long)wcstoul(rest.c_str(), nullptr, 16));
                continue;
            }
            if (c == std::wstring::npos && _wcsicmp(head.c_str(), L"SCAN") == 0) {
                InterlockedExchange(&g_scan, 1);               // done on the game's main thread (TestPadMainThread)
                continue;
            }
            if (c == std::wstring::npos) {
                WORD b = 0;
                for (size_t s = 0, e; s <= head.size(); s = e + 1) {      // A or BACK+Y (pressed together)
                    e = head.find(L'+', s); if (e == std::wstring::npos) e = head.size();
                    b |= Button(head.substr(s, e - s));
                }
                if (!b) { Log("Test pad: unknown \"%ls\"", tok.c_str()); continue; }
                g_pad.wButtons |= b; Hold(150); g_pad.wButtons &= ~b; Hold(250);
            } else if ((_wcsicmp(head.c_str(), L"L") == 0 || _wcsicmp(head.c_str(), L"R") == 0) && a.size() >= 3) {
                bool left = _wcsicmp(head.c_str(), L"L") == 0;
                (left ? g_pad.sThumbLX : g_pad.sThumbRX) = Axis(a[0]);
                (left ? g_pad.sThumbLY : g_pad.sThumbRY) = Axis(a[1]);
                Hold((DWORD)(a[2] * 1000));
                (left ? g_pad.sThumbLX : g_pad.sThumbRX) = 0;
                (left ? g_pad.sThumbLY : g_pad.sThumbRY) = 0;
                Hold(100);
            } else if ((_wcsicmp(head.c_str(), L"LT") == 0 || _wcsicmp(head.c_str(), L"RT") == 0) && a.size() >= 1) {
                BYTE& t = _wcsicmp(head.c_str(), L"LT") == 0 ? g_pad.bLeftTrigger : g_pad.bRightTrigger;
                t = 255; Hold((DWORD)(a[0] * 1000)); t = 0; Hold(150);
            } else if (_wcsicmp(head.c_str(), L"W") == 0 && a.size() >= 1) {
                Hold((DWORD)(a[0] * 1000));
            } else Log("Test pad: unknown \"%ls\"", tok.c_str());
        }
        Log("Test pad: done");
    }

    DWORD WINAPI Thread(LPVOID)
    {
        std::wstring last;
        bool first = true;
        for (;;) {
            wchar_t buf[2048] = L"";
            GetPrivateProfileStringW(L"TestPad", L"Cmd", L"", buf, 2048, g_ini);
            std::wstring now = buf;
            if (first) { last = now; first = false; }          // what was there at start isn't run
            else if (now != last) {
                last = now;
                size_t c = now.find(L':');
                if (c != std::wstring::npos) Run(now.substr(c + 1));
            }
            Hold(300);
        }
    }
}

void TestPadInit(const wchar_t* iniPath)
{
    if (!GetPrivateProfileIntW(L"TestPad", L"Enabled", 0, iniPath)) return;
    wcsncpy(g_ini, iniPath, MAX_PATH - 1);
    Push();                                    // "plugged in" (slot 5 too, for P3 tests)
    { XINPUT_GAMEPAD rest = {}; VPadSetRemote(kVPadFirst + 1, &rest); }
    HANDLE t = CreateThread(nullptr, 0, &Thread, nullptr, 0, nullptr);
    if (t) CloseHandle(t);
    Log("Test pad: a virtual controller in slot %d, driven by [TestPad] Cmd in the ini", kVPadFirst);
}

void TestPadMainThread()
{
    long use = InterlockedExchange(&g_use, 0);
    bool scan = InterlockedExchange(&g_scan, 0) != 0;
    if (!use && !scan) return;
    const int pl = (int)g_player;
    uint32_t me = CoopCharacterOf(pl);
    if (me == 0xFFFFFFFF) { Log("Test pad: no Player %d character", pl); return; }
    if (use) InteractUseId(pl, me, (uint32_t)use);
    if (scan) InteractScan(me);
}
