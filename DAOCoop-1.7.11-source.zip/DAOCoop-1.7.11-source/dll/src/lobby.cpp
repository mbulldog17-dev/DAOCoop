#include "lobby.h"
#include "coopcontrol.h"
#include "partyslots.h"
#include "pads.h"
#include "hooks.h"
#include "equiplock.h"
#include "game.h"
#include "targetui.h"
#include "coopcreate.h"
#include "log.h"
#include "vpad.h"
#include "xinputroute.h"
#include "online/OnlinePlay.h"
#include <windows.h>
#include <cwchar>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>

static LobbySettings g_s;
static wchar_t g_ini[MAX_PATH];

enum Mode { MODE_LOCAL, MODE_HOST, MODE_JOIN };
static bool g_loadSave = false;          // 1.2.28: the host chose Load Game (not New Game) before the lobby
enum Slot { SLOT_NOPAD, SLOT_CONNECTED, SLOT_JOINED, SLOT_READY };

static bool g_active = false;
static Mode g_mode = MODE_LOCAL;
static int  g_players = 2;
static bool g_p1Ready = false;
static Slot g_slot[4] = {};            // [2], [3]
static WORD g_prev[4] = {};
// Controller order: the first free controller to press START is Player 2, the next Player 3.
static int  g_savedPad[4] = { -1, -1, -1, -1 };   // assignment before the lobby (restored on Back)
static bool g_p1Kbm = false;                         // 1.2.32: Player 1 plays with keyboard and mouse
static int  g_p1Pad = 0;                              // Player 1's controller slot when on a controller
static unsigned g_p1PressAt = 0;                    // START/A seen on Player 1's controller (hint on screen)

static const char* ModeName(Mode m) { return m == MODE_HOST ? "online host" : m == MODE_JOIN ? "online join" : "local"; }

// ---------------------------------------------------------------------------
// Online: placeholders for the network layer (not built yet). The lobby and
// menus already call these, so plugging in a transport only means filling them.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Session
// ---------------------------------------------------------------------------
static void WriteSession(int players, const wchar_t* mode)
{
    wchar_t v[16];
    swprintf(v, 16, L"%d", players);
    WritePrivateProfileStringW(L"Session", L"Players", v, g_ini);
    WritePrivateProfileStringW(L"Session", L"Mode", mode, g_ini);
}

static void ApplySession(int players, bool fromLobby)
{
    CoopSetPlayers(players, fromLobby);
    if (fromLobby && g_s.slotsFromLobby && PartySlotsCurrent() < 3 + players)
        PartySlotsApply(3 + players);      // Warden + 3 companions + co-op players
}

void LobbyApplySavedSession()
{
    int players = (int)GetPrivateProfileIntW(L"Session", L"Players", 3, g_ini);
    wchar_t mode[16];
    GetPrivateProfileStringW(L"Session", L"Mode", L"", mode, 16, g_ini);
    Log("Session: last game was started with %d player%s (%ls)", players, players == 1 ? "" : "s", mode[0] ? mode : L"no lobby yet");
    CoopSetPlayers(players, false);
    // A game started from the lobby keeps its party slots when it is loaded again.
    if (g_s.slotsFromLobby && players >= 2 && (wcscmp(mode, L"local") == 0 || wcscmp(mode, L"online") == 0))
        PartySlotsApply(PartySlotsCurrent() > 3 + players ? PartySlotsCurrent() : 3 + players);
}

// ---------------------------------------------------------------------------
// Lobby state
// ---------------------------------------------------------------------------
static void Reset()
{
    g_p1Ready = false;
    for (int p = 2; p <= 3; ++p) { g_slot[p] = SLOT_NOPAD; g_prev[p] = 0xFFFF; }   // ignore buttons already held
}

static bool PlayerReady(int p)
{
    return g_slot[p] == SLOT_READY;            // local and Parsec-hosted alike
}

// Player 1's input: keyboard + mouse frees controller 1 for Players 2/3 (remembered in DAOCoop.ini).
static void SetP1Input(bool kbm, const char* why)
{
    if (kbm == g_p1Kbm && PadsP1Index() == (kbm ? -1 : g_p1Pad)) return;
    g_p1Kbm = kbm;
    if (!kbm) {   // back on the controller: a co-op player holding it lets go
        for (int p = 2; p <= 3; ++p) {
            CoopPlayer cp = p == 2 ? PLAYER_2 : PLAYER_3;
            if (PadsIndex(cp) == g_p1Pad) { PadsAssign(cp, -1); g_slot[p] = SLOT_NOPAD; }
        }
    }
    PadsSetP1Index(kbm ? -1 : g_p1Pad);
    XInputRouteP1None(kbm);
    WritePrivateProfileStringW(L"Controllers", L"P1Input", kbm ? L"keyboard" : L"controller", g_ini);
    Log("Lobby: Player 1 uses %s (%s)", kbm ? "keyboard and mouse" : "a controller", why);
}

static bool OurWindowInFront()
{
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

static bool AllReady()
{
    if (!g_p1Ready || g_mode == MODE_JOIN) return false;
    for (int p = 2; p <= g_players; ++p) if (!PlayerReady(p)) return false;
    return true;
}

// Online (1.2.26) = the host's game streamed with Parsec: remote players' controllers
// arrive as local XInput pads, so hosting works exactly like local co-op.
static bool CanStart() { return AllReady() && (g_mode == MODE_LOCAL || g_mode == MODE_HOST); }

// Presses come from the poll thread (PadsTakePressed: remembered until read),
// so this works whenever it runs - on the timer tick or when the menu polls.
static void LobbyProcess(unsigned now)
{
    if (!g_active || g_mode == MODE_JOIN) return;
    static bool noted = false;
    if (!noted) { noted = true; Log("Lobby: reading controllers"); }

    // Player 1 on the keyboard: E readies up (and frees controller 1 for the others)
    static bool eWas = true;
    bool e = OurWindowInFront() && (GetAsyncKeyState('E') & 0x8000) != 0;
    if (e && !eWas) {
        SetP1Input(true, "E pressed");
        g_p1Ready = !g_p1Ready;
        Log("Lobby: Player 1 %s (keyboard)", g_p1Ready ? "ready" : "not ready");
    }
    eWas = e;

    WORD playerPressed[4] = {};
    for (int slot = 0; slot < kVPadSlots; ++slot) {   // 4/5: online friends
        WORD pr = PadsTakePressed(slot);
        if (!pr) continue;
        int owner = slot == PadsIndex(PLAYER_2) ? 2 : slot == PadsIndex(PLAYER_3) ? 3 : 0;
        if (owner && owner <= g_players) { playerPressed[owner] |= pr; continue; }
        // keyboard Player 1 going back to their controller: View/Back on it (while nobody else has it)
        if (g_p1Kbm && slot == g_p1Pad && (pr & XINPUT_GAMEPAD_BACK)) { SetP1Input(false, "View on controller 1"); g_p1PressAt = now ? now : 1; continue; }
        if (!(pr & (XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_A))) continue;
        if (slot == PadsP1Index()) {
            // Player 1's own controller drives the menu; it never becomes Player 2/3.
            g_p1PressAt = now ? now : 1;
            static unsigned lastNote = 0;
            if (now - lastNote > 3000) { lastNote = now; Log("Lobby: START/A on controller %d = Player 1's controller ([Controllers] P1Pad=%d), not a co-op player", slot + 1, slot); }
            continue;
        }
        if (!g_s.assignInLobby) { Log("Lobby: START/A on controller %d - not a co-op player's slot ([Controllers] P2Pad/P3Pad)", slot + 1); continue; }
        Log("Lobby: START/A on free controller %d", slot + 1);
        for (int p = 2; p <= g_players; ++p) {
            CoopPlayer cp = p == 2 ? PLAYER_2 : PLAYER_3;
            if (PadsIndex(cp) >= 0) continue;
            PadsAssign(cp, slot);
            g_slot[p] = SLOT_JOINED;
            PadsRumble(cp, 150);
            Log("Lobby: controller %d is Player %d", slot + 1, p);
            break;
        }
    }

    // 1.4.6: an online friend gets the next free player slot as soon as they are connected (join order),
    // already joined - they only ready up with A.
    if (g_mode == MODE_HOST && g_s.assignInLobby) {
        for (int slot = kVPadFirst; slot < kVPadSlots; ++slot) {
            if (!PadsSlotConnected(slot) || slot == PadsIndex(PLAYER_2) || slot == PadsIndex(PLAYER_3)) continue;
            for (int p = 2; p <= g_players; ++p) {
                CoopPlayer cp = p == 2 ? PLAYER_2 : PLAYER_3;
                if (PadsIndex(cp) >= 0) continue;
                PadsAssign(cp, slot);
                g_slot[p] = SLOT_JOINED;
                Log("Lobby: online friend %ls is Player %d", OnlinePlay::FriendName(slot).c_str(), p);
                break;
            }
        }
    }

    for (int p = 2; p <= 3; ++p) {
        CoopPlayer cp = p == 2 ? PLAYER_2 : PLAYER_3;
        if (p > g_players) { g_slot[p] = SLOT_NOPAD; continue; }
        int idx = PadsIndex(cp);
        if (idx < 0 || !PadsSlotConnected(idx)) {
            if (g_slot[p] != SLOT_NOPAD && idx >= 0) {
                Log("Lobby: Player %d controller disconnected", p);
                if (g_s.assignInLobby) PadsAssign(cp, -1);
            }
            if (idx >= 0 || g_slot[p] != SLOT_JOINED) g_slot[p] = SLOT_NOPAD;
            continue;
        }
        WORD pressed = playerPressed[p];
        Slot was = g_slot[p];
        if (g_slot[p] == SLOT_NOPAD) g_slot[p] = SLOT_CONNECTED;
        switch (g_slot[p]) {
        case SLOT_CONNECTED:
            if (pressed & (XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_A)) g_slot[p] = SLOT_JOINED;
            break;
        case SLOT_JOINED:
            if (pressed & XINPUT_GAMEPAD_A) g_slot[p] = SLOT_READY;
            else if (pressed & XINPUT_GAMEPAD_B) {
                g_slot[p] = SLOT_CONNECTED;
                if (g_s.assignInLobby) { PadsAssign(cp, -1); g_slot[p] = SLOT_NOPAD; Log("Lobby: Player %d left (controller free again)", p); continue; }
            }
            break;
        case SLOT_READY:
            if (pressed & (XINPUT_GAMEPAD_B | XINPUT_GAMEPAD_START)) g_slot[p] = SLOT_JOINED;
            break;
        default: break;
        }
        if (g_slot[p] != was) {
            static const char* kName[] = { "no controller", "connected", "joined", "ready" };
            Log("Lobby: Player %d %s", p, kName[g_slot[p]]);
            if (g_slot[p] == SLOT_JOINED || g_slot[p] == SLOT_READY) PadsRumble(cp, g_slot[p] == SLOT_READY ? 250 : 120);
        }
    }
}

void LobbyTick(unsigned now)
{
    LobbyProcess(now);
}

// The lines the menu shows, "allReady|canStart|<code><text>|...".
static void BuildStatus(wchar_t* out, int cap)
{
    wchar_t line[160];
    int n = swprintf(out, cap, L"%d|%d|%d", AllReady() ? 1 : 0, CanStart() ? 1 : 0, g_p1Ready ? 1 : 0);   // (1.2.32: Player 1 ready, for the button)
    std::wstring friends;                 // 1.4.6: what online friends see of this lobby
    bool toFriends = false;
    auto add = [&](wchar_t code, const wchar_t* text) {
        if (n < cap - 4) n += swprintf(out + n, cap - n, L"|%c%ls", code, text);
        if (toFriends) { if (!friends.empty()) friends += L'|'; friends += code; friends += text; }
    };

    if (g_mode == MODE_HOST) {            // what the public list shows while everyone gets ready
        int joined = 0;
        for (int p = 2; p <= g_players; ++p) joined += g_slot[p] >= SLOT_JOINED ? 1 : 0;
        OnlinePlay::SetHostInfo(1 + joined, g_players, g_players - 1 - joined, L"");
    }
    std::vector<std::pair<wchar_t, std::wstring>> online;
    if (g_mode != MODE_LOCAL) OnlinePlay::LobbyLines(online);
    if (g_mode == MODE_JOIN) {
        for (auto& l : online) add(l.first, l.second.c_str());
        if (online.empty()) add(L'X', L"Online play could not start - see DAOCoop.log");
        return;
    }
    swprintf(line, 160, L"%ls co-op - %d players - %ls", g_mode == MODE_LOCAL ? L"Local" : L"Online", g_players, g_loadSave ? L"load a save" : L"new game");
    add(L'H', line);
    for (auto& l : online) add(l.first, l.second.c_str());   // the invite code
    toFriends = g_mode == MODE_HOST;
    if (toFriends) {
        friends = std::wstring(L"W") + (g_loadSave ? L"The host loads a saved game" : L"A new game") + L" - " + std::to_wstring(g_players) + L" players";
    }
    if (g_p1Ready) add(L'R', g_p1Kbm ? L"Player 1 (keyboard and mouse): ready" : L"Player 1 (controller): ready");
    else if (g_p1Kbm) add(L'W', L"Player 1 (keyboard and mouse): press E to ready up  (View on controller 1: use it instead)");
    else add(L'W', L"Player 1: press A on your controller, or E on the keyboard, to ready up");
    for (int p = 2; p <= g_players; ++p) {
        int pad = (p == 2 ? g_s.padP2 : g_s.padP3) + 1;
        switch (g_slot[p]) {
        case SLOT_NOPAD:
            if (g_s.assignInLobby) swprintf(line, 160, g_mode == MODE_HOST ? L"Player %d: START on a free controller here, or an online friend's"
                                                                            : L"Player %d: press START on a free controller", p);
            else swprintf(line, 160, L"Player %d: connect controller %d", p, pad);
            add(L'X', line); break;
        case SLOT_CONNECTED: swprintf(line, 160, L"Player %d: press START to join", p); add(L'W', line); break;
        case SLOT_JOINED:
        case SLOT_READY: {
            int idx = PadsIndex(p == 2 ? PLAYER_2 : PLAYER_3);
            wchar_t who[64];
            std::wstring fn = idx >= kVPadFirst ? OnlinePlay::FriendName(idx) : std::wstring();
            if (!fn.empty()) swprintf(who, 64, L"online: %ls", fn.c_str());
            else swprintf(who, 64, L"controller %d", idx + 1);
            if (g_slot[p] == SLOT_JOINED) { swprintf(line, 160, L"Player %d (%ls): joined - press A when ready", p, who); add(L'W', line); }
            else { swprintf(line, 160, L"Player %d (%ls): ready", p, who); add(L'R', line); }
            break;
        }
        }
    }
    if (g_p1PressAt && GetTickCount() - g_p1PressAt < 5000)
        add(L'X', L"That controller is Player 1's - if it should be Player 2, swap P1Pad in DAOCoop.ini");
    else if (AllReady()) add(L'R', L"Everyone is ready!");
    else add(L'W', g_loadSave ? L"When everyone is ready, Player 1 picks the save" : L"The game starts when everyone is ready");
    if (g_mode == MODE_HOST) OnlinePlay::SetLobbyText(friends);
}

// Handles "DAOCoop.<name>". Returns the answer text.
static const wchar_t* Handle(const char* name)
{
    static wchar_t reply[1024];
    wcscpy(reply, L"ok");

    if (strcmp(name, "Version") == 0) { wcscpy(reply, g_s.enabled ? L"1.0.0" : L""); return reply; }
    if (strcmp(name, "Lobby") == 0)   { LobbyProcess(GetTickCount()); BuildStatus(reply, 1024); return reply; }
    if (strcmp(name, "Games") == 0)   { std::wstring g = OnlinePlay::GamesList(); wcsncpy(reply, g.c_str(), 1023); reply[1023] = 0; return reply; }
    if (strcmp(name, "JoinStage") == 0) { swprintf(reply, 1024, L"%d", OnlinePlay::JoinStage()); return reply; }
    if (strcmp(name, "Clipboard") == 0) { std::wstring c = OnlinePlay::ClipboardCode(); wcsncpy(reply, c.c_str(), 1023); reply[1023] = 0; return reply; }
    if (strcmp(name, "Locked") == 0)  { int l = g_mode == MODE_HOST ? OnlinePlay::LockState() : -1; wcscpy(reply, l < 0 ? L"" : l ? L"1" : L"0"); return reply; }

    // Off-screen arrows (floatylayer.gfx): which co-op player owns arrow floaty <id>?
    if (strncmp(name, "Floaty.", 7) == 0) {
        int id = atoi(name + 7), owner = 0;
        for (int p = 2; p <= 3 && g_s.offscreenArrows && id > 0; ++p) {
            uint32_t c = CoopCharacterOf(p);
            if (c != 0xFFFFFFFF && game::OffscreenFloatyId(c) == id) owner = p;
        }
        swprintf(reply, 1024, L"%d", owner);
        return reply;
    }

    if (strcmp(name, "SkipDifficulty") == 0) { wcscpy(reply, L"0"); return reply; }   // (1.2.37 chargen.gfx; not used)

    // Ability bar next to a co-op character's portrait (portraits.gfx).
    if (strncmp(name, "Bar.", 4) == 0) {
        uint32_t id = (uint32_t)strtoul(name + 4, nullptr, 10);
        if (!CoopBarInfo(id, reply, 1024)) reply[0] = 0;
        return reply;
    }

    // Marker / arrow label for player N: the character's name or "P2"/"P3".
    if (strncmp(name, "Name.", 5) == 0) {
        TargetUiName(atoi(name + 5), reply, 64);
        return reply;
    }

    if (strncmp(name, "Cmd.", 4) != 0) { wcscpy(reply, L""); return reply; }
    const char* c = name + 4;
    Log("Lobby: menu command %s", c);
    if (strcmp(c, "Open") == 0) {
        g_active = true; g_mode = MODE_LOCAL; g_players = 2; Reset();
        PadsScanSlots(true);
        if (g_s.assignInLobby) {
            g_savedPad[2] = PadsIndex(PLAYER_2); g_savedPad[3] = PadsIndex(PLAYER_3);
            PadsAssign(PLAYER_2, -1); PadsAssign(PLAYER_3, -1);
            Log("Lobby: waiting for controllers - the first free one (not Player 1's, slot %d) to press START is Player 2", PadsP1Index());
        }
    } else if (strncmp(c, "Start.", 6) == 0) {
        g_loadSave = strcmp(c + 6, "load") == 0;
        Log("Lobby: %s", g_loadSave ? "load a saved game" : "start a new game");
    } else if (strcmp(c, "Leave") == 0) {
        OnlinePlay::Stop();                         // Back out of the join screen
    } else if (strcmp(c, "Close") == 0) {
        OnlinePlay::SetLobbyText(L"");
        g_active = false; OnlinePlay::Stop(); Reset();
        PadsScanSlots(false);
        if (g_s.assignInLobby) {                    // backed out: the old controller slots again
            PadsAssign(PLAYER_2, g_savedPad[2]); PadsAssign(PLAYER_3, g_savedPad[3]);
        }
    } else if (strncmp(c, "Mode.", 5) == 0) {
        const char* m = c + 5;
        g_mode = strcmp(m, "host") == 0 ? MODE_HOST : strcmp(m, "join") == 0 ? MODE_JOIN : MODE_LOCAL;
        Reset();
        if (g_mode == MODE_HOST) Log("Lobby: %s", OnlinePlay::StartHosting().c_str());
        else if (g_mode == MODE_JOIN) Log("Lobby: %s", OnlinePlay::OpenJoin().c_str());
        else OnlinePlay::Stop();
    } else if (strcmp(c, "Refresh") == 0) {
        OnlinePlay::BrowseRefresh();
    } else if (strncmp(c, "Ask.", 4) == 0) {
        wcscpy(reply, OnlinePlay::AskToJoin(c + 4) ? L"ok" : L"no");
    } else if (strncmp(c, "Code.", 5) == 0) {
        wcscpy(reply, OnlinePlay::JoinWithCode(c + 5) ? L"ok" : L"no");
    } else if (strcmp(c, "JoinBack") == 0) {
        OnlinePlay::JoinBack();
    } else if (strncmp(c, "Lock.", 5) == 0) {
        OnlinePlay::SetLocked(c[5] == '1');
    } else if (strncmp(c, "Players.", 8) == 0) {
        g_players = atoi(c + 8) >= 3 ? 3 : 2;
        Reset();
        Log("Lobby: %s co-op for %d players", ModeName(g_mode), g_players);
    } else if (strncmp(c, "Ready.", 6) == 0) {
        LobbyProcess(GetTickCount());               // (the A that pressed the button, if it was a controller)
        g_p1Ready = c[6] == '1';
        // the Ready button: pressed with Player 1's controller (A just seen on it) or clicked
        bool pad = g_p1PressAt && GetTickCount() - g_p1PressAt < 800;
        if (pad) SetP1Input(false, "A on controller");
        else if (!XInputRouteP1NoneGet()) {
            XINPUT_GAMEPAD gp;   // a mouse click while no controller is there at all: keyboard and mouse
            if (!PadsReadSlot(g_p1Pad, &gp)) SetP1Input(true, "Ready clicked, no controller");
        }
    } else if (strcmp(c, "Launch") == 0) {
        if (!CanStart()) { wcscpy(reply, L"no"); return reply; }
        Log("Lobby: starting %s %s co-op game for %d players", g_loadSave ? "a saved" : "a new", ModeName(g_mode), g_players);
        WriteSession(g_players, g_mode == MODE_LOCAL ? L"local" : L"online");
        if (g_s.assignInLobby && g_mode != MODE_JOIN) {
            int a = PadsIndex(PLAYER_2), b = PadsIndex(PLAYER_3);
            if (a < 0) a = g_savedPad[2];
            if (b < 0 && g_players < 3) b = g_savedPad[3];
            PadsAssign(PLAYER_2, a); PadsAssign(PLAYER_3, b);
            EquipLockSetPads(a, b);
            wchar_t v[8];
            swprintf(v, 8, L"%d", a); WritePrivateProfileStringW(L"Controllers", L"P2Pad", v, g_ini);
            swprintf(v, 8, L"%d", b); WritePrivateProfileStringW(L"Controllers", L"P3Pad", v, g_ini);
            Log("Lobby: controllers saved - Player 2 = %d, Player 3 = %d", a, b);
        }
        OnlinePlay::SetLobbyText(L"");               // friends: the game starts now
        ApplySession(g_players, true);
        if (g_loadSave) CoopLobbyLoadedSave();      // the menu opens the game's Load screen next
        else CoopCreateNewGame();
        g_active = false;
        PadsScanSlots(false);
    } else if (strcmp(c, "SinglePlayer") == 0) {
        Log("Lobby: plain New Game - single player (co-op off for this game)");
        WriteSession(1, L"single");
        CoopSetPlayers(1, false);
        g_active = false;
    } else {
        wcscpy(reply, L"unknown");
    }
    return reply;
}

// ---------------------------------------------------------------------------
// Engine hook: ExternalInterface "GetValue" (and "GetString", which jumps here)
// ---------------------------------------------------------------------------
struct GfxValue { int type; int unused; const void* data; };    // 12 bytes, as the game builds them

typedef void (__cdecl* GetValue_t)(void* holder, const GfxValue* args, unsigned argc);
static GetValue_t g_origGetValue = nullptr;

static bool Reply(void* holder, const wchar_t* text)
{
#ifdef _MSC_VER
    __try {
#endif
        void* movie = *reinterpret_cast<void**>(static_cast<char*>(holder) + 0x1C);
        if (!movie) return false;
        GfxValue v = { 5, 0, text };                                // 5 = wide string
        typedef void (__thiscall* SetRet_t)(void* movie, const GfxValue* v);
        SetRet_t setRet = reinterpret_cast<SetRet_t>((*reinterpret_cast<void***>(movie))[0xA8 / 4]);
        setRet(movie, &v);
        return true;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
#endif
}

static void __cdecl HookGetValue(void* holder, const GfxValue* args, unsigned argc)
{
    if (holder && args && argc == 1 && args[0].type == 4 && args[0].data) {
        const char* name = static_cast<const char*>(args[0].data);
        if (strncmp(name, "DAOCoop.", 8) == 0) {
            if (!Reply(holder, Handle(name + 8))) Log("Lobby: could not answer the menu (%s)", name);
            return;
        }
        // The creator asks for the difficulty right before its "which difficulty?" question
        // (CharGen.PromptDifficulty). Players 2/3 play on Player 1's: the question is confirmed for
        // them with Player 1's choice already selected (1.2.38).
        if (strcmp(name, "ClientOptions.GameOptions.DifficultyLevel") == 0 && CoopCreateSessionOpen()) {
            XInputRoutePressA(400);
            Log("Co-op creator: difficulty question - confirmed with Player 1's difficulty");
        }
    }
    g_origGetValue(holder, args, argc);
}

void LobbyInit(const LobbySettings& s, const wchar_t* iniPath)
{
    g_s = s;
    wcsncpy(g_ini, iniPath, MAX_PATH - 1);
    g_p1Pad = (int)GetPrivateProfileIntW(L"Controllers", L"P1Pad", 0, g_ini);
    {
        wchar_t in[16];
        GetPrivateProfileStringW(L"Controllers", L"P1Input", L"controller", in, 16, g_ini);
        if (lstrcmpiW(in, L"keyboard") == 0) { g_p1Kbm = true; PadsSetP1Index(-1); XInputRouteP1None(true); }
        Log("Player 1 input: %ls ([Controllers] P1Input; the lobby switches it: E = keyboard, A = controller)", g_p1Kbm ? L"keyboard and mouse" : L"controller");
    }
    if (!s.enabled && !s.offscreenArrows) { Log("Co-op lobby: off (no Co-op button on the start menu)"); return; }
    static const uint8_t kGetValue[] = { 0x6A, 0xFF, 0x68, 0xB8, 0x10, 0xA8, 0x00 };
    g_origGetValue = reinterpret_cast<GetValue_t>(
        HookInstall(0x51EC60, reinterpret_cast<void*>(&HookGetValue), 7, kGetValue, "menu GetValue"));
    Log("Co-op lobby: %s", g_origGetValue ? "ready (Co-op button on the start menu)" : "hook failed - no Co-op button");
}
