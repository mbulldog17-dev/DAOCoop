#include "menubanner.h"
#include "d3d9hook.h"
#include "equiplock.h"
#include "game.h"
#include "log.h"
#include "targetui.h"
#include "views.h"
#include <windows.h>
#include <d3d9.h>
#include <cstdint>
#include <cstring>
#include <string>

#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "msimg32.lib")

namespace
{
    struct State { std::wstring head, line; int owner = 0; };   // owner: who has the menu (not shown to them), 0 = nobody
    State g_now;
    DWORD g_nextCheck = 0;

    IDirect3DDevice9* g_dev = nullptr;
    IDirect3DTexture9* g_tex = nullptr;
    int g_texW = 0, g_texH = 0, g_pw = 0, g_ph = 0;
    std::wstring g_texFor;
    int g_texScaleH = 0;

    const COLORREF kGold = RGB(201, 165, 90), kGoldDark = RGB(98, 74, 40), kGoldBright = RGB(240, 214, 140);
    const COLORREF kCream = RGB(236, 226, 202);

    State Check()
    {
        State s;
        const game::Mode m = game::CurrentMode();
        const int o = EquipLockGuiOwner();
        const int owner = o >= 2 ? o : 1;
        std::wstring who = L"Player " + std::to_wstring(owner);
        if (owner >= 2) {
            wchar_t n[64] = {};
            TargetUiName(owner, n, 64);
            if (n[0] && wcscmp(n, owner == 2 ? L"P2" : L"P3") != 0) who += std::wstring(L" (") + n + L")";
        }
        if (m == game::MODE_GUI) { s.head = L"THE GAME WAITS"; s.line = who + L" is in a menu"; s.owner = owner; }
        else if (m == game::MODE_CHARGEN && o >= 2) { s.head = L"THE GAME WAITS"; s.line = who + L" is levelling up"; s.owner = owner; }
        else if ((m == game::MODE_EXPLORE || m == game::MODE_COMBAT) && game::IsPaused()) { s.head = L"PAUSED"; s.line = L"The game is paused"; }
        return s;
    }

    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }
    HFONT Font(int px, bool heading)
    {
        static const wchar_t* kHead[] = { L"Trajan Pro", L"Cinzel", L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static const wchar_t* kBody[] = { L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static int pick[2] = { -1, -1 };
        const wchar_t* const* list = heading ? kHead : kBody;
        const int n = heading ? 5 : 3;
        int& p = pick[heading ? 1 : 0];
        if (p < 0) {
            p = n - 1;
            HDC dc = CreateCompatibleDC(nullptr);
            for (int i = 0; i < n; ++i) {
                HFONT f = CreateFontW(-20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, list[i]);
                HGDIOBJ o = SelectObject(dc, f); wchar_t face[64] = {}; GetTextFaceW(dc, 64, face); SelectObject(dc, o); DeleteObject(f);
                if (_wcsicmp(face, list[i]) == 0) { p = i; break; }
            }
            DeleteDC(dc);
        }
        return CreateFontW(-px, 0, 0, 0, heading ? FW_SEMIBOLD : FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                           ANTIALIASED_QUALITY, DEFAULT_PITCH, list[p]);
    }
    void Fill(HDC dc, int x0, int y0, int x1, int y1, COLORREF c) { RECT r = { x0, y0, x1, y1 }; HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b); }
    void Grad(HDC dc, int x0, int y0, int x1, int y1, COLORREF a, COLORREF b, bool vertical)
    {
        if (x1 <= x0 || y1 <= y0) return;
        TRIVERTEX v[2] = { { x0, y0, (COLOR16)(GetRValue(a) << 8), (COLOR16)(GetGValue(a) << 8), (COLOR16)(GetBValue(a) << 8), 0 },
                           { x1, y1, (COLOR16)(GetRValue(b) << 8), (COLOR16)(GetGValue(b) << 8), (COLOR16)(GetBValue(b) << 8), 0 } };
        GRADIENT_RECT g = { 0, 1 };
        GdiGradientFill(dc, v, 2, &g, 1, vertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
    }
    void Gem(HDC dc, int cx, int cy, int r, COLORREF c)
    {
        POINT p[4] = { { cx, cy - r }, { cx + r, cy }, { cx, cy + r }, { cx - r, cy } };
        HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
        HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
        Polygon(dc, p, 4);
        SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
    }
    // A line that fades out at both ends (gold in the middle), like the game's title rules.
    void Rule(HDC dc, int x0, int x1, int y, int h, COLORREF mid, COLORREF end)
    {
        const int m = (x0 + x1) / 2;
        Grad(dc, x0, y, m, y + h, end, mid, false);
        Grad(dc, m, y, x1, y + h, mid, end, false);
    }

    bool Render(IDirect3DDevice9* dev, const State& st, float s)
    {
        auto S = [&](float v) { int x = (int)(v * s + 0.5f); return x < 1 ? 1 : x; };
        HDC dc = CreateCompatibleDC(nullptr);
        HFONT fHead = Font(S(26), true), fLine = Font(S(22), false);
        SIZE hs = {}, ls = {};
        HGDIOBJ o = SelectObject(dc, fHead);
        // the heading spaced out like the game's
        std::wstring head;
        for (size_t i = 0; i < st.head.size(); ++i) { head += st.head[i]; if (i + 1 < st.head.size()) head += L'\x2009'; }
        GetTextExtentPoint32W(dc, head.c_str(), (int)head.size(), &hs);
        SelectObject(dc, fLine);
        GetTextExtentPoint32W(dc, st.line.c_str(), (int)st.line.size(), &ls);
        SelectObject(dc, o);
        const int wide = (hs.cx > ls.cx ? hs.cx : ls.cx) + S(150);
        const int pw = wide > S(520) ? wide : S(520), ph = S(104);
        const int tw = Pow2(pw), th = Pow2(ph);
        if (!g_tex || g_texW != tw || g_texH != th) {
            if (g_tex) { g_tex->Release(); g_tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex) {
                g_tex = nullptr; DeleteObject(fHead); DeleteObject(fLine); DeleteDC(dc); return false;
            }
            g_texW = tw; g_texH = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = pw; bi.bmiHeader.biHeight = -ph;
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        bool ok = false;
        if (bmp && bits) {
            HGDIOBJ ob = SelectObject(dc, bmp);
            SetBkMode(dc, TRANSPARENT);
            // the plate: warm near-black, lighter in the middle; gold rules above and below fading out to the sides,
            // diamonds at their ends and in the middle - the look of the game's own title banners
            Grad(dc, 0, 0, pw, ph / 2, RGB(14, 11, 8), RGB(30, 24, 17), true);
            Grad(dc, 0, ph / 2, pw, ph, RGB(30, 24, 17), RGB(12, 9, 7), true);
            const int r1 = S(6), r2 = ph - S(8);
            Rule(dc, S(8), pw - S(8), r1, S(2), kGold, RGB(30, 24, 17));
            Rule(dc, S(28), pw - S(28), r1 + S(4), 1, kGoldDark, RGB(20, 16, 12));
            Rule(dc, S(8), pw - S(8), r2, S(2), kGold, RGB(30, 24, 17));
            Rule(dc, S(28), pw - S(28), r2 - S(4), 1, kGoldDark, RGB(20, 16, 12));
            Gem(dc, pw / 2, r1 + 1, S(6), kGoldBright);
            Gem(dc, pw / 2, r2 + 1, S(6), kGoldBright);
            Gem(dc, pw / 2, r1 + 1, S(2), RGB(30, 24, 17));
            Gem(dc, pw / 2, r2 + 1, S(2), RGB(30, 24, 17));
            SelectObject(dc, fHead);
            SetTextColor(dc, kGold);
            RECT hr = { 0, S(16), pw, S(52) };
            DrawTextW(dc, head.c_str(), -1, &hr, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
            // small diamonds beside the heading
            Gem(dc, pw / 2 - hs.cx / 2 - S(18), S(34), S(4), kGold);
            Gem(dc, pw / 2 + hs.cx / 2 + S(18), S(34), S(4), kGold);
            SelectObject(dc, fLine);
            SetTextColor(dc, kCream);
            RECT lr = { 0, S(52), pw, S(88) };
            DrawTextW(dc, st.line.c_str(), -1, &lr, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
            GdiFlush();
            D3DLOCKED_RECT lk;
            if (SUCCEEDED(g_tex->LockRect(0, &lk, nullptr, 0))) {
                for (int y = 0; y < th; ++y) {
                    uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lk.pBits) + y * lk.Pitch);
                    if (y >= ph) { std::memset(dst, 0, size_t(tw) * 4); continue; }
                    const uint32_t* src = static_cast<const uint32_t*>(bits) + size_t(y) * pw;
                    for (int x = 0; x < pw; ++x) {
                        // the plate's sides fade into the picture
                        const int edge = x < pw / 2 ? x : pw - 1 - x;
                        const int fade = S(60);
                        const uint32_t a = edge >= fade ? 0xE8 : (uint32_t)(0xE8 * edge / fade);
                        dst[x] = (src[x] & 0x00FFFFFF) | (a << 24);
                    }
                    if (tw > pw) std::memset(dst + pw, 0, size_t(tw - pw) * 4);
                }
                g_tex->UnlockRect(0);
                ok = true;
            }
            SelectObject(dc, ob);
            DeleteObject(bmp);
        }
        DeleteObject(fHead); DeleteObject(fLine);
        DeleteDC(dc);
        if (ok) { g_pw = pw; g_ph = ph; }
        return ok;
    }
    struct Vtx { float x, y, z, rhw; DWORD c; float u, v; };
}

void MenuBannerDraw(IDirect3DDevice9* dev, int viewer)
{
    if (!dev || !ViewsActive()) return;   // (co-op with views only: a game on its own pauses as it always did)
    if (dev != g_dev) { g_tex = nullptr; g_dev = dev; g_texFor.clear(); }
    const DWORD now = GetTickCount();
    if ((int)(now - g_nextCheck) >= 0) {
        g_nextCheck = now + 200;
        const State st = Check();
        if (st.line != g_now.line) {
            if (!st.line.empty()) Log("Menu banner: %ls (not for Player %d)", st.line.c_str(), st.owner);
            else if (!g_now.line.empty()) Log("Menu banner: off");
        }
        g_now = st;
    }
    if (g_now.line.empty() || (g_now.owner && viewer == g_now.owner)) return;
    int W = 0, H = 0;
    if (!D3D9BackBufferSize(&W, &H) || W <= 0 || H <= 0) return;
    const float s = H / 1080.f < 0.5f ? 0.5f : H / 1080.f;
    const std::wstring key = g_now.head + L"|" + g_now.line;
    if (!g_tex || key != g_texFor || g_texScaleH != H) {
        if (!Render(dev, g_now, s)) return;
        g_texFor = key; g_texScaleH = H;
    }
    const float x0 = (float)((W - g_pw) / 2) - 0.5f, y0 = (float)(int)(H * 0.11f) - 0.5f;
    IDirect3DStateBlock9* sb = D3D9SaveState(dev, 7);
    if (!sb) return;
    IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
    dev->GetRenderTarget(0, &oldRt);
    dev->GetDepthStencilSurface(&oldDs);
    if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
        dev->SetRenderTarget(0, bb);
        dev->SetDepthStencilSurface(nullptr);
        const bool began = SUCCEEDED(dev->BeginScene());
        D3DVIEWPORT9 vp = { 0, 0, (DWORD)W, (DWORD)H, 0.f, 1.f };
        dev->SetViewport(&vp);
        dev->SetVertexShader(nullptr);
        dev->SetPixelShader(nullptr);
        dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
        dev->SetRenderState(D3DRS_ZENABLE, FALSE);
        dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
        dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
        dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
        dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
        dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
        dev->SetRenderState(D3DRS_LIGHTING, FALSE);
        dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
        dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
        dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
        dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
        dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
        dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
        dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
        dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
        dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
        dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
        dev->SetTexture(0, g_tex);
        // a slow breath of the light, so it doesn't look like a frozen picture
        const float t = (now % 2400) / 2400.f;
        const float k = 0.86f + 0.14f * (t < 0.5f ? t * 2.f : (1.f - t) * 2.f);
        const DWORD shade = (DWORD)(k * 255.f + 0.5f);
        const DWORD c = 0xFF000000u | (shade << 16) | (shade << 8) | shade;
        const float u1 = (float)g_pw / g_texW, v1 = (float)g_ph / g_texH;
        const Vtx q[4] = { { x0, y0, 0, 1, c, 0, 0 }, { x0 + g_pw, y0, 0, 1, c, u1, 0 },
                           { x0, y0 + g_ph, 0, 1, c, 0, v1 }, { x0 + g_pw, y0 + g_ph, 0, 1, c, u1, v1 } };
        dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, q, sizeof(Vtx));
        dev->SetTexture(0, nullptr);
        if (began) dev->EndScene();
        bb->Release();
    }
    if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
    dev->SetDepthStencilSurface(oldDs);
    if (oldDs) oldDs->Release();
    sb->Apply();
}
