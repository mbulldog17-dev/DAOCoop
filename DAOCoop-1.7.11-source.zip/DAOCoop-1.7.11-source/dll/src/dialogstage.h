#pragma once
// Players 2/3 in scenes with the party.
//
// 1.3.2 conversations: a cinematic conversation places its cast with a stage (.stg): "pc", up
// to three "hench" spots and named spots for the characters the scene needs. With a bigger
// party the co-op characters often get no spot and stay where they were, out of the shots.
//
// 1.3.4 rendered cutscenes (.cut): the cast is PLAYER, "HENCHMAN 1-3" (the first followers in
// party order, AI companions before Players 2/3) and "HENCH:<tag>" (a named companion)
// [0x7E36B0 -> 0x7CD0A0 -> 0x7F2D80]. A cast creature is moved by its actor's tracks
// (0x7E30B0 saves its place and puts it back afterwards); anyone else is left standing.
//
// Both: a short moment after the scene starts, a co-op character the scene did not move and that
// isn't already near the Warden is placed just behind the Warden (P2 left, P3 right), facing the
// same way. In cutscenes they also take up a stance (an ambient animation, looped) and are put
// back to normal when the cutscene ends. Characters the scene casts are never touched.
#include <cstdint>

struct DialogStageSettings {
    bool enabled;          // conversations
    bool cutscenes;        // rendered cutscenes
    int  stance[2];        // Player 2 / 3: animation id while standing in a cutscene (0 = none)
};
void DialogStageInit(const DialogStageSettings& s);
// Main tick, every frame: the game mode and the co-op characters in play (0xFFFFFFFF = none).
void DialogStageTick(unsigned now, int mode /* game::Mode */, uint32_t p2, uint32_t p3);
// Stance names for the settings -> animation id (0 = unknown name).
int  DialogStageStance(const wchar_t* name);
