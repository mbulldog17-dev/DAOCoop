#include "targetui.h"
#include "interact.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include "views.h"
#include <cwchar>
#include <windows.h>

static TargetUiSettings g_s;
static const uint32_t kNone = 0xFFFFFFFF;

struct Want { uint32_t obj; const wchar_t* icon; int prio; };

struct PlayerUi {
    Want     want[3];
    int      nWant = 0;
    uint32_t previewObj = kNone;
    unsigned nextPreview = 0, previewShownAt = 0;
    wchar_t prompt[96] = L"";               // 1.7.1: for the player's own HUD (their view has no floaty layer)
    unsigned promptAt = 0;
    bool combat = false;
};
static PlayerUi g_ui[4];
static wchar_t  g_name[4][48];            // cached character names (answered to the floaty layer)
static unsigned g_nextName[4];

struct Shown { uint32_t obj; const wchar_t* icon; unsigned next; };
static Shown g_shown[8];
static int   g_nShown = 0;

// "_n" images have no "P2"/"P3" text: the floaty layer writes the player's
// character name above them instead (TargetUiSettings::names).
static const wchar_t* TargetIcon(int p)
{
    if (g_s.names) return p == 3 ? L"daocoop_p3_target_n" : L"daocoop_p2_target_n";
    return p == 3 ? L"daocoop_p3_target" : L"daocoop_p2_target";
}
static const wchar_t* AllyIcon(int p)
{
    if (g_s.names) return p == 3 ? L"daocoop_p3_ally_n" : L"daocoop_p2_ally_n";
    return p == 3 ? L"daocoop_p3_ally" : L"daocoop_p2_ally";
}
static const wchar_t* SelfIcon(int p)
{
    if (g_s.names) return p == 3 ? L"daocoop_p3_self_n" : L"daocoop_p2_self_n";
    return p == 3 ? L"daocoop_p3_self" : L"daocoop_p2_self";
}
static uint32_t Colour(int p)           { return p == 3 ? 0x66DD66 : 0x4DA6FF; }

void TargetUiInit(const TargetUiSettings& s)
{
    g_s = s;
    Log("Target markers: enemy %s, ally %s, use preview %s, own tag %s, %s",
        s.enemyMarker ? "on" : "off", s.allyMarker ? "on" : "off",
        s.usePreview ? "on" : "off", s.selfTag ? "on" : "off", s.names ? "character names" : "P2/P3 labels");
}

void TargetUiClear(int player)
{
    if (player < 2 || player > 3) return;
    g_ui[player].nWant = 0;
    g_ui[player].previewObj = kNone;
}

void TargetUiReset()
{
    for (int p = 2; p <= 3; ++p) TargetUiClear(p);
    g_nShown = 0;
}

static void AddWant(PlayerUi& u, uint32_t obj, const wchar_t* icon, int prio)
{
    if (obj == kNone || u.nWant >= 3) return;
    u.want[u.nWant++] = { obj, icon, prio };
}

void TargetUiTick(unsigned now, int player, uint32_t me, bool playable, bool inCombat,
                  uint32_t enemy, uint32_t ally, float dirX, float dirY)
{
    if (player < 2 || player > 3) return;
    PlayerUi& u = g_ui[player];
    if (!playable || me == kNone) { u.prompt[0] = 0; return; }      // keep icons through short GUI/dialog moments
    u.combat = inCombat;

    if ((int)(now - g_nextName[player]) >= 0) {   // the floaty layer asks for it (DAOCoop.Name.N)
        g_nextName[player] = now + 3000;
        wchar_t n[48];
        if (script::GetName(me, n, 48) && n[0]) wcsncpy(g_name[player], n, 47);
    }

    // Priorities: enemy 30, ally 20, own tag 10; Player 2 wins ties (+1).
    int bias = player == 2 ? 1 : 0;
    u.nWant = 0;
    if (g_s.drawn) {}                       // 1.7.4: drawn in every player's own view (rings.cpp) - the floaty icons go
    else if (g_s.enemyMarker && enemy != kNone && !script::IsDead(enemy)) AddWant(u, enemy, TargetIcon(player), 30 + bias);
    if (!g_s.drawn && g_s.allyMarker && ally != kNone) AddWant(u, ally, AllyIcon(player), 20 + bias);
    if (!g_s.drawn && g_s.selfTag) AddWant(u, me, SelfIcon(player), 10 + bias);

    // --- use preview (out of combat) -----------------------------------------------
    if (inCombat) u.prompt[0] = 0;
    if (!inCombat && (g_s.usePreview || g_s.prompt) && (int)(now - u.nextPreview) >= 0) {
        u.nextPreview = now + 200;
        uint32_t obj; const wchar_t* verb; wchar_t name[64];
        const bool picked = InteractPick(me, dirX, dirY, &obj, &verb, name, 64);
        if (picked) {
            wchar_t v[24]; wcsncpy(v, verb, 23); v[23] = 0;
            if (v[0] >= L'a' && v[0] <= L'z') v[0] = (wchar_t)(v[0] - 32);
            swprintf(u.prompt, 96, L"%ls %ls", v, name);
            u.promptAt = now;
            static int said = 0;
            if (said++ < 3) Log("Markers: Player %d's use prompt \"%ls\"", player, u.prompt);
        } else u.prompt[0] = 0;
        if (!g_s.usePreview || (g_s.drawn && ViewsActive())) {}   // (own views: it's in the player's own HUD instead)
        else if (picked) {
            // A floaty fades by itself, so re-show it while it stays the pick.
            if (obj != u.previewObj || now - u.previewShownAt > 1300) {
                wchar_t text[128];
                if (g_s.names) {
                    wchar_t who[48];
                    uint32_t me2 = me;
                    if (!script::GetName(me2, who, 48) || !who[0]) swprintf(who, 48, L"P%d", player);
                    swprintf(text, 128, L"%ls (A): %ls %ls", who, verb, name);
                } else {
                    swprintf(text, 128, L"P%d (A): %ls %ls", player, verb, name);
                }
                script::DisplayFloatyMessage(obj, text, Colour(player), 1.5f);
                u.previewObj = obj;
                u.previewShownAt = now;
            }
        } else {
            u.previewObj = kNone;
        }
    }
}

void TargetUiFlush(unsigned now)
{
    // What every creature should show: the highest-priority request.
    Want desired[8];
    int nd = 0;
    for (int p = 2; p <= 3; ++p) {
        const PlayerUi& u = g_ui[p];
        for (int i = 0; i < u.nWant; ++i) {
            const Want& w = u.want[i];
            int j = 0;
            while (j < nd && desired[j].obj != w.obj) ++j;
            if (j == nd) { if (nd < 8) desired[nd++] = w; }
            else if (w.prio > desired[j].prio) desired[j] = w;
        }
    }

    // Hide icons nobody wants any more.
    for (int i = 0; i < g_nShown; ) {
        bool keep = false;
        for (int j = 0; j < nd; ++j) if (desired[j].obj == g_shown[i].obj) keep = true;
        if (keep) { ++i; continue; }
        script::ShowFloatyIcon(g_shown[i].obj, L"");
        g_shown[i] = g_shown[--g_nShown];
    }

    // Show new / changed icons, and re-send every 2 s (survives the floaty
    // layer being rebuilt after a GUI screen or a reload).
    for (int j = 0; j < nd; ++j) {
        int i = 0;
        while (i < g_nShown && g_shown[i].obj != desired[j].obj) ++i;
        if (i == g_nShown) {
            if (g_nShown >= 8) continue;
            g_shown[g_nShown++] = { desired[j].obj, nullptr, 0 };
        }
        Shown& s = g_shown[i];
        if (s.icon != desired[j].icon || (int)(now - s.next) >= 0) {
            script::ShowFloatyIcon(s.obj, desired[j].icon);
            s.icon = desired[j].icon;
            s.next = now + 2000;
        }
    }
}

bool TargetUiPrompt(int player, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    if (player < 2 || player > 3 || cap < 2) return false;
    const PlayerUi& u = g_ui[player];
    if (!g_s.prompt || !u.prompt[0] || u.combat || GetTickCount() - u.promptAt > 700) return false;
    wcsncpy(out, u.prompt, cap - 1); out[cap - 1] = 0;
    return true;
}

void TargetUiName(int player, wchar_t* out, int cap)
{
    if (player < 2 || player > 3 || cap < 4) { if (cap > 0) out[0] = 0; return; }
    if (g_s.names && g_name[player][0]) { wcsncpy(out, g_name[player], cap - 1); out[cap - 1] = 0; }
    else swprintf(out, cap, L"P%d", player);
}
