#include "problems.h"
#include "d3d9hook.h"
#include <dbghelp.h>

typedef BOOL (WINAPI* MiniDumpWriteDump_t)(HANDLE, DWORD, HANDLE, MINIDUMP_TYPE, PMINIDUMP_EXCEPTION_INFORMATION,
                                           PMINIDUMP_USER_STREAM_INFORMATION, PMINIDUMP_CALLBACK_INFORMATION);
static MiniDumpWriteDump_t g_dump = nullptr;
static wchar_t g_pdir[MAX_PATH];
static volatile DWORD g_lastTick = 0;
static volatile LONG g_freezeDumped = 0;

void ProblemsNote(const char* text)
{
    if (!g_pdir[0]) return;
    wchar_t path[MAX_PATH];
    lstrcpynW(path, g_pdir, MAX_PATH - 32);
    lstrcatW(path, L"DAOCoop-problems.txt");
    HANDLE f = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t;
    GetLocalTime(&t);
    char line[1200];
    int n = wsprintfA(line, "[%04d-%02d-%02d %02d:%02d:%02d] ", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    lstrcpynA(line + n, text, (int)sizeof(line) - n - 3);
    lstrcatA(line, "\r\n");
    DWORD w = 0;
    WriteFile(f, line, (DWORD)lstrlenA(line), &w, nullptr);
    CloseHandle(f);
}

bool ProblemsDump(EXCEPTION_POINTERS* ep, const char* why)
{
    if (!g_dump || !g_pdir[0]) return false;
    SYSTEMTIME t;
    GetLocalTime(&t);
    wchar_t path[MAX_PATH], name[96];
    wsprintfW(name, L"daocoop-%S-%04d%02d%02d-%02d%02d%02d.dmp", why, t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    lstrcpynW(path, g_pdir, MAX_PATH - 100);
    lstrcatW(path, name);
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    MINIDUMP_EXCEPTION_INFORMATION ei = {};
    ei.ThreadId = GetCurrentThreadId();
    ei.ExceptionPointers = ep;
    ei.ClientPointers = FALSE;
    const MINIDUMP_TYPE type = (MINIDUMP_TYPE)(MiniDumpWithThreadInfo | MiniDumpWithUnloadedModules |
                                               MiniDumpWithIndirectlyReferencedMemory | MiniDumpScanMemory);
    BOOL ok = g_dump(GetCurrentProcess(), GetCurrentProcessId(), f, type, ep ? &ei : nullptr, nullptr, nullptr);
    CloseHandle(f);
    char msg[400];
    wsprintfA(msg, "%s dump %s: %S", why, ok ? "written" : "FAILED", name);
    ProblemsNote(msg);
    return ok != FALSE;
}

void ProblemsHeartbeat()
{
    g_lastTick = GetTickCount();
}

static bool GameInFront()
{
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

static DWORD WINAPI FreezeWatch(LPVOID)
{
    for (;;) {
        Sleep(1000);
        const DWORD last = g_lastTick;
        if (!last) continue;
        const DWORD gap = GetTickCount() - last;
        if (gap > 15000 && GameInFront() && InterlockedExchange(&g_freezeDumped, 1) == 0) {
            char msg[400];
            const char* st = D3D9CurrentStage();
            wsprintfA(msg, "FREEZE: no game frame for %lu s (drawing thread stage: %s) - writing a dump of every thread",
                      (unsigned long)(gap / 1000), st ? st : "not in the mod's drawing code");
            ProblemsNote(msg);
            ProblemsDump(nullptr, "freeze");
        }
    }
}

void ProblemsInit(const wchar_t* dir)
{
    lstrcpynW(g_pdir, dir, MAX_PATH);
    HMODULE h = LoadLibraryW(L"dbghelp.dll");   // loaded now: in a crash, loading a DLL can hang
    if (h) g_dump = (MiniDumpWriteDump_t)GetProcAddress(h, "MiniDumpWriteDump");
    HANDLE t = CreateThread(nullptr, 0, FreezeWatch, nullptr, 0, nullptr);
    if (t) CloseHandle(t);
}
