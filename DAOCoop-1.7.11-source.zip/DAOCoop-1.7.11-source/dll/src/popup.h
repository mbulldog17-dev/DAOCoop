#pragma once
// 1.4.1: a pop-up box on the host's screen ("<name> wants to join your game" - Yes / No),
// drawn on the finished frame like the player rings (d3d9hook overlay), so it shows in the
// menus, in game, in combat and in conversations alike. The text is drawn with GDI into a
// texture, so no extra libraries are needed.
//
// Any thread may call PopupSet / PopupHit; the drawing happens on the render thread.
#include <string>

void PopupInit();
// show = false hides it. sel: 0 = Yes highlighted, 1 = No highlighted.
void PopupSet(bool show, const std::wstring& title, const std::wstring& sub, int sel);
// Which button is under a point of the back buffer (pixels): 0 Yes, 1 No, -1 none.
int  PopupHit(int x, int y);
// 1.7.0: a notice in the same box, without buttons, that hides itself after ms (e.g. "the host left").
void PopupNotice(const std::wstring& title, const std::wstring& sub, unsigned ms);
