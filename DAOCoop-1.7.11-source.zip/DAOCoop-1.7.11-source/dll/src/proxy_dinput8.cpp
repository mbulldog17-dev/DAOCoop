// The game loads our DLL as dinput8.dll from bin_ship (it imports DirectInput8Create).
// Every call is passed on to the "real" dinput8:
//   1. bin_ship\dinput8_chain.dll, if present: another mod's dinput8.dll that the installer
//      renamed (for example the Native Controller Framework), so both mods run together;
//   2. otherwise Windows' own dinput8.dll from the system folder.
#include <windows.h>
#include <objbase.h>   // REFIID, REFCLSID, LPUNKNOWN
#include "proxy.h"
#include "log.h"
#include "online/Paths.h"

static HMODULE g_real = nullptr;
static wchar_t g_realPath[MAX_PATH] = L"";
static wchar_t g_chainFailed[MAX_PATH] = L"";
static DWORD g_chainError = 0;

static HMODULE LoadReal()
{
    if (g_real) return g_real;

    // 1. a chained mod next to us
    HMODULE self = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)&LoadReal, &self);
    wchar_t selfPath[MAX_PATH];
    GetModuleFileNameW(self, selfPath, MAX_PATH);
    wchar_t path[MAX_PATH];
    lstrcpyW(path, selfPath);
    wchar_t* slash = wcsrchr(path, L'\\');
    // (1.5.5: also dinput8.chain.dll, the name DAOLib's loader gives a mod it chains)
    static const wchar_t* kChain[] = { L"dinput8_chain.dll", L"dinput8.chain.dll" };
    for (const wchar_t* name : kChain) {
        if (!slash) break;
        lstrcpyW(slash + 1, name);
        // never chain to ourselves (that would pass every call back in here forever)
        if (lstrcmpiW(path, selfPath) != 0 && GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) {
            HMODULE m = LoadLibraryW(path);
            if (!m) {
                // 1.7.8: the other mod is there but Windows would not load it (126: a DLL it needs is missing - for the
                // Native Controller Framework, Microsoft's Visual C++ runtime (x86)); told in the log at startup
                g_chainError = GetLastError();
                lstrcpyW(g_chainFailed, path);
            }
            if (m == self) {
                FreeLibrary(m);
            } else if (m) {
                g_real = m;
                lstrcpyW(g_realPath, path);
                return g_real;
            }
        }
    }

    // 2. Windows' own (a 32-bit process is redirected to SysWOW64)
    GetSystemDirectoryW(path, MAX_PATH);
    lstrcatW(path, L"\\dinput8.dll");
    g_real = LoadLibraryW(path);
    if (g_real) lstrcpyW(g_realPath, path);
    return g_real;
}

static FARPROC Real(const char* name)
{
    HMODULE m = LoadReal();
    return m ? GetProcAddress(m, name) : nullptr;
}

const wchar_t* ProxyTargetPath()
{
    LoadReal();
    return g_realPath;
}

const wchar_t* ProxyChainFailed(unsigned long* error)
{
    LoadReal();
    if (error) *error = g_chainError;
    return g_chainFailed[0] ? g_chainFailed : nullptr;
}

// ---- 1.7.8: the chat line blocks the game's keyboard while typing ----
// The game reads the keyboard through DirectInput. Its keyboard device's GetDeviceState / GetDeviceData are patched
// (vtable slots 9 / 10) to report nothing while the chat line is open, so typed letters don't move or cast.
static const GUID kSysKeyboard = { 0x6F1D2B61, 0xD5A0, 0x11CF, { 0xBF, 0xC7, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00 } };
static volatile LONG g_kbdBlocked = 0;
static void* volatile g_kbd[4] = {};
typedef HRESULT (STDMETHODCALLTYPE* GetState_t)(void* self, DWORD size, void* data);
typedef HRESULT (STDMETHODCALLTYPE* GetData_t)(void* self, DWORD objSize, void* data, DWORD* inOut, DWORD flags);
typedef HRESULT (STDMETHODCALLTYPE* CreateDevice_t)(void* self, REFGUID guid, void** dev, void* outer);
static GetState_t g_origGetState = nullptr;
static GetData_t g_origGetData = nullptr;
static CreateDevice_t g_origCreateDevice = nullptr;

static bool IsKeyboard(void* self)
{
    for (void* k : g_kbd) if (k && k == self) return true;
    return false;
}
static HRESULT STDMETHODCALLTYPE HookGetState(void* self, DWORD size, void* data)
{
    const HRESULT hr = g_origGetState(self, size, data);
    if (g_kbdBlocked && SUCCEEDED(hr) && data && IsKeyboard(self)) ZeroMemory(data, size);
    return hr;
}
static HRESULT STDMETHODCALLTYPE HookGetData(void* self, DWORD objSize, void* data, DWORD* inOut, DWORD flags)
{
    const HRESULT hr = g_origGetData(self, objSize, data, inOut, flags);
    if (g_kbdBlocked && SUCCEEDED(hr) && inOut && IsKeyboard(self) && !(flags & 1 /*DIGDD_PEEK*/)) *inOut = 0;   // the events are dropped
    return hr;
}
static void PatchSlot(void** vt, int slot, void* fn, void** orig)
{
    if (vt[slot] == fn) return;
    DWORD old;
    if (!VirtualProtect(&vt[slot], sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) return;
    if (!*orig) *orig = vt[slot];
    if (vt[slot] == *orig) vt[slot] = fn;          // (only where it's the same function: never chain two different ones)
    VirtualProtect(&vt[slot], sizeof(void*), old, &old);
}
static HRESULT STDMETHODCALLTYPE HookCreateDevice(void* self, REFGUID guid, void** dev, void* outer)
{
    const HRESULT hr = g_origCreateDevice(self, guid, dev, outer);
    if (SUCCEEDED(hr) && dev && *dev && IsEqualGUID(guid, kSysKeyboard)) {
        for (auto& k : g_kbd) if (!k) { k = *dev; break; }
        void** vt = *reinterpret_cast<void***>(*dev);
        PatchSlot(vt, 9, (void*)&HookGetState, (void**)&g_origGetState);
        PatchSlot(vt, 10, (void*)&HookGetData, (void**)&g_origGetData);
    }
    return hr;
}

void ProxyBlockKeyboard(bool on) { InterlockedExchange(&g_kbdBlocked, on ? 1 : 0); }

extern "C" HRESULT WINAPI Proxy_DirectInput8Create(HINSTANCE inst, DWORD version, REFIID riid, LPVOID* out, LPUNKNOWN outer)
{
    typedef HRESULT (WINAPI* fn_t)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
    static fn_t fn = (fn_t)Real("DirectInput8Create");
    const HRESULT hr = fn ? fn(inst, version, riid, out, outer) : E_FAIL;
    // 1.7.8: the keyboard block for the chat line hooks DirectInput. Not with a chained controller mod (the Native
    // Controller Framework works through DirectInput too) unless [Chat] BlockKeyboard=1; 0 = never.
    static int block = -1;
    if (block < 0) {
        const bool chained = wcsstr(g_realPath, L"chain") != nullptr;
        block = (int)GetPrivateProfileIntA("Chat", "BlockKeyboard", chained ? 0 : 1, Paths::GetConfigPath().c_str());
        Log("Chat: the game's keyboard %s while typing%s", block ? "is blocked" : "is NOT blocked",
            block ? "" : (chained ? " (a controller mod is chained in - [Chat] BlockKeyboard=1 to try it)" : " ([Chat] BlockKeyboard=0)"));
    }
    if (block && SUCCEEDED(hr) && out && *out) {
        void** vt = *reinterpret_cast<void***>(*out);
        PatchSlot(vt, 3, (void*)&HookCreateDevice, (void**)&g_origCreateDevice);
    }
    return hr;
}

extern "C" HRESULT WINAPI Proxy_DllCanUnloadNow()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllCanUnloadNow");
    return fn ? fn() : S_FALSE;
}

extern "C" HRESULT WINAPI Proxy_DllGetClassObject(REFCLSID clsid, REFIID riid, LPVOID* out)
{
    typedef HRESULT (WINAPI* fn_t)(REFCLSID, REFIID, LPVOID*);
    static fn_t fn = (fn_t)Real("DllGetClassObject");
    return fn ? fn(clsid, riid, out) : CLASS_E_CLASSNOTAVAILABLE;
}

extern "C" HRESULT WINAPI Proxy_DllRegisterServer()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllRegisterServer");
    return fn ? fn() : E_FAIL;
}

extern "C" HRESULT WINAPI Proxy_DllUnregisterServer()
{
    typedef HRESULT (WINAPI* fn_t)();
    static fn_t fn = (fn_t)Real("DllUnregisterServer");
    return fn ? fn() : E_FAIL;
}
