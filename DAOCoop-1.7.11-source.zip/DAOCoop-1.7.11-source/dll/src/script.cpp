#include "online/OnlineChat.h"
#include "online/Paths.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <windows.h>
#include <cmath>
#include <cstring>

namespace script {

// ---------------------------------------------------------------------------
// Raw engine entry points (all __thiscall; checked by game::CheckBuild)
// ---------------------------------------------------------------------------
typedef int  (__thiscall* PushInt_t)(void* vm, int v);
typedef int  (__thiscall* PushFloat_t)(void* vm, float v);
typedef int  (__thiscall* PushObject_t)(void* vm, uint32_t id);
typedef int  (__thiscall* PushStruct_t)(void* vm, int type, void* p);
typedef int  (__thiscall* PushString_t)(void* vm, const void* str);
typedef int  (__thiscall* PopInt_t)(void* vm, int* out);
typedef int  (__thiscall* PopFloat_t)(void* vm, float* out);
typedef int  (__thiscall* PopObject_t)(void* vm, uint32_t* out);
typedef int  (__thiscall* PopStruct_t)(void* vm, int type, void** out);
typedef int  (__thiscall* PopString_t)(void* vm, void* out);
typedef int  (__thiscall* PopArray_t)(void* vm, void* out);
typedef void (__thiscall* ArrayFree_t)(void* value);
typedef void (__thiscall* StringDtor_t)(void* str);
typedef void (__thiscall* Truncate_t)(void* stack, int depth);
typedef int  (__thiscall* RunCommand_t)(void* impl, int id, int argc);
typedef void (__thiscall* DestroyStruct_t)(void* impl, int type, void* p);
typedef void* (__cdecl* GameNew_t)(size_t);
typedef void  (__cdecl* GameDelete_t)(void*);

#define ENGINE(T, A) (reinterpret_cast<T>(game::A))

static bool  g_ready = false;
static int   g_faults = 0;
static DWORD g_backoffUntil = 0;          // unused since 1.2.5 (one failing command no longer stops the others)
// Per command: a crash pauses only that command for 2 s; 5 crashes switch it off for the session.
static const int kMaxCmd = 1024;
static unsigned char g_cmdFaults[kMaxCmd];
static DWORD g_cmdPauseUntil[kMaxCmd];

static void* Vm() { return *reinterpret_cast<void**>(game::kVmPtr); }
static int*  StackCount(void* vm) { return reinterpret_cast<int*>(static_cast<char*>(vm) + game::kVmStackOffset); }
static void* Impl(void* vm) { return *reinterpret_cast<void**>(static_cast<char*>(vm) + game::kVmImplOffset); }

// The game's string type (MSVC 2008 std::wstring layout, 0x1C bytes).
struct GameString {
    uint32_t proxy;
    union { wchar_t buf[8]; wchar_t* ptr; };
    uint32_t size;
    uint32_t cap;          // 7 = text is in buf
};

// A script array value as PopArray leaves it: {tag, holder, owning stack}.
// For object arrays (tag 0x43) holder[0] -> std::vector<uint32_t> {proxy, first, last, end}.
struct ArrayValue { int tag; void** holder; void* owner; };

// ---------------------------------------------------------------------------
// One guarded "call a script command" transaction. Plain C types only, so the
// structured exception handler can wrap it.
// ---------------------------------------------------------------------------
enum ArgType { A_INT, A_FLOAT, A_OBJECT, A_VECTOR, A_STRUCT, A_STRING, A_RESOURCE };
struct Arg {
    ArgType type;
    int i; float f; uint32_t o; float v[3]; int stype; void* sp; const wchar_t* s;
};
enum RetType { R_NONE, R_INT, R_FLOAT, R_OBJECT, R_VECTOR, R_STRUCT, R_STRING, R_OBJARRAY };
struct Ret {
    RetType type; int stype;
    int i; float f; uint32_t o; float v[3]; void* sp;
    wchar_t* text; int textCap;          // R_STRING
    uint32_t* objs; int objsMax;         // R_OBJARRAY (count in i)
};

static bool PushStringRaw(void* vm, const wchar_t* text, bool resource)
{
    GameString gs = {};
    size_t len = wcslen(text);
    wchar_t* heap = nullptr;
    if (len < 8) {
        memcpy(gs.buf, text, (len + 1) * sizeof(wchar_t));
        gs.cap = 7;
    } else {
        heap = static_cast<wchar_t*>(ENGINE(GameNew_t, kGameNew)((len + 1) * sizeof(wchar_t)));
        if (!heap) return false;
        memcpy(heap, text, (len + 1) * sizeof(wchar_t));
        gs.ptr = heap;
        gs.cap = static_cast<uint32_t>(len);
    }
    gs.size = static_cast<uint32_t>(len);
    int ok = resource ? ENGINE(PushString_t, kVmPushResource)(vm, &gs)    // copies the string
                      : ENGINE(PushString_t, kVmPushString)(vm, &gs);
    if (heap) ENGINE(GameDelete_t, kGameDelete)(heap);
    return ok != 0;
}

static bool PopStringRaw(void* vm, wchar_t* out, int cap)
{
    GameString gs = {};
    gs.cap = 7;                                               // = the game's empty-string ctor
    int ok = ENGINE(PopString_t, kVmPopString)(vm, &gs);
    if (ok && out && cap > 0) {
        const wchar_t* src = gs.cap >= 8 ? gs.ptr : gs.buf;
        int n = (int)gs.size < cap - 1 ? (int)gs.size : cap - 1;
        if (n > 0 && src) memcpy(out, src, n * sizeof(wchar_t));
        out[n < 0 ? 0 : n] = 0;
    }
    ENGINE(StringDtor_t, kStringDtor)(&gs);
    return ok != 0;
}

static bool PopObjectArrayRaw(void* vm, Ret* r)
{
    ArrayValue av = {};
    if (!ENGINE(PopArray_t, kVmPopArray)(vm, &av)) return false;
    r->i = 0;
    // av.holder -> {tag, box}, box -> {std::vector<uint32_t>*, refcount*}
    // (0xA2D4E0 copies the stack value with 0xA2D260; checked in 1.2.5).
    void** box = (av.tag == 0x43 && av.holder) ? static_cast<void**>(av.holder[1]) : nullptr;
    if (box && box[0]) {
        char* vec = static_cast<char*>(box[0]);
        uint32_t* first = *reinterpret_cast<uint32_t**>(vec + 4);
        uint32_t* last  = *reinterpret_cast<uint32_t**>(vec + 8);
        for (uint32_t* p = first; p && p < last && r->i < r->objsMax; ++p) r->objs[r->i++] = *p;
    }
    if (av.owner) ENGINE(ArrayFree_t, kVmArrayFree)(&av);
    return true;
}

// Returns the command's result code (0 = success), or a negative local code:
// -1 bridge not ready, -2 push failed, -3 pop failed, -4 crashed (caught), -5 backing off.
static int CallRaw(int cmd, const Arg* args, int argc, Ret* ret)
{
    void* vm = Vm();
    if (!vm) return -1;
    int* count = StackCount(vm);
    int depth = *count;
    int rc = -2;
    // Script parameters are popped first-to-last, so push them last-to-first.
    for (int k = argc - 1; k >= 0; --k) {
        const Arg& a = args[k];
        int ok = 0;
        switch (a.type) {
        case A_INT:    ok = ENGINE(PushInt_t, kVmPushInt)(vm, a.i); break;
        case A_FLOAT:  ok = ENGINE(PushFloat_t, kVmPushFloat)(vm, a.f); break;
        case A_OBJECT: ok = ENGINE(PushObject_t, kVmPushObject)(vm, a.o); break;
        case A_VECTOR: ok = ENGINE(PushFloat_t, kVmPushFloat)(vm, a.v[0]) &&
                            ENGINE(PushFloat_t, kVmPushFloat)(vm, a.v[1]) &&
                            ENGINE(PushFloat_t, kVmPushFloat)(vm, a.v[2]); break;
        case A_STRUCT: ok = ENGINE(PushStruct_t, kVmPushStruct)(vm, a.stype, a.sp); break;
        case A_STRING: ok = PushStringRaw(vm, a.s, false); break;
        case A_RESOURCE: ok = PushStringRaw(vm, a.s, true); break;
        }
        if (!ok) goto done;
    }
    {
        void* impl = Impl(vm);
        if (!impl) { rc = -1; goto done; }
        RunCommand_t run = reinterpret_cast<RunCommand_t>((*reinterpret_cast<void***>(impl))[2]);
        rc = run(impl, cmd, argc);
    }
    if (rc == 0 && ret && ret->type != R_NONE) {
        int ok = 0;
        switch (ret->type) {
        case R_INT:    ok = ENGINE(PopInt_t, kVmPopInt)(vm, &ret->i); break;
        case R_FLOAT:  ok = ENGINE(PopFloat_t, kVmPopFloat)(vm, &ret->f); break;
        case R_OBJECT: ok = ENGINE(PopObject_t, kVmPopObject)(vm, &ret->o); break;
        case R_VECTOR: ok = ENGINE(PopFloat_t, kVmPopFloat)(vm, &ret->v[2]) &&
                            ENGINE(PopFloat_t, kVmPopFloat)(vm, &ret->v[1]) &&
                            ENGINE(PopFloat_t, kVmPopFloat)(vm, &ret->v[0]); break;
        case R_STRUCT: ok = ENGINE(PopStruct_t, kVmPopStruct)(vm, ret->stype, &ret->sp); break;
        case R_STRING: ok = PopStringRaw(vm, ret->text, ret->textCap); break;
        case R_OBJARRAY: ok = PopObjectArrayRaw(vm, ret); break;
        default: ok = 1;
        }
        if (!ok) rc = -3;
    }
done:
    // Leave the VM stack exactly as we found it (frees anything left over).
    if (*count != depth) {
        void* stack = static_cast<char*>(vm) + game::kVmStackOffset;
        ENGINE(Truncate_t, kVmStackTruncate)(stack, depth);
    }
    return rc;
}

static bool Backoff() { return false; }

static bool CmdPaused(int cmd)
{
    if (cmd < 0 || cmd >= kMaxCmd) return false;
    if (g_cmdFaults[cmd] >= 5) return true;
    return g_cmdPauseUntil[cmd] && (int)(GetTickCount() - g_cmdPauseUntil[cmd]) < 0;
}

static void NoteFault(int cmd, DWORD code, const void* where)
{
    if (cmd >= 0 && cmd < kMaxCmd) {
        unsigned n = ++g_cmdFaults[cmd];
        g_cmdPauseUntil[cmd] = GetTickCount() + 2000;
        if (!g_cmdPauseUntil[cmd]) g_cmdPauseUntil[cmd] = 1;
        if (n == 5) Log("Script bridge: command %d crashed 5 times - switched off for this session", cmd);
    }
    if (++g_faults <= 30) Log("Script bridge: command %d crashed (0x%08lX at 0x%p) - caught, that command paused 2 s", cmd, code, where);
}

static int CallGuarded(int cmd, const Arg* args, int argc, Ret* ret)
{
    if (!g_ready) return -1;
    // After a crash, wait 2 seconds before touching the engine again (the
    // game may be loading or between areas).
    if (CmdPaused(cmd)) return -5;
#ifdef _MSC_VER
    const void* volatile where = nullptr;
    __try {
        return CallRaw(cmd, args, argc, ret);
    } __except (where = GetExceptionInformation()->ExceptionRecord->ExceptionAddress, EXCEPTION_EXECUTE_HANDLER) {
        NoteFault(cmd, GetExceptionCode(), where);
        return -4;
    }
#else
    (void)NoteFault;
    return CallRaw(cmd, args, argc, ret);   // 32-bit MinGW has no __try: test builds only
#endif
}

static int Call(int cmd, const Arg* args, int argc, Ret* ret)
{
    int rc = CallGuarded(cmd, args, argc, ret);
    if (rc != 0 && rc != -5) {
        static int logged = 0;
        if (++logged <= 60) Log("Script bridge: command %d returned %d", cmd, rc);
    }
    return rc;
}

// Popped engine structures (locations, commands) are copies we own.
static void FreeStructRaw(int type, void* p)
{
    void* vm = Vm();
    void* impl = vm ? Impl(vm) : nullptr;
    if (!impl || !p) return;
    DestroyStruct_t destroy = reinterpret_cast<DestroyStruct_t>(
        (*reinterpret_cast<void***>(impl))[game::kImplDestroyStruct / 4]);
    destroy(impl, type, p);
}

static void FreeStruct(int type, void* p)
{
    if (!p || !g_ready) return;
#ifdef _MSC_VER
    __try { FreeStructRaw(type, p); }
    __except (EXCEPTION_EXECUTE_HANDLER) { NoteFault(-1, GetExceptionCode(), nullptr); }
#else
    FreeStructRaw(type, p);
#endif
}

static Arg AInt(int v)        { Arg a = {}; a.type = A_INT; a.i = v; return a; }
static Arg AFloat(float v)    { Arg a = {}; a.type = A_FLOAT; a.f = v; return a; }
static Arg AObj(uint32_t v)   { Arg a = {}; a.type = A_OBJECT; a.o = v; return a; }
static Arg AVec(const Vec3& v){ Arg a = {}; a.type = A_VECTOR; a.v[0] = v.x; a.v[1] = v.y; a.v[2] = v.z; return a; }
static Arg AStruct(int t, void* p) { Arg a = {}; a.type = A_STRUCT; a.stype = t; a.sp = p; return a; }
static Arg AStr(const wchar_t* s)  { Arg a = {}; a.type = A_STRING; a.s = s; return a; }
static Arg ARes(const wchar_t* s)  { Arg a = {}; a.type = A_RESOURCE; a.s = s; return a; }

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
bool Init()
{
    g_ready = game::CheckBuild();
    return g_ready;
}

bool Ready() { return g_ready && !Backoff(); }

static uint32_t CallObject(int cmd, const Arg* args, int argc)
{
    Ret r = {}; r.type = R_OBJECT; r.o = game::kInvalidObject;
    return Call(cmd, args, argc, &r) == 0 ? r.o : game::kInvalidObject;
}

static int CallInt(int cmd, const Arg* args, int argc, int fallback)
{
    Ret r = {}; r.type = R_INT; r.i = fallback;
    return Call(cmd, args, argc, &r) == 0 ? r.i : fallback;
}

static float CallFloat(int cmd, const Arg* args, int argc, float fallback)
{
    Ret r = {}; r.type = R_FLOAT; r.f = fallback;
    return Call(cmd, args, argc, &r) == 0 ? r.f : fallback;
}

uint32_t GetHero()       { return CallObject(game::GETHERO, nullptr, 0); }
uint32_t GetControlled() { return CallObject(game::GETCONTROLLED, nullptr, 0); }

uint32_t GetObjectByTag(const wchar_t* tag, int nth)
{
    Arg a[2] = { AStr(tag), AInt(nth) };
    return CallObject(game::GETOBJECTBYTAG, a, 2);
}

bool IsObjectValid(uint32_t obj)
{
    if (obj == game::kInvalidObject) return false;
    Arg a[1] = { AObj(obj) };
    return CallInt(game::ISOBJECTVALID, a, 1, 0) != 0;
}

bool GetTag(uint32_t obj, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    Arg a[1] = { AObj(obj) };
    Ret r = {}; r.type = R_STRING; r.text = out; r.textCap = cap;
    return Call(game::GETTAG, a, 1, &r) == 0;
}

bool SetTag(uint32_t obj, const wchar_t* tag)
{
    Arg a[2] = { AObj(obj), AStr(tag) };
    return Call(game::SETTAG, a, 2, nullptr) == 0;
}

int GetObjectType(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallInt(game::GETOBJECTTYPE, a, 1, 0);
}

uint32_t GetArea(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallObject(game::GETAREA, a, 1);
}

bool GetPosition(uint32_t obj, Vec3* out)
{
    Arg a[1] = { AObj(obj) };
    Ret r = {}; r.type = R_VECTOR;
    if (Call(game::GETPOSITION, a, 1, &r) != 0) return false;
    out->x = r.v[0]; out->y = r.v[1]; out->z = r.v[2];
    return std::isfinite(out->x) && std::isfinite(out->y) && std::isfinite(out->z);
}

float GetFacing(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallFloat(game::GETFACING, a, 1, 0.f);
}

float GetDistance(uint32_t a, uint32_t b)
{
    Arg args[2] = { AObj(a), AObj(b) };
    return CallFloat(game::GETDISTANCEBETWEENOBJECTS, args, 2, -1.f);
}

bool GetName(uint32_t obj, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    Arg a[1] = { AObj(obj) };
    Ret r = {}; r.type = R_STRING; r.text = out; r.textCap = cap;
    return Call(game::GETNAME, a, 1, &r) == 0;
}

bool IsDead(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallInt(game::ISDEAD, a, 1, 1) != 0;
}

int IsDeadChecked(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallInt(game::ISDEAD, a, 1, -1);
}

bool IsHostile(uint32_t a, uint32_t b)
{
    Arg args[2] = { AObj(a), AObj(b) };
    return CallInt(game::ISHOSTILE, args, 2, 0) != 0;
}

int GetCombatState(uint32_t creature)
{
    Arg a[1] = { AObj(creature) };
    return CallInt(game::GETCOMBATSTATE, a, 1, 0);
}

int GetPartySize() { return CallInt(game::GETPARTYSIZE, nullptr, 0, -1); }

void DoAutoSave() { Call(game::DOAUTOSAVE, nullptr, 0, nullptr); }

bool HasAbility(uint32_t creature, int ability)
{
    Arg a[2] = { AObj(creature), AInt(ability) };
    return CallInt(game::HASABILITY, a, 2, 0) != 0;
}

void AddAbility(uint32_t creature, int ability)
{
    Arg a[3] = { AObj(creature), AInt(ability), AInt(0) };     // no notification
    Call(game::ADDABILITY, a, 3, nullptr);
}

void RemoveAbility(uint32_t creature, int ability)
{
    Arg a[2] = { AObj(creature), AInt(ability) };
    Call(game::REMOVEABILITY, a, 2, nullptr);
}

int GetCommandQueueSize(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    return CallInt(game::GETCOMMANDQUEUESIZE, a, 1, -1);
}

int GetNearestByHostility(uint32_t obj, bool hostile, int objectType, uint32_t* out, int max,
                          bool livingOnly, bool perceivedOnly)
{
    // GetNearestObjectByHostility(object oObject, int bHostile, int nObjectType,
    //                             int nNumberOfObjects, int bCheckLiving, int bCheckPerceived)
    Arg a[6] = { AObj(obj), AInt(hostile ? 1 : 0), AInt(objectType), AInt(max),
                 AInt(livingOnly ? 1 : 0), AInt(perceivedOnly ? 1 : 0) };
    Ret r = {}; r.type = R_OBJARRAY; r.objs = out; r.objsMax = max;
    return Call(game::GETNEARESTOBJECTBYHOSTILITY, a, 6, &r) == 0 ? r.i : -1;
}

int GetNearestObjects(uint32_t obj, int objectType, uint32_t* out, int max, bool livingOnly, bool perceivedOnly)
{
    // GetNearestObject(object, int nObjectType, int nNumber, int bCheckLiving, int bCheckPerceived, int bIncludeSelf)
    Arg a[6] = { AObj(obj), AInt(objectType), AInt(max), AInt(livingOnly ? 1 : 0), AInt(perceivedOnly ? 1 : 0), AInt(0) };
    Ret r = {}; r.type = R_OBJARRAY; r.objs = out; r.objsMax = max;
    return Call(game::GETNEARESTOBJECT, a, 6, &r) == 0 ? r.i : -1;
}

int GetQuickSlot(uint32_t creature, int slot)
{
    Arg a[2] = { AObj(creature), AInt(slot) };
    return CallInt(game::GETQUICKSLOT, a, 2, 0);
}

bool IsAbilityAvailable(uint32_t creature, int ability)
{
    Arg a[2] = { AObj(creature), AInt(ability) };
    return CallInt(game::ISABILITYAVAILABLE, a, 2, 0) != 0;
}

// Pops a command struct, adds it to obj's queue, frees our copy.
static bool QueueCommand(void* cmd, uint32_t obj, bool addToFront)
{
    // AddCommand(object oObject, command cCommand, int bAddToFront, int bStatic) -> int
    Arg aa[4] = { AObj(obj), AStruct(game::kStructCommand, cmd), AInt(addToFront ? 1 : 0), AInt(0) };
    Ret ar = {}; ar.type = R_INT;
    bool ok = Call(game::ADDCOMMAND, aa, 4, &ar) == 0;
    FreeStruct(game::kStructCommand, cmd);          // AddCommand queued its own copy
    return ok;
}

bool MoveTo(uint32_t obj, const Vec3& pos, float facingDeg, bool run, bool addToFront)
{
    uint32_t area = GetArea(obj);
    if (area == game::kInvalidObject) return false;

    // Location(object oArea, vector vPosition, float fFacing) -> location
    Arg la[3] = { AObj(area), AVec(pos), AFloat(facingDeg) };
    Ret lr = {}; lr.type = R_STRUCT; lr.stype = game::kStructLocation;
    if (Call(game::LOCATION, la, 3, &lr) != 0 || !lr.sp) { FreeStruct(game::kStructLocation, lr.sp); return false; }

    // CommandMoveToLocation(location lLocation, int bRun, int bDeactivateAtEnd) -> command
    Arg ma[3] = { AStruct(game::kStructLocation, lr.sp), AInt(run ? 1 : 0), AInt(0) };
    Ret mr = {}; mr.type = R_STRUCT; mr.stype = game::kStructCommand;
    int rc = Call(game::COMMANDMOVETOLOCATION, ma, 3, &mr);
    FreeStruct(game::kStructLocation, lr.sp);       // the push made the VM its own copy
    if (rc != 0 || !mr.sp) { FreeStruct(game::kStructCommand, mr.sp); return false; }

    return QueueCommand(mr.sp, obj, addToFront);
}

bool PlayAnimation(uint32_t obj, int animation, int loops, bool addToFront)
{
    // CommandPlayAnimation(int nAnimation, int nLoops, int, int bBlendIn) -> command [0x66FC20]
    Arg a[4] = { AInt(animation), AInt(loops), AInt(0), AInt(1) };
    Ret r = {}; r.type = R_STRUCT; r.stype = game::kStructCommand;
    if (Call(game::COMMANDPLAYANIMATION, a, 4, &r) != 0 || !r.sp) { FreeStruct(game::kStructCommand, r.sp); return false; }
    return QueueCommand(r.sp, obj, addToFront);
}

bool Attack(uint32_t obj, uint32_t target, bool addToFront)
{
    // CommandAttack(object oTarget, int nAttackType) -> command
    Arg a[2] = { AObj(target), AInt(0) };
    Ret r = {}; r.type = R_STRUCT; r.stype = game::kStructCommand;
    if (Call(game::COMMANDATTACK, a, 2, &r) != 0 || !r.sp) { FreeStruct(game::kStructCommand, r.sp); return false; }
    return QueueCommand(r.sp, obj, addToFront);
}

bool UseAbility(uint32_t obj, int ability, uint32_t target, const Vec3& targetPos, bool addToFront)
{
    // CommandUseAbility(int nAbility, object oTarget, vector vTarget, float fConjure, string sItem)
    // (this handler pops all five; there are no defaults)
    Arg a[5] = { AInt(ability), AObj(target), AVec(targetPos), AFloat(-1.f), AStr(L"") };
    Ret r = {}; r.type = R_STRUCT; r.stype = game::kStructCommand;
    if (Call(game::COMMANDUSEABILITY, a, 5, &r) != 0 || !r.sp) { FreeStruct(game::kStructCommand, r.sp); return false; }
    return QueueCommand(r.sp, obj, addToFront);
}

bool MoveToObject(uint32_t obj, uint32_t target, bool run, float minRange, bool addToFront)
{
    // CommandMoveToObject pops: object oTarget, int bRun, float fMinRange, int, float fMaxRange (>= min)
    Arg a[5] = { AObj(target), AInt(run ? 1 : 0), AFloat(minRange), AInt(0), AFloat(minRange) };
    Ret r = {}; r.type = R_STRUCT; r.stype = game::kStructCommand;
    if (Call(game::COMMANDMOVETOOBJECT, a, 5, &r) != 0 || !r.sp) { FreeStruct(game::kStructCommand, r.sp); return false; }
    return QueueCommand(r.sp, obj, addToFront);
}

bool SetPosition(uint32_t obj, const Vec3& pos)
{
    Arg a[3] = { AObj(obj), AVec(pos), AInt(0) };
    return Call(game::SETPOSITION, a, 3, nullptr) == 0;
}

static void* CallLocation(int cmd, const Arg* args, int argc);

bool SetPositionSafe(uint32_t obj, uint32_t nearObj, const Vec3& pos)
{
    uint32_t area = GetArea(nearObj);
    if (area == game::kInvalidObject) return false;
    Arg la[3] = { AObj(area), AVec(pos), AFloat(0.f) };
    Ret lr = {}; lr.type = R_STRUCT; lr.stype = game::kStructLocation;
    if (Call(game::LOCATION, la, 3, &lr) != 0 || !lr.sp) { FreeStruct(game::kStructLocation, lr.sp); return false; }
    Arg sa[1] = { AStruct(game::kStructLocation, lr.sp) };
    void* safe = CallLocation(game::GETSAFELOCATION, sa, 1);
    FreeStruct(game::kStructLocation, lr.sp);
    if (!safe) return false;
    Arg a[2] = { AObj(obj), AStruct(game::kStructLocation, safe) };
    bool ok = Call(game::SETLOCATION, a, 2, nullptr) == 0;
    FreeStruct(game::kStructLocation, safe);
    return ok;
}

bool SetLocationSafe(uint32_t obj, uint32_t nearObj, const Vec3& pos, float facingDeg)
{
    uint32_t area = GetArea(nearObj);
    if (area == game::kInvalidObject) return false;
    Arg la[3] = { AObj(area), AVec(pos), AFloat(facingDeg) };
    Ret lr = {}; lr.type = R_STRUCT; lr.stype = game::kStructLocation;
    if (Call(game::LOCATION, la, 3, &lr) != 0 || !lr.sp) { FreeStruct(game::kStructLocation, lr.sp); return false; }
    Arg sa[1] = { AStruct(game::kStructLocation, lr.sp) };
    void* safe = CallLocation(game::GETSAFELOCATION, sa, 1);
    FreeStruct(game::kStructLocation, lr.sp);
    if (!safe) return false;
    Arg a[2] = { AObj(obj), AStruct(game::kStructLocation, safe) };
    bool ok = Call(game::SETLOCATION, a, 2, nullptr) == 0;
    FreeStruct(game::kStructLocation, safe);
    return ok;
}

void DestroyObject(uint32_t obj)
{
    if (obj == game::kInvalidObject) return;
    Arg p[2] = { AObj(obj), AInt(0) };
    Call(game::SETPLOT, p, 2, nullptr);
    Arg a[2] = { AObj(obj), AInt(0) };
    Call(game::DESTROYOBJECT, a, 2, nullptr);
}

bool ClearAllCommands(uint32_t obj, bool hard)
{
    Arg a[2] = { AObj(obj), AInt(hard ? 1 : 0) };
    return CallInt(game::CLEARALLCOMMANDS, a, 2, 0) != 0;
}

bool SetFollowPartyLeader(uint32_t obj, bool follow)
{
    Arg a[2] = { AObj(obj), AInt(follow ? 1 : 0) };
    return Call(game::SETFOLLOWPARTYLEADER, a, 2, nullptr) == 0;
}

void SetPrimaryControlled(uint32_t obj)
{
    Arg a[1] = { AObj(obj) };
    Call(game::SETPRIMARYCONTROLLED, a, 1, nullptr);
}

// Pops a location from a command returning one (we own the copy).
static void* CallLocation(int cmd, const Arg* args, int argc)
{
    Ret r = {}; r.type = R_STRUCT; r.stype = game::kStructLocation;
    if (Call(cmd, args, argc, &r) != 0) { FreeStruct(game::kStructLocation, r.sp); return nullptr; }
    return r.sp;
}

bool JumpToSafeSpotNear(uint32_t obj, uint32_t anchor)
{
    // 1. formation spot behind the leader
    Arg fa[1] = { AObj(obj) };
    void* loc = CallLocation(game::GETFOLLOWERWOULDBELOCATION, fa, 1);
    // 2. fallback: right next to the anchor
    if (!loc) {
        Vec3 p;
        uint32_t area = GetArea(anchor);
        if (area == game::kInvalidObject || !GetPosition(anchor, &p)) return false;
        p.x += 1.2f; p.y -= 1.2f;
        Arg la[3] = { AObj(area), AVec(p), AFloat(GetFacing(anchor)) };
        loc = CallLocation(game::LOCATION, la, 3);
        if (!loc) return false;
    }
    // 3. nearest safe (walkable, unoccupied) spot
    Arg sa[1] = { AStruct(game::kStructLocation, loc) };
    void* safe = CallLocation(game::GETSAFELOCATION, sa, 1);
    FreeStruct(game::kStructLocation, loc);
    if (!safe) return false;
    // 4. CommandJumpToLocation(safe), front of the queue
    ClearAllCommands(obj, true);
    Arg ja[1] = { AStruct(game::kStructLocation, safe) };
    Ret jr = {}; jr.type = R_STRUCT; jr.stype = game::kStructCommand;
    int rc = Call(game::COMMANDJUMPTOLOCATION, ja, 1, &jr);
    FreeStruct(game::kStructLocation, safe);
    if (rc != 0 || !jr.sp) { FreeStruct(game::kStructCommand, jr.sp); return false; }
    return QueueCommand(jr.sp, obj, true);
}

uint32_t CreateObject(int objectType, const wchar_t* resource, uint32_t nearObj)
{
    Vec3 pos;
    uint32_t area = GetArea(nearObj);
    if (area == game::kInvalidObject || !GetPosition(nearObj, &pos)) return game::kInvalidObject;
    pos.x += 1.5f;
    Arg la[3] = { AObj(area), AVec(pos), AFloat(GetFacing(nearObj)) };
    Ret lr = {}; lr.type = R_STRUCT; lr.stype = game::kStructLocation;
    if (Call(game::LOCATION, la, 3, &lr) != 0 || !lr.sp) { FreeStruct(game::kStructLocation, lr.sp); return game::kInvalidObject; }
    // CreateObject(int nObjectType, resource rTemplate, location lLoc, string sOverrideScript, int bSpawnActive)
    Arg ca[5] = { AInt(objectType), ARes(resource), AStruct(game::kStructLocation, lr.sp), AStr(L""), AInt(1) };
    uint32_t obj = CallObject(game::CREATEOBJECT, ca, 5);
    FreeStruct(game::kStructLocation, lr.sp);
    return obj;
}

bool AddToParty(uint32_t obj)
{
    // AddToParty(object oCreature, object oParty) - the handler ignores the party argument
    Arg a[2] = { AObj(obj), AObj(game::kInvalidObject) };
    return Call(game::ADDTOPARTY, a, 2, nullptr) == 0;
}

bool SetFollowerState(uint32_t obj, int state)
{
    Arg a[2] = { AObj(obj), AInt(state) };
    return Call(game::SETFOLLOWERSTATE, a, 2, nullptr) == 0;
}

void PreloadCharGen() { Call(game::PRELOADCHARGEN, nullptr, 0, nullptr); }

void SetGameMode(int gm)
{
    Arg a[1] = { AInt(gm) };
    Call(game::SETGAMEMODE, a, 1, nullptr);
}

bool StartCharGen(uint32_t creature, int mode)
{
    Arg a[3] = { AObj(creature), AInt(mode), AInt(0) };
    return Call(game::STARTCHARGEN, a, 3, nullptr) == 0;
}

void DisplayStatusMessage(const wchar_t* text, uint32_t rgb)
{
    // 1.7.8: the mod's messages go to the small panel at the bottom left (above the health bar), not the game's big
    // blue banner across everyone's screen. [Messages] GameBanner=1 for the old banner.
    static int banner = -1;
    if (banner < 0) banner = (int)GetPrivateProfileIntA("Messages", "GameBanner", 0, Paths::GetConfigPath().c_str());
    if (!banner) { OnlineChat::Notice(text, rgb); return; }
    Arg a[2] = { AStr(text), AInt((int)rgb) };
    Call(game::DISPLAYSTATUSMESSAGE, a, 2, nullptr);
}

void DisplayFloatyMessage(uint32_t obj, const wchar_t* text, uint32_t rgb, float seconds)
{
    // DisplayFloatyMessage(object, string, int nStyle, int nColour, float fDuration)
    Arg a[5] = { AObj(obj), AStr(text), AInt(0), AInt((int)rgb), AFloat(seconds) };
    Call(game::DISPLAYFLOATYMESSAGE, a, 5, nullptr);
}

void ShowFloatyIcon(uint32_t creature, const wchar_t* image)
{
    Arg a[2] = { AObj(creature), AStr(image) };
    Call(game::SHOWFLOATYICON, a, 2, nullptr);
}

float GetCreatureProperty(uint32_t creature, int property, int valueType)
{
    Arg a[3] = { AObj(creature), AInt(property), AInt(valueType) };
    return CallFloat(game::GETCREATUREPROPERTY, a, 3, -1.f);
}

void SetCreatureProperty(uint32_t creature, int property, float value, int valueType)
{
    Arg a[4] = { AObj(creature), AInt(property), AFloat(value), AInt(valueType) };
    Call(game::SETCREATUREPROPERTY, a, 4, nullptr);
}

bool GetStringById(int strref, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    Arg a[1] = { AInt(strref) };
    Ret r = {}; r.type = R_STRING; r.text = out; r.textCap = cap;
    return Call(game::GETSTRINGBYSTRINGID, a, 1, &r) == 0;
}

bool GetM2DAString(int table, const wchar_t* column, int row, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    Arg a[4] = { AInt(table), AStr(column), AInt(row), AStr(L"") };
    Ret r = {}; r.type = R_STRING; r.text = out; r.textCap = cap;
    return Call(game::GETM2DASTRING, a, 4, &r) == 0;
}

float GetRemainingCooldown(uint32_t creature, int ability)
{
    Arg a[3] = { AObj(creature), AInt(ability), AStr(L"") };
    return CallFloat(game::GETREMAININGCOOLDOWN, a, 3, -1.f);
}

bool IsModalAbilityActive(uint32_t creature, int ability)
{
    Arg a[2] = { AObj(creature), AInt(ability) };
    return CallInt(game::ISMODALABILITYACTIVE, a, 2, 0) != 0;
}

int GetM2DAInt(int table, const wchar_t* column, int row)
{
    // GetM2DAInt(int nTable, string sColumn, int nRow, string sWorksheet)
    Arg a[4] = { AInt(table), AStr(column), AInt(row), AStr(L"") };
    return CallInt(game::GETM2DAINT, a, 4, -1);
}

bool GetCanLevelUp(uint32_t creature)
{
    Arg a[1] = { AObj(creature) };
    return CallInt(game::GETCANLEVELUP, a, 1, 0) != 0;
}

void SetAutoLevelUp(uint32_t creature, int mode)
{
    Arg a[2] = { AObj(creature), AInt(mode) };
    Call(game::SETAUTOLEVELUP, a, 2, nullptr);
}

static int* ImplSelfSlot()
{
    void* vm = Vm();
    void* impl = vm ? Impl(vm) : nullptr;
    return impl ? reinterpret_cast<int*>(static_cast<char*>(impl) + game::kImplSelf) : nullptr;
}

bool RunScriptOn(uint32_t obj, const wchar_t* scriptName, const wchar_t* runscriptVar)
{
    if (!g_ready) return false;
    uint32_t module = CallObject(game::GETMODULE, nullptr, 0);
    if (runscriptVar) {
        Arg a[3] = { AObj(module), AStr(L"RUNSCRIPT_VAR"), AStr(runscriptVar) };
        Call(game::SETLOCALSTRING, a, 3, nullptr);
    }
    int* self = ImplSelfSlot();
    if (!self) return false;
    int saved = *self;
    *self = (int)obj;                          // OBJECT_SELF for Event() and HandleEvent()
    // Event(EVENT_TYPE_INVALID) -> event struct (creator = OBJECT_SELF)
    Arg ea[1] = { AInt(0) };
    Ret er = {}; er.type = R_STRUCT; er.stype = game::kStructEvent;
    bool ok = false;
    if (Call(game::EVENT, ea, 1, &er) == 0 && er.sp) {
        // HandleEvent(event ev, resource rScript): runs the script now on OBJECT_SELF
        Arg ha[2] = { AStruct(game::kStructEvent, er.sp), ARes(scriptName) };
        ok = Call(game::HANDLEEVENT, ha, 2, nullptr) == 0;
    }
    FreeStruct(game::kStructEvent, er.sp);
    *self = saved;
    return ok;
}

bool OpenInventory(uint32_t container, uint32_t player)
{
    if (!g_ready) return false;
    int* slot = ImplSelfSlot();
    if (!slot) return false;
    int saved = *slot;
    *slot = (int)container;                    // OBJECT_SELF = the container, as in its own script
    Arg a[3] = { AObj(container), AObj(player), AInt(0) };
    const bool ok = Call(game::OPENINVENTORY, a, 3, nullptr) == 0;
    *slot = saved;
    return ok;
}

int LineOfSight(uint32_t self, const Vec3& a, const Vec3& b)
{
    // The command raises both points by 1.8 m and takes the area from OBJECT_SELF
    // (0x655CA0), so lower the points and run it as `self`.
    if (!g_ready) return -1;
    int* slot = ImplSelfSlot();
    if (!slot) return -1;
    Vec3 la = a, lb = b;
    la.z -= 1.8f; lb.z -= 1.8f;
    Arg args[2] = { AVec(la), AVec(lb) };
    int saved = *slot;
    *slot = (int)self;
    int r = CallInt(game::CHECKLINEOFSIGHTPOSITION, args, 2, -1);
    *slot = saved;
    return r;
}

uint32_t CreateItemOn(uint32_t obj, const wchar_t* resource, int stack)
{
    Arg a[6] = { ARes(resource), AObj(obj), AInt(stack), AStr(L""), AInt(1), AInt(1) };
    return CallObject(game::CREATEITEMONOBJECT, a, 6);
}

bool EquipItem(uint32_t creature, uint32_t item, int slot, int weaponSet)
{
    Arg a[4] = { AObj(creature), AObj(item), AInt(slot), AInt(weaponSet) };
    return CallInt(game::EQUIPITEM, a, 4, 0) != 0;
}

uint32_t ItemInEquipSlot(uint32_t creature, int slot, int weaponSet)
{
    Arg a[3] = { AInt(slot), AObj(creature), AInt(weaponSet) };
    return CallObject(game::GETITEMINEQUIPSLOT, a, 3);
}

} // namespace script
