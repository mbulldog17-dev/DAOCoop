#pragma once
// 1.7.2 the co-op menu: 1.7.7 hold View for 2 seconds (every player; START is the game's own), or press [Menu] Key
// (F10 by default). Players 2/3 and online friends also find "Step away" in it (it was View held 2 s).
// Tab 1 Voice: this PC's voice chat settings (mic on / off, sensitivity, friends' volume, ...).
// Tab 2 Controls: every button the mod adds.
// Drawn on this PC only (never in the online stream); whoever opened it drives it with their controller.
struct IDirect3DDevice9;

void ModMenuShow(int player, int padIndex);   // player 1-3 (0: an online friend on their own PC); padIndex -1 = keyboard
bool ModMenuOpen();
void ModMenuSetStepAway(void (*cb)(int player));   // 1.7.7: Players 2/3 picked "Step away" (coopcontrol)
bool ModMenuOpenFor(int player);              // open for that player (and a moment after it closed)
void ModMenuDraw(IDirect3DDevice9* dev);      // last in the frame; also reads the owner's controller
