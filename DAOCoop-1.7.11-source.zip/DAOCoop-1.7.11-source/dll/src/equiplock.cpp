#include "equiplock.h"
#include "xinputroute.h"
#include "hooks.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include "xpshare.h"
#include "pads.h"
#include "coopcontrol.h"
#include "dialogskill.h"
#include <cwchar>

static EquipLockSettings g_s;
static uint32_t g_owner[4] = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF };   // [2], [3] used
static bool     g_routeInstalled = false;
static unsigned g_nextRouteTry = 0;
static volatile DWORD g_lastMouseDown = 0;
static bool     g_inGui = false;
static uint32_t g_p1Controlled = 0xFFFFFFFF;     // what Player 1 drove before the screen opened
static uint32_t g_lastSelected = 0xFFFFFFFF;
static DWORD    g_lastBlockMsg = 0;
static int      g_openerPlayer = 0;          // who opened the current screen (loot window)
static DWORD    g_openerTime = 0;
static int      g_screenOwner = 0;           // 0 = follow the selected tab, 1-3 = that player keeps it
static WORD     g_prevHand[4] = {};          // hand-over button, per player (1 = Player 1's own pad)
static bool     g_prevKey = false;
static bool     g_inDialog = false;
static DWORD    g_allowControlUntil = 0;     // the mod itself selects a co-op character (opening its screen)
static DWORD    g_lastControlMsg = 0;
static volatile int g_fallMsg = 0;       // 1.2.51: set in the control hook, shown from the tick (1 = to an AI follower, 2 = waiting)

static int OwnerOf(uint32_t creature)
{
    if (creature == 0xFFFFFFFF) return 1;
    if (creature == g_owner[2]) return 2;
    if (creature == g_owner[3]) return 3;
    return 1;
}

int CoopOwnerOf(uint32_t creature) { return OwnerOf(creature); }
uint32_t CoopCharacterOf(int player) { return player >= 2 && player <= 3 ? g_owner[player] : 0xFFFFFFFF; }

uint32_t CoopPlayer1Character()
{
    if (g_p1Controlled != 0xFFFFFFFF) return g_p1Controlled;
    return script::GetHero();
}

void CoopNoteScreenOpener(int player)
{
    g_openerPlayer = player;
    g_openerTime = GetTickCount();
}

static int PadOf(int player) { return player == 2 ? g_s.padP2 : player == 3 ? g_s.padP3 : 0; }

// Who caused the action right now?
static int Actor()
{
    if (GetTickCount() - g_lastMouseDown < 400) return 1;             // mouse = Player 1
    int route = XInputRouteGet();
    if (route >= 0) {                                                 // (0: keyboard Player 1, a co-op player on controller 1)
        if (route == g_s.padP2) return 2;
        if (route == g_s.padP3) return 3;
    }
    return 1;
}

// CCCreature (client) -> object id: CCCreature+0x10 (= (this+4)->+0xC, see 0x6BBD06 / 0x53CC40)
static uint32_t CreatureId(void* ccreature)
{
#ifdef _MSC_VER
    __try { return *reinterpret_cast<uint32_t*>(static_cast<char*>(ccreature) + 0x10); }
    __except (EXCEPTION_EXECUTE_HANDLER) { return 0xFFFFFFFF; }
#else
    return *reinterpret_cast<uint32_t*>(static_cast<char*>(ccreature) + 0x10);
#endif
}

static bool Allowed(void* ccreature, const char* what)
{
    if (!g_s.enabled) return true;
    uint32_t id = CreatureId(ccreature);
    int owner = OwnerOf(id), actor = Actor();
    if (owner == actor) return true;
    Log("Equipment lock: %s on 0x%08X refused (belongs to Player %d, done by Player %d)", what, id, owner, actor);
    DWORD now = GetTickCount();
    if (now - g_lastBlockMsg > 1500) {
        g_lastBlockMsg = now;
        wchar_t text[96];
        swprintf(text, 96, L"Only Player %d can change this character's equipment", owner);
        script::DisplayStatusMessage(text, 0xFF9966);
    }
    return false;
}

// Message handlers: bool __thiscall CCCreature::OnXxx(const Message&), ret 4
typedef bool (__thiscall* Handler_t)(void* self, const void* msg);
static Handler_t g_origEquip = nullptr, g_origUnequip = nullptr, g_origSwitchNow = nullptr;

static bool __fastcall HookEquip(void* self, void*, const void* msg)
{ return Allowed(self, "equip") ? g_origEquip(self, msg) : true; }
static bool __fastcall HookUnequip(void* self, void*, const void* msg)
{ return Allowed(self, "unequip") ? g_origUnequip(self, msg) : true; }
static bool __fastcall HookSwitchNow(void* self, void*, const void* msg)
{ return Allowed(self, "weapon set switch") ? g_origSwitchNow(self, msg) : true; }


// --- 1.2.51: the game's own "control this party member" (0x6368F0, thiscall(party, id, a, b)) ---
// When Player 1's character dies the game hands Player 1 the next living party member by
// itself (1.2.50 switched back afterwards, but control of a fallen character is refused by
// the engine, so Player 1 ended up on Player 2's character anyway). While Player 1's current
// character is dead, a switch to Player 2's/3's character goes to the next living AI follower
// instead, or doesn't happen at all (Player 1 waits on the fallen character).
typedef int (__thiscall* Switch_t)(void*, uint32_t, int, int);
static Switch_t g_origSwitch = nullptr;
static bool EngineDead(uint32_t id)
{
    char* c = static_cast<char*>(game::ClientCreature(id));
    if (!c) return false;
    typedef int (__thiscall* Dead_t)(void*);
#ifdef _MSC_VER
    __try { return reinterpret_cast<Dead_t>((*reinterpret_cast<void***>(c))[0x1D0 / 4])(c) != 0; }
    __except (1) { return false; }
#else
    return reinterpret_cast<Dead_t>((*reinterpret_cast<void***>(c))[0x1D0 / 4])(c) != 0;
#endif
}
static int __fastcall HookSwitch(void* party, void*, uint32_t id, int a, int b)
{
    int owner = OwnerOf(id);
    if (owner >= 2 && g_s.blockPlayer1 && CoopPlayerActive(owner) && GetTickCount() > g_allowControlUntil) {
        typedef uint32_t (__thiscall* Ctl_t)(void*);
        void* app = *reinterpret_cast<void**>(0xC327EC);
        uint32_t cur = app ? reinterpret_cast<Ctl_t>(0x5D5CA0)(app) : 0xFFFFFFFF;
        if (cur != 0xFFFFFFFF && OwnerOf(cur) == 1 && EngineDead(cur)) {
            uint32_t m[16];
            int n = game::PartyMembers(m, 16);
            for (int i = 0; i < n; ++i) {
                if (OwnerOf(m[i]) != 1 || m[i] == cur || EngineDead(m[i])) continue;
                Log("Equipment lock: Player 1's character fell - control goes to AI follower 0x%08X, not Player %d's", m[i], owner);
                g_fallMsg = 1;
                return g_origSwitch(party, m[i], a, b);
            }
            static DWORD lastLog = 0;
            if (GetTickCount() - lastLog > 5000) { lastLog = GetTickCount(); Log("Equipment lock: Player 1's character fell, no AI follower standing - Player 1 waits (not Player %d's character)", owner); }
            g_fallMsg = 2;
            return 0;
        }
    }
    return g_origSwitch(party, id, a, b);
}

void EquipLockInit(const EquipLockSettings& s)
{
    g_s = s;
    XInputRouteSetPassThrough(s.passThrough);
    if (!s.enabled) { Log("Equipment lock: off"); return; }
    static const uint8_t kEquip[]   = { 0x6A, 0xFF, 0x68, 0x80, 0x32, 0xAA, 0x00 };
    static const uint8_t kUnequip[] = { 0x6A, 0xFF, 0x68, 0xF4, 0x2F, 0xAA, 0x00 };
    static const uint8_t kSwitch[]  = { 0x6A, 0xFF, 0x68, 0xC8, 0x16, 0xAA, 0x00 };
    g_origEquip = reinterpret_cast<Handler_t>(HookInstall(0x6BE330, reinterpret_cast<void*>(&HookEquip), 7, kEquip, "equip item"));
    g_origUnequip = reinterpret_cast<Handler_t>(HookInstall(0x6BC050, reinterpret_cast<void*>(&HookUnequip), 7, kUnequip, "unequip item"));
    g_origSwitchNow = reinterpret_cast<Handler_t>(HookInstall(0x6AB3C0, reinterpret_cast<void*>(&HookSwitchNow), 7, kSwitch, "switch weapon set"));
    static const uint8_t kCtl[] = { 0x6A, 0xFF, 0x68, 0x58, 0x9A, 0xA9, 0x00 };
    g_origSwitch = reinterpret_cast<Switch_t>(HookInstall(0x6368F0, reinterpret_cast<void*>(&HookSwitch), 7, kCtl, "party control switch"));
    Log("Equipment lock: on (P2 pad %d, P3 pad %d, Player 1 pass-through buttons 0x%04X)", s.padP2, s.padP3, s.passThrough);
}

void EquipLockSetOwner(int player, uint32_t creature)
{
    if (player < 2 || player > 3 || g_owner[player] == creature) return;
    g_owner[player] = creature;
    Log("Equipment lock: Player %d owns 0x%08X", player, creature);
}

static int RouteHolder()
{
    int r = XInputRouteGet();
    if (r >= 0 && r == g_s.padP2) return 2;
    if (r >= 0 && r == g_s.padP3) return 3;
    return 1;
}

// Gives the open screen to `player` (1-3) until it closes.
static void HandScreenTo(int player)
{
    g_screenOwner = player;
    XInputRouteSet(player == 1 ? -1 : PadOf(player));
    Log("Screen hand-over: Player %d has the %s", player, g_inDialog ? "conversation" : "screen");
    if (g_inDialog) DialogSkillUse(player, player >= 2 ? CoopCharacterOf(player) : 0xFFFFFFFF);
    wchar_t text[128];
    const wchar_t* what = g_inDialog ? L"conversation" : L"screen";
    if (player == 1) swprintf(text, 128, L"Player 1 has the %ls", what);
    else if (g_inDialog) swprintf(text, 128, L"Player %d speaks now - your skills count for persuade and intimidate (RS passes it on)", player);
    else swprintf(text, 128, L"Player %d: your controller has this %ls (RS passes it on)", player, what);
    script::DisplayStatusMessage(text, player == 3 ? 0x66DD66 : player == 2 ? 0x4DA6FF : 0xFFFFFF);
}

// Hand-over button (RS click by default) on the controller that holds the
// screen, or Player 1's own controller / keyboard key at any time: the screen
// goes to the next player who is playing (1 -> 2 -> 3 -> 1).
// Buttons already held when a screen opens don't count as a press.
static void PrimeHandOver()
{
    PadSnapshot p1 = PadsGetP1();
    g_prevHand[1] = p1.connected ? p1.gamepad.wButtons : 0;
    for (int p = 2; p <= 3; ++p) {
        PadSnapshot ps = PadsGet(p == 2 ? PLAYER_2 : PLAYER_3);
        g_prevHand[p] = ps.connected ? ps.gamepad.wButtons : 0;
    }
    g_prevKey = g_s.handOverKey && (GetAsyncKeyState(g_s.handOverKey) & 0x8000);
}

static void HandOverTick()
{
    if (!g_routeInstalled || !g_s.handOverButton) return;
    bool req = false;
    int holder = RouteHolder();
    // Player 1: own controller (read directly, never routed) or the keyboard key.
    PadSnapshot p1 = PadsGetP1();
    WORD b1 = p1.connected ? p1.gamepad.wButtons : 0;
    if ((b1 & g_s.handOverButton) && !(g_prevHand[1] & g_s.handOverButton)) req = true;
    g_prevHand[1] = b1;
    if (g_s.handOverKey) {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        bool down = pid == GetCurrentProcessId() && (GetAsyncKeyState(g_s.handOverKey) & 0x8000);
        if (down && !g_prevKey) req = true;
        g_prevKey = down;
    }
    // Player 2/3: only the one who holds the screen.
    for (int p = 2; p <= 3; ++p) {
        PadSnapshot ps = PadsGet(p == 2 ? PLAYER_2 : PLAYER_3);
        WORD b = ps.connected ? ps.gamepad.wButtons : 0;
        if (p == holder && (b & g_s.handOverButton) && !(g_prevHand[p] & g_s.handOverButton)) req = true;
        g_prevHand[p] = b;
    }
    if (!req) return;
    int next = holder;
    for (int i = 0; i < 3; ++i) {
        next = next % 3 + 1;
        if (next == 1 || CoopPlayerActive(next)) break;
    }
    if (next == holder) {
        script::DisplayStatusMessage(g_inDialog ? L"No other player to pass the conversation to"
                                                : L"No other player to pass the screen to", 0xFFFFFF);
        return;
    }
    HandScreenTo(next);
}

void EquipLockTick(unsigned now)
{
    // Physical mouse buttons = Player 1 (polled; works whether the game reads
    // the mouse through DirectInput or window messages).
    if ((GetAsyncKeyState(VK_LBUTTON) | GetAsyncKeyState(VK_RBUTTON)) & 0x8000) g_lastMouseDown = GetTickCount();

    if (!g_s.enabled) return;
    if (!g_routeInstalled && (int)(now - g_nextRouteTry) >= 0) {
        g_nextRouteTry = now + 5000;
        g_routeInstalled = XInputRouteInstall();
    }
    if (!script::Ready()) return;

    game::Mode mode = game::CurrentMode();
    // Full-screen GUIs and the character creator / level-up screens.
    bool gui = mode == game::MODE_GUI || mode == game::MODE_CHARGEN;

    // Conversations: Player 1 starts them, but RS passes the choices on.
    bool dialog = mode == game::MODE_DIALOG && g_s.passConversations;
    if (dialog && !g_inDialog) {
        g_inDialog = true;
        g_screenOwner = 1;
        PrimeHandOver();
    }
    if (!dialog && g_inDialog) {
        g_inDialog = false;
        g_screenOwner = 0;
        XInputRouteSet(-1);
        DialogSkillRestore();
    }
    if (g_inDialog) { HandOverTick(); return; }

    if (!gui) {
        if (g_inGui) {
            g_inGui = false;
            g_screenOwner = 0;
            XInputRouteSet(-1);
            // The screens switch the selected party member; give Player 1 back
            // the character they had if a co-op character is left selected.
            uint32_t sel = script::GetControlled();
            if (OwnerOf(sel) != 1 && g_p1Controlled != 0xFFFFFFFF && script::IsObjectValid(g_p1Controlled)) {
                Log("Equipment lock: screen closed on Player %d's character, giving Player 1 back 0x%08X",
                    OwnerOf(sel), g_p1Controlled);
                script::SetPrimaryControlled(g_p1Controlled);
            }
            g_lastSelected = 0xFFFFFFFF;
        }
        if (g_fallMsg) {
            DWORD t = GetTickCount();
            static DWORD lastFallMsg = 0;
            if (t - lastFallMsg > 8000) {
                lastFallMsg = t;
                script::DisplayStatusMessage(g_fallMsg == 1 ? L"Player 1 has fallen - now playing the next AI follower"
                                                            : L"Player 1 has fallen - waiting to be revived (or the end of the fight)", 0xFF9966);
            }
            g_fallMsg = 0;
        }
        if (mode == game::MODE_EXPLORE || mode == game::MODE_COMBAT) {
            uint32_t c = script::GetControlled();
            int owner = OwnerOf(c);
            if (owner == 1 && c != 0xFFFFFFFF) g_p1Controlled = c;
            // Player 1 may not take over Player 2's/3's character (party keys,
            // portrait clicks): straight back to the one they had.
            else if (owner >= 2 && g_s.blockPlayer1 && GetTickCount() > g_allowControlUntil && CoopPlayerActive(owner) &&
                     g_p1Controlled != 0xFFFFFFFF && script::IsObjectValid(g_p1Controlled)) {
                // 1.2.50: when Player 1's character has died the game hands Player 1 the next
                // living party member - skip Player 2/3 to the next living AI follower, or, if
                // there is none, leave Player 1 on their fallen character until revived.
                uint32_t back = g_p1Controlled;
                bool fallen = script::IsDeadChecked(back) == 1;
                if (fallen) {
                    uint32_t m[16];
                    int n = game::PartyMembers(m, 16);
                    for (int i = 0; i < n; ++i)
                        if (OwnerOf(m[i]) == 1 && m[i] != back && script::IsDeadChecked(m[i]) == 0) { back = m[i]; break; }
                }
                script::SetPrimaryControlled(back);
                DWORD t = GetTickCount();
                if (t - g_lastControlMsg > (fallen ? 8000u : 2000u)) {
                    g_lastControlMsg = t;
                    wchar_t name[64], text[128];
                    if (fallen && back == g_p1Controlled)
                        wcscpy(text, L"Player 1 has fallen - waiting to be revived (or the end of the fight)");
                    else if (fallen) {
                        if (!script::GetName(back, name, 64) || !name[0]) wcscpy(name, L"the next party member");
                        swprintf(text, 128, L"Player 1 has fallen - now playing %ls", name);
                    } else {
                        if (!script::GetName(c, name, 64) || !name[0]) wcscpy(name, L"That character");
                        swprintf(text, 128, L"%ls is played by Player %d", name, owner);
                    }
                    script::DisplayStatusMessage(text, 0xFF9966);
                    Log("Equipment lock: Player 1 got Player %d's character 0x%08X - %s 0x%08X", owner, c,
                        fallen ? (back == g_p1Controlled ? "fallen, staying on" : "fallen, next AI follower") : "switched back to", back);
                }
            }
        }
        return;
    }

    // In a full-screen GUI (inventory, character record, loot window, ...).
    if (!g_inGui) {
        PrimeHandOver();
        // A screen that Player 2/3 opened (a chest they used) is theirs until it closes.
        // 1.7.1: not when Player 1 clicked since (their own chest then opened on Player 2's screen)
        g_screenOwner = (g_openerPlayer >= 2 && GetTickCount() - g_openerTime < 5000 &&
                         (int)(g_lastMouseDown - g_openerTime) <= 0) ? g_openerPlayer : 0;
        g_openerPlayer = 0;
        if (g_screenOwner && g_routeInstalled) {
            Log("Equipment lock: screen opened by Player %d, their controller has it", g_screenOwner);
            XInputRouteSet(PadOf(g_screenOwner));
            wchar_t text[96];
            swprintf(text, 96, L"Player %d: your controller has this screen", g_screenOwner);
            script::DisplayStatusMessage(text, 0x66CCFF);
        }
    }
    g_inGui = true;
    HandOverTick();
    // The creator / level-up screen shows the creature StartCharGen was given;
    // the other screens show the selected (controlled) party member.
    uint32_t sel = script::GetControlled();
    if (mode == game::MODE_CHARGEN) {
        uint32_t cg = XpShareLastCharGenCreature();
        if (cg != 0xFFFFFFFF) sel = cg;
    }
    if (sel != g_lastSelected) {
        g_lastSelected = sel;
        int owner = OwnerOf(sel);
        wchar_t name[64];
        script::GetName(sel, name, 64);
        Log("Equipment lock: tab \"%ls\" (0x%08X) belongs to Player %d", name, sel, owner);
        if (g_screenOwner) {
            // keep the screen with the player who opened it
        } else if (owner >= 2 && g_routeInstalled) {
            XInputRouteSet(PadOf(owner));
            wchar_t text[96];
            swprintf(text, 96, L"Player %d: your controller has this screen", owner);
            script::DisplayStatusMessage(text, 0x66CCFF);
        } else {
            XInputRouteSet(-1);
        }
    }
}

void EquipLockSetPads(int padP2, int padP3)
{
    g_s.padP2 = padP2;
    g_s.padP3 = padP3;
}

void EquipLockAllowControl(unsigned ms)
{
    g_allowControlUntil = GetTickCount() + ms;
}

int EquipLockGuiOwner() { return g_inGui ? g_screenOwner : 0; }
