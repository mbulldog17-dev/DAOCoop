#pragma once
// 1.7.0: Player 2's (and Player 3's) own HUD, drawn on that player's picture (views.cpp): name, health and stamina/mana at the
// bottom left, and the three ability slots of the page Player 2 is on (X / Y / B, RT and LT pages) at the
// bottom right, like the controller ability cluster. Text is drawn with GDI into a texture (as popup.cpp).
#include <cstdint>

struct IDirect3DDevice9;

struct P2HudData
{
    bool valid = false;
    wchar_t name[64] = L"";
    float hp = -1.f, mp = -1.f;       // 0..1, -1 unknown
    bool mage = false;
    int page = 0;                     // 0 plain, 1 RT, 2 LT
    int ability[3] = {};              // X, Y, B (0 = empty slot)
    wchar_t abilityName[3][48] = {};
    wchar_t icon[3][48] = {};         // ABI_base "icon" (the game's icon in its GUI atlas, iconatlas.h)
    float cooldown[3] = {};           // seconds left
    bool active[3] = {};              // a sustained (modal) ability that is on
    wchar_t prompt[96] = L"";         // 1.7.1: what A uses now ("Open Chest"), bottom middle; empty: none
};

// player: 2 or 3 (1.7.0: Player 3 has their own HUD too, in their own colour)
void P2HudSet(int player, const P2HudData& d);                     // any thread
void P2HudDraw(int player, IDirect3DDevice9* dev, int W, int H);   // render thread, on the current render target
// The same in a box at ox, oy, W x H pixels (sizes follow H: half size in a split-screen box)
void P2HudDrawAt(int player, IDirect3DDevice9* dev, int ox, int oy, int W, int H);
