// 1.7.0: the game's GUI icon atlas (iconatlas.h).
#include "iconatlas.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cstdint>
#include <cstring>
#include <cwctype>
#include <string>
#include <vector>
#include <map>

namespace
{
    struct Entry { int page; float uv[4]; };
    struct Page { std::wstring name; IDirect3DTexture9* tex = nullptr; };

    bool g_tried = false, g_ok = false;
    IDirect3DDevice9* g_dev = nullptr;
    std::map<std::wstring, Entry> g_icons;     // lower-case name without ".dds"
    std::vector<Page> g_pages;
    std::wstring g_erf;

    struct TocEntry { uint32_t off, size; };
    std::map<std::wstring, TocEntry> g_toc;

    std::wstring Lower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }
    std::wstring Strip(std::wstring s)
    {
        s = Lower(s);
        if (s.size() > 4 && s.compare(s.size() - 4, 4, L".dds") == 0) s.resize(s.size() - 4);
        return s;
    }

    bool ReadToc(HANDLE f)
    {
        uint8_t hdr[32];
        DWORD got = 0;
        if (!ReadFile(f, hdr, 32, &got, nullptr) || got != 32) return false;
        if (std::memcmp(hdr, L"ERF V2.0", 16) != 0) { Log("Icons: %ls is not an ERF V2.0 file", g_erf.c_str()); return false; }
        uint32_t n; std::memcpy(&n, hdr + 16, 4);
        std::vector<uint8_t> toc(72u * n);
        if (!ReadFile(f, toc.data(), (DWORD)toc.size(), &got, nullptr) || got != toc.size()) return false;
        for (uint32_t i = 0; i < n; ++i) {
            const uint8_t* e = toc.data() + 72 * i;
            wchar_t nm[33] = {};
            std::memcpy(nm, e, 64);
            TocEntry t; std::memcpy(&t.off, e + 64, 4); std::memcpy(&t.size, e + 68, 4);
            g_toc[Lower(nm)] = t;
        }
        return true;
    }

    bool ReadEntry(HANDLE f, const wchar_t* name, std::vector<uint8_t>& out)
    {
        auto it = g_toc.find(Lower(name));
        if (it == g_toc.end()) return false;
        out.resize(it->second.size);
        LARGE_INTEGER pos; pos.QuadPart = it->second.off;
        DWORD got = 0;
        return SetFilePointerEx(f, pos, nullptr, FILE_BEGIN) && ReadFile(f, out.data(), (DWORD)out.size(), &got, nullptr) && got == out.size();
    }

    // <AtlasTexture Name="atl_shared_dxt1_00.dds"> <SourceTexture Name="x.dds" OffsetAndScale="u v su sv" .../> ...
    void ParseXml(const std::string& x)
    {
        size_t p = 0;
        int page = -1;
        auto attr = [&](size_t from, size_t to, const char* key) -> std::string {
            std::string k = std::string(key) + "=\"";
            size_t a = x.find(k, from);
            if (a == std::string::npos || a > to) return "";
            a += k.size();
            size_t b = x.find('"', a);
            return b == std::string::npos ? "" : x.substr(a, b - a);
        };
        for (;;) {
            size_t t = x.find('<', p);
            if (t == std::string::npos) break;
            size_t e = x.find('>', t);
            if (e == std::string::npos) break;
            if (x.compare(t, 13, "<AtlasTexture") == 0) {
                std::string nm = attr(t, e, "Name");
                Page pg; pg.name.assign(nm.begin(), nm.end());
                g_pages.push_back(pg);
                page = (int)g_pages.size() - 1;
            } else if (x.compare(t, 14, "<SourceTexture") == 0 && page >= 0) {
                std::string nm = attr(t, e, "Name"), os = attr(t, e, "OffsetAndScale");
                float u, v, su, sv;
                if (!nm.empty() && sscanf(os.c_str(), "%f %f %f %f", &u, &v, &su, &sv) == 4) {
                    Entry en{ page, { u, v, u + su, v + sv } };
                    g_icons[Strip(std::wstring(nm.begin(), nm.end()))] = en;
                }
            }
            p = e + 1;
        }
    }

    IDirect3DTexture9* LoadDds(IDirect3DDevice9* dev, const std::vector<uint8_t>& d, const std::wstring& nm)
    {
        if (d.size() < 128 || std::memcmp(d.data(), "DDS ", 4) != 0) return nullptr;
        uint32_t h, w, fourcc;
        std::memcpy(&h, d.data() + 12, 4); std::memcpy(&w, d.data() + 16, 4); std::memcpy(&fourcc, d.data() + 84, 4);
        D3DFORMAT fmt; uint32_t blk;
        if (fourcc == MAKEFOURCC('D', 'X', 'T', '1')) { fmt = D3DFMT_DXT1; blk = 8; }
        else if (fourcc == MAKEFOURCC('D', 'X', 'T', '5')) { fmt = D3DFMT_DXT5; blk = 16; }
        else { Log("Icons: %ls has an unexpected format", nm.c_str()); return nullptr; }
        const uint32_t bw = (w + 3) / 4, bh = (h + 3) / 4, row = bw * blk;
        if (d.size() < 128 + (size_t)row * bh) return nullptr;
        IDirect3DTexture9* t = nullptr;
        if (FAILED(dev->CreateTexture(w, h, 1, 0, fmt, D3DPOOL_MANAGED, &t, nullptr)) || !t) return nullptr;
        D3DLOCKED_RECT lr;
        if (FAILED(t->LockRect(0, &lr, nullptr, 0))) { t->Release(); return nullptr; }
        for (uint32_t y = 0; y < bh; ++y)
            std::memcpy(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch, d.data() + 128 + (size_t)y * row, row);
        t->UnlockRect(0);
        return t;
    }

    void Load(IDirect3DDevice9* dev)
    {
        g_tried = true;
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        std::wstring dir = exe;
        for (int i = 0; i < 2; ++i) { size_t s = dir.find_last_of(L"\\/"); if (s != std::wstring::npos) dir.resize(s); }   // ...\bin_ship\DAOrigins.exe -> game folder
        g_erf = dir + L"\\packages\\core\\data\\guiexport.erf";
        HANDLE f = CreateFileW(g_erf.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
        if (f == INVALID_HANDLE_VALUE) { Log("Icons: can't open %ls", g_erf.c_str()); return; }
        std::vector<uint8_t> buf;
        if (ReadToc(f) && ReadEntry(f, L"atl_shared_dxt1_dat.xml", buf)) {
            ParseXml(std::string(buf.begin(), buf.end()));
            for (auto& pg : g_pages) {
                if (ReadEntry(f, pg.name.c_str(), buf)) pg.tex = LoadDds(dev, buf, pg.name);
                if (!pg.tex) Log("Icons: couldn't load %ls", pg.name.c_str());
            }
            g_ok = !g_pages.empty();
        }
        CloseHandle(f);
        Log("Icons: %zu icons on %zu atlas pages from guiexport.erf%s", g_icons.size(), g_pages.size(), g_ok ? "" : " - FAILED");
    }
}

bool IconAtlasFind(IDirect3DDevice9* dev, const wchar_t* name, IDirect3DTexture9** tex, float uv[4])
{
    if (dev != g_dev) {                       // a new device: its textures are new too (old ones not released: gone with it)
        g_dev = dev; g_tried = false; g_ok = false; g_icons.clear(); g_pages.clear(); g_toc.clear();
    }
    if (!g_tried) Load(dev);
    if (!g_ok || !name || !name[0]) return false;
    auto it = g_icons.find(Strip(name));
    if (it == g_icons.end()) return false;
    const Page& pg = g_pages[it->second.page];
    if (!pg.tex) return false;
    *tex = pg.tex;
    std::memcpy(uv, it->second.uv, sizeof(float) * 4);
    return true;
}
