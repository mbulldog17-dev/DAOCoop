#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include <string>
#include "log.h"

// 1.7.1: the log is written by its own thread. Log() only adds the line to a buffer (a few microseconds);
// every 50 ms the writer thread puts what has gathered into the file. Before, every line was written and
// flushed to disk right away on whatever thread logged it - the game's own thread too, in the middle of a
// frame (a busy disk or a virus scanner could hold it for milliseconds).
static CRITICAL_SECTION g_lock;      // the buffer
static CRITICAL_SECTION g_fileLock;  // the file
static FILE* g_file = nullptr;
static bool g_ready = false;
static std::string g_buf;
static HANDLE g_writer = nullptr;
static volatile LONG g_stop = 0;

static void WriteOut()
{
    std::string out;
    EnterCriticalSection(&g_lock);
    out.swap(g_buf);
    LeaveCriticalSection(&g_lock);
    if (out.empty()) return;
    EnterCriticalSection(&g_fileLock);
    if (g_file) { fwrite(out.data(), 1, out.size(), g_file); fflush(g_file); }
    LeaveCriticalSection(&g_fileLock);
}

static DWORD WINAPI Writer(LPVOID)
{
    while (!g_stop) { Sleep(50); WriteOut(); }
    return 0;
}

bool LogInit(const wchar_t* path)
{
    if (!g_ready) {
        InitializeCriticalSection(&g_lock);
        InitializeCriticalSection(&g_fileLock);
        g_ready = true;
    }
    EnterCriticalSection(&g_fileLock);
    if (!g_file) g_file = _wfopen(path, L"w");
    bool ok = g_file != nullptr;
    LeaveCriticalSection(&g_fileLock);
    if (ok && !g_writer) g_writer = CreateThread(nullptr, 0, &Writer, nullptr, 0, nullptr);
    return ok;
}

void Log(const char* fmt, ...)
{
    if (!g_ready || !g_file) return;
    char line[2048];
    SYSTEMTIME t;
    GetLocalTime(&t);
    int n = _snprintf_s(line, sizeof line, _TRUNCATE, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    if (n < 0) n = 0;
    va_list args;
    va_start(args, fmt);
    int m = _vsnprintf_s(line + n, sizeof line - n - 1, _TRUNCATE, fmt, args);
    va_end(args);
    if (m < 0) m = static_cast<int>(strlen(line + n));
    n += m;
    line[n++] = '\n';
    EnterCriticalSection(&g_lock);
    g_buf.append(line, static_cast<size_t>(n));
    const bool big = g_buf.size() > (1u << 20);
    LeaveCriticalSection(&g_lock);
    if (big || !g_writer) WriteOut();   // (no writer thread, or it fell far behind: write here)
}

void LogShutdown()
{
    if (!g_ready) return;
    InterlockedExchange(&g_stop, 1);    // (not waited for: this can run while Windows holds the loader lock)
    WriteOut();
    EnterCriticalSection(&g_fileLock);
    if (g_file) { fclose(g_file); g_file = nullptr; }
    LeaveCriticalSection(&g_fileLock);
}
