#include <windows.h>
#include <shlobj.h>
#include <string>
#include <cstring>
#include "coopcreate.h"
#include "script.h"
#include "game.h"
#include "hooks.h"
#include "log.h"
#include "equiplock.h"
#include "savesafe.h"
#include <windows.h>
#include <cwchar>

static const wchar_t* TagOf(int p) { return p == 3 ? L"daocoop_p3" : L"daocoop_p2"; }
static uint32_t ColourOf(int p)    { return p == 3 ? 0x66DD66 : 0x4DA6FF; }

static CoopCreateSettings g_s;

enum Stage { ST_IDLE, ST_SAVING, ST_PRELOAD, ST_CHARGEN, ST_FINISH };
static Stage    g_stage = ST_IDLE;
static unsigned g_stageTime = 0;
static int      g_player = 0;                       // whose session is running
static unsigned g_nextAreaCheck = 0;
static uint32_t g_lastArea = game::kInvalidObject;
static bool     g_inTriggerArea = false;
static bool     g_prompt[4] = {};
static bool     g_declined[4] = {};                 // creator failed to open: don't nag again here
static unsigned g_nextPrompt[4] = {};
static uint32_t g_char[4] = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF };
static uint32_t g_heroForCreate = game::kInvalidObject;
static bool     g_inOrigin = false;         // hero is in an origin-story area
static bool     g_inSolo = false;           // ...one where the story wants the Warden alone (the Harrowing)
static bool     g_newGame = false;          // a lobby game just started: open the creators by themselves
static bool     g_skipSave = false;         // no save-before-creator (a brand-new game has nothing to lose)
static unsigned g_exploreSince = 0, g_lastExploreTick = 0, g_nextPartyCheck = 0;
static int      g_creatureType = 32;

// Read by the engine hooks (main thread only).
static volatile bool     g_session = false;     // the creator is open for a co-op character
static volatile uint32_t g_sessionCreature = 0xFFFFFFFF;
static volatile bool     g_endSeen = false;
static uint32_t g_warden = 0xFFFFFFFF;          // the hero before the creator opened
static bool     g_lookAdopted = false;              // the preview's look went onto the real creature
static bool     g_startQueued[4] = {};              // START pressed while another player's creator was open

// Face (1.2.23): the creator stores the face it made in the player profile,
// where only the hero's model looks. Keep the Warden's face, take the new one
// as a .mor file in the override folder and point the character's HeadMorph at
// it - the way NPCs get their faces.
static const int kMorphCap = 512 * 1024;
static unsigned char* g_wardenMorph = nullptr;  static int g_wardenMorphLen = -1;
static unsigned char* g_newMorph = nullptr;     static int g_newMorphLen = -1;
static void*    g_stashLook = nullptr;              // the preview's appearance data, taken at CharGenEnd
static wchar_t  g_morphRes[64] = L"";              // resref of the written .mor ("" = none)

static bool IsMorphBlob(const unsigned char* d, int n)
{
    return d && n > 32 && memcmp(d, "GFF V4.0", 8) == 0 && memcmp(d + 12, "MORP", 4) == 0;
}

// 1.7.4: a second copy of every co-op face in <game>\DAOCoop\Faces. The faces live only in Documents\...\override,
// and an installer cleanup (1.7.1 - 1.7.4) deleted them there: a missing face is put back from this copy.
static std::wstring FaceBackupDir()
{
    wchar_t exe[MAX_PATH];
    if (!GetModuleFileNameW(nullptr, exe, MAX_PATH)) return L"";
    std::wstring d = exe;
    for (int up = 0; up < 2; ++up) { size_t cut = d.find_last_of(L"\\/"); if (cut == std::wstring::npos) return L""; d.resize(cut); }   // ...\bin_ship\DAOrigins.exe -> game folder
    return d + L"\\DAOCoop\\Faces";
}
static std::wstring OverrideDir()
{
    wchar_t docs[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, docs))) return L"";
    return std::wstring(docs) + L"\\BioWare\\Dragon Age\\packages\\core\\override";
}
// once a run: every co-op face in the override folder copied to the backup folder (if it isn't there yet)
static void BackupFacesOnce()
{
    static bool done = false;
    if (done) return;
    done = true;
    const std::wstring from = OverrideDir(), to = FaceBackupDir();
    if (from.empty() || to.empty()) return;
    SHCreateDirectoryExW(nullptr, to.c_str(), nullptr);
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((from + L"\\daocoop_p*.mor").c_str(), &fd);
    int copied = 0, have = 0;
    if (h != INVALID_HANDLE_VALUE) {
        do {
            ++have;
            if (CopyFileW((from + L"\\" + fd.cFileName).c_str(), (to + L"\\" + fd.cFileName).c_str(), TRUE)) ++copied;
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    Log("Co-op faces: %d in the override folder, %d newly copied to %ls", have, copied, to.c_str());
}
// a face missing from the override folder, put back from the backup copy
static bool RestoreFace(const wchar_t* name)
{
    const std::wstring from = FaceBackupDir() + L"\\" + name + L".mor", to = OverrideDir() + L"\\" + name + L".mor";
    if (FaceBackupDir().empty() || OverrideDir().empty() || GetFileAttributesW(from.c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    SHCreateDirectoryExW(nullptr, OverrideDir().c_str(), nullptr);
    const bool ok = CopyFileW(from.c_str(), to.c_str(), FALSE) != 0;
    Log("Co-op face: %ls was missing - put back from the copy in DAOCoop\\Faces: %s", name, ok ? "ok" : "FAILED");
    return ok;
}

// The saved face of a co-op character (its HeadMorph name -> the .mor in the override folder), cached.
struct FaceFile { wchar_t name[64]; unsigned char* data; int len; };
static FaceFile g_faces[8] = {};
static const FaceFile* LoadFace(const wchar_t* name)
{
    for (FaceFile& f : g_faces) if (f.data && wcscmp(f.name, name) == 0) return &f;
    wchar_t docs[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, docs))) return nullptr;
    std::wstring path = std::wstring(docs) + L"\\BioWare\\Dragon Age\\packages\\core\\override\\" + name + L".mor";
    BackupFacesOnce();
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE && RestoreFace(name)) h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        static int missing = 0;
        if (missing++ < 5) Log("Co-op face: %ls is missing - that character shows the default face", path.c_str());
        return nullptr;
    }
    DWORD size = GetFileSize(h, nullptr), got = 0;
    unsigned char* buf = (size > 32 && size < kMorphCap) ? new unsigned char[size] : nullptr;
    bool ok = buf && ReadFile(h, buf, size, &got, nullptr) && got == size && IsMorphBlob(buf, (int)size);
    CloseHandle(h);
    if (!ok) { delete[] buf; Log("Co-op face: %ls could not be read", path.c_str()); return nullptr; }
    FaceFile* slot = &g_faces[0];
    for (FaceFile& f : g_faces) if (!f.data) { slot = &f; break; }
    delete[] slot->data;
    wcsncpy(slot->name, name, 63); slot->name[63] = 0;
    slot->data = buf; slot->len = (int)size;
    Log("Co-op face: loaded %ls (%d bytes)", name, (int)size);
    return slot;
}

// The model builder 0x6C1400 thiscall(creature, appearance, a, b, force), ret 0x10. A full build
// (b == 0) of an appearance whose HeadMorph is one of ours gets its face from that file (the game
// itself finds new override files only after a restart). 1.2.29: Player 2's face was lost on load.
typedef unsigned (__thiscall* BuildModel_t)(void* obj, void* app, int a, int b, int force);
static BuildModel_t g_origBuild = nullptr;
static int g_buildDepth = 0;
static unsigned __fastcall HookBuildModel(void* obj, void*, void* app, int a, int b, int force)
{
    if (b == 0 && app && obj && g_buildDepth == 0 && !g_session) {
        wchar_t hm[64];
        bool have = game::AppHeadMorph(app, hm, 64);
        static int seen = 0;
        if (have && hm[0] && seen < 30) { ++seen; Log("Model build: HeadMorph \"%ls\" (a %d, force %d)", hm, a, force); }
        if (have && wcsncmp(hm, L"daocoop_p", 9) == 0) {
            if (const FaceFile* f = LoadFace(hm)) {
                ++g_buildDepth;
                unsigned r = game::BuildWithFace(reinterpret_cast<void*>(g_origBuild), obj, app, a, b, force, f->data, f->len, hm);
                --g_buildDepth;
                static int logged = 0;
                if (logged++ < 10) Log("Co-op face: model built with %ls", hm);
                return r;
            }
        }
    }
    return g_origBuild(obj, app, a, b, force);
}

static wchar_t g_faceIni[260] = L"";
void CoopFaceSetIni(const wchar_t* ini) { wcsncpy(g_faceIni, ini, 259); g_faceIni[259] = 0; }

// After a load / area change: the character's face from its file (1.2.30). The HeadMorph name comes
// from its appearance (the save keeps it) or, if the save lost it, from DAOCoop.ini [Faces] <name>.
void CoopFaceRefresh(int player, uint32_t creature)
{
    static uint32_t lastObj[4] = {};
    static unsigned lastAt[4] = {};
    if (player < 2 || player > 3 || creature == game::kInvalidObject || g_session) return;
    unsigned now = GetTickCount();
    if (lastObj[player] == creature && now - lastAt[player] < 3000) return;
    lastObj[player] = creature; lastAt[player] = now;
    wchar_t hm[64] = L"", name[64] = L"", saved[64] = L"", tag[64] = L"", hero[64] = L"", key[200];
    wchar_t own[16];
    swprintf(own, 16, L"daocoop_p%d_", player);
    script::GetTag(creature, tag, 64);
    script::GetName(creature, name, 64);
    script::GetName(script::GetHero(), hero, 64);
    swprintf(key, 200, L"%ls|P%d|%ls", hero, player, name);
    if (wcsncmp(tag, own, wcslen(own)) == 0) wcscpy(hm, tag);             // the face this character was made with
    else {
        game::HeadMorph(creature, hm, 64);
        if (wcsncmp(hm, own, wcslen(own)) != 0) {
            hm[0] = 0;
            if (g_faceIni[0]) GetPrivateProfileStringW(L"Faces", key, L"", saved, 64, g_faceIni);
            if (g_faceIni[0] && wcsncmp(saved, own, wcslen(own)) != 0)   // characters made before 1.2.36: by name only
                GetPrivateProfileStringW(L"Faces", name, L"", saved, 64, g_faceIni);
            if (wcsncmp(saved, own, wcslen(own)) == 0) wcscpy(hm, saved);
        }
        if (hm[0]) script::SetTag(creature, hm);                          // from now on the save carries it
    }
    Log("Co-op face: Player %d (%ls, tag \"%ls\") face \"%ls\"", player, name, tag, hm);
    if (!hm[0]) return;                                                   // made before 1.2.36 with a name another character shares: default face
    game::SetHeadMorph(creature, hm);
    const FaceFile* f = LoadFace(hm);
    void* obj = game::ClientCreature(creature);
    void* app = obj ? *reinterpret_cast<void**>(static_cast<char*>(obj) + 0x7B0) : nullptr;
    if (!f || !app || !g_origBuild) return;
    ++g_buildDepth;
    game::BuildWithFace(reinterpret_cast<void*>(g_origBuild), obj, app, 0, 0, 1, f->data, f->len, hm);
    --g_buildDepth;
    Log("Co-op face: Player %d's model rebuilt with %ls", player, hm);
}

static bool WriteMorphFile(int player, const unsigned char* d, int n, wchar_t* resref, int cap)
{
    wchar_t docs[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, docs))) return false;
    std::wstring dir = std::wstring(docs) + L"\\BioWare\\Dragon Age\\packages\\core\\override";
    SHCreateDirectoryExW(nullptr, dir.c_str(), nullptr);
    SYSTEMTIME t; GetLocalTime(&t);
    swprintf(resref, cap, L"daocoop_p%d_%02d%02d%02d%02d%02d%02d", player, t.wYear % 100, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    std::wstring path = dir + L"\\" + resref + L".mor";
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) { Log("Co-op creator: could not write %ls (error %lu)", path.c_str(), GetLastError()); resref[0] = 0; return false; }
    DWORD w = 0;
    bool ok = WriteFile(h, d, (DWORD)n, &w, nullptr) && (int)w == n;
    CloseHandle(h);
    Log("Co-op creator: Player %d's face written to %ls (%d bytes): %s", player, path.c_str(), n, ok ? "ok" : "FAILED");
    if (ok) {                                       // 1.7.4: and a copy in DAOCoop\\Faces
        const std::wstring bd = FaceBackupDir();
        if (!bd.empty()) { SHCreateDirectoryExW(nullptr, bd.c_str(), nullptr); CopyFileW(path.c_str(), (bd + L"\\" + resref + L".mor").c_str(), FALSE); }
    }
    if (!ok) resref[0] = 0;
    return ok;
}

// The creator in creation mode makes its creature the game's "hero" (what
// GetHero returns; seen in 1.2.5: the Warden's place went to Player 2's
// character). Put the Warden back.
static void RestoreHero(const char* when)
{
    uint32_t now = game::HeroId();
    if (g_warden == game::kInvalidObject || now == g_warden) return;
    bool coop = (now == g_char[2] && now != game::kInvalidObject) || (now == g_char[3] && now != game::kInvalidObject);
    if (!coop && now != game::kInvalidObject) return;   // something else on purpose: leave it
    bool ok = game::SetHero(g_warden);
    Log("Co-op creator: the hero was 0x%08X (%s) %s - %s back to the Warden 0x%08X",
        now, now == g_char[2] ? "Player 2's character" : now == g_char[3] ? "Player 3's character" : "nobody",
        when, ok ? "set" : "FAILED to set", g_warden);
}

// 1.3.1: starting weapons. The creator gives a co-op character its background's starting gear
// (background_defaults.gda -> default_*.utc), but the Dwarf Noble and Mage templates have no
// weapon: those origins hand one out in their own scripts (bdnpt_generic: longsword + metal
// shield; bhm000pt_tranquility: the mage staff), which don't run for Players 2/3. Give the
// class's first weapons if the main hand is empty.
static void GiveStarterWeapons(int player, uint32_t c)
{
    if (script::ItemInEquipSlot(c, 0, 0) != game::kInvalidObject) {
        Log("Co-op creator: Player %d already has a weapon", player);
        return;
    }
    int cls = (int)(script::GetCreatureProperty(c, 27, 2) + 0.5f);        // PROPERTY_SIMPLE_CURRENT_CLASS
    if (cls <= 0) cls = (int)(script::GetCreatureProperty(c, 27, 1) + 0.5f);
    const wchar_t* mainHand = nullptr; const wchar_t* offHand = nullptr;
    switch (cls) {
    case 1: mainHand = L"gen_im_wep_mel_lsw_lsw.uti"; offHand = L"gen_im_arm_shd_sml_met.uti"; break;  // warrior
    case 2: mainHand = L"gen_im_wep_mag_sta_bhs.uti"; break;                                              // mage
    case 3: mainHand = L"gen_im_wep_mel_dag_dag.uti"; offHand = L"gen_im_wep_mel_dag_dag.uti"; break;  // rogue
    default: Log("Co-op creator: Player %d has no weapon, class %d unknown - none given", player, cls); return;
    }
    uint32_t m = script::CreateItemOn(c, mainHand, 1);
    bool okM = m != game::kInvalidObject && script::EquipItem(c, m, 0, 0);
    bool okO = true;
    if (offHand && script::ItemInEquipSlot(c, 1, 0) == game::kInvalidObject) {
        uint32_t o = script::CreateItemOn(c, offHand, 1);
        okO = o != game::kInvalidObject && script::EquipItem(c, o, 1, 0);
    }
    Log("Co-op creator: Player %d had no weapon (class %d) - gave %ls%s%ls: %s", player, cls, mainHand,
        offHand ? L" + " : L"", offHand ? offHand : L"", okM && okO ? "equipped" : "FAILED (check the inventory)");
}

// ---------------------------------------------------------------------------
// Engine hooks
// ---------------------------------------------------------------------------

// Module::RunEventScript(Event* ev, const GameString* script)   thiscall, ret 8
typedef void (__thiscall* ModuleEvent_t)(void* module, int* ev, void* script);
static ModuleEvent_t g_origModuleEvent = nullptr;

static void __fastcall HookModuleEvent(void* module, void* /*edx*/, int* ev, void* script)
{
    if (g_session && ev) {
        int type = ev[8];                                   // Event+0x20
        if (type == 55 || type == 1027) {
            Log("Co-op creator: dropped module event %d (%s)", type,
                type == 55 ? "background -> origin plot flags" : "chargen done -> origin start");
            typedef void (__thiscall* Dtor_t)(void*, int);
            (*reinterpret_cast<Dtor_t*>(*reinterpret_cast<void**>(ev)))(ev, 1);   // delete ev
            return;
        }
        if (type >= 44 && type <= 59) Log("Co-op creator: module event %d", type);
    }
    g_origModuleEvent(module, ev, script);
}

// CharGen finished message handler (stdcall, one message: +4 creature, +8 mode, +C flag)
typedef void (__stdcall* ChargenEnd_t)(int* msg);
static ChargenEnd_t g_origChargenEnd = nullptr;

static void __stdcall HookChargenEnd(int* msg)
{
    if (g_session && msg && (uint32_t)msg[1] == g_sessionCreature) {
        int mode = msg[2];
        Log("Co-op creator: Player %d's character creation finished (mode %d, flag %d), finishing as %s",
            g_player, mode, msg[3], g_s.endAs == 1 ? "level-up" : "creation");
        game::DumpChargen(g_sessionCreature);             // before the end handler tears the preview down
        // Keep a copy of the preview's finished appearance (built onto the
        // character once the game is back, see ST_FINISH).
        g_stashLook = game::StashPreviewLook();
        Log("Co-op creator: Player %d's look copied from the preview: %s", g_player, g_stashLook ? "ok" : "FAILED");
        g_lookAdopted = false;
        msg[2] = g_s.endAs == 1 ? 1 : mode;
        g_origChargenEnd(msg);
        msg[2] = mode;
        g_endSeen = true;
        RestoreHero("when the creator closed");
        // The face the creator made is now in the profile: take it, give the
        // Warden's back.
        if (!g_newMorph) g_newMorph = new unsigned char[kMorphCap];
        g_newMorphLen = game::ProfileMorphGet(g_newMorph, kMorphCap);
        bool changed = g_newMorphLen != g_wardenMorphLen ||
                       (g_newMorphLen > 0 && memcmp(g_newMorph, g_wardenMorph, g_newMorphLen) != 0);
        Log("Co-op creator: face in the profile after the creator: %d bytes%s, %s", g_newMorphLen,
            IsMorphBlob(g_newMorph, g_newMorphLen) ? " (morph)" : "", changed ? "new" : "same as the Warden's");
        if (changed && g_wardenMorphLen >= 0) {
            bool ok = game::ProfileMorphSet(g_wardenMorph, g_wardenMorphLen);
            Log("Co-op creator: Warden's face put back in the profile: %s", ok ? "ok" : "FAILED");
        }
        if (changed && IsMorphBlob(g_newMorph, g_newMorphLen))
            WriteMorphFile(g_player, g_newMorph, g_newMorphLen, g_morphRes, 64);
        else
            g_newMorphLen = -1;
        return;
    }
    if (msg) Log("Character creator finished for 0x%08X (mode %d) - not a new co-op character, untouched",
                 (uint32_t)msg[1], msg[2]);
    g_origChargenEnd(msg);
}

// GUICharGen "SelectAppearanceAndSoundSet" (0x736E10, thiscall(gui, msg), ret 4) - the voice
// pick. It sends event 48 (+ msg+4 int, msg+0xC string) to the PLAYER's creature (app+0x2B8 ->
// 0x5D4FC0), not to the creature in the creator [dec 0x736E10]: Player 2's/3's voice went to
// the Warden, and their own creature (and so the preview's "test voice") had none. During a
// co-op session the same event goes to the co-op character, the name is also set on it right
// away, and the preview gets it (ChargenVoiceSync in the tick) so the test voice plays.
typedef int (__thiscall* SelectVoice_t)(void* gui, char* msg);
static SelectVoice_t g_origSelectVoice = nullptr;
static int __fastcall HookSelectVoice(void* gui, void*, char* msg)
{
    if (!g_session || !msg || g_sessionCreature == game::kInvalidObject) return g_origSelectVoice(gui, msg);
    wchar_t name[64] = L"";
    game::ReadGameString(msg + 0xC, name, 64);
    typedef void* (__cdecl* New_t)(size_t);
    typedef void* (__thiscall* EvCtor_t)(void*);
    typedef void  (__thiscall* EvInt_t)(void*, int, int);
    typedef void  (__thiscall* EvStr_t)(void*, int, const void*);
    typedef void  (__thiscall* Send_t)(void*, uint32_t, uint32_t, int, void*);
    typedef void  (__thiscall* Paper_t)(void*);
    char* app = *reinterpret_cast<char**>(0xC327EC);
    void* ev = reinterpret_cast<New_t>(0x413660)(0x50);
    if (!app || !ev) return g_origSelectVoice(gui, msg);
    ev = reinterpret_cast<EvCtor_t>(0x69BAC0)(ev);
    uint32_t target = g_sessionCreature;
    *reinterpret_cast<uint32_t*>(static_cast<char*>(ev) + 0x24) = target;
    reinterpret_cast<EvInt_t>(0xA5B950)(ev, 0, *reinterpret_cast<int*>(msg + 4));
    *reinterpret_cast<int*>(static_cast<char*>(ev) + 0x20) = 0x30;
    reinterpret_cast<EvStr_t>(0xA5BA10)(ev, 0, msg + 0xC);
    reinterpret_cast<Send_t>(0x64AD80)(*reinterpret_cast<void**>(app + 0x1AC), target, target, 10, ev);
    bool direct = name[0] == L's' && name[1] == L's' && name[2] == L'_' && game::SetSoundSetFrom(target, msg + 0xC);
    char* paper = *reinterpret_cast<char**>(static_cast<char*>(gui) + 0x110);
    if (paper) {
        reinterpret_cast<Paper_t>(0x7FECF0)(paper);
        reinterpret_cast<Paper_t>(0x803000)(paper);
    }
    int synced = game::ChargenVoiceSync(target);
    Log("Co-op creator: Player %d picked voice \"%ls\" (value %d) - event to the co-op character%s, preview %s",
        g_player, name, *reinterpret_cast<int*>(msg + 4), direct ? ", set directly" : "",
        synced > 0 ? "updated" : synced == 0 ? "already has it" : "not found");
    return 1;
}

// GUICharGen "ResetCreature" (0x738410, thiscall(gui, msg), ret 4): the creator
// GUI sends it when its first scene starts. It resets the PLAYER - deletes the
// hero's and the party's client objects, makes a new player and hero - then
// points the creator and its preview at that hero [dec 0x738410 -> 0x69E120 ->
// 0x69DDA0 / 0x69D200 / 0x69DBB0]. Fine for a new game; for Player 2 it threw
// the Warden out and showed the wrong body. During a co-op session we only do
// the last part, with Player 2's creature.
typedef unsigned (__thiscall* GuiMsg_t)(void* gui, void* msg);
static GuiMsg_t g_origResetCreature = nullptr;
static unsigned __fastcall HookResetCreature(void* gui, void*, void* msg)
{
    if (g_session && g_sessionCreature != game::kInvalidObject) {
        bool ok = game::ChargenUse(g_sessionCreature);
        Log("Co-op creator: creator reset -> skipped the player reset, creator and preview use Player %d's character 0x%08X: %s",
            g_player, (uint32_t)g_sessionCreature, ok ? "ok" : "FAILED");
        return 1;
    }
    return g_origResetCreature(gui, msg);
}

// GUICharGen preview refresh after a race/gender/class pick (0x7356F0,
// thiscall(gui, n), ret 4). It skips the refresh when flag 0x4236 is set,
// which it is outside the new-game creator; do it without that check.
typedef void (__thiscall* GuiInt_t)(void* gui, int n);
static GuiInt_t g_origPreviewRefresh = nullptr;
static void __fastcall HookPreviewRefresh(void* gui, void*, int n)
{
    if (g_session) {
        bool ok = game::ChargenRefresh(n);
        static int dumps = 0;
        if (dumps++ == 0) game::DumpChargen(g_sessionCreature);
        static int logged = 0;
        if (logged++ < 20) Log("Co-op creator: preview refresh (%d): %s", n, ok ? "ok" : "FAILED");
        return;
    }
    g_origPreviewRefresh(gui, n);
}

// "Exit to the start menu" (GameModeController / GameModeCharGen handler
// 0x6400C0, thiscall(this, msg), ret 4). In the creator, Back on its first
// screen sends it (CharGen.as GoBack) - for Player 2 that threw the whole game
// back to the main menu (1.2.12 test). Not while a co-op creator is open.
static GuiMsg_t g_origExitToMenu = nullptr;
static unsigned __fastcall HookExitToMenu(void* self, void*, void* msg)
{
    if (g_session) {
        Log("Co-op creator: Player %d pressed Back on the creator's first screen - not leaving the game", g_player);
        wchar_t text[96];
        swprintf(text, 96, L"Player %d: finish your character - Back can't leave the creator", g_player);
        script::DisplayStatusMessage(text, ColourOf(g_player));
        return 1;
    }
    return g_origExitToMenu(self, msg);
}

static void InstallHooks()
{
    static const uint8_t kModuleEvent[] = { 0x53, 0x56, 0x57, 0x8B, 0x7C, 0x24, 0x10 };
    static const uint8_t kChargenEnd[]  = { 0x6A, 0xFF, 0x68, 0xE6, 0xD4, 0xAB, 0x00 };
    g_origModuleEvent = reinterpret_cast<ModuleEvent_t>(
        HookInstall(0x67BFB0, reinterpret_cast<void*>(&HookModuleEvent), 7, kModuleEvent, "module events"));
    g_origChargenEnd = reinterpret_cast<ChargenEnd_t>(
        HookInstall(0x7FCA90, reinterpret_cast<void*>(&HookChargenEnd), 7, kChargenEnd, "chargen end"));
    static const uint8_t kBuild[]   = { 0x6A, 0xFF, 0x68, 0xAB, 0x35, 0xAA, 0x00 };
    g_origBuild = reinterpret_cast<BuildModel_t>(
        HookInstall(0x6C1400, reinterpret_cast<void*>(&HookBuildModel), 7, kBuild, "model build (co-op faces)"));
    static const uint8_t kReset[]   = { 0x6A, 0xFF, 0x68, 0xC0, 0xEE, 0xAA, 0x00 };
    static const uint8_t kRefresh[] = { 0x56, 0x8B, 0xF1, 0x8B, 0x86, 0xC0, 0x00, 0x00, 0x00 };
    g_origResetCreature = reinterpret_cast<GuiMsg_t>(
        HookInstall(0x738410, reinterpret_cast<void*>(&HookResetCreature), 7, kReset, "chargen reset creature"));
    static const uint8_t kVoice[] = { 0x6A, 0xFF, 0x68, 0x8B, 0xC3, 0xA9, 0x00 };
    g_origSelectVoice = reinterpret_cast<SelectVoice_t>(
        HookInstall(0x736E10, reinterpret_cast<void*>(&HookSelectVoice), 7, kVoice, "chargen voice pick"));
    g_origPreviewRefresh = reinterpret_cast<GuiInt_t>(
        HookInstall(0x7356F0, reinterpret_cast<void*>(&HookPreviewRefresh), 9, kRefresh, "chargen preview refresh"));
    static const uint8_t kExit[] = { 0x8B, 0x0D, 0xEC, 0x27, 0xC3, 0x00, 0x6A, 0x00 };
    g_origExitToMenu = reinterpret_cast<GuiMsg_t>(
        HookInstall(0x6400C0, reinterpret_cast<void*>(&HookExitToMenu), 8, kExit, "exit to start menu"));
}

static bool HooksReady() { return g_origModuleEvent && g_origChargenEnd && g_origResetCreature && g_origPreviewRefresh; }

// ---------------------------------------------------------------------------

void CoopCreateInit(const CoopCreateSettings& s)
{
    g_s = s;
    if (s.hooks) InstallHooks();
    Log("Co-op creator: %s at areas \"%ls\", template \"%ls\", follower state %d, end as %s, hooks %s",
        s.autoAtArea ? "offered" : "not offered", s.areas, s.templ, s.followerState,
        s.endAs == 1 ? "level-up" : "creation", HooksReady() ? "ready" : "OFF");
}

bool CoopCreatePrompting(int p) { return p >= 2 && p <= 3 && g_prompt[p]; }

bool CoopCreateBusy() { return g_stage != ST_IDLE; }
int  CoopCreatePlayer() { return g_stage != ST_IDLE ? g_player : 0; }

// The override folder that holds the co-op faces (Documents\BioWare\Dragon Age\packages\core\override).
static std::wstring FaceDir()
{
    wchar_t docs[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, docs))) return L"";
    return std::wstring(docs) + L"\\BioWare\\Dragon Age\\packages\\core\\override";
}

// 1.2.36: a co-op character's tag is its face's name ("daocoop_p3_<date>"), so every save carries
// which face belongs to which character (the save does not keep HeadMorph, and names repeat:
// "Elissa" got another save's Elissa's face). Older characters still have the plain tag.
bool CoopCreateSessionOpen() { return g_session; }

uint32_t CoopCreateCharacter(int p)
{
    if (p < 2 || p > 3) return game::kInvalidObject;
    if (g_char[p] != game::kInvalidObject && script::IsObjectValid(g_char[p])) {
        // (1.2.39: after loading another save the remembered object number can be someone else)
        wchar_t tag[64] = L"";
        script::GetTag(g_char[p], tag, 64);
        if (wcsncmp(tag, TagOf(p), 10) == 0) return g_char[p];
        g_char[p] = game::kInvalidObject;
    }
    uint32_t o = script::GetObjectByTag(TagOf(p), 0);
    if (!script::IsObjectValid(o)) {
        // 1.7.4: a party member with this player's tag ("daocoop_p2_<date>") - also when its face file is missing
        // (then it was taken for "no character yet" and Player 2 was asked to make one)
        uint32_t m[16];
        const int n = game::PartyMembers(m, 16);
        for (int i = 0; i < n; ++i) {
            wchar_t tag[64] = L"";
            script::GetTag(m[i], tag, 64);
            if (wcsncmp(tag, TagOf(p), 10) == 0 && (tag[10] == 0 || tag[10] == L'_')) { o = m[i]; break; }
        }
    }
    if (!script::IsObjectValid(o)) {
        // the faces of this player that exist: one of them is the character's tag
        o = game::kInvalidObject;
        std::wstring dir = FaceDir();
        wchar_t pat[32];
        swprintf(pat, 32, L"\\daocoop_p%d_*.mor", p);
        WIN32_FIND_DATAW fd;
        HANDLE h = dir.empty() ? INVALID_HANDLE_VALUE : FindFirstFileW((dir + pat).c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                std::wstring stem = fd.cFileName;
                size_t dot = stem.rfind(L'.');
                if (dot != std::wstring::npos) stem.resize(dot);
                uint32_t c = script::GetObjectByTag(stem.c_str(), 0);
                if (script::IsObjectValid(c)) { o = c; break; }
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
    }
    g_char[p] = script::IsObjectValid(o) ? o : game::kInvalidObject;
    return g_char[p];
}

static bool TagInList(const wchar_t* tag, const wchar_t* list)
{
    size_t n = wcslen(tag);
    if (!n) return false;
    for (const wchar_t* p = list; *p; ) {
        while (*p == L',' || *p == L' ') ++p;
        const wchar_t* e = p;
        while (*e && *e != L',') ++e;
        const wchar_t* t = e;
        while (t > p && t[-1] == L' ') --t;
        if ((size_t)(t - p) == n && _wcsnicmp(p, tag, n) == 0) return true;
        p = e;
    }
    return false;
}

static void SetStage(Stage s, unsigned now) { g_stage = s; g_stageTime = now; }

// "bhn100ar_castle" starts with one of "bhn,bdn,..."?
static bool PrefixInList(const wchar_t* tag, const wchar_t* list)
{
    for (const wchar_t* p = list; *p; ) {
        while (*p == L',' || *p == L' ') ++p;
        const wchar_t* e = p;
        while (*e && *e != L',' && *e != L' ') ++e;
        size_t n = (size_t)(e - p);
        if (n && _wcsnicmp(tag, p, n) == 0) return true;
        p = e;
    }
    return false;
}

static bool InParty(uint32_t c)
{
    uint32_t m[16];
    int n = game::PartyMembers(m, 16);
    if (n < 0) return true;                       // unreadable: don't touch anything
    for (int i = 0; i < n; ++i) if (m[i] == c) return true;
    return false;
}

void CoopCreateNewGame()
{
    g_newGame = g_s.atStart;
    g_exploreSince = 0;
    for (int p = 2; p <= 3; ++p) g_declined[p] = false;
    Log("Co-op creator: new co-op game%s", g_newGame ? " - Players 2/3 make their characters when the story starts" : "");
}

void CoopCreateBegin(int player, uint32_t hero, int creatureType)
{
    if (CoopCreateBusy() || player < 2 || player > 3) return;
    if (!HooksReady()) {
        Log("Co-op creator: the safety hooks are not installed, refusing to open the creator");
        script::DisplayStatusMessage(L"Character creator unavailable (see DAOCoop.log)", 0xFF6666);
        return;
    }
    g_player = player;
    g_prompt[player] = false;
    g_heroForCreate = hero;
    g_creatureType = creatureType;

    // Save safety: an autosave + backup of the Warden's saves before the creator
    // (not at the very start of a new game: there is nothing to protect yet).
    // (Also when Player 2/3 pressed START before the automatic start-of-story
    // creator: 1.2.7 waited ~20 s for a save there.)
    bool skipSave = g_skipSave || g_newGame;
    g_skipSave = false;
    wchar_t heroName[64] = L"", n2[64] = L"", n3[64] = L"", tag[32];
    script::GetName(hero, heroName, 64);
    if (CoopCreateCharacter(2) != game::kInvalidObject) script::GetName(CoopCreateCharacter(2), n2, 64);
    if (CoopCreateCharacter(3) != game::kInvalidObject) script::GetName(CoopCreateCharacter(3), n3, 64);
    swprintf(tag, 32, L"before-creator-p%d", player);
    if (!skipSave) SaveSafeBackup(tag, true, heroName, n2, n3);
    if (!skipSave && SaveSafeBusy()) {
        wchar_t text[96];
        swprintf(text, 96, L"Player %d: saving the game first...", player);
        script::DisplayStatusMessage(text, ColourOf(player));
        SetStage(ST_SAVING, GetTickCount());
        return;
    }
    Log("Co-op creator: preloading the character creator for Player %d", player);
    script::PreloadCharGen();
    SetStage(ST_PRELOAD, GetTickCount());
}

static void CreateAndOpen(unsigned now)
{
    int p = g_player;
    uint32_t hero = g_heroForCreate;
    uint32_t obj = script::CreateObject(g_creatureType, g_s.templ, hero);
    Log("Co-op creator: CreateObject(\"%ls\") -> 0x%08X", g_s.templ, obj);
    if (!script::IsObjectValid(obj)) {
        wchar_t text[96];
        swprintf(text, 96, L"Player %d: could not create the character (see DAOCoop.log)", p);
        script::DisplayStatusMessage(text, 0xFF6666);
        g_declined[p] = true;
        SetStage(ST_IDLE, now);
        return;
    }
    script::SetTag(obj, TagOf(p));
    wchar_t tag[64];
    script::GetTag(obj, tag, 64);
    bool joined = script::SetFollowerState(obj, g_s.followerState);
    Log("Co-op creator: tag now \"%ls\", SetFollowerState(%d) %s, party size %d",
        tag, g_s.followerState, joined ? "ok" : "failed", script::GetPartySize());
    g_char[p] = obj;
    EquipLockSetOwner(p, obj);          // this player's character from now on (XP, gear, screens)
    CoopNoteScreenOpener(p);            // the creator goes to this player's controller

    if (game::IsPaused()) Log("Co-op creator: game is paused - the creator refuses to open while paused");
    if (g_warden == game::kInvalidObject || !script::IsObjectValid(g_warden)) g_warden = game::HeroId();
    Log("Co-op creator: hero before the creator 0x%08X (GetHero 0x%08X)", game::HeroId(), script::GetHero());
    // The creator's preview and its race/body/face changes follow the game's
    // hero (1.2.6 test: the preview stayed the Warden's body type whatever race
    // was picked). In a real new game the creator's creature IS the hero, so make
    // it so for the session; RestoreHero puts the Warden back when it closes.
    bool heroSet = game::SetHero(obj);
    Log("Co-op creator: Player %d's character is the hero while the creator is open: %s", p, heroSet ? "yes" : "FAILED");
    if (!g_wardenMorph) g_wardenMorph = new unsigned char[kMorphCap];
    g_wardenMorphLen = game::ProfileMorphGet(g_wardenMorph, kMorphCap);
    Log("Co-op creator: Warden's face in the profile: %d bytes%s", g_wardenMorphLen,
        IsMorphBlob(g_wardenMorph, g_wardenMorphLen) ? " (morph)" : "");
    g_stashLook = nullptr; g_morphRes[0] = 0; g_newMorphLen = -1;
    g_sessionCreature = obj;
    g_endSeen = false;
    g_session = true;
    bool ok = script::StartCharGen(obj, 0);
    Log("Co-op creator: StartCharGen(Player %d, creation) %s", p, ok ? "called" : "failed");
    SetStage(ST_CHARGEN, now);
}

void CoopCreateTick(unsigned now, uint32_t hero, int creatureType,
                    const bool startPressed[4], const bool canPrompt[4])
{
    game::Mode mode = game::CurrentMode();

    // A player waiting for their creator who presses START while someone else's
    // is open keeps their place: theirs opens next.
    if (g_stage != ST_IDLE)
        for (int p = 2; p <= 3; ++p)
            if (startPressed[p] && p != g_player && canPrompt[p] && CoopCreateCharacter(p) == game::kInvalidObject && !g_startQueued[p]) {
                g_startQueued[p] = true;
                Log("Co-op creator: Player %d pressed START - their creator opens next", p);
                wchar_t text[96];
                swprintf(text, 96, L"Player %d: your character creator opens next", p);
                script::DisplayStatusMessage(text, ColourOf(p));
            }

    switch (g_stage) {
    case ST_SAVING:
        if (SaveSafeBusy() && now - g_stageTime < 25000) return;
        Log("Co-op creator: save done, preloading the character creator for Player %d", g_player);
        script::PreloadCharGen();
        SetStage(ST_PRELOAD, now);
        return;

    case ST_PRELOAD:
        if (now - g_stageTime > 1500) CreateAndOpen(now);
        return;

    case ST_CHARGEN:
        if (g_endSeen) { SetStage(ST_FINISH, now); return; }
        // Keep the creator and its preview on Player 2's creature.
        if (mode == game::MODE_CHARGEN) {
            game::ChargenInfo ci;
            void* mine = game::ClientCreature(g_sessionCreature);
            if (game::ChargenInfoGet(&ci) && mine && (ci.target != g_sessionCreature || ci.shown != mine)) {
                static unsigned lastFix = 0;
                if (now - lastFix > 500) {
                    lastFix = now;
                    Log("Co-op creator: creator works on 0x%08X, preview shows %p (Player %d's character 0x%08X = %p) - pointing both at Player %d's",
                        ci.target, ci.shown, g_player, (uint32_t)g_sessionCreature, mine, g_player);
                    game::ChargenUse(g_sessionCreature);
                }
            }
        }
        // The preview's "test voice" plays the preview creature's own voice (1.3.3).
        if (mode == game::MODE_CHARGEN && game::ChargenVoiceSync(g_sessionCreature) > 0)
            Log("Co-op creator: preview took Player %d's voice", g_player);
        // The creator never opened (refused or failed): give up after 10 s.
        if (mode != game::MODE_CHARGEN && now - g_stageTime > 10000) {
            Log("Co-op creator: the character creator did not open (mode %s); Player %d keeps the default character",
                game::ModeName(mode), g_player);
            g_session = false;
            g_declined[g_player] = true;
            RestoreHero("after the creator failed to open");
            SetStage(ST_IDLE, now);
        }
        return;

    case ST_FINISH:
        // Normally the game returns to explore by itself; nudge it if not.
        if (mode == game::MODE_EXPLORE || mode == game::MODE_COMBAT) {
            g_session = false;
            RestoreHero("back in the game");
            {
                uint32_t c = g_char[g_player];
                int live = game::ModelLive(c), wlive = game::ModelLive(g_warden);
                Log("Co-op creator: model live flags: Player %d %d, Warden %d", g_player, live, wlive);
                // The preview showed the new look, but the character in the world
                // keeps its old model until something rebuilds it (a new game
                // reloads the area here). Rebuild it from its appearance now.
                int app = -1; wchar_t morph[128];
                game::LookInfo(c, &app, morph, 128);
                Log("Co-op creator: Player %d's look: appearance %d, head morph \"%ls\"", g_player, app, morph);
                bool ok = false;
                if (g_stashLook) {
                    // Build the creator's look onto the character. The face is
                    // read from the profile for the hero only, so for this one
                    // build: the new face in the profile and the character marked
                    // as the hero; then everything back.
                    bool face = g_newMorphLen > 0 && game::ProfileMorphSet(g_newMorph, g_newMorphLen);
                    ++g_buildDepth;                              // (our own face trick here)
                    ok = game::ApplyLook(c, g_stashLook, face);
                    --g_buildDepth;
                    if (face && g_wardenMorphLen >= 0) game::ProfileMorphSet(g_wardenMorph, g_wardenMorphLen);
                    wchar_t hm[64]; game::HeadMorph(c, hm, 64);
                    Log("Co-op creator: Player %d's character took the creator's look: %s (face %s, HeadMorph \"%ls\")",
                        g_player, ok ? "ok" : "FAILED", face ? "from the creator" : "none", hm);
                    g_stashLook = nullptr;                       // the character owns it now
                    if (g_morphRes[0]) {
                        bool set = game::SetHeadMorph(c, g_morphRes);
                        script::SetTag(c, g_morphRes);                // the tag names the face (saves keep tags)
                        wchar_t cname[64] = L"", hname[64] = L"", key[200];
                        if (g_faceIni[0] && script::GetName(c, cname, 64) && cname[0]) {
                            script::GetName(g_warden, hname, 64);
                            swprintf(key, 200, L"%ls|P%d|%ls", hname, g_player, cname);
                            WritePrivateProfileStringW(L"Faces", key, g_morphRes, g_faceIni);
                        }
                        game::HeadMorph(c, hm, 64);
                        Log("Co-op creator: Player %d's HeadMorph set to the saved face: %s (\"%ls\") - it loads from the override folder after the game restarts",
                            g_player, set ? "ok" : "FAILED", hm);
                    }
                }
                if (!ok) ok = game::RebuildModel(c);
                game::LookInfo(c, &app, morph, 128);
                Log("Co-op creator: rebuilt Player %d's model in the world: %s (live %d, appearance %d, morph \"%ls\")",
                    g_player, ok ? "ok" : "FAILED", game::ModelLive(c), app, morph);
            }
            {
                wchar_t v[64] = L"", w[64] = L"";
                game::SoundSet(g_char[g_player], v, 64); game::SoundSet(g_warden, w, 64);
                Log("Co-op creator: Player %d's voice \"%ls\", the Warden's \"%ls\"", g_player, v, w);
            }
            GiveStarterWeapons(g_player, g_char[g_player]);
            Log("Co-op creator: back in the game. Player %d now plays the new character (hero 0x%08X)", g_player, game::HeroId());
            wchar_t text[64];
            swprintf(text, 64, L"Player %d is ready!", g_player);
            script::DisplayStatusMessage(text, ColourOf(g_player));
            SetStage(ST_IDLE, now);
            for (int p = 2; p <= 3; ++p) g_nextPrompt[p] = now + 3000;   // let the message show first
        } else if (now - g_stageTime > 4000) {
            Log("Co-op creator: still in %s 4 s after the creator closed, switching to explore", game::ModeName(mode));
            script::SetGameMode(0);                       // GM_EXPLORE
            g_stageTime = now;
        }
        return;

    default:
        break;
    }

    if (hero == game::kInvalidObject) return;
    if (mode != game::MODE_EXPLORE) return;

    // Watchdog: a co-op character must never be the hero (older saves too).
    static unsigned nextHeroCheck = 0;
    if ((int)(now - nextHeroCheck) >= 0) {
        nextHeroCheck = now + 2000;
        uint32_t h = game::HeroId();
        for (int p = 2; p <= 3; ++p) {
            if (h == game::kInvalidObject || CoopCreateCharacter(p) != h) continue;
            if (g_warden == game::kInvalidObject || !script::IsObjectValid(g_warden) || g_warden == h) {
                // Don't know the Warden (a save from 1.2.5): the party member that isn't a co-op character.
                uint32_t party[12]; int n = game::PartyMembers(party, 12);
                g_warden = game::kInvalidObject;
                for (int i = 0; i < n; ++i) {
                    wchar_t tag[64] = L"";
                    script::GetTag(party[i], tag, 64);
                    if (wcsncmp(tag, L"daocoop_", 8) != 0) { g_warden = party[i]; break; }
                }
                Log("Co-op creator: the hero is Player %d's character; the Warden looks like 0x%08X (first party member that isn't a co-op character)", p, g_warden);
            }
            RestoreHero("(watchdog)");
        }
    }

    // Watch for area changes (once a second).
    if ((int)(now - g_nextAreaCheck) >= 0) {
        g_nextAreaCheck = now + 1000;
        uint32_t area = script::GetArea(hero);
        if (area != g_lastArea) {
            g_lastArea = area;
            wchar_t tag[96];
            script::GetTag(area, tag, 96);
            Log("Area: \"%ls\" (0x%08X)", tag, area);
            g_inOrigin = PrefixInList(tag, g_s.originAreas);
            g_inSolo = PrefixInList(tag, g_s.soloAreas);
            // Offered in the origin story, anywhere else (a player who joins later),
            // and optionally at the old Ostagar trigger - never in "Warden alone" areas.
            g_inTriggerArea = !g_inSolo && ((g_s.autoAtArea && TagInList(tag, g_s.areas)) ||
                                            (g_s.atStart && g_inOrigin) || g_s.anywhere);
            for (int p = 2; p <= 3; ++p) { g_prompt[p] = false; g_declined[p] = false; }
            if (g_inTriggerArea && (g_inOrigin || !g_s.anywhere))
                Log("Co-op creator: %s", g_inOrigin ? "origin story area" : "trigger area reached");
        }
    }

    // Origin stories: their scripts may drop extra followers from the party
    // (they were written for a party of one plus guests). Put the co-op
    // characters back while the party is in an origin area.
    if (g_s.keepInOrigin && g_inOrigin && !g_inSolo && (int)(now - g_nextPartyCheck) >= 0) {
        g_nextPartyCheck = now + 2000;
        static int tries[4] = {};
        static uint32_t triedArea = 0xFFFFFFFF;
        if (triedArea != g_lastArea) { triedArea = g_lastArea; tries[2] = tries[3] = 0; }
        for (int p = 2; p <= 3; ++p) {
            uint32_t c = CoopCreateCharacter(p);
            if (c == game::kInvalidObject || InParty(c)) { tries[p] = 0; continue; }
            if (tries[p] >= 3) continue;                      // it doesn't stick here: stop retrying (and logging)
            ++tries[p];
            bool ok = script::SetFollowerState(c, g_s.followerState);
            Log("Co-op creator: Player %d's character was dropped from the party by the story - put back: %s%s", p, ok ? "ok" : "failed",
                tries[p] == 3 ? " (giving up in this area)" : "");
        }
    }

    // A lobby game just started: each joined player opens their own creator
    // with START when they're ready (asked until they do). Nothing opens by
    // itself any more (players weren't ready when it popped up).
    if (false) {
        if (now - g_lastExploreTick > 500) g_exploreSince = now;     // explore again after a scene
        g_lastExploreTick = now;
        if (now - g_exploreSince > 4000 && !game::IsPaused()) {
            for (int p = 2; p <= 3; ++p) {
                if (!canPrompt[p] || g_declined[p] || CoopCreateCharacter(p) != game::kInvalidObject) continue;
                wchar_t text[96];
                swprintf(text, 96, L"Player %d: make your character!", p);
                script::DisplayStatusMessage(text, ColourOf(p));
                Log("Co-op creator: start of the story - opening the creator for Player %d", p);
                g_skipSave = true;
                CoopCreateBegin(p, hero, creatureType);
                return;
            }
            g_newGame = false;                      // everyone who joined has a character
            Log("Co-op creator: start-of-story creators done");
        }
    }

    // In a trigger area: ask every joined player who has no character yet.
    // (A player who joins later while still here is asked too.)
    for (int p = 2; p <= 3; ++p) {
        bool want = g_inTriggerArea && canPrompt[p] && !g_declined[p] &&
                    CoopCreateCharacter(p) == game::kInvalidObject;
        if (want != g_prompt[p]) {
            g_prompt[p] = want;
            if (want) {
                Log("Co-op creator: asking Player %d to press START", p);
                g_nextPrompt[p] = now + (p == 3 ? 3000 : 0);   // don't stack both messages
            }
        }
    }
    for (int p = 2; p <= 3; ++p) {
        if (!g_prompt[p]) { g_startQueued[p] = false; continue; }
        if ((startPressed[p] || g_startQueued[p]) && !game::IsPaused()) {
            g_startQueued[p] = false;
            CoopCreateBegin(p, hero, creatureType);
            return;
        }
        if ((int)(now - g_nextPrompt[p]) >= 0) {
            g_nextPrompt[p] = now + 6000;
            wchar_t text[96];
            swprintf(text, 96, L"Player %d: press START on your controller to create your character", p);
            script::DisplayStatusMessage(text, ColourOf(p));
        }
    }
}
