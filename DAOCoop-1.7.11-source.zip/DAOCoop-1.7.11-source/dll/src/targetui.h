#pragma once
// On-screen markers so Players 2/3 always see what they're aiming at, using
// the game's own floaty layer (floatylayer.gfx):
//   - enemy target:   our icon over the enemy (ShowFloatyIcon, command 749;
//                     the movie loads "<name>.dds", so our icons in override work)
//   - ally target:    a "+" icon over the friend helpful spells go to
//   - use preview:    "P2 (A) loot Chest" floating over the chest/door/body the
//                     use button would pick (DisplayFloatyMessage 744, any object)
//   - own character:  a "P2" tag over the player's own character
//
// A creature shows one icon at a time, so all requests go through one manager
// (TargetUiFlush): enemy marker > ally marker > own tag, Player 2 before Player 3.
#include <cstdint>

struct TargetUiSettings {
    bool enemyMarker;
    bool allyMarker;
    bool usePreview;
    bool selfTag;
    bool names;          // character names instead of "P2"/"P3" (patched floatylayer.gfx)
    bool prompt;         // 1.7.1: "(A) Open Chest" in the player's own HUD ([Markers] UsePrompt)
    bool drawn;          // 1.7.4: the markers are drawn by rings.cpp in every player's view: no floaty icons
};

void TargetUiInit(const TargetUiSettings& s);
// Call every tick for player 2/3. inCombat/playable from the game mode;
// enemy / ally = current targets (or invalid); dirX/dirY = facing preference.
void TargetUiTick(unsigned now, int player, uint32_t me, bool playable, bool inCombat,
                  uint32_t enemy, uint32_t ally, float dirX, float dirY);
void TargetUiClear(int player);     // drop this player's markers (control off, character lost)
void TargetUiFlush(unsigned now);   // once per tick after all players, while playable
void TargetUiReset();               // loading screen: objects are gone, forget everything silently
// Label for a player's markers: the character's name (names on) or "P2"/"P3".
void TargetUiName(int player, wchar_t* out, int cap);
// 1.7.1: what this player's A would use right now ("Open Chest"), for their own HUD; false: nothing
bool TargetUiPrompt(int player, wchar_t* out, int cap);
