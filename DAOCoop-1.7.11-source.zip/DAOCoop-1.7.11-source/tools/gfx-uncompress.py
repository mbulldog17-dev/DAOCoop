"""Saves Scaleform .gfx files uncompressed (CFX -> GFX), in place.
The game reads both; uncompressed files avoid virus scanners treating them as packed data.
    python gfx-uncompress.py <file.gfx> [...]
"""
import sys,zlib,struct
for p in sys.argv[1:]:
    d=open(p,'rb').read()
    if d[:3]==b'GFX': print(p,'already uncompressed'); continue
    assert d[:3]==b'CFX',p
    n=struct.unpack_from('<I',d,4)[0]
    body=zlib.decompress(d[8:])
    out=b'GFX'+d[3:8]+body
    assert len(out)==n,(len(out),n)
    open(p,'wb').write(out); print(p,len(d),'->',len(out))
