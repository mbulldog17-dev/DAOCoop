#!/bin/bash
# Rebuilds dll/assets/floatylayer.gfx (floating-icon layer with coloured P2/P3 off-screen arrows).
# Needs JPEXS ffdec and the original floatylayer.gfx from packages/core/data/guiexport.erf.
#   build.sh <original floatylayer.gfx> <ffdec.jar>
set -e
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/build/scripts/__Packages"
cp "$here/FloatyLayer.as" "$here/build/scripts/__Packages/FloatyLayer.as"
java -jar "$2" -importScript "$1" "$here/build/floatylayer.gfx" "$here/build/scripts"
cp "$here/build/floatylayer.gfx" "$here/../../dll/assets/floatylayer.gfx"
python3 "$here/../gfx-uncompress.py" "$here/../../dll/assets/floatylayer.gfx"   # 1.7.11: stored uncompressed
echo "dll/assets/floatylayer.gfx rebuilt"
