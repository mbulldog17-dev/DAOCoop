#!/bin/bash
# Rebuilds dll/assets/startmenu2.gfx (start menu with the Co-op button).
# Needs JPEXS ffdec and the original startmenu2.gfx from packages/core/data/guiexport.erf.
#   build.sh <original startmenu2.gfx> <ffdec.jar>
set -e
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/build/scripts/__Packages"
cp "$here/StartMenu.as" "$here/build/scripts/__Packages/StartMenu.as"
java -jar "$2" -importScript "$1" "$here/build/startmenu2.gfx" "$here/build/scripts"
cp "$here/build/startmenu2.gfx" "$here/../../dll/assets/startmenu2.gfx"
python3 "$here/../gfx-uncompress.py" "$here/../../dll/assets/startmenu2.gfx"   # 1.7.11: stored uncompressed
echo "dll/assets/startmenu2.gfx rebuilt"
