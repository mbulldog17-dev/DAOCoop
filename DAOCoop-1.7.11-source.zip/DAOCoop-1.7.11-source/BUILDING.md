# Building DAOCoop from source

DAOCoop is a co-op mod for Dragon Age: Origins (patch 1.05). Everything it ships is built from this
repository with free tools.

## What gets built

| Output | From | Notes |
|---|---|---|
| `dinput8.dll` | `dll/` (C++, 32-bit) | The mod. The game loads it from `bin_ship`; it passes DirectInput on to the real `dinput8.dll` (or to another mod's, renamed `dinput8_chain.dll`). |
| `DAOCoopStream.exe` | `helper/` + `dll/src/online/OnlineVideo9.cpp`, `NvencDirect.cpp` (C++, 64-bit) | The online stream's video encoder. The game starts it while hosting an online game. |
| `DAOCoop-<version>-Setup.exe` | `installer/DAOCoop.iss` (Inno Setup 6) | The installer. |
| `DAOCoop-<version>.zip` | `scripts/Make-Install-Package.ps1` | The same files laid out like the game folder, for a manual install. |

The menu art in `dll/assets` (`.gfx`, `.dds`) comes from the ActionScript sources in `tools/` (see the
`build.sh` next to each).

## Requirements (all free)

1. **Visual Studio 2022 or newer** (Community is fine) with the workload **Desktop development with C++**.
   CMake comes with it.
2. **Inno Setup 6**: https://jrsoftware.org/isdl.php (or `winget install JRSoftware.InnoSetup`).

## Build

1. Open a command prompt in the repository folder.
2. Run `build.bat -NoInstall`

It configures and builds the DLL (Win32), the stream encoder (x64), then makes both downloads in `dist\`:
`DAOCoop-<version>-Setup.exe` and `DAOCoop-<version>.zip`. The version comes from `kVersion` in
`dll/src/dllmain.cpp`.

Without `-NoInstall`, `build.bat` also installs the result into a Dragon Age: Origins folder on the PC
(for testing).

## Third-party code

- `dll/src/online/nvEncodeAPI.h`: NVIDIA Video Codec SDK 12.0 header, MIT licence (notice at its top).
- Online play was adapted from the open-source AmalurCoop project (MIT). See `installer/LICENSES.txt`.
- No game files are included.
