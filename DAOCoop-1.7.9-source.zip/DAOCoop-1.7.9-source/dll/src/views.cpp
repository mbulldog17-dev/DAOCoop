// 1.7.0: Player 2's and Player 3's own views, drawn by the game's own renderer (see views.h).
#include "views.h"
#include "menubanner.h"
#include "hooks.h"
#include "log.h"
#include "d3d9hook.h"
#include "pads.h"
#include <cstdio>
#include <cwchar>
#include "coopcontrol.h"
#include "equiplock.h"
#include "game.h"
#include "p2hud.h"
#include "rings.h"
#include "targetui.h"
#include "coopcreate.h"
#include "online/OnlinePlay.h"
#include "script.h"
#include <d3d9.h>
#include <windows.h>
#include <intrin.h>
#include <mmsystem.h>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cwctype>
#include <string>
#include <vector>

namespace
{
    constexpr uintptr_t kRenderScene = 0x52A090;
    constexpr uintptr_t kPerspectiveCameraVt = 0xB58604;

    using RenderScene_t = void(__fastcall*)(void* gfx, void* edx, void* scene, int a2, int a3, int a4);
    using SetTransform_t = void(__fastcall*)(void* cam, void* edx, const float* pos, const float* quat);

    RenderScene_t g_orig = nullptr;
    volatile long g_mode = 0;
    bool g_followCompanion = false;
    wchar_t g_ini[MAX_PATH] = L"";
    long g_liveSeen = -1;
    // [Views] ForceCharacterLevel0: -1 automatic (full character detail while a joiner has their own view), 1 always, 0 never.
    // The game's own option byte app+0x258: when set, 0x695E00 gives every character detail level 0, the most detailed
    // (tested in game: characters near Player 2 far from Player 1 were low detail without it, full detail with it).
    volatile int g_detailManual = -1;
    int g_detailKeep = -1;            // the game's own value, while ours is on
    volatile int g_joinerTest = 0;
    volatile int g_joinerSkip = 0;
    SRWLOCK g_lock = SRWLOCK_INIT;
    float g_lead[3] = {};
    // [Views] JoinerShadows / JoinerEffects (live): 0 = the joiners' passes without shadows / without the frame
    // buffer effects (bloom, blur ...), the switches the game itself uses for its small renders (0x528BC0):
    // shadows = bit 2 of 0xC1E7E4 (0x451800 / 0x451820), frame buffer effects = the byte 0xC1E8B5.
    bool g_joinShadows = true, g_joinEffects = true;
    bool g_alternate = false;         // [Views] AlternateJoiners: Player 2 and Player 3 drawn on alternate frames
    int g_farPct = 100;               // [Views] JoinerDrawDistance: the joiners' far plane, percent of Player 1's
    bool JoinShadows(); bool JoinEffects(); int JoinFarPct();   // 1.7.1: with JoinerAutoQuality (below)
    bool g_autoQuality = true;        // [Views] JoinerAutoQuality (live)
    int g_autoLevel = 0;              // 0 as set .. 6 lightest (see AutoQualityFrame)

    // stats (render thread of the scene = the game's main thread)
    LARGE_INTEGER g_freq = {};
    double g_extraMs = 0.0, g_mainMs = 0.0;
    int g_frames = 0;
    DWORD g_statSince = 0;
    int g_loggedSetup = 0;

    const char* ModeName(long m)
    {
        switch (m) {
        case 1: return "Player 2's and Player 3's frames drawn, shown in the corner (local test)";
        case 2: return "Player 2's and Player 3's frames drawn, not shown (cost test)";
        case 3: return "online: Player 2's and Player 3's frames drawn for their own streams, not on Player 1's screen";
        case 4: return "diagnostic: Player 2's camera left on the scene (not swapped back)";
        case 5: return "split screen: everyone's view on this screen (online friends still get their own view)";
        default: return "off";
        }
    }

    // Rotation part of a view matrix (row-major, column vectors: m[r*4+c]) -> quaternion (x, y, z, w),
    // the inverse of the game's 0x4D3940.
    void MatToQuat(const float* m, float q[4])
    {
        const float m00 = m[0], m01 = m[1], m02 = m[2];
        const float m10 = m[4], m11 = m[5], m12 = m[6];
        const float m20 = m[8], m21 = m[9], m22 = m[10];
        const float tr = m00 + m11 + m22;
        if (tr > 0.f) {
            float s = std::sqrt(tr + 1.f) * 2.f;              // 4w
            q[3] = 0.25f * s;
            q[0] = (m21 - m12) / s;
            q[1] = (m02 - m20) / s;
            q[2] = (m10 - m01) / s;
        } else if (m00 > m11 && m00 > m22) {
            float s = std::sqrt(1.f + m00 - m11 - m22) * 2.f; // 4x
            q[3] = (m21 - m12) / s;
            q[0] = 0.25f * s;
            q[1] = (m01 + m10) / s;
            q[2] = (m02 + m20) / s;
        } else if (m11 > m22) {
            float s = std::sqrt(1.f + m11 - m00 - m22) * 2.f; // 4y
            q[3] = (m02 - m20) / s;
            q[0] = (m01 + m10) / s;
            q[1] = 0.25f * s;
            q[2] = (m12 + m21) / s;
        } else {
            float s = std::sqrt(1.f + m22 - m00 - m11) * 2.f; // 4z
            q[3] = (m10 - m01) / s;
            q[0] = (m02 + m20) / s;
            q[1] = (m12 + m21) / s;
            q[2] = 0.25f * s;
        }
    }

    DWORD WINAPI ExitLater(LPVOID) { Sleep(8000); ExitProcess(0); return 0; }
    void PollIni();
    DWORD WINAPI IniThread(LPVOID) { for (;;) { PollIni(); Sleep(250); } }

    void SetMode(long m)
    {
        InterlockedExchange(&g_mode, m);
        Log("Views: %s", ModeName(m));
        g_frames = 0; g_extraMs = g_mainMs = 0.0; g_statSince = GetTickCount();
    }

    // [Views] LiveMode in the ini, read once a second: a new value (0-3) switches the mode (for testing remotely).
    void PollIni()
    {
        static DWORD next = 0;
        DWORD now = GetTickCount();
        if (!g_ini[0] || (int)(now - next) < 0) return;
        next = now + 1000;
        g_alternate = GetPrivateProfileIntW(L"Views", L"AlternateJoiners", 0, g_ini) != 0;   // (live, for testing)
        {   // [Views] JoinerTest (live, finding what speeds up animation): 1 no end frame, 2 no preparation, 3 neither
            const int t = (int)GetPrivateProfileIntW(L"Views", L"JoinerTest", 0, g_ini);
            if (t != g_joinerTest) { g_joinerTest = t; Log("Views: JoinerTest %d", t); }
            {   // [Views] ForceCharacterLevel0 (live): the game's own option byte app+0x258 - when set, 0x695E00 gives
                // every character detail level 0 (the game handles it: unlike forcing the level ourselves)
                const int f = (int)GetPrivateProfileIntW(L"Views", L"ForceCharacterLevel0", -1, g_ini);
                if (f != g_detailManual) { g_detailManual = f; Log("Views: character detail for the joiners: %s", f < 0 ? "automatic" : f ? "always full" : "the game's own"); }
            }
            const int k = (int)GetPrivateProfileIntW(L"Views", L"JoinerSkip", 0, g_ini);
            if (k != g_joinerSkip) { g_joinerSkip = k; Log("Views: JoinerSkip %d", k); }
        }
        g_joinShadows = GetPrivateProfileIntW(L"Views", L"JoinerShadows", 1, g_ini) != 0;
        g_joinEffects = GetPrivateProfileIntW(L"Views", L"JoinerEffects", 1, g_ini) != 0;
        g_autoQuality = GetPrivateProfileIntW(L"Views", L"JoinerAutoQuality", 1, g_ini) != 0;
        { int f = (int)GetPrivateProfileIntW(L"Views", L"JoinerDrawDistance", 100, g_ini); g_farPct = (f < 20 || f > 100) ? 100 : f; }
        {   // 1.7.0: online friends connected while in split screen: online mode (each friend gets their own view,
            // Player 1 sees only their own); back to split screen when they've left
            static bool autoOnline = false;
            const int friends = OnlinePlay::FriendsPlaying();
            if (friends > 0 && g_mode == 5) { autoOnline = true; Log("Views: online friends connected - online mode (each player sees their own view)"); SetMode(3); }
            else if (friends == 0 && autoOnline) { autoOnline = false; if (g_mode == 3) { Log("Views: no online friends now - split screen again"); SetMode(5); } }
        }
        long v = (long)GetPrivateProfileIntW(L"Views", L"LiveMode", -1, g_ini);
        if (v != g_liveSeen) {
            bool first = g_liveSeen == -1 && v == -1;
            g_liveSeen = v;
            if (!first && v >= 0 && v <= 5 && v != g_mode) SetMode(v);
            if (!first && v == 8) {                       // testing remotely: bring the game's window back (minimized fullscreen)
                HWND w = reinterpret_cast<HWND>(D3D9GameWindow());
                if (w) {
                    HWND fg = GetForegroundWindow();
                    DWORD ft = fg ? GetWindowThreadProcessId(fg, nullptr) : 0, wt = GetWindowThreadProcessId(w, nullptr);
                    if (ft && ft != wt) AttachThreadInput(wt, ft, TRUE);
                    ShowWindow(w, SW_RESTORE);
                    SetForegroundWindow(w);
                    BringWindowToTop(w);
                    if (ft && ft != wt) AttachThreadInput(wt, ft, FALSE);
                    Log("Views: LiveMode 8 - game window restored");
                }
            }
            if (!first && v == 9) {                       // testing remotely: close the game (it can't be reached minimized)
                Log("Views: LiveMode 9 - closing the game");
                HWND w = reinterpret_cast<HWND>(D3D9GameWindow());
                if (w) PostMessageW(w, WM_CLOSE, 0, 0);
                HANDLE t = CreateThread(nullptr, 0, &ExitLater, nullptr, 0, nullptr);
                if (t) CloseHandle(t);
            }
        }
    }

    void PollKey()
    {
        static bool down = false;
        SHORT st = GetAsyncKeyState(VK_SCROLL);             // Scroll Lock (F9 is the game's quickload)
        bool now = (st & 0x8000) != 0 || (st & 1) != 0;
        if (now && !down) {
            HWND fg = GetForegroundWindow();
            DWORD pid = 0;
            if (fg) GetWindowThreadProcessId(fg, &pid);
            if (pid == GetCurrentProcessId()) {
                { static const long next[6] = { 1, 2, 3, 5, 0, 0 }; SetMode(next[g_mode < 0 || g_mode > 5 ? 0 : g_mode]); }   // 0 1 2 3 5
            }
        }
        down = now;
    }

    double Ms(const LARGE_INTEGER& a, const LARGE_INTEGER& b)
    {
        return double(b.QuadPart - a.QuadPart) * 1000.0 / double(g_freq.QuadPart);
    }

    // The renderer camera of a scene, or null if it isn't what we expect.
    char* SceneRendererCamera(void* scene)
    {
        char* sc = *reinterpret_cast<char**>(static_cast<char*>(scene) + 0xC0);
        if (!sc) return nullptr;
        char* cam = *reinterpret_cast<char**>(sc + 4);
        if (!cam || *reinterpret_cast<uintptr_t*>(cam) != kPerspectiveCameraVt) return nullptr;
        return cam;
    }

    struct Pose { float pos[3]; float quat[4]; };

    Pose CurrentPose(const char* cam)
    {
        Pose p;
        const float* world = reinterpret_cast<const float*>(cam + 0xC0);
        p.pos[0] = world[3]; p.pos[1] = world[7]; p.pos[2] = world[11];
        MatToQuat(reinterpret_cast<const float*>(cam + 0x80), p.quat);
        return p;
    }

    void SetPose(char* cam, const Pose& p)
    {
        auto fn = *reinterpret_cast<SetTransform_t*>(*reinterpret_cast<char**>(cam) + 4);
        fn(cam, nullptr, p.pos, p.quat);
    }

    // ---- the joining players (1.7.0: Player 2 and Player 3) ----
    struct Joiner
    {
        int player = 2;                   // 2 or 3
        CoopPlayer pad = PLAYER_2;
        // from the main thread (g_lock)
        float pos[3] = {};
        bool have = false;
        uint32_t id = 0xFFFFFFFF;
        // their camera: a SceneCamera made the way the game makes its main one (0x40AE60), so the
        // renderer gets a separate object for each view
        void* cam = nullptr;
        bool camFailed = false, camLogged = false;
        // turning (right stick) and walls
        float yaw = 0.f;                  // this frame: their view's turn from Player 1's camera (radians)
        float heading = 0.f;              // their own compass heading (radians); only their right stick turns it
        bool headingSet = false;
        float lastP1Heading = 0.f;
        float pitch = 0.f;                // their camera's downward tilt (radians); their right stick up/down
        float follow[3] = {};             // their camera's follow point, smoothed (the game's position steps with its logic)
        bool followSet = false;
        LARGE_INTEGER followAt = {};
        float stepPos[3] = {}, stepVel[3] = {};   // 1.7.4: the last logic position, and the character's speed from the steps
        bool stepSet = false;
        LARGE_INTEGER stepAt = {};
        DWORD yawAt = 0;
        float frac = 1.f, fracWant = 1.f;
        DWORD nextRay = 0, fracAt = 0;
        int raysOk = -2;
        // the picture
        IDirect3DTexture9* tex = nullptr;
        IDirect3DSurface9* surf = nullptr;
        bool ready = false;
        int texW = 0, texH = 0;
        bool gameGui = false;             // this frame shows the game's GUI (a screen this player opened)
        bool drawn = false;               // drawn this frame (else: Player 1's picture is copied in)
        bool band = false;                // 2-player split screen: shown as the middle band of the bottom box
        DWORD hudNext = 0;
        double ms = 0.0;
        int frames = 0;
        void FreeTex()
        {
            if (surf) { surf->Release(); surf = nullptr; }
            if (tex) { tex->Release(); tex = nullptr; }
            ready = false;
        }
    };
    Joiner g_j[2];
    Joiner* volatile g_cur = nullptr;
    volatile float g_p1Far = 0.f;         // 1.7.4: how far Player 1's camera draws (metres; 0 = not known yet)     // the joiner whose frame is being drawn (render = main thread)

    using Alloc_t = void*(__cdecl*)(size_t);
    using StrCtor_t = void(__fastcall*)(void* str, void* edx, const wchar_t* text);
    using StrDtor_t = void(__fastcall*)(void* str, void* edx);
    using SceneCamCtor_t = void*(__fastcall*)(void* mem, void* edx, void* name, int a, int b);
    void* g_keptMainCam = nullptr;    // mode 4: the scene's own camera, put back when the mode changes
    void* g_keptScene = nullptr;
    float g_lift = 0.f;               // [Views] TestLiftMetres: raise the joiners' eyes (makes the test easy to see)

    void* MakeCamera()
    {
        void* mem = reinterpret_cast<Alloc_t>(0x413660)(0x40);
        if (!mem) return nullptr;
        alignas(16) unsigned char str[64] = {};
        reinterpret_cast<StrCtor_t>(0x4C2480)(str, nullptr, L"SceneCamera");
        void* cam = reinterpret_cast<SceneCamCtor_t>(0x537A00)(mem, nullptr, str, 1, 0);
        reinterpret_cast<StrDtor_t>(0x4C0DB0)(str, nullptr);
        return cam;
    }

    // The joiner's renderer camera, matched to the main one (projection, viewport), or null.
    char* JoinerRendererCamera(Joiner& j, const char* mainCam)
    {
        if (!j.cam && !j.camFailed) {
#ifdef _MSC_VER
            __try { j.cam = MakeCamera(); } __except (EXCEPTION_EXECUTE_HANDLER) { j.cam = nullptr; }
#else
            j.cam = MakeCamera();
#endif
            if (!j.cam) { j.camFailed = true; Log("Views: couldn't make Player %d's camera", j.player); return nullptr; }
        }
        if (!j.cam) return nullptr;
        char* cam = *reinterpret_cast<char**>(static_cast<char*>(j.cam) + 4);
        if (!cam || *reinterpret_cast<uintptr_t*>(cam) != kPerspectiveCameraVt) {
            if (!j.camFailed) Log("Views: Player %d's camera isn't the expected kind", j.player);
            j.camFailed = true; j.cam = nullptr;
            return nullptr;
        }
        // projection, matrices and flags (+0x10..+0x150); keep our own vtable (+0), viewport (+4) and culling camera (+8)
        memcpy(cam + 0x10, mainCam + 0x10, 0x150 - 0x10);
        char* vpMain = *reinterpret_cast<char* const*>(mainCam + 4);
        char*& vpOurs = *reinterpret_cast<char**>(cam + 4);
        if (vpMain) {
            if (vpOurs && *reinterpret_cast<uintptr_t*>(vpOurs) == *reinterpret_cast<uintptr_t*>(vpMain))
                memcpy(vpOurs + 4, vpMain + 4, 0x18);       // x, y, w, h, min z, max z
            else
                vpOurs = vpMain;
        }
        if (!j.camLogged) { j.camLogged = true; Log("Views: Player %d's own camera ready (%p)", j.player, j.cam); }
        return cam;
    }

    // Each joiner turns their own view with their right stick (around their character; Player 1's camera untouched).
    void UpdateYaw(Joiner& j)
    {
        DWORD now = GetTickCount();
        float dt = j.yawAt ? (now - j.yawAt) / 1000.f : 0.f;
        j.yawAt = now;
        if (dt > 0.2f) dt = 0.2f;
        PadSnapshot s = PadsGet(j.pad);
        if (!s.connected) return;
        const float y = s.gamepad.sThumbRY / 32767.f;
        if (y < -0.2f || y > 0.2f) {                     // tilt: stick up looks up, down looks down
            j.pitch -= y * 1.2f * dt;
            if (j.pitch < 0.05f) j.pitch = 0.05f;
            if (j.pitch > 1.25f) j.pitch = 1.25f;
        }
        float x = s.gamepad.sThumbRX / 32767.f;
        if (x > -0.2f && x < 0.2f) return;
        j.heading -= x * 2.2f * dt;                      // about 2 radians a second at full tilt
        if (j.heading > 3.14159265f) j.heading -= 6.2831853f;
        if (j.heading < -3.14159265f) j.heading += 6.2831853f;
    }
    void QuatMul(const float a[4], const float b[4], float o[4])
    {
        o[0] = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
        o[1] = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
        o[2] = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
        o[3] = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
    }

    // ---- a joiner's camera against walls and ceilings ----
    // The game's collision ray (script LineOfSight, the same one Player 1's camera uses) from the joiner's head
    // to the wanted eye; when something is in between, the eye comes in toward the head (a few rays, binary
    // search, 6 times a second). It comes in at once and goes back out slowly, so it doesn't pump.
    bool g_collide = true;
    void Collide(Joiner& j, uint32_t id, const float p2[3], float eye[3])
    {
        if (!g_collide || id == 0xFFFFFFFF) return;
        const script::Vec3 head = { p2[0], p2[1], p2[2] + 1.7f };
        DWORD now = GetTickCount();
        if ((int)(now - j.nextRay) >= 0) {
            j.nextRay = now + 160;
            const script::Vec3 up = { head.x, head.y, head.z + 0.3f };
            int sane = script::LineOfSight(id, head, up);
            if (sane != j.raysOk) { j.raysOk = sane; Log("Views: Player %d's camera wall check %s (%d)", j.player, sane == 1 ? "working" : "not usable here", sane); }
            if (sane == 1) {
                auto at = [&](float t) {
                    // a little past the eye, so the near plane doesn't clip into the wall
                    float k = t * 1.08f;
                    return script::Vec3{ head.x + (eye[0] - head.x) * k, head.y + (eye[1] - head.y) * k, head.z + (eye[2] - head.z) * k };
                };
                if (script::LineOfSight(id, head, at(1.f)) != 0) j.fracWant = 1.f;
                else {
                    float lo = 0.f, hi = 1.f;
                    for (int i = 0; i < 5; ++i) { float m = (lo + hi) * 0.5f; if (script::LineOfSight(id, head, at(m)) != 0) lo = m; else hi = m; }
                    j.fracWant = lo < 0.15f ? 0.15f : lo;
                }
            } else j.fracWant = 1.f;
        }
        float dt = j.fracAt ? (now - j.fracAt) / 1000.f : 0.f;
        j.fracAt = now;
        if (dt > 0.2f) dt = 0.2f;
        if (j.fracWant < j.frac) j.frac = j.fracWant;                     // in: at once
        else { j.frac += 1.5f * dt; if (j.frac > j.fracWant) j.frac = j.fracWant; }   // out: slowly
        for (int i = 0; i < 3; ++i) eye[i] = (&head.x)[i] + (eye[i] - (&head.x)[i]) * j.frac;
    }

    // ---- the joiners' own cameras (1.7.0) ----
    // Placed from their own character only: behind it along their own heading, at [Views] JoinerCamDistance
    // (decimetres) and their own tilt, looking at their head. Player 1's camera is read once, only for the
    // engine's axis conventions (which row of the view matrix looks forward / up / right, and their signs).
    float g_camDist = 5.0f, g_camPitch = 0.42f, g_camHead = 1.6f;
    bool g_convOk = false;
    float g_sF = 1.f, g_sU = 1.f, g_sR = 1.f;
    void QuatRows(const float q[4], float r[3][3])
    {
        const float x = q[0], y = q[1], z = q[2], w = q[3];
        r[0][0] = 1 - 2 * (y * y + z * z); r[0][1] = 2 * (x * y - w * z);     r[0][2] = 2 * (x * z + w * y);
        r[1][0] = 2 * (x * y + w * z);     r[1][1] = 1 - 2 * (x * x + z * z); r[1][2] = 2 * (y * z - w * x);
        r[2][0] = 2 * (x * z - w * y);     r[2][1] = 2 * (y * z + w * x);     r[2][2] = 1 - 2 * (x * x + y * y);
    }
    float Sign(float v) { return v < 0.f ? -1.f : 1.f; }
    void LearnConventions(const Pose& p1, const float lead[3])
    {
        if (g_convOk) return;
        float t[3] = { lead[0] - p1.pos[0], lead[1] - p1.pos[1], lead[2] + 1.0f - p1.pos[2] };
        const float tl = std::sqrt(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]);
        const float th = std::sqrt(t[0] * t[0] + t[1] * t[1]);
        if (tl < 0.5f || th < 0.3f) return;
        for (float& v : t) v /= tl;
        float r[3][3]; QuatRows(p1.quat, r);
        if (std::fabs(r[1][2]) < 0.1f) return;                       // (not sure which way is up yet)
        const float right[3] = { t[1] / th, -t[0] / th, 0.f };         // t x z, flattened
        g_sF = Sign(r[2][0] * t[0] + r[2][1] * t[1] + r[2][2] * t[2]);
        g_sU = Sign(r[1][2]);
        g_sR = Sign(r[0][0] * right[0] + r[0][1] * right[1]);
        g_convOk = true;
        Log("Views: the joiners' own cameras: view rows forward %+.0f, up %+.0f, right %+.0f (distance %.1f m, tilt %.0f degrees)",
            g_sF, g_sU, g_sR, g_camDist, g_camPitch * 57.2958f);
    }
    bool OwnCamera(Joiner& j, uint32_t id, const Pose& p1, const float lead[3], const float p2[3], Pose& out)
    {
        LearnConventions(p1, lead);
        if (!g_convOk) return false;
        const float cp = std::cos(j.pitch), sp = std::sin(j.pitch);
        const float f[3] = { cp * std::cos(j.heading), cp * std::sin(j.heading), -sp };     // looking along the heading, tilted down
        float rl = std::sqrt(f[0] * f[0] + f[1] * f[1]);
        const float rt[3] = { f[1] / rl, -f[0] / rl, 0.f };                                 // right = f x z
        const float up[3] = { rt[1] * f[2] - rt[2] * f[1], rt[2] * f[0] - rt[0] * f[2], rt[0] * f[1] - rt[1] * f[0] };
        float m[16] = {};
        for (int c = 0; c < 3; ++c) { m[c] = g_sR * rt[c]; m[4 + c] = g_sU * up[c]; m[8 + c] = g_sF * f[c]; }
        m[15] = 1.f;
        MatToQuat(m, out.quat);
        {   // follow the character smoothly. The logic position comes in steps (not always every frame); easing toward
            // each step made the camera's speed pulse, so the character juddered on screen while running. 1.7.4: the
            // position is carried on between steps at the character's speed, and the camera eases toward that.
            LARGE_INTEGER now; QueryPerformanceCounter(&now);
            const float dt = j.followSet ? (float)Ms(j.followAt, now) / 1000.f : 0.f;
            j.followAt = now;
            if (p2[0] != j.stepPos[0] || p2[1] != j.stepPos[1] || p2[2] != j.stepPos[2]) {   // a new logic step
                const float gap = j.stepSet ? (float)Ms(j.stepAt, now) / 1000.f : 0.f;
                if (j.stepSet && gap > 0.005f && gap < 0.3f) {
                    for (int c = 0; c < 3; ++c) {
                        const float v = (p2[c] - j.stepPos[c]) / gap;
                        j.stepVel[c] = j.stepVel[c] * 0.5f + v * 0.5f;          // (a little averaging: steps vary in length)
                    }
                } else for (float& v : j.stepVel) v = 0.f;
                for (int c = 0; c < 3; ++c) j.stepPos[c] = p2[c];
                j.stepAt = now; j.stepSet = true;
            }
            float since = j.stepSet ? (float)Ms(j.stepAt, now) / 1000.f : 0.f;
            if (since > 0.12f) { since = 0.12f; for (float& v : j.stepVel) v *= 0.9f; }   // stopped: no running on past it
            float want[3];
            for (int c = 0; c < 3; ++c) want[c] = p2[c] + j.stepVel[c] * since;
            const float ddx = want[0] - j.follow[0], ddy = want[1] - j.follow[1], ddz = want[2] - j.follow[2];
            if (!j.followSet || ddx * ddx + ddy * ddy + ddz * ddz > 9.f || dt <= 0.f || dt > 0.5f) {
                for (int c = 0; c < 3; ++c) j.follow[c] = want[c];
                j.followSet = true;
            } else {
                const float a = 1.f - std::exp(-dt * 22.f);
                j.follow[0] += ddx * a; j.follow[1] += ddy * a; j.follow[2] += ddz * a;
            }
        }
        const float target[3] = { j.follow[0], j.follow[1], j.follow[2] + g_camHead };
        for (int c = 0; c < 3; ++c) out.pos[c] = target[c] - f[c] * g_camDist;
        out.pos[2] += g_lift;
        Collide(j, id, j.follow, out.pos);
        j.yaw = j.heading - j.lastP1Heading;            // (for the old relative interface)
        return true;
    }

    bool JoinerPose(Joiner& j, const Pose& p1, Pose& out)
    {
        float lead[3], p2[3]; bool have; uint32_t id;
        AcquireSRWLockShared(&g_lock);
        memcpy(lead, g_lead, sizeof lead); memcpy(p2, j.pos, sizeof p2); have = j.have; id = j.id;
        ReleaseSRWLockShared(&g_lock);
        if (!have) return false;
        UpdateYaw(j);
        // Player 1's camera offset from Player 1's character, turned by the joiner's yaw, around the joiner's character.
        const float dx = p1.pos[0] - lead[0], dy = p1.pos[1] - lead[1], dz = p1.pos[2] - lead[2];
        // Their view keeps its own compass heading: Player 1 turning their camera doesn't turn it. Player 1's
        // heading = from their camera toward their character (kept while the camera looks straight down).
        {   // Player 1's facing from their camera's rotation (the view matrix's third row, flattened), not its
            // position: their camera's position and rotation are smoothed separately, and following the position
            // made the joiners' views tug and jitter whenever Player 1's camera moved.
            const float* q = p1.quat;
            float fx = 2.f * (q[0] * q[2] - q[3] * q[1]), fy = 2.f * (q[1] * q[2] + q[3] * q[0]);
            if (fx * -dx + fy * -dy < 0.f) { fx = -fx; fy = -fy; }      // (the side that looks toward Player 1's character)
            if (fx * fx + fy * fy > 0.0025f) j.lastP1Heading = std::atan2(fy, fx);
            else if (dx * dx + dy * dy > 0.09f) j.lastP1Heading = std::atan2(-dy, -dx);   // (looking straight down)
        }
        if (!j.headingSet) { j.heading = j.lastP1Heading; j.pitch = g_camPitch; j.headingSet = true; }   // (starts facing where Player 1 faces)
        if (OwnCamera(j, id, p1, lead, p2, out)) return true;
        float rel = j.heading - j.lastP1Heading;
        while (rel > 3.14159265f) rel -= 6.2831853f;
        while (rel < -3.14159265f) rel += 6.2831853f;
        j.yaw = rel;
        const float cs = std::cos(j.yaw), sn = std::sin(j.yaw);
        out.pos[0] = p2[0] + cs * dx - sn * dy;
        out.pos[1] = p2[1] + sn * dx + cs * dy;
        out.pos[2] = p2[2] + dz + g_lift;
        // view rotation R' = R * Rz(-yaw)
        const float qz[4] = { 0.f, 0.f, std::sin(-j.yaw * 0.5f), std::cos(-j.yaw * 0.5f) };
        QuatMul(p1.quat, qz, out.quat);
        Collide(j, id, p2, out.pos);
        return true;
    }

    void Draw(void* gfx, void* scene, int a2, int a3, int a4)
    {
#ifdef _MSC_VER
        __try { g_orig(gfx, nullptr, scene, a2, a3, a4); }
        __except (EXCEPTION_EXECUTE_HANDLER) { Log("Views: the game's scene drawing failed - test turned off"); InterlockedExchange(&g_mode, 0); }
#else
        g_orig(gfx, nullptr, scene, a2, a3, a4);
#endif
    }

    // ---- the main scene's preparation (0x52A090): records its arguments; mode 4 leaves Player 2's camera on ----
    int g_lastA3 = 0;
    void* g_scene = nullptr;
    bool g_ownCall = false;           // our own scene preparations (not counted as the game's)
    // The renderer's frame number (16 bits at 0xBF8510, never 0), counted up by every scene preparation (0x559D40).
    // Animation is moved on once per new frame number - so each extra view made it move on again (2x / 3x fast).
    // Our own preparations run with the number set one back, so they end on the game's own: the same frame.
    volatile uint16_t& FrameNumber() { return *reinterpret_cast<volatile uint16_t*>(0xBF8510); }
    uint16_t g_lastFrameNumber = 0;
    int g_frameNumberSteps = 0;
    // [Views] JoinerTest 4 (finding what speeds up animation): the scene preparation (0x52A090) done here step by
    // step, and the visibility step (0x5396B0) too, so single steps can be left out ([Views] JoinerSkip, bit mask):
    //   1 0x5039B0   2 0x455D50   4 scene+D8 vt+4   8 scene+DC vt+4   16 scene+E0 vt+4   32 0x467380 (Umbra)
    //   64 0x537D40   128 0x538FA0   256 0x538750   512 0x537EA0   1024 0x537EE0   2048 0x538E50
    //   4096 0x537E80   8192 0x537EC0
    using Thiscall0 = void(__fastcall*)(void* self, void* edx);
    using Thiscall1 = void(__fastcall*)(void* self, void* edx, uintptr_t a);
    using Plain0 = void(*)();
    void VCall4(char* obj) { if (obj) reinterpret_cast<Thiscall0>((*reinterpret_cast<void***>(obj))[1])(obj, nullptr); }
    void PrepareSteps(void* gfx, void* scene, int skip)
    {
        char* g = static_cast<char*>(gfx);
        char* sc = static_cast<char*>(scene);
        void* oldScene = *reinterpret_cast<void**>(g + 0x58);
        *reinterpret_cast<void**>(g + 0x58) = scene;
        char* cam = *reinterpret_cast<char**>(sc + 0xC0);              // 0x86E0F0: the scene's camera
        const uintptr_t camArg = cam ? *reinterpret_cast<uintptr_t*>(cam + 4) : 0;
        if (!(skip & 1)) reinterpret_cast<Plain0>(0x5039B0)();
        // (0x559D40, the frame number: left out - the same frame)
        // 0x5396B0, the visibility step:
        if (!(skip & 2)) reinterpret_cast<Thiscall0>(0x455D50)(sc, nullptr);
        if (!(skip & 4)) VCall4(*reinterpret_cast<char**>(sc + 0xD8));
        if (!(skip & 8)) VCall4(*reinterpret_cast<char**>(sc + 0xDC));
        if (!(skip & 16)) VCall4(*reinterpret_cast<char**>(sc + 0xE0));
        if (!(skip & 32)) { char* u = *reinterpret_cast<char**>(sc + 0xD4); if (u) reinterpret_cast<Thiscall0>(0x467380)(u, nullptr); }
        if (!(skip & 64)) reinterpret_cast<Thiscall0>(0x537D40)(sc, nullptr);
        if (!(skip & 128)) reinterpret_cast<Thiscall0>(0x538FA0)(sc, nullptr);
        if (!(skip & 256)) reinterpret_cast<Thiscall0>(0x538750)(sc, nullptr);
        // the rest of 0x52A090 (a2 = a3 = a4 = 0)
        if (!(skip & 512)) reinterpret_cast<Thiscall1>(0x537EA0)(sc, nullptr, camArg);
        if (!(skip & 1024)) reinterpret_cast<Thiscall0>(0x537EE0)(sc, nullptr);
        if (!(skip & 2048)) reinterpret_cast<Thiscall0>(0x538E50)(sc, nullptr);
        if (!(skip & 4096)) reinterpret_cast<Thiscall1>(0x537E80)(sc, nullptr, camArg);
        if (!(skip & 8192)) reinterpret_cast<Thiscall0>(0x537EC0)(sc, nullptr);
        *reinterpret_cast<void**>(g + 0x58) = oldScene;
    }
    // The joiners' preparation (found by testing in game): the scene preparation without the scene+0xD8
    // manager's two steps (0x537EA0 with the camera, 0x537EE0) - they move character animation on each time,
    // so with them every extra view sped animation up (2x with Player 2, 3x with Player 3). Without them,
    // animation runs at its speed in every view, and the joiners' pictures are drawn as before.
    // ([Views] JoinerTest 4 + JoinerSkip: other steps left out instead, for testing.)
    //
    // Better (found next): the animation manager is one object (Animation::AnimationManager, vtable 0xB26584, the
    // function-static at 0xC395E0 that 0x8107F0 returns). Every AnimationTask (0x8154D0) moves its animation on
    // by its time step (vtable +0x10, 0x810340: the double at +0x80, or +0x88 for real time) times its speed.
    // So the joiners' preparations run complete - everything they see is animated and posed - with both time
    // steps 0: animation moves on only in the game's own preparation, once a frame, however many views there are.
    // (Leaving the update out instead froze whatever only a joiner could see.)
    constexpr uintptr_t kAnimManager = 0xC395E0, kAnimManagerVt = 0xB26584;
    constexpr int kJoinerSkip = 512 | 1024;
    double g_stepKeep[2] = {};
    bool g_stepZeroed = false;
    // 1.7.1: but whoever Player 1's view leaves out (Player 2 walked away) was then never moved on at all - the game's
    // preparation only animates what its camera sees - and those NPCs stuttered in both pictures, and kept doing so.
    // Now each AnimationTask (vtable 0xB26784, Run at +8 = 0x8154D0) is watched: the first run of a character's
    // animation in a frame moves it on by the real time step (in whichever view that is); any further run in the same
    // frame (another view) gets 0. Its time step is the manager's vtable +0x10 (0x810340), answered per thread.
    volatile bool g_stillPass = false;           // a joiner's preparation (time steps 0) is running
    volatile LONG g_animFrame = 0;               // the game's frames (its own scene preparation)
    bool g_animDedup = false;                    // the hooks are in
    struct AnimSeen { void* volatile obj; volatile LONG frame; };
    AnimSeen g_animSeen[2048];                   // open addressing by the animated object's address
    LONG g_animMoved = 0, g_animHeld = 0;        // (for the log) joiner-pass runs moved on / held still
    __declspec(thread) int t_animAdvance = 0;    // this thread's task should get the real time step
    bool AnimFirstThisFrame(void* obj)           // true once per animated object per frame (and notes it)
    {
        // (no lock: the game's animation tasks run on several threads at once, and a lock on each of thousands
        // of tasks a second cost frames; a rare clash only lets one animation move on a second time)
        const LONG f = g_animFrame;
        const size_t h = (reinterpret_cast<uintptr_t>(obj) >> 4) * 2654435761u;
        for (int k = 0; k < 32; ++k) {
            AnimSeen& e = g_animSeen[(h + k) & 2047];
            void* cur = e.obj;
            if (cur == obj) { const LONG old = InterlockedExchange(&e.frame, f); return old != f; }
            if (!cur || f - e.frame > 120) {
                if (InterlockedCompareExchangePointer(&e.obj, obj, cur) == cur) { InterlockedExchange(&e.frame, f); return true; }
                if (e.obj == obj) { const LONG old = InterlockedExchange(&e.frame, f); return old != f; }
            }
        }
        return true;
    }
    using AnimRun_t = int(__fastcall*)(void* task, void* edx, void* arg);   // (thiscall, 1 argument: ret 4)
    AnimRun_t g_origAnimRun = nullptr;
    using AnimStep_t = double(__fastcall*)(void* mgr, void* edx, char real);
    AnimStep_t g_origAnimStep = nullptr;
    int __fastcall HookAnimRun(void* task, void* edx, void* arg)
    {
        void* obj = nullptr;
#ifdef _MSC_VER
        __try { obj = *reinterpret_cast<void**>(static_cast<char*>(task) + 0x18); } __except (EXCEPTION_EXECUTE_HANDLER) { obj = nullptr; }
#endif
        const bool first = obj ? AnimFirstThisFrame(obj) : true;
        if (!g_stillPass) return g_origAnimRun(task, edx, arg);      // the game's own view: as always (noted above)
        if (first) InterlockedIncrement(&g_animMoved); else InterlockedIncrement(&g_animHeld);
        t_animAdvance = first ? 1 : 0;
        const int r = g_origAnimRun(task, edx, arg);
        t_animAdvance = 0;
        return r;
    }
    double __fastcall HookAnimStep(void* mgr, void* edx, char real)
    {
        if (g_stillPass && t_animAdvance) return g_stepKeep[real ? 1 : 0];   // first run this frame: the real step
        return g_origAnimStep(mgr, edx, real);
    }
    void RestoreSteps()
    {
        if (!g_stepZeroed) return;
        double* step = reinterpret_cast<double*>(kAnimManager + 0x80);
        step[0] = g_stepKeep[0]; step[1] = g_stepKeep[1];
        g_stepZeroed = false;
    }
    void PrepareStill(void* gfx, void* scene)
    {
        static int logged = 0;
        double* step = reinterpret_cast<double*>(kAnimManager + 0x80);
        if (*reinterpret_cast<uintptr_t*>(kAnimManager) != kAnimManagerVt) {     // (not made yet / not this game)
            if (!logged) { logged = 1; Log("Views: the animation manager isn't where expected - the joiners' views skip its update"); }
            PrepareSteps(gfx, scene, kJoinerSkip);
            return;
        }
        if (logged != 2) { logged = 2; Log("Views: the joiners' views are animated with time steps 0 (animation moves on once a frame)"); }
        g_stepKeep[0] = step[0]; g_stepKeep[1] = step[1]; g_stepZeroed = true;
        step[0] = 0.0; step[1] = 0.0;
        g_stillPass = g_animDedup;
        PrepareSteps(gfx, scene, 0);
        g_stillPass = false;
        RestoreSteps();
    }
    void PrepareOwn(void* gfx, void* scene)
    {
        if (g_joinerTest & 4) { PrepareSteps(gfx, scene, g_joinerSkip); return; }
#ifdef _MSC_VER
        __try { PrepareStill(gfx, scene); return; }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            g_stillPass = false;
            RestoreSteps();
            Log("Views: the joiners' own scene preparation failed - the game's used instead");
        }
#endif
        const uint16_t keep = FrameNumber();
        FrameNumber() = keep > 1 ? (uint16_t)(keep - 1) : (uint16_t)0xFFFF;
        g_orig(gfx, nullptr, scene, 0, 0, 0);
        FrameNumber() = keep;
    }
    // Our own preparations pass a3 = 0: with it set, 0x52A090 also calls 0x5387F0, which moves the scene's
    // animation on by a frame's time - once per extra view, so the game ran 2x / 3x fast with joiners in.
    int g_gamePrepCalls = 0;          // the game's preparations of the main scene since the last frame

    void __fastcall HookRenderScene(void* gfx, void*, void* scene, int a2, int a3, int a4)
    {
        PollKey();
        const long mode = g_mode;
        void* mainScene = *reinterpret_cast<void**>(static_cast<char*>(gfx) + 0x58);
        if (g_keptScene && mode != 4) {                                  // leaving mode 4: the game's camera back
            *reinterpret_cast<void**>(static_cast<char*>(g_keptScene) + 0xC0) = g_keptMainCam;
            g_keptScene = g_keptMainCam = nullptr;
        }
        if (scene == mainScene) { g_scene = scene; g_lastA3 = a3; if (!g_ownCall) ++g_gamePrepCalls; }
        if (mode != 4 || scene != mainScene) { g_orig(gfx, nullptr, scene, a2, a3, a4); return; }
        if (g_keptScene == scene) *reinterpret_cast<void**>(static_cast<char*>(scene) + 0xC0) = g_keptMainCam;
        Joiner& j = g_j[0];
        char* cam = SceneRendererCamera(scene);
        Pose p2;
        char* cam2 = cam ? JoinerRendererCamera(j, cam) : nullptr;
        if (!cam2 || !JoinerPose(j, CurrentPose(cam), p2)) { g_orig(gfx, nullptr, scene, a2, a3, a4); return; }
        SetPose(cam2, p2);
        if (!g_keptScene) { g_keptScene = scene; g_keptMainCam = *reinterpret_cast<void**>(static_cast<char*>(scene) + 0xC0); }
        *reinterpret_cast<void**>(static_cast<char*>(scene) + 0xC0) = j.cam;
        Draw(gfx, scene, a2, a3, a4);
    }

    // ---- the joiners' frames (single-threaded renderer) ----
    // The game's frame: 0x52A470 prepares every scene, then 0x52A600 ("end frame", IGraphicsInternal vtable +0x54)
    // runs the frame buffer program that really draws them with the scene's camera, and presents.
    // Here, before the game's end frame, for each joiner: their camera on the scene, prepare + end frame with its
    // Present swallowed (the picture copied to their texture instead); then Player 1's camera back, prepare again,
    // and the game's own end frame. Needs the single-threaded renderer: then all drawing happens inside these calls.
    using EndFrame_t = void(__fastcall*)(void* gfx, void* edx, int flag);
    EndFrame_t g_origEnd = nullptr;
    bool g_singleThread = false;
    int g_pipPercent = 33;
    bool Drawing(long m) { return m == 1 || m == 2 || m == 3 || m == 5; }
    // split screen (mode 5): Player 1's finished frame, before the layout is put together on the back buffer
    IDirect3DTexture9* g_p1Tex = nullptr;
    IDirect3DSurface9* g_p1Surf = nullptr;
    int g_p1W = 0, g_p1H = 0;
    // 3-player split screen: Player 1's box is the whole width and half the height (32:9). Their frame is drawn
    // with the camera's aspect doubled (a wider view, squeezed into the 16:9 frame) and shown at half height,
    // which un-squeezes it; their GUI is drawn into the middle half of the width at full height, so after the
    // half-height copy it is the same size as Player 2's and Player 3's (half), not squashed.
    volatile bool g_wideP1 = false;       // this frame's Player 1 pass is the wide one
    volatile bool g_frameWide = false;    // the frame about to be shown was drawn wide
    volatile bool g_fitGui = false;       // Player 1's GUI movies are drawing right now
    int g_bbW = 0, g_bbH = 0;
    // [Views] SplitTopWide = 0 (default): Player 1's top box is the middle band of their normal view (cheaper:
    // the game draws no more than usual); their GUI is drawn at half size into that band. 1: the wider view above
    // (the camera's aspect doubled - about 4 ms more a frame, the game draws far more of the world).
    bool g_topWide = false;
    bool FitGui(long r[4])
    {
        if (!g_fitGui || g_bbW <= 0) return false;
        if (r[0] < 0 || r[1] < 0 || r[2] > g_bbW || r[3] > g_bbH) return false;
        r[0] = g_bbW / 4 + r[0] / 2;
        r[2] = g_bbW / 4 + r[2] / 2;
        if (!g_topWide || g_cur) { r[1] = g_bbH / 4 + r[1] / 2; r[3] = g_bbH / 4 + r[3] / 2; }   // (a joiner's band: always the middle band)
        return true;
    }
    // ---- Player 1's mouse in the 3-player split screen (1.7.0) ----
    // Player 1's GUI is drawn at half size in the top box, so the mouse position the game reads (GetCursorPos)
    // is turned into GUI coordinates: x' = 2x - W/2, y' = 2y (the same for both top-box styles). Clicks in the
    // world go through the camera's screen-to-ray function (PerspectiveCamera vtable slot 17, 0xA262D0), which
    // gets that GUI position back as the spot of Player 1's frame shown under the pointer.
    volatile bool g_mouseFit = false;     // this frame was shown as the split screen (Player 1's box at half size)
    volatile bool g_rayFix = false;       // 3-box: world clicks need the GUI position turned back into the band's
    volatile LONG g_lastGx = -100000, g_lastGy = -100000;   // the GUI position given to the game last (back buffer pixels)
    using GetCursorPos_t = BOOL(WINAPI*)(POINT*);
    using SetCursorPos_t = BOOL(WINAPI*)(int, int);
    GetCursorPos_t g_realGetCursorPos = nullptr;
    SetCursorPos_t g_realSetCursorPos = nullptr;
    bool ClientInfo(HWND& w, RECT& rc)
    {
        w = reinterpret_cast<HWND>(D3D9GameWindow());
        return w && GetClientRect(w, &rc) && rc.right > 0 && rc.bottom > 0 && g_bbW > 0 && g_bbH > 0;
    }
    BOOL WINAPI HookGetCursorPos(POINT* p)
    {
        const BOOL ok = g_realGetCursorPos(p);
        HWND w; RECT rc;
        if (!ok || !p || !g_mouseFit || !ClientInfo(w, rc)) return ok;
        POINT c = *p;
        ScreenToClient(w, &c);
        const double bx = c.x * double(g_bbW) / rc.right, by = c.y * double(g_bbH) / rc.bottom;   // back buffer pixels
        const double gx = 2.0 * bx - g_bbW / 2.0, gy = 2.0 * by;
        g_lastGx = (LONG)(gx + 0.5); g_lastGy = (LONG)(gy + 0.5);
        c.x = (LONG)(gx * rc.right / g_bbW + 0.5); c.y = (LONG)(gy * rc.bottom / g_bbH + 0.5);
        ClientToScreen(w, &c);
        *p = c;
        return ok;
    }
    BOOL WINAPI HookSetCursorPos(int x, int y)          // the game putting the pointer somewhere: its GUI position back to the screen's
    {
        HWND w; RECT rc;
        if (!g_mouseFit || !ClientInfo(w, rc)) return g_realSetCursorPos(x, y);
        POINT c = { x, y };
        ScreenToClient(w, &c);
        const double gx = c.x * double(g_bbW) / rc.right, gy = c.y * double(g_bbH) / rc.bottom;
        const double bx = (gx + g_bbW / 2.0) / 2.0, by = gy / 2.0;
        c.x = (LONG)(bx * rc.right / g_bbW + 0.5); c.y = (LONG)(by * rc.bottom / g_bbH + 0.5);
        ClientToScreen(w, &c);
        return g_realSetCursorPos(c.x, c.y);
    }
    // The same for the mouse messages the game's window gets (menus take the pointer from WM_MOUSEMOVE & co.)
    WNDPROC g_origWndProc = nullptr;
    HWND g_subclassed = nullptr;
    LRESULT CALLBACK MouseWndProc(HWND w, UINT msg, WPARAM wp, LPARAM lp)
    {
        RECT rc;
        if (g_mouseFit && msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST && msg != WM_MOUSEWHEEL && msg != WM_MOUSEHWHEEL &&
            g_bbW > 0 && GetClientRect(w, &rc) && rc.right > 0 && rc.bottom > 0) {
            const int cx = (short)LOWORD(lp), cy = (short)HIWORD(lp);
            const double bx = cx * double(g_bbW) / rc.right, by = cy * double(g_bbH) / rc.bottom;
            const double gx = 2.0 * bx - g_bbW / 2.0, gy = 2.0 * by;
            const int nx = (int)(gx * rc.right / g_bbW + 0.5), ny = (int)(gy * rc.bottom / g_bbH + 0.5);
            lp = MAKELPARAM((WORD)(short)nx, (WORD)(short)ny);
        }
        return CallWindowProcW(g_origWndProc, w, msg, wp, lp);
    }
    void SubclassGameWindow()
    {
        HWND w = reinterpret_cast<HWND>(D3D9GameWindow());
        if (!w || w == g_subclassed) return;
        WNDPROC old = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(w, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(&MouseWndProc)));
        if (old) { g_origWndProc = old; g_subclassed = w; Log("Views: the game window's mouse messages follow the split screen too"); }
    }
    using ScreenRay_t = void(__fastcall*)(void* cam, void* edx, int x, int y, float* nearPt, float* farPt);
    ScreenRay_t g_origScreenRay = nullptr;
    void __fastcall HookScreenRay(void* cam, void* edx, int x, int y, float* nearPt, float* farPt)
    {
        if (g_mouseFit && g_rayFix && std::abs(x - g_lastGx) <= 2 && std::abs(y - g_lastGy) <= 2) {
            const int bx = (x + g_bbW / 2) / 2, by = y / 2;     // the pointer's spot in the top box
            x = bx; y = by + g_bbH / 4;                         // = that spot of Player 1's frame (the middle band)
        }
        g_origScreenRay(cam, edx, x, y, nearPt, farPt);
    }
    void** FindImportSlot(const char* dll, const char* func)
    {
        BYTE* base = reinterpret_cast<BYTE*>(GetModuleHandleW(nullptr));
        auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + reinterpret_cast<IMAGE_DOS_HEADER*>(base)->e_lfanew);
        const IMAGE_DATA_DIRECTORY& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
        if (!dir.VirtualAddress) return nullptr;
        for (auto* imp = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + dir.VirtualAddress); imp->Name; ++imp) {
            if (_stricmp(reinterpret_cast<char*>(base + imp->Name), dll) != 0) continue;
            auto* names = reinterpret_cast<IMAGE_THUNK_DATA*>(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
            auto* slots = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imp->FirstThunk);
            for (; names->u1.AddressOfData; ++names, ++slots) {
                if (IMAGE_SNAP_BY_ORDINAL(names->u1.Ordinal)) continue;
                auto* byName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + names->u1.AddressOfData);
                if (strcmp(reinterpret_cast<char*>(byName->Name), func) == 0) return reinterpret_cast<void**>(&slots->u1.Function);
            }
        }
        return nullptr;
    }
    bool SwapSlot(void** slot, void* fn, void** orig)
    {
        DWORD old;
        if (!slot || !VirtualProtect(slot, 4, PAGE_READWRITE, &old)) return false;
        *orig = *slot; *slot = fn;
        VirtualProtect(slot, 4, old, &old);
        return true;
    }

    // ---- level of detail, measuring (1.7.0): the LodManager (vtable 0xB03C04) loads / lets go of models' detail
    // levels: slot 1 (0x618BF0, level 0-2 + model id) asks for one, slot 2 (0x6186E0) lets one go. Counted here by
    // who asks: the game's own pass (Player 1) or a joiner's, and logged with the performance lines.
    using LodCall_t = uintptr_t(__fastcall*)(void* self, void* edx, int level, int id);
    LodCall_t g_origLodGet = nullptr, g_origLodPut = nullptr;
    volatile bool g_inJoinerPass = false;
    long g_lodGet[2][4] = {}, g_lodPut[2][4] = {};
    void* g_lodCallers[12] = {};
    void NoteLodCaller(void* ret, int level, bool put)
    {
        for (void*& c : g_lodCallers) {
            if (c == ret) return;
            if (!c) { c = ret; Log("Detail: %s level %d from the game's code at %p", put ? "let go of" : "asked for", level, ret); return; }
        }
    }
    uintptr_t __fastcall HookLodGet(void* self, void* edx, int level, int id)
    {
        NoteLodCaller(_ReturnAddress(), level, false);
        ++g_lodGet[g_inJoinerPass ? 1 : 0][level < 0 || level > 2 ? 3 : level];
        return g_origLodGet(self, edx, level, id);
    }
    uintptr_t __fastcall HookLodPut(void* self, void* edx, int level, int id)
    {
        NoteLodCaller(_ReturnAddress(), level, true);
        ++g_lodPut[g_inJoinerPass ? 1 : 0][level < 0 || level > 2 ? 3 : level];
        return g_origLodPut(self, edx, level, id);
    }

    // ---- character detail for the joiners (1.7.0) ----
    // The game picks a character model's detail level where Player 1 is (the LodManager only ever got requests from
    // outside the joiners' passes), so characters near Player 2 / 3 but far from Player 1 stayed at low detail.
    // The level is set through the character models' vtable slot 17 (AnimBase / AnimBaseHead / AnimBaseParts /
    // AnimBaseWield / AnimBaseVFX: 0xA5D5D0 / 0xA669C0, thiscall(level, x), ret 8). While a joiner has their own
    // view ([Views] JoinerFullDetail = 1), every character is asked for at level 0, the most detailed.
    bool g_fullDetail = false;
    using SetLod_t = uintptr_t(__fastcall*)(void* self, void* edx, int level, uintptr_t x);
    SetLod_t g_origSetLodA = nullptr, g_origSetLodB = nullptr;
    void* g_lodSetCallers[6] = {};
    bool JoinersInView()
    {
        if (!g_fullDetail || !Drawing(g_mode)) return false;
        return g_j[0].have || g_j[1].have;
    }
    void NoteSetLod(void* ret, int level)
    {
        for (void*& c : g_lodSetCallers) {
            if (c == ret) return;
            if (!c) { c = ret; Log("Detail: a character's level set to %d from the game's code at %p", level, ret); return; }
        }
    }
    uintptr_t __fastcall HookSetLodA(void* self, void* edx, int level, uintptr_t x)
    {
        NoteSetLod(_ReturnAddress(), level);
        if (level > 0 && JoinersInView()) level = 0;
        return g_origSetLodA(self, edx, level, x);
    }
    uintptr_t __fastcall HookSetLodB(void* self, void* edx, int level, uintptr_t x)
    {
        NoteSetLod(_ReturnAddress(), level);
        if (level > 0 && JoinersInView()) level = 0;
        return g_origSetLodB(self, edx, level, x);
    }

    volatile bool g_capP1 = false;        // Player 1's pass: its Present keeps the picture
    volatile bool g_p1Kept = false;       // Player 1's picture is in g_p1Surf, to be put back before the overlays
    void FreeP1()
    {
        if (g_p1Surf) { g_p1Surf->Release(); g_p1Surf = nullptr; }
        if (g_p1Tex) { g_p1Tex->Release(); g_p1Tex = nullptr; }
    }

    void OnReset(IDirect3DDevice9*) { for (Joiner& j : g_j) j.FreeTex(); FreeP1(); }

    // ---- the joiners' own HUDs (p2hud.h) ----
    // The game's HUD belongs to Player 1, so it is left out of the joiners' frames ([Views] P2HideGameHud: the
    // renderer's "no GUI" flag gfx+0x154 while their frame is drawn). Each joiner gets their own: name, health,
    // stamina / mana, and the abilities on their X / Y / B buttons (the RT / LT page they hold), read here on
    // the main thread and drawn on their picture.
    bool g_hideGameHud = true;
    bool g_ownHud = true;
    struct AbName { int id; wchar_t name[48]; wchar_t icon[48]; };
    AbName g_names[48] = {};
    const AbName& AbilityInfo(int ab)
    {
        for (auto& n : g_names) if (n.id == ab) return n;
        static int next = 0;
        AbName& n = g_names[next++ % 48];
        n.id = ab; n.name[0] = 0; n.icon[0] = 0;
        int ref = script::GetM2DAInt(1, L"Namestrref", ab);            // ABI_base
        if (ref > 0) script::GetStringById(ref, n.name, 48);
        if (!n.name[0]) swprintf(n.name, 48, L"#%d", ab);
        script::GetM2DAString(1, L"icon", ab, n.icon, 48);              // e.g. tlt_ico_shield_bash
        static int logged = 0;
        if (logged++ < 12) Log("Views: ability %d \"%ls\" icon \"%ls\"", ab, n.name, n.icon);
        return n;
    }
    void ReadHud(Joiner& j)
    {
        uint32_t id;
        AcquireSRWLockShared(&g_lock); id = j.have ? j.id : 0xFFFFFFFF; ReleaseSRWLockShared(&g_lock);
        DWORD now = GetTickCount();
        if ((int)(now - j.hudNext) < 0) return;
        j.hudNext = now + 100;
        P2HudData d;
        std::memset(&d, 0, sizeof d);
        if (id == 0xFFFFFFFF || !g_ownHud) { P2HudSet(j.player, d); return; }
        d.valid = true;
        script::GetName(id, d.name, 64);
        auto frac = [&](int prop) {
            float cur = script::GetCreatureProperty(id, prop, 3), max = script::GetCreatureProperty(id, prop, 1);
            return max > 0.f ? (cur < 0.f ? 0.f : cur > max ? 1.f : cur / max) : -1.f;
        };
        d.hp = (int)(frac(7) * 100.f + 0.5f) / 100.f;                    // PROPERTY_DEPLETABLE_HEALTH (whole percents)
        d.mp = (int)(frac(8) * 100.f + 0.5f) / 100.f;                    // PROPERTY_DEPLETABLE_MANA_STAMINA
        int cls = (int)(script::GetCreatureProperty(id, 27, 2) + 0.5f);
        if (cls <= 0) cls = (int)(script::GetCreatureProperty(id, 27, 1) + 0.5f);
        d.mage = cls == 2;
        wchar_t bar[64];
        if (CoopBarInfo(id, bar, 64)) {                                  // "player|page|abX|abY|abB"
            int pl = 0;
            swscanf(bar, L"%d|%d|%d|%d|%d", &pl, &d.page, &d.ability[0], &d.ability[1], &d.ability[2]);
        }
        for (int i = 0; i < 3; ++i) {
            if (d.ability[i] <= 0) continue;
            const AbName& info = AbilityInfo(d.ability[i]);
            wcsncpy(d.abilityName[i], info.name, 47);
            wcsncpy(d.icon[i], info.icon, 47);
            float cd = script::GetRemainingCooldown(id, d.ability[i]);
            // 1.7.1: whole seconds (what the HUD shows): the panel is redrawn once a second, not ten times
            d.cooldown[i] = cd > 0.f ? (float)(int)(cd + 0.99f) : 0.f;
            d.active[i] = script::IsModalAbilityActive(id, d.ability[i]);
        }
        TargetUiPrompt(j.player, d.prompt, 96);              // 1.7.1: what their A uses now
        P2HudSet(j.player, d);
    }

    bool EnsureTex(IDirect3DDevice9* dev, Joiner& j, int w, int h)
    {
        if (j.tex && (j.texW != w || j.texH != h)) j.FreeTex();
        if (!j.tex && SUCCEEDED(dev->CreateTexture(w, h, 1, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &j.tex, nullptr))) {
            j.tex->GetSurfaceLevel(0, &j.surf);
            j.texW = w; j.texH = h;
            Log("Views: Player %d's picture %dx%d", j.player, w, h);
        }
        return j.surf != nullptr;
    }

    // Present of a joiner's frame: keep the picture, don't show it.
    bool EnsureP1(IDirect3DDevice9* dev, int W, int H, D3DFORMAT fmt)
    {
        if (g_p1Tex && (g_p1W != W || g_p1H != H)) FreeP1();
        if (!g_p1Tex) {
            if (FAILED(dev->CreateTexture(W, H, 1, D3DUSAGE_RENDERTARGET, fmt, D3DPOOL_DEFAULT, &g_p1Tex, nullptr)) || !g_p1Tex) { g_p1Tex = nullptr; return false; }
            g_p1Tex->GetSurfaceLevel(0, &g_p1Surf);
            g_p1W = W; g_p1H = H;
            Log("Views: Player 1's picture %dx%d", W, H);
        }
        return g_p1Surf != nullptr;
    }
    IDirect3DDevice9* g_dev = nullptr;    // (render thread) the device, for the frame's own Present
    bool Swallow(IDirect3DDevice9* dev)
    {
        g_dev = dev;
        if (g_capP1) {                                // Player 1's frame, drawn first: kept, shown after the joiners'
            IDirect3DSurface9* bb = nullptr;
            if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
                D3DSURFACE_DESC d; bb->GetDesc(&d);
                if (EnsureP1(dev, (int)d.Width, (int)d.Height, d.Format) && SUCCEEDED(dev->StretchRect(bb, nullptr, g_p1Surf, nullptr, D3DTEXF_NONE)))
                    g_p1Kept = true;
                bb->Release();
            }
            return true;
        }
        Joiner* j = g_cur;
        if (!j) return false;
        IDirect3DSurface9* bb = nullptr;
        if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
            D3DSURFACE_DESC d; bb->GetDesc(&d);
            EnsureTex(dev, *j, (int)d.Width, (int)d.Height);
            if (!j->gameGui) RingsDrawView(dev, j->player);   // 1.7.4: rings, name plates, target marks - with this player's own camera
            if (g_ownHud && !j->gameGui && !j->band) P2HudDraw(j->player, dev, (int)d.Width, (int)d.Height);   // (band: drawn in its box)
            if (!j->gameGui) MenuBannerDraw(dev, j->player);   // 1.7.8: "the game waits - Player 1 is in a menu" (not to whoever has it)
            if (j->surf && SUCCEEDED(dev->StretchRect(bb, nullptr, j->surf, nullptr, D3DTEXF_NONE))) j->ready = true;
            bb->Release();
        }
        return true;
    }
    // Before every overlay of the frame that is shown: Player 1's kept picture back on the back buffer.
    void PutP1Back(IDirect3DDevice9* dev)
    {
        if (!g_p1Kept) return;
        g_p1Kept = false;
        IDirect3DSurface9* bb = nullptr;
        if (g_p1Surf && SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
            dev->StretchRect(g_p1Surf, nullptr, bb, nullptr, D3DTEXF_NONE);
            bb->Release();
        }
    }

    // Split screen (mode 5, local only): every view whole (16:9, not cropped, so every HUD stays), in quarters -
    //   2 players: Player 1 above, Player 2 below, each a quarter of the screen, centred;
    //   3 players: Player 1 across the top (a wider view, the box is 32:9), Player 2 bottom left, Player 3 bottom right.
    // When nobody has their own view this frame (conversations, cutscenes, the creator ...) Player 1's
    // picture stays on the whole screen: everyone watches the same thing.
    void SplitScreen(IDirect3DDevice9* dev, IDirect3DSurface9* bb, const D3DSURFACE_DESC& d)
    {
        SubclassGameWindow();
        g_mouseFit = false;
        Joiner* in[2]; int k = 0;
        bool anyDrawn = false;
        for (Joiner& j : g_j) if (j.have && j.ready && j.surf) { in[k++] = &j; anyDrawn |= j.drawn; }
        if (!k || !anyDrawn) return;
        const int W = (int)d.Width, H = (int)d.Height;
        g_bbW = W; g_bbH = H;                         // (the mouse translation's back buffer size)
        if (!EnsureP1(dev, W, H, d.Format) || FAILED(dev->StretchRect(bb, nullptr, g_p1Surf, nullptr, D3DTEXF_NONE))) return;
        // Like the old console shooters' 3-player split: a wide box on top, two below, a thin dark line between.
        const int hw = W / 2, hh = H / 2, b = 1;     // half sizes, half the divider's width
        dev->ColorFill(bb, nullptr, D3DCOLOR_XRGB(0, 0, 0));
        auto put = [&](IDirect3DSurface9* src, int x, int y) {
            RECT r = { x + (x ? b : 0), y + (y ? b : 0), x + hw - (x + hw < W ? b : 0), y + hh - (y + hh < H ? b : 0) };
            dev->StretchRect(src, nullptr, bb, &r, D3DTEXF_LINEAR);
        };
        if (k == 1 && g_frameWide && in[0]->band) {   // two players: Player 1 across the top, Player 2 across the bottom
            g_mouseFit = true; g_rayFix = !g_topWide;
            RECT top = { 0, 0, W, hh - b };
            RECT band1 = { 0, H / 4, W, H / 4 + (hh - b) };
            dev->StretchRect(g_p1Surf, g_topWide ? nullptr : &band1, bb, &top, g_topWide ? D3DTEXF_LINEAR : D3DTEXF_NONE);
            RECT bottom = { 0, hh + b, W, H };
            RECT band2 = { 0, H / 4, W, H / 4 + (H - hh - b) };
            dev->StretchRect(in[0]->surf, &band2, bb, &bottom, D3DTEXF_NONE);
            if (g_ownHud && !in[0]->gameGui) {
                dev->SetRenderTarget(0, bb);
                P2HudDrawAt(in[0]->player, dev, 0, hh + b, W, H - hh - b);   // their HUD at half size, in their box
            }
        } else if (k == 1) {                          // two players (not in bands this frame): above and below, centred
            g_mouseFit = true; g_rayFix = false;      // (Player 1's whole picture at half size: GUI and world scaled alike)
            put(g_p1Surf, (W - hw) / 2, 0);
            put(in[0]->surf, (W - hw) / 2, hh);
        } else if (g_frameWide) {                     // three: Player 1 across the top (wide view), Player 2 and Player 3 below
            g_mouseFit = true; g_rayFix = !g_topWide;
            RECT top = { 0, 0, W, hh - b };
            RECT band = { 0, H / 4, W, H / 4 + (hh - b) };    // (SplitTopWide = 0: the middle band, shown 1:1)
            dev->StretchRect(g_p1Surf, g_topWide ? nullptr : &band, bb, &top, g_topWide ? D3DTEXF_LINEAR : D3DTEXF_NONE);
            put(in[0]->surf, 0, hh);
            put(in[1]->surf, hw, hh);
        } else {                                      // (not drawn wide this frame: Player 1 whole, centred on top)
            put(g_p1Surf, (W - hw) / 2, 0);
            put(in[0]->surf, 0, hh);
            put(in[1]->surf, hw, hh);
        }
    }

    // Player 1's frame: joiners not drawn this frame (conversations, cutscenes ...) get Player 1's picture; in
    // mode 1 the joiners' pictures go in the top right corner (Player 2 on top, Player 3 under it).
    void DrawPip(IDirect3DDevice9* dev)
    {
        const long mode = g_mode;
        if (!Drawing(mode) || !g_singleThread) return;
        IDirect3DSurface9* bb = nullptr;
        if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) || !bb) return;
        D3DSURFACE_DESC d; bb->GetDesc(&d);
        for (Joiner& j : g_j) {
            if (j.drawn || !j.have) continue;            // this joiner's picture = Player 1's (before the corner is drawn)
            if (EnsureTex(dev, j, (int)d.Width, (int)d.Height) && SUCCEEDED(dev->StretchRect(bb, nullptr, j.surf, nullptr, D3DTEXF_NONE))) j.ready = true;
        }
        if (mode == 5) SplitScreen(dev, bb, d);
        if (mode == 1) {
            const int w = (int)d.Width * g_pipPercent / 100, h = (int)d.Height * g_pipPercent / 100, m = 12;
            int y = m;
            for (Joiner& j : g_j) {
                if (!j.have || !j.ready || !j.surf) continue;
                RECT r = { (LONG)d.Width - w - m, y, (LONG)d.Width - m, y + h };
                RECT frame = { r.left - 3, r.top - 3, r.right + 3, r.bottom + 3 };
                dev->ColorFill(bb, &frame, j.player == 3 ? D3DCOLOR_XRGB(102, 221, 102) : D3DCOLOR_XRGB(77, 166, 255));
                dev->StretchRect(j.surf, nullptr, bb, &r, D3DTEXF_LINEAR);
                y += h + m;
            }
        }
        bb->Release();
    }


    // ---- the game's GUI movies in a joiner's menu frame (1.7.0) ----
    // The game draws its GUI as separate Scaleform movies (0x5287B0 walks them: the HUD's party portraits,
    // quickbar, minimap ... and the full-screen ones like the inventory). In a joiner's frame with their own
    // screen open, the HUD movies are left out, so they see only their screen. The movies are told apart
    // by the name the game keeps for them; [Views] P2MenuHide lists (parts of) names to leave out.
    std::vector<std::wstring> g_hideNames;
    struct MovieInfo { void* entry; wchar_t name[64]; };
    MovieInfo g_movies[48] = {};
    int g_nMovies = 0;

    bool Readable(const void* p, size_t n)
    {
        MEMORY_BASIC_INFORMATION mi;
        if (!p || !VirtualQuery(p, &mi, sizeof mi) || mi.State != MEM_COMMIT) return false;
        if (mi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
        return static_cast<const char*>(p) + n <= static_cast<const char*>(mi.BaseAddress) + mi.RegionSize;
    }
    // GFxMovieRoot (vtable 0xB4CA6C) slot 1: GetMovieDef; GFxMovieDefImpl (vtable 0xB48FEC) slot 11: GetFileURL.
    void MovieName(void** entry, wchar_t* out)
    {
        out[0] = 0;
        void* root = entry[0];
        if (!Readable(root, 8)) return;
        using Get_t = void*(__fastcall*)(void*, void*);
        void** vt = *static_cast<void***>(root);
        if (!Readable(vt, 8)) return;
        void* def = reinterpret_cast<Get_t>(vt[1])(root, nullptr);
        if (!Readable(def, 8)) return;
        void** dvt = *static_cast<void***>(def);
        if (!Readable(dvt, 48)) return;
        const char* url = static_cast<const char*>(reinterpret_cast<Get_t>(dvt[11])(def, nullptr));
        if (!Readable(url, 4)) return;
        const char* start = url;
        int n = 0;
        while (n < 200 && url[n]) { if (url[n] == '/' || url[n] == '\\' || url[n] == ':') start = url + n + 1; ++n; }
        int k = 0;
        for (const char* q = start; *q && k < 63; ++q) out[k++] = (wchar_t)*q;
        out[k] = 0;
    }
    const wchar_t* MovieKnown(void** entry)
    {
        for (int i = 0; i < g_nMovies; ++i) if (g_movies[i].entry == entry) return g_movies[i].name;
        if (g_nMovies >= 48) return L"";
        MovieInfo& m = g_movies[g_nMovies++];
        m.entry = entry;
#ifdef _MSC_VER
        __try { MovieName(entry, m.name); } __except (EXCEPTION_EXECUTE_HANDLER) { m.name[0] = 0; }
#else
        MovieName(entry, m.name);
#endif
        Log("Views: GUI movie %d at %p (vtable %p): \"%ls\"", g_nMovies - 1, entry[0], *static_cast<void**>(entry[0]), m.name);
        return m.name;
    }
    bool HideMovie(void** entry)
    {
        Joiner* j = g_cur;
        if (!j || !j->gameGui) return false;
        const wchar_t* nm = MovieKnown(entry);
        if (!nm[0]) return false;
        wchar_t low[64]; wcsncpy(low, nm, 63); low[63] = 0;
        for (wchar_t* q = low; *q; ++q) *q = (wchar_t)towlower(*q);
        for (auto& h : g_hideNames) if (wcsstr(low, h.c_str())) return true;
        return false;
    }
    // 0x528862: "mov ecx,[esi]; mov edx,[ecx]; mov eax,[edx+7Ch]; call eax" -> push esi; call DisplayMovie
    void __stdcall DisplayMovie(void** entry)
    {
        if (HideMovie(entry)) return;
        using Display_t = void(__fastcall*)(void*, void*);
        Display_t fn = reinterpret_cast<Display_t>((*static_cast<void***>(entry[0]))[0x7C / 4]);
        Joiner* cur = g_cur;
        const bool fit = (g_wideP1 && !cur) || (cur && cur->band);
        if (fit) g_fitGui = true;
        fn(entry[0], nullptr);
        if (fit) g_fitGui = false;
    }
    // 0x52885B: call 0x528090 (a movie drawn into its own texture first): thiscall(gfx, &entry[2])
    void __fastcall CompositeMovie(void* gfx, void*, void* arg)
    {
        void** entry = reinterpret_cast<void**>(arg) - 2;
        if (HideMovie(entry)) return;
        Joiner* cur = g_cur;
        const bool fit = (g_wideP1 && !cur) || (cur && cur->band);
        if (fit) g_fitGui = true;
        reinterpret_cast<void(__fastcall*)(void*, void*, void*)>(0x528090)(gfx, nullptr, arg);
        if (fit) g_fitGui = false;
    }
    void InstallMovieFilter()
    {
        static const uint8_t kOld[] = { 0x8B, 0x0E, 0x8B, 0x11, 0x8B, 0x42, 0x7C, 0xFF, 0xD0 };
        uint8_t now[9] = { 0x56, 0xE8, 0, 0, 0, 0, 0x90, 0x90, 0x90 };
        int32_t rel = (int32_t)(reinterpret_cast<uintptr_t>(&DisplayMovie) - (0x528863 + 5));
        std::memcpy(now + 2, &rel, 4);
        bool a = PatchBytes(0x528862, kOld, now, 9, "GUI movie draw (views)");
        uint8_t oldCall[5] = { 0xE8 }; int32_t r0 = (int32_t)(0x528090 - (0x52885B + 5)); std::memcpy(oldCall + 1, &r0, 4);
        uint8_t newCall[5] = { 0xE8 }; int32_t r1 = (int32_t)(reinterpret_cast<uintptr_t>(&CompositeMovie) - (0x52885B + 5)); std::memcpy(newCall + 1, &r1, 4);
        bool b = PatchBytes(0x52885B, oldCall, newCall, 5, "GUI movie composite (views)");
        Log("Views: GUI movie filter %s / %s (hidden in the joiners' screens: names with %zu listed parts)", a ? "on" : "FAILED", b ? "on" : "FAILED", g_hideNames.size());
    }

    // One joiner's frame: drawn and kept (Present swallowed). False if it failed.
    // 1.7.7: the renderer's "no GUI" flag (gfx+0x154) set for a pass and put back after it - only if we set it, and only
    // if it still holds what we set. Before, the value from before the pass was always written back: when the game
    // itself changed the flag during the pass (the HUD shown again after a conversation or a fight), that was undone
    // and Player 1's whole HUD and menus stayed hidden.
    struct GuiFlag
    {
        volatile char* f; char before; bool forced = false;
        explicit GuiFlag(void* gfx) : f(static_cast<volatile char*>(static_cast<char*>(gfx) + 0x154)), before(*f) {}
        void Hide() { if (*f != 1) { *f = 1; forced = true; } }
        void Restore() { if (forced && *f == 1) *f = before; forced = false; }
    };

    bool DrawJoiner(void* gfx, void* scene, int flag, Joiner& j, char* cam2, const Pose& pose)
    {
        const int test = g_joinerTest;
        g_inJoinerPass = true;
        SetPose(cam2, pose);
        ReadHud(j);
        GuiFlag gui(gfx);
        void** sceneCam = reinterpret_cast<void**>(static_cast<char*>(scene) + 0xC0);
        void* mainCam = *sceneCam;
        bool ok = true;
        *sceneCam = j.cam;
        volatile uint32_t& shadowBits = *reinterpret_cast<volatile uint32_t*>(0xC1E7E4);
        volatile uint8_t& fbEffects = *reinterpret_cast<volatile uint8_t*>(0xC1E8B5);
        const uint32_t keepShadows = shadowBits;
        const uint8_t keepEffects = fbEffects;
        if (!JoinShadows()) shadowBits = keepShadows & ~2u;
        if (!JoinEffects()) fbEffects = 0;
#ifdef _MSC_VER
        __try {
#endif
            g_ownCall = true;
            if (!(test & 2)) PrepareOwn(gfx, scene);    // the joiner: what's visible
            g_ownCall = false;
            g_cur = &j;
            if (g_hideGameHud && !j.gameGui) gui.Hide();   // no game HUD in their frame
            if (!(test & 1)) g_origEnd(gfx, nullptr, flag);   // drawn, kept (Present swallowed)
#ifdef _MSC_VER
        } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
#endif
        g_cur = nullptr;
        g_inJoinerPass = false;
        shadowBits = (shadowBits & ~2u) | (keepShadows & 2u);
        fbEffects = keepEffects;
        gui.Restore();
        *sceneCam = mainCam;
        return ok;
    }

    // ---- performance (1.7.0) ----
    // Every 5 s: frames per second and where a frame's time goes on the game's main thread - the game's own
    // work (logic, animation, its scene preparation), the joiners' frames, Player 1's frame, and the wait in
    // Present (vsync / the graphics card catching up). Logged with the views off too, for comparison.
    unsigned g_frameNo = 0;
    struct Perf { double frame = 0, joiners = 0, p1 = 0, present = 0, prep = 0; int frames = 0, joinerFrames = 0, prepCalls = 0; DWORD since = 0; LARGE_INTEGER last = {}; };
    Perf g_perf;
    double g_frameJoinMs = 0;         // this frame's joiner drawing
    double g_frameP1Ms = -1;          // this frame's Player 1 pass (-1: not measured apart, the whole end frame)
    // The game's scene preparation (IGraphicsInternal vtable +0x50, 0x52A470), timed
    using Prep_t = void(__fastcall*)(void* gfx, void* edx, int a);
    Prep_t g_origPrep = nullptr;
    char* g_wideCam = nullptr;        // Player 1's camera while its aspect is doubled (3-player split screen)
    float g_wideKeep = 0.f;
    bool WantWide(void* gfx);
    void WideOff()
    {
        if (!g_wideCam) return;
        *reinterpret_cast<float*>(g_wideCam + 0x144) = g_wideKeep;
        *(g_wideCam + 0x30) = 1;
        g_wideCam = nullptr;
    }
    void __fastcall HookPrep(void* gfx, void*, int a)
    {
        InterlockedIncrement(&g_animFrame);            // 1.7.1: a new frame for the animation bookkeeping
        LARGE_INTEGER t0, t1; QueryPerformanceCounter(&t0);
        WideOff();
        if (WantWide(gfx)) {                          // the game prepares (culls) Player 1's view with the wide box already
            void* scene = *reinterpret_cast<void**>(static_cast<char*>(gfx) + 0x58);
            char* cam = scene ? SceneRendererCamera(scene) : nullptr;
            float* aspect = cam ? reinterpret_cast<float*>(cam + 0x144) : nullptr;
            if (aspect && *aspect > 0.1f) {
                g_wideCam = cam; g_wideKeep = *aspect;
                if (g_topWide) {
                    *aspect = g_wideKeep * 2.f;
                    *(cam + 0x30) = 1;                // projection to be rebuilt (as the camera's own setter does)
                }
                int w = 0, h = 0;
                if (D3D9BackBufferSize(&w, &h)) { g_bbW = w; g_bbH = h; }
            }
        }
        g_origPrep(gfx, nullptr, a);
        QueryPerformanceCounter(&t1);
        g_perf.prep += Ms(t0, t1);
    }

    // [Views] FrameCap (default 30, 0 = off): the game's frames are held to this rate. Its movement and physics
    // advance a step per frame, so above its usual 30 everything moves too fast (triple buffering lifts vsync's cap).
    int g_frameCap = 30;
    LARGE_INTEGER g_capLast = {};
    void CapWait()
    {
        // 1.7.1: a friend's PC only shows the host's stream: held to 60 (twice the stream's 30, so every picture is
        // shown on time) - uncapped, its menu ran at hundreds of frames a second and took the processor from the
        // network and the decoder
        // 1.7.5: the screen paces the game (d3d9hook: each frame shown for exactly 2 refreshes at 60 Hz) - no timer.
        // On a friend's PC that is 30 a second too, in step with the host's 30: each of the host's pictures shown once.
        if (D3D9PacedInterval() > 0) { g_capLast.QuadPart = 0; return; }
        const bool watching = OnlinePlay::Watching();
        if (g_frameCap <= 0 && !watching) return;
        const LONGLONG period = g_freq.QuadPart / (watching ? 60 : g_frameCap);
        LARGE_INTEGER now; QueryPerformanceCounter(&now);
        if (g_capLast.QuadPart && now.QuadPart - g_capLast.QuadPart < period) {
            const LONGLONG until = g_capLast.QuadPart + period;
            for (;;) {
                QueryPerformanceCounter(&now);
                const LONGLONG left = until - now.QuadPart;
                if (left <= 0) break;
                if (left * 1000 > g_freq.QuadPart * 2) Sleep(1); else YieldProcessor();
            }
            g_capLast.QuadPart = until;                  // (steady pacing, not drifting)
            if (now.QuadPart - g_capLast.QuadPart > period) g_capLast = now;
        } else g_capLast = now;
    }

    // 1.7.1: [Views] JoinerAutoQuality (default 1): the joiners' views get lighter by themselves when a frame's work
    // no longer fits the frame cap (the frame rate then swung between 30 and the low 20s), and richer again when
    // there is room: 0 as set, 1 no shadows in their views, 4 no frame effects in them; still too slow (all 3 players
    // held to a steady 30): 5 no shadows in Player 1's view either, 6 nor its frame effects. (1.7.4: steps 2 and 3 no
    // longer shorten the joiners' draw distance or let go of full character detail - their world thinned out.)
    // Judged each second on the work of a frame (the cap's waiting left out).
    struct AutoWin { double work = 0; int frames = 0; DWORD since = 0; int over = 0, under = 0; } g_autoWin;
    bool JoinShadows() { return g_joinShadows && g_autoLevel < 1; }
    bool JoinEffects() { return g_joinEffects && g_autoLevel < 4; }
    // 1.7.4: the joiners always see as far as Player 1 ([Views] JoinerDrawDistance only): the automatic shorter
    // draw distance made their world thin out and pop in
    int JoinFarPct() { return g_farPct; }
    void AutoQualityFrame(double workMs, bool joinersDrawn)
    {
        if (!g_autoQuality || g_frameCap <= 0) { g_autoLevel = 0; return; }
        const DWORD now = GetTickCount();
        if (!g_autoWin.since) g_autoWin.since = now;
        if (joinersDrawn) { g_autoWin.work += workMs; ++g_autoWin.frames; }
        if (now - g_autoWin.since < 1000) return;
        const double budget = 1000.0 / g_frameCap;
        const double avg = g_autoWin.frames ? g_autoWin.work / g_autoWin.frames : 0.0;
        const int frames = g_autoWin.frames;
        g_autoWin.work = 0; g_autoWin.frames = 0; g_autoWin.since = now;
        if (frames < 5) { g_autoWin.over = g_autoWin.under = 0; return; }   // (no joiner views: as it was)
        g_autoWin.over = avg > budget * 0.98 ? g_autoWin.over + 1 : 0;
        g_autoWin.under = avg < budget * 0.72 ? g_autoWin.under + 1 : 0;
        if (g_autoWin.over >= 2 && g_autoLevel < 6) {
            ++g_autoLevel; g_autoWin.over = 0; g_autoWin.under = 0;
            Log("Views: frames take %.1f ms of work (cap %.1f) - the joiners' views lighter: level %d", avg, budget, g_autoLevel);
        } else if (g_autoWin.under >= 6 && g_autoLevel > 0) {
            --g_autoLevel; g_autoWin.under = 0;
            Log("Views: frames take %.1f ms of work (cap %.1f) - the joiners' views richer again: level %d", avg, budget, g_autoLevel);
        }
    }

    void EndFrameBody(void* gfx, int flag);
    void __fastcall HookEndFrame(void* gfx, void*, int flag)
    {
        LARGE_INTEGER tw0, tw1; QueryPerformanceCounter(&tw0);
        CapWait();
        QueryPerformanceCounter(&tw1);
        {
            static LARGE_INTEGER lastStart = {};
            static double lastWait = 0;
            static bool lastDrawn = false;
            // (1.7.5: with screen pacing the frame waits for its refresh in Present: that waiting isn't work either)
            const long long presentWait = D3D9TakePresentWait();
            const double presentMs = D3D9PacedInterval() > 0 ? presentWait * 1000.0 / (double)g_freq.QuadPart : 0.0;
            if (lastStart.QuadPart) AutoQualityFrame(Ms(lastStart, tw0) - lastWait - presentMs, lastDrawn);
            lastStart = tw0;
            lastWait = Ms(tw0, tw1);
            lastDrawn = false;
            for (const Joiner& j : g_j) if (j.have) lastDrawn = true;
        }
        LARGE_INTEGER t0, t1; QueryPerformanceCounter(&t0);
        if (g_perf.last.QuadPart) g_perf.frame += Ms(g_perf.last, t0);
        g_perf.last = t0;
        g_frameJoinMs = 0;
        g_frameP1Ms = -1;
        ++g_frameNo;
        { const uint16_t fn = FrameNumber(); g_frameNumberSteps += (uint16_t)(fn - g_lastFrameNumber); g_lastFrameNumber = fn; }
        EndFrameBody(gfx, flag);
        WideOff();
        QueryPerformanceCounter(&t1);
        g_perf.joiners += g_frameJoinMs;
        g_perf.p1 += g_frameP1Ms >= 0 ? g_frameP1Ms : Ms(t0, t1) - g_frameJoinMs;
        if (g_frameP1Ms >= 0) ++g_perf.joinerFrames;          // (new order: the Present was outside Player 1's pass)
        g_perf.prepCalls += g_gamePrepCalls; g_gamePrepCalls = 0;
        ++g_perf.frames;
        DWORD now = GetTickCount();
        if (!g_perf.since) g_perf.since = now;
        if (now - g_perf.since >= 5000 && g_perf.frames > 1) {
            long long pt = 0; int pc = 0;
            D3D9TakePresentStats(&pt, &pc);
            const double present = double(pt) * 1000.0 / double(g_freq.QuadPart);
            const double n = g_perf.frames, frame = g_perf.frame / (n - 1 > 0 ? n - 1 : 1);
            // the Present wait sits in the last joiner's pass on frames drawn in the new order, else in Player 1's
            // (in the new order the Present is outside both passes, so it only comes off Player 1's when the old order ran)
            const double p1In = g_perf.frames ? present * (g_perf.frames - g_perf.joinerFrames) / g_perf.frames : present;
            const double p1 = (g_perf.p1 - p1In) / n, join = g_perf.joiners / n, prep = g_perf.prep / n;
            Log("Performance: %.1f fps (%.1f ms a frame) = game logic %.1f + game scene preparation %.1f (x%.1f) + joiners %.1f + Player 1's drawing %.1f + Present wait %.1f ms [mode %ld%s]",
                1000.0 / frame, frame, frame - prep - join - p1 - present / n, prep, g_perf.prepCalls / n, join, p1, present / n,
                (long)g_mode, g_alternate ? ", joiners alternate" : "");
            Log("Performance: Player 2's pass %.1f ms (%d frames), Player 3's pass %.1f ms (%d frames)%s%s%s",
                g_j[0].frames ? g_j[0].ms / g_j[0].frames : 0.0, g_j[0].frames, g_j[1].frames ? g_j[1].ms / g_j[1].frames : 0.0, g_j[1].frames,
                g_farPct < 100 ? " (shorter draw distance)" : "", g_joinShadows ? "" : " (no shadows)", g_joinEffects ? "" : " (no frame effects)");
            Log("Detail: asked for (level 0/1/2) by Player 1's pass %ld/%ld/%ld, by the joiners' %ld/%ld/%ld; let go by Player 1's %ld/%ld/%ld, joiners' %ld/%ld/%ld",
                g_lodGet[0][0], g_lodGet[0][1], g_lodGet[0][2], g_lodGet[1][0], g_lodGet[1][1], g_lodGet[1][2],
                g_lodPut[0][0], g_lodPut[0][1], g_lodPut[0][2], g_lodPut[1][0], g_lodPut[1][1], g_lodPut[1][2]);
            std::memset(g_lodGet, 0, sizeof g_lodGet); std::memset(g_lodPut, 0, sizeof g_lodPut);
            Log("Performance: the renderer's frame number went up %.2f times a frame (1.00 = animation at normal speed)",
                g_perf.frames > 1 ? g_frameNumberSteps / double(g_perf.frames) : 0.0);
            g_frameNumberSteps = 0;
            if (g_animDedup) {
                const LONG mv = InterlockedExchange(&g_animMoved, 0), hd = InterlockedExchange(&g_animHeld, 0);
                Log("Performance: animations in the joiners' views - %ld moved on there (only they see them), %ld already moved on in Player 1's", mv, hd);
            }
            for (Joiner& j : g_j) { j.ms = 0.0; j.frames = 0; }
            const LARGE_INTEGER keep = g_perf.last;
            g_perf = Perf(); g_perf.since = now; g_perf.last = keep;
        }
    }

    // What the joiners get this frame.
    //   exploring / combat: their own view; a screen they opened (inventory, level-up ...): their own frame
    //   with the game's GUI (Player 1's frame then without it); conversations, cutscenes, loading, the
    //   character creator and the rest: Player 1's picture (one camera tells the story).
    struct Decision { bool own = false, screen = false; int guiOwner = 0; };
    Decision Decide(void* scene)
    {
        Decision d;
        const game::Mode gm = game::CurrentMode();
        d.guiOwner = EquipLockGuiOwner();
        d.screen = gm == game::MODE_GUI || gm == game::MODE_CHARGEN;   // (level-up is the creator's mode)
        // The character creator (Player 1's, or a co-op player's being made) is a room of its own, not the world:
        // everyone sees the creator then. Level-up (also the creator's mode) is a screen over the world.
        const bool creator = CoopCreateBusy() || (gm == game::MODE_CHARGEN && d.guiOwner < 2);
        d.own = !creator && scene && scene == g_scene && (gm == game::MODE_EXPLORE || gm == game::MODE_COMBAT || d.screen);
        static game::Mode loggedMode = game::MODE_NONE; static int loggedOwner = -1;
        if (gm != loggedMode || d.guiOwner != loggedOwner) {
            loggedMode = gm; loggedOwner = d.guiOwner;
            Log("Views: game mode %d, screen owner %d -> %s", (int)gm, d.guiOwner,
                !d.own ? "the joiners see Player 1's picture" : d.screen && d.guiOwner >= 2 ? "that joiner sees their screen, the other joiner their own view" : "each joiner sees their own view");
        }
        return d;
    }
    bool BothJoiners()
    {
        bool both;
        AcquireSRWLockShared(&g_lock); both = g_j[0].have && g_j[1].have; ReleaseSRWLockShared(&g_lock);
        return both;
    }
    bool AnyJoiner()
    {
        bool any;
        AcquireSRWLockShared(&g_lock); any = g_j[0].have || g_j[1].have; ReleaseSRWLockShared(&g_lock);
        return any;
    }
    bool WantWide(void* gfx)
    {
        if (g_mode != 5 || !g_singleThread || !AnyJoiner()) return false;
        return Decide(*reinterpret_cast<void**>(static_cast<char*>(gfx) + 0x58)).own;
    }

    // The frame (single-threaded renderer), 1.7.0 performance order:
    //   1. Player 1's frame with the game's own preparation (no second culling pass): drawn, kept in g_p1Surf.
    //   2. each joiner: their camera on the scene, prepared, drawn, kept; the last one's Present goes through,
    //      with Player 1's picture put back on the back buffer first (PutP1Back, before every overlay).
    void CharacterDetail()
    {
        char* app = reinterpret_cast<char*(*)()>(0x401F30)();
        if (!app) return;
        volatile char& opt = *(app + 0x258);
        bool want;
        if (g_detailManual >= 0) want = g_detailManual != 0;
        else {
            bool joiners;
            AcquireSRWLockShared(&g_lock); joiners = g_j[0].have || g_j[1].have; ReleaseSRWLockShared(&g_lock);
            want = joiners && Drawing(g_mode) && g_singleThread;
            // (1.7.4: kept on at every JoinerAutoQuality step - letting it go put low-detail models in the joiners' views)
        }
        if (want && g_detailKeep < 0) {
            g_detailKeep = opt ? 1 : 0;
            opt = 1;
            Log("Views: full character detail on (a joiner has their own view; the game's option was %d)", g_detailKeep);
        } else if (want && !opt) {
            opt = 1;                                   // (the game's options were applied again: back on)
        } else if (!want && g_detailKeep >= 0) {
            opt = (char)g_detailKeep;
            g_detailKeep = -1;
            Log("Views: full character detail off (the game's own setting back)");
        }
    }

    void EndFrameBody(void* gfx, int flag)
    {
        CharacterDetail();
        const long mode = g_mode;
        void* scene = *reinterpret_cast<void**>(static_cast<char*>(gfx) + 0x58);
        for (Joiner& j : g_j) { j.drawn = false; j.band = false; }
        g_frameWide = false;
        if (!Drawing(mode) || !g_singleThread) { g_origEnd(gfx, nullptr, flag); return; }
        const Decision dec = Decide(scene);
        char* cam = dec.own ? SceneRendererCamera(scene) : nullptr;
        if (!cam) { g_origEnd(gfx, nullptr, flag); return; }
        // Player 1's pose without the wide box (the joiners' cameras copy Player 1's projection: not the doubled aspect)
        const Pose p1 = CurrentPose(cam);
        { const float drawM = *reinterpret_cast<float*>(cam + 0x134); if (drawM > 5.f && drawM < 100000.f) g_p1Far = drawM; }   // 1.7.4: the tether

        struct Todo { Joiner* j; char* cam2; Pose pose; };
        Todo todo[2]; int n = 0;
        bool any = false, p1NoGui = false;
        int active = 0;
        for (Joiner& j : g_j) if (j.have) ++active;
        for (int ji = 0; ji < 2; ++ji) {
            Joiner& j = g_j[ji];
            // AlternateJoiners: with both joiners in play, one is drawn this frame and the other keeps last frame's picture
            if (g_alternate && active == 2 && j.ready && (int)(g_frameNo & 1) != ji && j.have) {
                j.drawn = true; any = true;
                if (dec.screen && dec.guiOwner == j.player) p1NoGui = true;
                continue;
            }
            Pose pose;
            char* cam2 = JoinerRendererCamera(j, cam);
            if (!cam2 || !JoinerPose(j, p1, pose)) continue;
            if (g_wideCam == cam) { *reinterpret_cast<float*>(cam2 + 0x144) = g_wideKeep; *(cam2 + 0x30) = 1; }
            { const int farPct = JoinFarPct(); if (farPct < 100) { *reinterpret_cast<float*>(cam2 + 0x134) *= farPct / 100.f; *(cam2 + 0x30) = 1; } }
            j.gameGui = dec.screen && dec.guiOwner == j.player;
            j.band = mode == 5 && active == 1;            // 2-player split screen: the bottom box, full width
            if (j.gameGui) p1NoGui = true;
            if (g_loggedSetup < 2) {
                ++g_loggedSetup;
                Log("Views: Player 1 eye %.1f %.1f %.1f, Player %d eye %.1f %.1f %.1f", p1.pos[0], p1.pos[1], p1.pos[2], j.player, pose.pos[0], pose.pos[1], pose.pos[2]);
            }
            todo[n++] = Todo{ &j, cam2, pose };
            any = true;
        }
        if (!n) {                                     // nothing to draw for the joiners: Player 1's frame as the game would
            GuiFlag gui(gfx);
            if (p1NoGui) gui.Hide();
            g_origEnd(gfx, nullptr, flag);
            gui.Restore();
            g_frameWide = g_wideCam == cam;
            return;
        }

        // 1. Player 1, kept (JoinerAutoQuality 5 and 6: lighter too)
        LARGE_INTEGER t0, t1;
        QueryPerformanceCounter(&t0);
        volatile uint32_t& p1Shadow = *reinterpret_cast<volatile uint32_t*>(0xC1E7E4);
        volatile uint8_t& p1Fx = *reinterpret_cast<volatile uint8_t*>(0xC1E8B5);
        const uint32_t p1ShadowKeep = p1Shadow;
        const uint8_t p1FxKeep = p1Fx;
        if (g_autoQuality && g_autoLevel >= 5) p1Shadow = p1ShadowKeep & ~2u;
        if (g_autoQuality && g_autoLevel >= 6) p1Fx = 0;
        GuiFlag gui(gfx);
        if (p1NoGui) gui.Hide();   // a joiner's screen is on their picture only
        g_wideP1 = g_wideCam == cam;                  // (Player 1's GUI fitted into the wide box)
        g_capP1 = true;
        g_p1Kept = false;
        g_origEnd(gfx, nullptr, flag);
        p1Shadow = (p1Shadow & ~2u) | (p1ShadowKeep & 2u);
        p1Fx = p1FxKeep;
        g_capP1 = false;
        g_wideP1 = false;
        gui.Restore();
        g_frameWide = g_wideCam == cam;
        WideOff();                                    // the scene's camera back to normal before the joiners' passes
        QueryPerformanceCounter(&t1);
        g_frameP1Ms = Ms(t0, t1);
        if (!g_p1Kept) {                              // (couldn't keep it: the old order, Player 1 drawn last again)
            for (int k = 0; k < n; ++k) DrawJoiner(gfx, scene, flag, *todo[k].j, todo[k].cam2, todo[k].pose), todo[k].j->drawn = true;
            g_ownCall = true; PrepareOwn(gfx, scene); g_ownCall = false;
            g_origEnd(gfx, nullptr, flag);
            return;
        }

        // 2. the joiners; the last one presents (Player 1's picture put back first)
        for (int k = 0; k < n; ++k) {
            Joiner& j = *todo[k].j;
            LARGE_INTEGER a, b;
            QueryPerformanceCounter(&a);
            const bool ok = DrawJoiner(gfx, scene, flag, j, todo[k].cam2, todo[k].pose);
            QueryPerformanceCounter(&b);
            if (!ok) {
                Log("Views: Player %d's frame failed - views turned off", j.player);
                InterlockedExchange(&g_mode, 0);
                break;
            }
            j.drawn = true;
            j.ms += Ms(a, b); ++j.frames;
            g_frameJoinMs += Ms(a, b);
        }
        // 3. the frame shown: Player 1's picture back (PutP1Back, before the overlays), with Player 1's camera on
        //    the scene again, through the device's Present (our hook: overlays, the online picture, then the real one)
        if (g_dev) {
            const HRESULT hr = g_dev->Present(nullptr, nullptr, nullptr, nullptr);
            static bool logged = false;
            if (!logged) { logged = true; Log("Views: frames shown in the new order (Player 1 first, kept; Present 0x%08lX)", (unsigned long)hr); }
        }
        (void)any;
    }
}

void ViewsInit(const wchar_t* iniPath)
{
    if (!GetPrivateProfileIntW(L"Views", L"Experiment", 0, iniPath)) return;
    QueryPerformanceFrequency(&g_freq);
    wcsncpy(g_ini, iniPath, MAX_PATH - 1);
    g_j[0].player = 2; g_j[0].pad = PLAYER_2;
    g_j[1].player = 3; g_j[1].pad = PLAYER_3;
    g_followCompanion = GetPrivateProfileIntW(L"Views", L"FollowCompanion", 0, iniPath) != 0;
    g_lift = (float)GetPrivateProfileIntW(L"Views", L"TestLiftMetres", 0, iniPath);
    g_pipPercent = (int)GetPrivateProfileIntW(L"Views", L"CornerPercent", 33, iniPath);
    g_collide = GetPrivateProfileIntW(L"Views", L"P2CameraCollision", 1, iniPath) != 0;
    g_hideGameHud = GetPrivateProfileIntW(L"Views", L"P2HideGameHud", 1, iniPath) != 0;
    g_ownHud = GetPrivateProfileIntW(L"Views", L"P2Hud", 1, iniPath) != 0;
    g_alternate = GetPrivateProfileIntW(L"Views", L"AlternateJoiners", 0, iniPath) != 0;
    g_topWide = GetPrivateProfileIntW(L"Views", L"SplitTopWide", 0, iniPath) != 0;
    {
        int d = (int)GetPrivateProfileIntW(L"Views", L"JoinerCamDistance", 50, iniPath);      // decimetres
        int t = (int)GetPrivateProfileIntW(L"Views", L"JoinerCamTilt", 24, iniPath);          // degrees down
        if (d < 15 || d > 200) d = 50;
        if (t < 3 || t > 70) t = 24;
        g_camDist = d / 10.f; g_camPitch = t / 57.2958f;
    }
    g_frameCap = (int)GetPrivateProfileIntW(L"Views", L"FrameCap", 30, iniPath);
    if (g_frameCap < 0 || g_frameCap > 240) g_frameCap = 30;
    if (g_frameCap > 0) timeBeginPeriod(1);           // (Sleep(1) really 1 ms for the cap's waiting)
    {   // Player 1's mouse in the 3-player split screen
        bool a = SwapSlot(FindImportSlot("user32.dll", "GetCursorPos"), reinterpret_cast<void*>(&HookGetCursorPos), reinterpret_cast<void**>(&g_realGetCursorPos));
        bool b = SwapSlot(FindImportSlot("user32.dll", "SetCursorPos"), reinterpret_cast<void*>(&HookSetCursorPos), reinterpret_cast<void**>(&g_realSetCursorPos));
        void** ray = reinterpret_cast<void**>(kPerspectiveCameraVt + 17 * 4);
        bool c = *ray == reinterpret_cast<void*>(0xA262D0) && SwapSlot(ray, reinterpret_cast<void*>(&HookScreenRay), reinterpret_cast<void**>(&g_origScreenRay));
        void** lodVt = reinterpret_cast<void**>(0xB03C04);
        bool l1 = lodVt[1] == reinterpret_cast<void*>(0x618BF0) && SwapSlot(&lodVt[1], reinterpret_cast<void*>(&HookLodGet), reinterpret_cast<void**>(&g_origLodGet));
        bool l2 = lodVt[2] == reinterpret_cast<void*>(0x6186E0) && SwapSlot(&lodVt[2], reinterpret_cast<void*>(&HookLodPut), reinterpret_cast<void**>(&g_origLodPut));
        Log("Views: level of detail counting %s / %s", l1 ? "on" : "FAILED", l2 ? "on" : "FAILED");
        {   // 1.7.1: each character's animation moved on once a frame, in whichever view gets to it first
            void** run = reinterpret_cast<void**>(0xB26784 + 8);
            void** stepFn = reinterpret_cast<void**>(kAnimManagerVt + 0x10);
            const bool want = GetPrivateProfileIntW(L"Views", L"JoinerAnimateOwn", 1, iniPath) != 0;
            bool a1 = false, a2 = false;
            if (want && *run == reinterpret_cast<void*>(0x8154D0) && *stepFn == reinterpret_cast<void*>(0x810340)) {
                a2 = SwapSlot(stepFn, reinterpret_cast<void*>(&HookAnimStep), reinterpret_cast<void**>(&g_origAnimStep));
                a1 = a2 && SwapSlot(run, reinterpret_cast<void*>(&HookAnimRun), reinterpret_cast<void**>(&g_origAnimRun));
            }
            g_animDedup = a1 && a2;
            Log("Views: animation of what only a joiner sees: %s ([Views] JoinerAnimateOwn=%d)",
                g_animDedup ? "moved on in their view (once a frame)" : want ? "FAILED - held still" : "off - held still", want ? 1 : 0);
        }
        // (1.7.0: off by default - forcing level 0 crashed the game right away: the level asked for has to be loaded)
        g_fullDetail = GetPrivateProfileIntW(L"Views", L"JoinerFullDetail", 0, iniPath) != 0;
        int hooked = 0;
        if (g_fullDetail) {
        const uintptr_t vts[5] = { 0xB5959C, 0xB5973C, 0xB597FC, 0xB598FC, 0xB599B4 };   // AnimBase, Wield, VFX, Parts, Head
        for (uintptr_t vt : vts) {
            void** slot = reinterpret_cast<void**>(vt + 0x44);
            if (*slot == reinterpret_cast<void*>(0xA5D5D0)) {
                void* orig;
                if (SwapSlot(slot, reinterpret_cast<void*>(&HookSetLodA), &orig)) { g_origSetLodA = reinterpret_cast<SetLod_t>(orig); ++hooked; }
            } else if (*slot == reinterpret_cast<void*>(0xA669C0)) {
                void* orig;
                if (SwapSlot(slot, reinterpret_cast<void*>(&HookSetLodB), &orig)) { g_origSetLodB = reinterpret_cast<SetLod_t>(orig); ++hooked; }
            }
        }
        }
        Log("Views: character detail for the joiners: %d of 5 model kinds hooked, full detail while they have a view %s", hooked, g_fullDetail ? "on" : "off ([Views] JoinerFullDetail=0)");
        Log("Views: Player 1's mouse in the split screen: cursor %s / %s, world clicks %s; frame cap %d", a ? "on" : "FAILED", b ? "on" : "FAILED", c ? "on" : "FAILED", g_frameCap);
    }
    g_farPct = (int)GetPrivateProfileIntW(L"Views", L"JoinerDrawDistance", 100, iniPath);
    if (g_farPct < 20 || g_farPct > 100) g_farPct = 100;
    {
        wchar_t list[512];
        GetPrivateProfileStringW(L"Views", L"P2MenuHide", L"portrait,quickbar,minimap,navbar,partybar,hud,notification,floaty,radial", list, 512, iniPath);
        std::wstring cur;
        for (const wchar_t* p = list; ; ++p) {
            if (*p == L',' || *p == L' ' || *p == 0) {
                if (!cur.empty()) { for (auto& ch : cur) ch = (wchar_t)towlower(ch); g_hideNames.push_back(cur); cur.clear(); }
                if (!*p) break;
            } else cur += *p;
        }
    }
    if (g_pipPercent < 10 || g_pipPercent > 45) g_pipPercent = 33;
    long start = GetPrivateProfileIntW(L"Views", L"StartMode", 0, iniPath);
    if (start >= 0 && start <= 5) g_mode = start;

    // The single-threaded renderer: 0x527900(bool threaded) is called once at startup (0x4017D0, by core count);
    // "mov cl, [esp+4]" -> "xor ecx, ecx; nop; nop" makes it always choose single-threaded.
    if (GetPrivateProfileIntW(L"Views", L"SingleThreadRenderer", 1, iniPath)) {
        static const uint8_t kOld[] = { 0x8A, 0x4C, 0x24, 0x04 };
        static const uint8_t kNew[] = { 0x31, 0xC9, 0x90, 0x90 };
        g_singleThread = PatchBytes(0x527900, kOld, kNew, sizeof kOld, "single-threaded renderer (views)");
        Log("Views: the game's renderer %s", g_singleThread ? "set to single-threaded (needed to draw the joiners' frames)" : "patch FAILED - the joiners' frames won't be drawn");
    }
    static const uint8_t kPrologue[] = { 0x53, 0x55, 0x56, 0x8B, 0x74, 0x24, 0x10, 0x57 };
    g_orig = reinterpret_cast<RenderScene_t>(
        HookInstall(kRenderScene, reinterpret_cast<void*>(&HookRenderScene), 8, kPrologue, "scene drawing (views)"));
    // end frame: IGraphicsInternal vtable (0xAF6D2C) +0x54
    void** slot = reinterpret_cast<void**>(0xAF6D2C + 0x54);
    if (*slot == reinterpret_cast<void*>(0x52A600)) {
        DWORD old;
        if (VirtualProtect(slot, 4, PAGE_READWRITE, &old)) {
            g_origEnd = reinterpret_cast<EndFrame_t>(*slot);
            *slot = reinterpret_cast<void*>(&HookEndFrame);
            VirtualProtect(slot, 4, old, &old);
        }
    }
    {   // the game's scene preparation: IGraphicsInternal vtable +0x50 (timed for the performance line)
        void** ps = reinterpret_cast<void**>(0xAF6D2C + 0x50);
        DWORD old;
        if (*ps == reinterpret_cast<void*>(0x52A470) && VirtualProtect(ps, 4, PAGE_READWRITE, &old)) {
            g_origPrep = reinterpret_cast<Prep_t>(*ps);
            *ps = reinterpret_cast<void*>(&HookPrep);
            VirtualProtect(ps, 4, old, &old);
        }
    }
    InstallMovieFilter();
    { HANDLE t = CreateThread(nullptr, 0, &IniThread, nullptr, 0, nullptr); if (t) CloseHandle(t); }   // LiveMode, even while minimized
    D3D9SetSwallow(&Swallow);
    D3D9SetRectFilter(&FitGui);
    D3D9SetPreOverlay(&PutP1Back);
    D3D9SetResetCallback2(&OnReset);
    D3D9AddOverlay(&DrawPip);
    Log("Views: %s (end frame hook %s) - [Views] LiveMode: 1 the joiners' views in the corner, 2 drawn only (cost), 3 online (each joiner's view to their own stream), 5 split screen, 4 diagnostic, 0 off",
        g_orig ? "ready" : "FAILED", g_origEnd ? "on" : "FAILED");
    g_statSince = GetTickCount();
}

void ViewsSetLead(const float lead[3])
{
    AcquireSRWLockExclusive(&g_lock);
    memcpy(g_lead, lead, sizeof g_lead);
    ReleaseSRWLockExclusive(&g_lock);
}

void ViewsSetPlayer(int player, const float pos[3], bool have, uint32_t id)
{
    if (player != 2 && player != 3) return;
    Joiner& j = g_j[player - 2];
    AcquireSRWLockExclusive(&g_lock);
    j.id = have ? id : 0xFFFFFFFF;
    if (have) memcpy(j.pos, pos, sizeof j.pos);
    j.have = have;
    ReleaseSRWLockExclusive(&g_lock);
}

bool ViewsActive() { return g_orig && (Drawing(g_mode) || g_mode == 4); }
bool ViewsFollowCompanion() { return g_followCompanion; }

bool ViewsJoinerHeading(int player, float* fx, float* fy)
{
    if ((player != 2 && player != 3) || !g_orig || !g_singleThread || !Drawing(g_mode) || !g_convOk) return false;
    const Joiner& j = g_j[player - 2];
    if (!j.headingSet) return false;
    *fx = std::cos(j.heading); *fy = std::sin(j.heading);
    return true;
}

bool ViewsJoinerYaw(int player, float* yaw)
{
    if ((player != 2 && player != 3) || !g_orig || !g_singleThread || !Drawing(g_mode)) return false;
    *yaw = g_j[player - 2].yaw;
    return true;
}
float ViewsP1DrawDistance() { return ViewsActive() ? g_p1Far : 0.f; }
bool ViewsOnline() { return g_orig && g_singleThread && (g_mode == 3 || g_mode == 5); }

IDirect3DSurface9* ViewsPicture(int player, int* w, int* h)
{
    if ((player != 2 && player != 3) || !g_orig || !g_singleThread || !Drawing(g_mode)) return nullptr;
    Joiner& j = g_j[player - 2];
    if (!j.have || !j.ready || !j.surf) return nullptr;
    if (w) *w = j.texW;
    if (h) *h = j.texH;
    return j.surf;
}
